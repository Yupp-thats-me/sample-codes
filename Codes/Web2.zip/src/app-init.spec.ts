import { AppInit } from './app-init';

describe('AppInit', () => {
  it('should create an instance', () => {
    expect(new AppInit()).toBeTruthy();
  });
});
