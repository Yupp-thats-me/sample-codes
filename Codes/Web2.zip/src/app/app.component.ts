import { Component, ElementRef, Inject, OnInit, Renderer2, ViewChild } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { HttpClient } from "@angular/common/http";
import { OAuthService, AuthConfig } from 'angular-oauth2-oidc';

import { AuthenticationService } from '@services/authentication.service';
import { NavigationStart, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { LocationStrategy } from '@angular/common';

export let browserRefresh = false;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  //providers: [
  //  { provide: TreeviewI18n, useClass: DropdownTreeviewI18n }
  //]
})



export class AppComponent implements OnInit {

  subscription: Subscription;

  constructor(
    public translate: TranslateService,
    private oauthService: OAuthService,
    private httpClient: HttpClient,
    private authenticationService: AuthenticationService,
    private renderer: Renderer2,
    private router: Router,
    private Location: LocationStrategy) {
   // this.configure();
   history.pushState(null, null, window.location.href);

this.Location.onPopState(() => {

history.pushState(null, null, window.location.href);

});
  }

  
  ngOnInit() {
   
   }


  ngAfterViewInit() {
    let loader = this.renderer.selectRootElement('#loader');
    this.renderer.setStyle(loader, 'display', 'none');
  }

  // private configure() {
  //   this.oauthService.configure(this.authConfig);
  //   this.oauthService.loadDiscoveryDocumentAndTryLogin();
  //   this.oauthService.loadUserProfile.name;
  //   this.oauthService.events
  //     .pipe(filter(e => e.type === 'token_received'))
  //     .subscribe(_ => this.oauthService.loadUserProfile());
  // }

  // //oauth
  // authConfig: AuthConfig = {
  //   issuer: 'http://localhost:8080/auth/realms/master',
  //   redirectUri: window.location.origin + "/admin",
  //   clientId: 'sjp',
  //   scope: 'openid profile email offline_access sjpscope',
  //   responseType: 'code',
  //   showDebugInformation: true
  // }
}
