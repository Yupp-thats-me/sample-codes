import { Component, Input, OnInit } from '@angular/core';
import { NavigationItemslanding } from '@layout/shared/navigation/navigation';

@Component({
  selector: 'app-nav-text',
  templateUrl: './nav-text.component.html',
  styleUrls: ['./nav-text.component.scss']
})
export class NavTextComponent implements OnInit {
  @Input() item: NavigationItemslanding;
  constructor() { }

  ngOnInit(): void {
  }

}
