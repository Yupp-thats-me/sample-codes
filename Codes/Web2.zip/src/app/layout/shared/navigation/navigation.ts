import { Injectable } from '@angular/core';
import { ResolveStart } from '@angular/router';
import { Role } from '@app/models/role.enum';

export interface NavigationItem {
  id: string;
  title: string;
  type: 'item' | 'collapse' | 'group';
  translate?: string;
  icon?: string;
  roles?: any;
  hidden?: boolean;
  url?: string;
  classes?: string;
  exactMatch?: boolean;
  external?: boolean;
  target?: boolean;
  breadcrumbs?: boolean;
  function?: any;
  badge?: {
    title?: string;
    type?: string;
  };
  children?: Navigation[];
}

export interface GeneralItems {
  id: string;
  title: string;
  text: string;
  type: 'item' | 'collapse' | 'group';
  translate?: string;
  icon?: string;
  roles?: string;
  hidden?: boolean;
  url?: string;
  classes?: string;
  exactMatch?: boolean;
  external?: boolean;
  target?: boolean;
  breadcrumbs?: boolean;
  function?: any;
  badge?: {
    title?: string;
    type?: string;
  };
  children?: GeneralNavigation[];
}

export interface NavigationItemslanding {
  id: string;
  title: string;
  text: string;
  type: 'item' | 'collapse' | 'group';
  translate?: string;
  icon?: string;
  roles?: string;
  hidden?: boolean;
  url?: string;
  classes?: string;
  exactMatch?: boolean;
  external?: boolean;
  target?: boolean;
  breadcrumbs?: boolean;
  function?: any;
  badge?: {
    title?: string;
    type?: string;
  };
  children?: NavigationLanding[];
}


export interface MobileNavigationItemslanding {
  id: string;
  title: string;
  text: string;
  type: 'item' | 'collapse' | 'group';
  translate?: string;
  roles?: string;
  icon?: string;
  hidden?: boolean;
  url?: string;
  classes?: string;
  exactMatch?: boolean;
  external?: boolean;
  target?: boolean;
  breadcrumbs?: boolean;
  function?: any;
  badge?: {
    title?: string;
    type?: string;
  };
  children?: MobileNavigationLanding[];
}

export interface AdminNavigationItems {
  id: string;
  title: string;
  type: 'item' | 'collapse' | 'group';
  translate?: string;
  icon?: string;
  hidden?: boolean;
  url?: string;
  roles?: string;
  classes?: string;
  exactMatch?: boolean;
  external?: boolean;
  target?: boolean;
  breadcrumbs?: boolean;
  function?: any;
  badge?: {
    title?: string;
    type?: string;
  };
  children?: AdminNavigation[];
}



export interface Navigation extends NavigationItem {
  children?: NavigationItem[];
}

export interface GeneralNavigation extends GeneralItems {
  children?: GeneralItems[];
}

export interface NavigationLanding extends NavigationItemslanding {
  children?: NavigationItemslanding[];
}

export interface MobileNavigationLanding extends MobileNavigationItemslanding {
  children?: MobileNavigationItemslanding[];
}

export interface AdminNavigation extends AdminNavigationItems {
  children?: AdminNavigationItems[];
}

const MobileNavigationItemslanding = [
  {
    id: 'navigation',
    title: 'Navigation',
    type: 'group',
    // icon: 'feather icon-align-left',
    children: [
      {
        id: 'home',
        menuName: 'Home',
        title: 'HOME',
        type: 'item',
        url: '/home-page',
        classes: 'nav-item',
      },
      {
        id: 'about',
        menuName: 'About us',
        title: 'ABOUT US',
        type: 'item',
        url: '/home-page/about-us',
        classes: 'nav-item',
      },
      {
        id: 'academics',
        menuName: 'Academics',
        title: 'Academics',
        type: 'collapse',
        children: [
          {
            id: 'scholar',
            menuName: 'Scholarship',
            title: 'Scholarship',
            type: 'item',
            url: '/scholarship/home',
            classes: 'nav-item',
          },
          {
            id: 'credits',
            menuName: 'Credit Transfer',
            title: 'Credit Transfer',
            type: 'collapse',
            children: [
              {
                id: 'profile',
                menuName: 'My Profile',
                title: 'My Profile',
                text: 'Discover yourself by taking up proven. It’s Easy and Simple.',
                type: 'item',
                icon: 'icon-intership-icon',
                url: '/profileview'
              },
              {
                id: 'profile',
                menuName: 'My Profile',
                title: 'My Profile',
                text: 'Discover yourself by taking up proven. It’s Easy and Simple.',
                type: 'item',
                icon: 'icon-intership-icon',
                url: '/profileview'
              },
            ]
          }

        ]
      },
      {
        id: 'career',
        menuName: 'Careers',
        title: 'Careers',
        type: 'collapse',
        children: [
          {
            id: 'intern',
            menuName: 'Internships',
            title: 'Internships',
            type: 'item',
            //url: '/carrers',
            url: '/home-page/under-construction',
            classes: 'nav-item',
          },
          {
            id: 'assesment',
            menuName: 'Assessment Tool/LMI',
            title: 'Assessment Tool/LMI',
            type: 'item',
            //url: '/assesment',
            url: '/home-page/under-construction'
          },
          {
            id: 'coun',
            menuName: 'Counselling',
            title: 'Counselling',
            type: 'item',
            url: '/counselling/home',
            // url: '/home-page/under-construction',
            classes: 'nav-item',
          }

        ]
      },

      // {
      //   id: 'crowd',
      //   menuName: 'Crowdfunding',
      //   title: 'CROWD FUNDING',
      //   type: 'item',
      //   //url: '/crowd',
      //   url: '/home-page/under-construction'
      // },
      {
        id: 'cxo',
        menuName: 'CXO',
        title: 'CXO',
        type: 'collapse',
        translate: 'ar',
        children: [
          {
            id: 'home',
            menuName: 'Home',
            title: 'Home',
            type: 'item',
            url: '/cxouser/home',
            classes: 'nav-item',
          },
          {
            id: 'publication',
            menuName: 'Publications',
            title: 'Publications',
            type: 'item',
            url: '/cxouser/publication-home',
            classes: 'nav-item',
          },
          {
            id: 'seminar',
            menuName: 'Seminars/Lectures',
            title: 'Seminars/Lectures',
            type: 'item',
            url: '/cxouser/training',
            classes: 'nav-item',
          }
        ]
      },
      {
        id: 'media',
        menuName: 'Media Centre',
        title: 'Media Centre',
        type: 'item',
        url: '/mediacenter',
        classes: 'nav-item',
      },
      {
        id: 'logincontact',
        menuName: 'Contact',
        title: 'Contact us',
        type: 'item',
        url: '/home-page/contact',
        classes: 'nav-item',
      }
    ]
  }
]
const NavigationItemslanding = [
  {
    id: 'navigationlanding',
    title: 'NavigationLanding',
    type: 'group',
    // icon: 'feather icon-align-left',
    children: [
      {
        id: 'home',
        menuName: 'Home',
        title: 'Home',
        type: 'item',
        url: '/home-page',
        classes: 'nav-item',
      },
      {
        id: 'about',
        menuName: 'About us',
        title: 'About us',
        type: 'item',
        url: '/home-page/about-us',
        classes: 'nav-item',
      },
      {
        id: 'academics',
        menuName: 'Academics',
        title: 'Academics',
        type: 'collapse',
        children: [
          {
            id: 'scholar',
            menuName: 'Scholarship',
            title: 'Scholarship',
            text: 'Students should be able to focus on their education rather than worrying about how to pay for it',
            type: 'item',
            url: '/scholarship/home',
            icon: 'icon-intership-icon',
            classes: 'nav-item',
          },
          {
            id: 'credits',
            menuName: 'Credit Transfer',
            title: 'Credit Transfer',
            text: 'Whether you are straight out of School, changing direction or going further, we can help you plan the route to your destination',
            type: 'item',
            icon: 'icon-credit-trasnsfer',
            url: '/credittransfer/home',
            classes: 'nav-item',
          }

        ]
      },
      {
        id: 'career',
        menuName: 'Careers',
        title: 'Careers',
        type: 'collapse',
        children: [
          {
            id: 'intern',
            menuName: 'Internships',
            title: 'Internships',
            text: 'Opportunities for motivated high performing students,ideally in their junior or senior year to access internships opportunities',
            type: 'item',
            url: '/internship/home',
            //url: '/home-page/under-construction',
            icon: 'icon-intership-icon',
          },
          {
            id: 'assesment',
            menuName: 'Assessment Tool/LMI',
            title: 'Assessment Tool/LMI',
            text: 'Discover yourself by taking up proven.It’s Easy and Simple',
            type: 'item',
            icon: 'icon-assesment-icon',
            url: '/assesment',
            //url: '/home-page/under-construction'
          },
          {
            id: 'coun',
            menuName: 'Counselling',
            title: 'Counselling',
            text: 'Discover and explore your strengths, weaknesses, learning patterns and interests by counselling with experts',
            type: 'item',
            icon: 'icon-counselling-icon',
            url: '/counselling/home',
            //url: '/home-page/under-construction',
            classes: 'nav-item',
          }

        ]
      },

      // {
      //   id: 'crowd',
      //   menuName: 'Crowdfunding',
      //   title: 'CROWD FUNDING',
      //   type: 'item',
      //   //url: '/crowd',
      //   url: '/home-page/under-construction'
      // },
      {
        id: 'cxo',
        menuName: 'CXO',
        title: 'CXO',
        type: 'collapse',
        translate: 'ar',
        children: [
          {
            id: 'Profiles',
            menuName: 'Profiles',
            text: 'Discover yourself by taking up proven.It’s Easy and Simple',
            title: 'Home',
            icon: 'icon-intership-icon',
            type: 'item',
            url: '/cxouser/profile-type',
            classes: 'nav-item',
          },
          {
            id: 'publication',
            menuName: 'Publications',
            title: 'Publications',
            type: 'item',
            icon: 'icon-intership-icon',
            text: 'To improve the Students curriculum by sharing of knowledge, experiences and best practices from the CXO',
            url: '/cxouser/summit',
            classes: 'nav-item',
          },
          {
            id: 'seminar',
            menuName: 'Seminars/Lectures',
            title: 'Seminars/Lectures',
            type: 'item',
            icon: 'icon-intership-icon',
            text: 'Learn all about team work, performance and leaderships skills at the experience and proven industry movers and shakers',
            url: '/cxouser/training',
            classes: 'nav-item',
          }
        ]
      },
      {
        id: 'media',
        menuName: 'Media Centre',
        title: 'Media Centre',
        type: 'item',
        url: '/mediacenter',
        classes: 'nav-item',
      },
      {
        id: 'logincontact',
        menuName: 'Contact',
        title: 'Contact us',
        type: 'item',
        url: '/home-page/contact',
        classes: 'nav-item',
      }
    ]
  }
]

const NavigationItems = [
  {
    id: 'navigation',
    menuName: 'Navigation',
    title: 'Navigation',
    type: 'group',
    icon: 'feather icon-align-left',
    children: [
      {
        id: 'academics',
        menuName: 'Academics',
        roles: Role.Student,
        title: 'Academics',
        type: 'collapse',
        children: [
          {
            id: 'profile',
            menuName: 'My Profile',
            title: 'My Profile',
            roles: Role.Student,
            text: 'Discover yourself by taking up proven. It’s Easy and Simple.',
            type: 'item',
            icon: 'icon-intership-icon',
            url: '/profileview'
          },
          {
            id: 'scholar',
            menuName: 'Scholarship',
            title: 'Scholarship',
            icon: 'icon-intership-icon',
            text: 'Students should be able to focus on their education rather than worrying about how to pay for it',
            type: 'item',
            url: '/scholarship/home',
            classes: 'nav-item',
          },
          {
            id: 'credits',
            menuName: 'Credit Transfer',
            title: 'Credit Transfer',
            text: 'Whether you are straight out of School, changing direction or going further, we can help you plan the route to your destination',
            type: 'item',
            icon: 'icon-credit-trasnsfer',
            url: '/credittransfer/home',
            classes: 'nav-item',
          },
        ]
      },
      {
        id: 'career',
        menuName: 'Careers',
        title: 'Careers',
        type: 'collapse',
        children: [
          {
            id: 'intern',
            menuName: 'Internships',
            title: 'Internships',
            text: 'Opportunities for motivated high performing students, ideally in their junior or senior year to access internships opportunities.',
            type: 'item',
            icon: 'icon-intership-icon',
            url: '/internship/home',
            //url: '/home-page/under-construction',
            classes: 'nav-item',
          },
          {
            id: 'assesment',
            menuName: 'Assessment Tool/LMI',
            title: 'Assessment Tool/LMI',
            icon: 'icon-assesment-icon',
            type: 'item',
            text: 'Discover yourself by taking up proven. It’s Easy and Simple.',
            url: '/assesment',
            //url: '/home-page/under-construction',
            classes: 'nav-item',

          },
          {
            id: 'counselling',
            menuName: 'Counselling',
            title: 'Counselling',
            text: 'Discover and explore your strengths, weaknesses, learning patterns and interests by counselling with experts',
            type: 'item',
            icon: 'icon-counselling-icon',
            url: '/counselling/home',
            //url: '/home-page/under-construction',
            classes: 'nav-item',
          }

        ]
      },
      {
        id: 'cxo',
        menuName: 'CXO',
        title: 'CXO',
        type: 'collapse',
        translate: 'ar',
        children: [
          {
            id: 'Profiles',
            menuName: 'Profiles',
            title: 'Home',
            text: 'Discover yourself by taking up proven. It’s Easy and Simple.',
            type: 'item',
            icon: 'icon-intership-icon',
            url: '/cxouser/profile-type',
            classes: 'nav-item',
          },
          {
            id: 'punblication',
            menuName: 'Publications',
            title: 'Publications',
            icon: 'icon-intership-icon',
            text: 'Learn all about team work, performance and leaderships skills at the experience and proven industry movers and shakers',
            type: 'item',
            url: '/cxouser/summit',
            classes: 'nav-item',
          },
          {
            id: 'seminar',
            menuName: 'Seminars/Lectures',
            icon: 'icon-intership-icon',
            title: 'Seminars/Lectures',
            text: 'Learn all about team work, performance and leaderships skills at the experience and proven industry movers and shakers',
            type: 'item',
            url: '/cxouser/training',
            classes: 'nav-item',
          }
        ]
      },
      // {
      //   id: 'crowd',
      //   menuName: 'Crowdfunding',
      //   title: 'CROWD FUNDING',
      //   type: 'item',
      //   //url: '/cro',
      //   url: '/home-page/under-construction',
      //   classes: 'nav-item',
      // },
      {
        id: 'media',
        menuName: 'Media Centre',
        title: 'Media Centre',
        type: 'item',
        url: '/mediacenter',
        classes: 'nav-item',
      },
    ]
  }
];

const GeneralItems = [
  {
    id: 'navigation',
    menuName: 'Navigation',
    title: 'Navigation',
    type: 'group',
    icon: 'feather icon-align-left',
    children: [
      {
        id: 'academics',
        menuName: 'Academics',
        title: 'ACADEMICS',
        type: 'collapse',
        children: [
          {
            id: 'scholar',
            menuName: 'Scholarship',
            title: 'Scholarship',
            icon: 'icon-intership-icon',
            text: 'Students should be able to focus on their education rather than worrying about how to pay for it',
            type: 'item',
            url: '/scholarship/home',
            classes: 'nav-item',
          },

        ]
      },
      {
        id: 'cxo',
        menuName: 'CXO',
        title: 'CXO',
        type: 'collapse',
        translate: 'ar',
        children: [
          {
            id: 'Profiles',
            menuName: 'Profiles',
            title: 'Home',
            text: 'Discover yourself by taking up proven. It’s Easy and Simple.',
            type: 'item',
            icon: 'icon-intership-icon',
            url: '/cxouser/profile-type',
            classes: 'nav-item',
          },
          {
            id: 'punblication',
            menuName: 'Publications',
            title: 'Publications',
            icon: 'icon-intership-icon',
            text: 'Learn all about team work, performance and leaderships skills at the experience and proven industry movers and shakers',
            type: 'item',
            url: '/cxouser/summit',
            classes: 'nav-item',
          },
          {
            id: 'seminar',
            menuName: 'Seminars/Lectures',
            icon: 'icon-intership-icon',
            title: 'Seminars/Lectures',
            text: 'Learn all about team work, performance and leaderships skills at the experience and proven industry movers and shakers',
            type: 'item',
            url: '/cxouser/training',
            classes: 'nav-item',
          }
        ]
      },
      // {
      //   id: 'crowd',
      //   menuName: 'Crowdfunding',
      //   title: 'CROWD FUNDING',
      //   type: 'item',
      //   //url: '/cro',
      //   url: '/home-page/under-construction',
      //   classes: 'nav-item',
      // },
      {
        id: 'media',
        menuName: 'Media Centre',
        title: 'MEDIA CENTER',
        type: 'item',
        url: '/mediacenter',
        classes: 'nav-item',
      },
    ]
  }
];

const AdminNavigationItems = [
  {
    id: 'navigationAdmin',
    menuName: 'NavigationAdmin',
    title: 'NavigationAdmin',
    type: 'group',
    children: [
      {
        id: 'academics',
        menuName: 'ACADEMICS',
        title: 'ACADEMICS',
        type: 'collapse',
        icon: 'icon-assesment-icon',
        roles: Role.ContentApprover,
        children: [
          {
            id: 'credit',
            menuName: 'CREDIT TRANSFER',
            title: 'CREDIT TRANSFER',
            type: 'collapse',
            roles: Role.ContentApprover,
            children: [
              {
                id: 'credit list',
                menuName: 'Add Credit transfer',
                title: 'Add Credit transfer',
                type: 'item',
                url: '/credittransfer/credit',
                classes: 'nav-item',
                roles: Role.ContentCreator,
              },
              {
                id: 'capproval',
                menuName: 'Approval',
                title: 'Approval',
                type: 'item',
                url: '/credittransfer/approval',
                classes: 'nav-item',
                roles: Role.ContentApprover,
              }
            ]
          },
          {
            id: 'sch',
            menuName: 'SCHOLARSHIPS',
            title: 'SCHOLARSHIPS',
            type: 'collapse',
            roles: Role.ContentApprover,
            children: [
              {
                id: 'list',
                menuName: 'Post Scholarship',
                title: 'Post Scholarship',
                type: 'item',
                url: '/admin/scholarship/scholarshipdetail',
                classes: 'nav-item',
                roles: Role.ContentCreator,
              },
              {
                id: 'approva',
                menuName: 'Approval',
                title: 'Approval',
                type: 'item',
                url: 'admin/scholarship/approval',
                classes: 'nav-item',
                roles: Role.ContentApprover,
              },

            ]
          },
        ]
      },
      {
        id: 'cxo',
        menuName: 'CXO',
        title: 'CXO',
        type: 'collapse',
        icon: 'icon-intership-icon',
        roles: Role.CXO,
        children: [
          {
            id: 'profile',
            menuName: 'Profile',
            title: 'Profile',
            type: 'item',
            url: '/cxo/my-profile',
            classes: 'nav-item',
            roles: Role.CXO,
          },
          {
            id: 'event',
            menuName: 'Events',
            title: 'Events',
            type: 'item',
            url: '/cxo/events',
            classes: 'nav-item',
            roles: Role.CXO,
          },
          {
            id: 'publication',
            menuName: 'Publications',
            title: 'Publications',
            type: 'item',
            url: '/cxo/publication',
            classes: 'nav-item',
            roles: Role.CXO,
          },
          {
            id: 'seminar',
            menuName: 'Seminars/Lectures',
            title: 'Seminars/Lectures',
            type: 'item',
            url: '/cxo/seminar',
            classes: 'nav-item',
            roles: Role.CXO,
          },
          {
            id: 'Approval',
            menuName: 'Approval',
            title: 'Approval',
            type: 'collapse',
            roles: Role.ContentApprover,
            children: [
              {
                id: 'aprofile',
                menuName: 'Profiles',
                title: 'Profiles',
                type: 'item',
                roles: Role.ContentApprover,
                url: 'cxo/approval-profile',
              },
              {
                id: 'profile',
                menuName: 'Events',
                title: 'Events',
                type: 'item',
                roles: Role.ContentApprover,
                url: 'cxo/approval-event',
              },
              {
                id: 'apublication',
                menuName: 'Publications',
                title: 'Publications',
                type: 'item',
                roles: Role.ContentApprover,
                url: 'cxo/approval-publication',
              },
              {
                id: 'aseminar',
                menuName: 'Seminars',
                title: 'Seminars',
                type: 'item',
                roles: Role.ContentApprover,
                url: 'cxo/approval-seminar',
              },
            ]
          }
        ]
      },
      {
        id: 'intern',
        menuName: 'INTERNSHIPS',
        title: 'Internships',
        icon: 'icon-intership-icon',
        type: 'collapse',
        roles: Role.ContentApprover,
        children: [
          {
            id: 'list',
            menuName: 'Post Internship',
            title: 'Post Internship',
            type: 'item',
            url: '/admin/internship/post-internship',
            //url: '/home-page/under-construction',
            classes: 'nav-item',
            roles: Role.ContentCreator,
          },
          {
            id: 'approval',
            menuName: 'Approval',
            title: 'Approval',
            type: 'item',
            url: 'admin/internship/approval',
            //url: '/home-page/under-construction',
            classes: 'nav-item',
            roles: Role.ContentApprover,
          },
          {
            id: 'disagreeapplication',
            menuName: 'Disagree Application',
            title: 'Disagree Application',
            type: 'item',
            url: '/admin/internship/disagree-application',
            //url: '/home-page/under-construction',
            classes: 'nav-item',
            roles: Role.InternshipCounsellor,
          },
          {
            id: 'recruit',
            menuName: 'Recruitment',
            title: 'Recruitment',
            type: 'collapse',
            roles: Role.ContentCreator,
            children: [
              {
                id: 'flow',
                menuName: 'Review Phase',
                title: 'flow',
                type: 'item',
                url: '/admin/internship/recruitment',
                //url: '/home-page/under-construction',
                classes: 'nav-item',
                roles: Role.ContentCreator,
              },
              {
                id: 'selected applicants',
                menuName: 'Search/Update list of selected applicants',
                title: 'Search/Update list of selected applicants',
                type: 'item',
                url: '/admin/internship/update-list',
                //url: '/home-page/under-construction',
                classes: 'nav-item',
                roles: Role.ContentCreator,
              },
              {
                id: 'list',
                menuName: 'Confirm Accepted Candidates Start date',
                title: 'Confirm Accepted Candidates Start date',
                type: 'item',
                url: '/admin/internship/accepted-candidates',
                //url: '/home-page/under-construction',
                classes: 'nav-item',
                roles: Role.ContentCreator,
              },
              {
                id: 'feedback',
                menuName: 'Provide Feedback',
                title: 'Provide Feedback',
                type: 'item',
                url: '/admin/internship/provide-feedback',
                //url: '/home-page/under-construction',
                classes: 'nav-item',
                roles: Role.ContentCreator,
              },
            ],
          },
          {
            id: 'expiry',
            menuName: 'Expiry Notification',
            title: 'Expiry Notification',
            type: 'item',
            url: 'admin/internship/expiry',
            //url: '/home-page/under-construction',
            classes: 'nav-item',
            roles: Role.ContentCreator,
          },
          {
            id: 'disagree',
            menuName: 'Internship Application Notification',
            title: 'Internship Application Notification',
            type: 'item',
            url: '/admin/internship/disagree-application',
            //url: '/home-page/under-construction',
            classes: 'nav-item',
            roles: Role.InternshipCounsellor,
          },
          {
            id: 'disagreed',
            menuName: 'Disagreed Notification',
            title: 'Disagreed Notification',
            type: 'item',
            url: '/admin/internship/disagreed-list',
            //url: '/home-page/under-construction',
            classes: 'nav-item',
            roles: Role.SuperAdmin,
          },
         
          {
            id: 'feedback received',
            menuName: 'Feedback Received',
            title: 'Feedback Received',
            type: 'item',
            url: '/admin/internship/feedback-received',
            //url: '/home-page/under-construction',
            classes: 'nav-item',
            roles: Role.ContentCreator,
          },
          {
            id: 'counselor',
            menuName: 'Counsellor Student Feedback',
            title: 'Counsellor Student Feedback',
            type: 'item',
            url: '/admin/internship/counselor-studentfeedback',
            //url: '/home-page/under-construction',
            classes: 'nav-item',
            roles: Role.InternshipCounsellor,
          },
          {
            id: 'employee',
            menuName: 'Counsellor Employer Feedback',
            title: 'Counsellor Employer Feedback',
            type: 'item',
            url: 'admin/internship/counselor-adminfeedback',
            //url: '/home-page/under-construction',
            classes: 'nav-item',
            roles: Role.InternshipCounsellor,
          },
          {
            id: 'moe',
            menuName: 'MOE Admin Feedback',
            title: 'MOE Admin Feedback',
            type: 'item',
            url: 'admin/internship/moe-adminfeedback',
            //url: '/home-page/under-construction',
            classes: 'nav-item',
            roles: Role.SuperAdmin,
          },
        ]
      },
      {
        id: 'media',
        menuName: 'MEDIA CENTER',
        title: 'MEDIA CENTER',
        icon: 'icon-counselling-icon',
        type: 'collapse',
        roles: Role.ContentApprover,
        children: [
          {
            id: 'volun',
            menuName: 'Post Media',
            title: 'Post Media',
            type: 'collapse',
            roles: Role.ContentApprover,
            children: [
              {
                id: 'ann',
                menuName: 'Announcements',
                title: 'Announcements',
                type: 'item',
                url: 'admin/mediacenter/announcements',
                roles: Role.ContentCreator,
              },
              {
                id: 'event',
                menuName: 'Events',
                title: 'Events',
                type: 'item',
                url: 'admin/mediacenter/events',
                roles: Role.ContentCreator,
              },
              {
                id: 'news',
                menuName: 'News',
                title: 'News',
                type: 'item',
                url: 'admin/mediacenter/news',
                roles: Role.ContentCreator,
              }
            ]
          },
          {
            id: 'volun',
            menuName: 'Approval',
            title: 'Approval',
            type: 'collapse',
            roles: Role.ContentCreator,
            children: [
              {
                id: 'ann',
                menuName: 'Announcements',
                title: 'Announcements',
                type: 'item',
                url: 'admin/mediacenter/approval/announcements',
                roles: Role.ContentApprover,
              },
              {
                id: 'event',
                menuName: 'Events',
                title: 'Events',
                type: 'item',
                url: 'admin/mediacenter/approval/events',
                roles: Role.ContentApprover,
              },

              {
                id: 'news',
                menuName: 'News',
                title: 'News',
                type: 'item',
                url: 'admin/mediacenter/approval/news',
                roles: Role.ContentApprover,
              },
            ]
          },
        ]
      },
      {
        id: 'user',
        menuName: 'USER MANAGEMENT',
        title: 'User Management',
        icon: 'icon-counselling-icon',
        roles: Role.SuperAdmin,
        type: 'collapse',
        children: [
          {
            id: 'ann',
            menuName: 'User Approval',
            title: 'User Approval',
            roles: Role.SuperAdmin,
            type: 'item',
            url: 'admin/manage-users/approval',
          },
          {
            id: 'manage',
            menuName: 'Manage Users',
            title: 'Manage Users',
            roles: Role.SuperAdmin,
            type: 'item',
            url: 'admin/manage-users/users',
          },
          {
            id: 'import',
            menuName: 'Import Counsellors',
            title: 'Import Counsellors',
            roles: Role.SuperAdmin,
            type: 'item',
            url: 'admin/manage-users/import-users',
          }
        ]
      },
      {
        id: 'reports',
        menuName: 'Reports',
        title: 'Reports',
        icon: 'icon-counselling-icon',
        roles: Role.SuperAdmin,
        type: 'collapse',
        children: [
          {
            id: 'dashboard',
            menuName: 'Dashboard',
            title: 'Dashboard',
            roles: Role.SuperAdmin,
            type: 'item',
            url: 'admin/reports/dashboard',
          },
          {
            id: 'studprofilereports',
            menuName: 'Student profile',
            title: 'Student profile',
            roles: Role.SuperAdmin,
            type: 'collapse',
            children: [
              {
                id: 'studprofilereport1',
                menuName: 'Report 1',
                title: 'Report 1',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/student-profile/report1',
              }
            ]
          },
          {
            id: 'mediacenterreports',
            menuName: 'Media center',
            title: 'Media center',
            roles: Role.SuperAdmin,
            type: 'collapse',
            children: [
              {
                id: 'mediacenterreport1',
                menuName: 'Report 1',
                title: 'Report 1',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/media-center/report1',
              },
              {
                id: 'mediacenterreport2',
                menuName: 'Report 2',
                title: 'Report 2',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/media-center/report2',
              },
              {
                id: 'mediacenterreport3',
                menuName: 'Report 3',
                title: 'Report 3',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/media-center/report3',
              },
              {
                id: 'mediacenterreport4',
                menuName: 'Report 4',
                title: 'Report 4',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/media-center/report4',
              },
              {
                id: 'mediacenterreport5',
                menuName: 'Report 5',
                title: 'Report 5',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/media-center/report5',
              },
              {
                id: 'mediacenterreport6',
                menuName: 'Report 6',
                title: 'Report 6',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/media-center/report6',
              }
            ]
          },
          {
            id: 'scholarship',
            menuName: 'Scholarship',
            title: 'Scholarship',
            roles: Role.SuperAdmin,
            type: 'collapse',
            children: [
              {
                id: 'scholarshipreport1',
                menuName: 'Report 1',
                title: 'Report 1',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/scholarship/report1',
              },
              {
                id: 'scholarshipreport2',
                menuName: 'Report 2',
                title: 'Report 2',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/scholarship/report2',
              },
              {
                id: 'scholarshipreport3',
                menuName: 'Report 3',
                title: 'Report 3',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/scholarship/report3',
              }
            ]
          },
          {
            id: 'credit-transfer',
            menuName: 'Credit Transfer',
            title: 'Credit Transfer',
            roles: Role.SuperAdmin,
            type: 'collapse',
            children: [
              {
                id: 'credittransferreport1',
                menuName: 'Report 1',
                title: 'Report 1',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/credit-transfer/report1',
              },
              {
                id: 'credittransferreport2',
                menuName: 'Report 2',
                title: 'Report 2',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/credit-transfer/report2',
              },
              {
                id: 'credittransferreport3',
                menuName: 'Report 3',
                title: 'Report 3',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/credit-transfer/report3',
              }
            ]
          },
          {
            id: 'cxo',
            menuName: 'CXO',
            title: 'CXO',
            roles: Role.SuperAdmin,
            type: 'collapse',
            children: [
              {
                id: 'cxoreport1',
                menuName: 'Report 1',
                title: 'Report 1',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/cxo/report1',
              },
              {
                id: 'cxoreport2',
                menuName: 'Report 2',
                title: 'Report 2',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/cxo/report2',
              },
              {
                id: 'cxoreport3',
                menuName: 'Report 3',
                title: 'Report 3',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/cxo/report3',
              },
              {
                id: 'cxoreport4',
                menuName: 'Report 4',
                title: 'Report 4',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/cxo/report4',
              },
              {
                id: 'cxoreport4',
                menuName: 'Report 5',
                title: 'Report 5',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/cxo/report5',
              }
            ]
          },
          {
            id: 'internship',
            menuName: 'Internship',
            title: 'Internship',
            roles: Role.SuperAdmin,
            type: 'collapse',
            children: [
              {
                id: 'internshipreport1',
                menuName: 'Report 1',
                title: 'Report 1',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/internship/report1',
              },
              {
                id: 'internshipreport2',
                menuName: 'Report 2',
                title: 'Report 2',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/internship/report2',
              },
              {
                id: 'internshipreport3',
                menuName: 'Report 3',
                title: 'Report 3',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/internship/report3',
              },
              {
                id: 'internshipreport4',
                menuName: 'Report 4',
                title: 'Report 4',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/internship/report4',
              },
              {
                id: 'internshipreport5',
                menuName: 'Report 5',
                title: 'Report 5',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/internship/report5',
              },
              {
                id: 'internshipreport6',
                menuName: 'Report 6',
                title: 'Report 6',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/internship/report6',
              },
              {
                id: 'internshipreport7',
                menuName: 'Report 7',
                title: 'Report 7',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/internship/report7',
              }
            ]
          },
          {
            id: 'counselling',
            menuName: 'Counselling',
            title: 'Counselling',
            roles: Role.SuperAdmin,
            type: 'collapse',
            children: [
              {
                id: 'counsellingreport1',
                menuName: 'Report 1',
                title: 'Report 1',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/counselling/report1',
              },
              {
                id: 'counsellingreport2',
                menuName: 'Report 2',
                title: 'Report 2',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/counselling/report2',
              },
              {
                id: 'counsellingreport3',
                menuName: 'Report 3',
                title: 'Report 3',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/counselling/report3',
              },
              {
                id: 'counsellingreport4',
                menuName: 'Report 4',
                title: 'Report 4',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/counselling/report4',
              },
              {
                id: 'counsellingreport5',
                menuName: 'Report 5',
                title: 'Report 5',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/counselling/report5',
              },
              {
                id: 'counsellingreport6',
                menuName: 'Report 6',
                title: 'Report 6',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/counselling/report6',
              },
              {
                id: 'counsellingreport7',
                menuName: 'Report 7',
                title: 'Report 7',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/counselling/report7',
              },
              {
                id: 'counsellingreport8',
                menuName: 'Report 8',
                title: 'Report 8',
                roles: Role.SuperAdmin,
                type: 'item',
                url: 'admin/reports/counselling/report8',
              }
            ]
          },
        ]
      },
      {
        id: 'counselling',
        menuName: 'COUNSELLING',
        title: 'COUNSELLING',
        icon: 'icon-counselling-icon',
        roles: Role.ContentApprover,
        type: 'collapse',
        children: [
          {
            id: 'post-faq',
            menuName: 'POST FAQ',
            title: 'POST FAQ',
            roles: Role.ContentCreator,
            type: 'item',
            url: 'admin/counselling/faq-post',
          },
          {
            id: 'approve-faq',
            menuName: 'APPROVE FAQ',
            title: 'APPROVE FAQ',
            roles: Role.ContentApprover,
            type: 'item',
            url: 'admin/counselling/faq-approval',
          },
        ]
      },
    ]
  }
];


@Injectable()
export class NavigationItem {
  public get() {
    return NavigationItems;
  }
  public getland() {
    return NavigationItemslanding;
  }
  public getAdmin() {
    return AdminNavigationItems;
  }
  public getMobileLand() {
    return MobileNavigationItemslanding;
  }
  public getGeneral() {
    return GeneralItems;
  }
}
