import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { LayoutService } from '@services/layout.service';


@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit,OnDestroy {

  private _destroyed$ = new Subject();
  isImage:boolean =true;

  constructor(private layoutService: LayoutService) { }

  ngOnInit(): void {
    this.layoutService.languageimgchangeObserver.subscribe(navbarImage => {
      if (navbarImage) {
        this.isImage = true;
      }
      else {
        this.isImage = false;
      }
    });
  }

  ngOnDestroy(): void {
    //this._destroyed$.next();
    //this._destroyed$.complete();
  }

  scroll(){
    window.scrollTo(0,0)
  }

}
