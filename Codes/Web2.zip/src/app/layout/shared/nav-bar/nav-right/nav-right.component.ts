import { Component, OnInit } from '@angular/core';
import { NgbDropdownConfig } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { LayoutService } from '@services/layout.service'
import { AuthenticationService } from '@services/authentication.service';
import { BehaviorSubject, Observable } from 'rxjs';
///oauth
import { OAuthService } from 'angular-oauth2-oidc';
import { LangService } from '@services/lang.service';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { environment } from 'environments/environment';
import { Role } from '@app/models/role.enum';
import { Router } from "@angular/router";

@Component({
  selector: 'app-nav-right',
  templateUrl: './nav-right.component.html',
  styleUrls: ['./nav-right.component.scss'],
  providers: [NgbDropdownConfig]
})
export class NavRightComponent extends BaseComponent {
  public styleSelectorToggle: boolean; // open configuration menu
  public isSearch: boolean;
  isButtonVisible: boolean = true;

  isSignInVisible: Observable<boolean>;

  KCLoginUser: Observable<string>;

  KCIsLogin: Observable<boolean>;

  isLoggedIn: Observable<boolean>;
  userDisplayName: Observable<string>;

  accountType: Observable<string>;
  userrole: Role;
  isinternaladmin: boolean = false;
  constructor(
    public translate: TranslateService,
    private layout: LayoutService,
    private oauthService: OAuthService,
    private langservice: LangService, context: ContextContainer,
    private router: Router
  ) {
    super(context);
    this.isSearch = false;
    this.KCLoginUser = this.context.authenticationService.kcLoggedInUser();
    this.KCIsLogin = this.context.authenticationService.isKCLoggedUser();
    this.accountType = this.context.authenticationService.getAccountType();
    this.isLoggedIn = this.context.accountService.isLoggedIn();
    this.userDisplayName = this.context.accountService.getUserDisplayName();

  }

  setRtlLayout() {
    const flag = true;
    this.changeRtlLayout(flag);
  }

  setLtrLayout() {
    const flage = false;
    this.changeLtrLayout(flage);
  }

  changeRtlLayout(flag: boolean) {
    if (flag) {
      document.querySelector('body').classList.add('able-pro-rtl');
    } else {
      document.querySelector('body').classList.remove('able-pro-rtl');
    }
    this.isButtonVisible = false;
    this.langservice.enableArab();
    this.layout.enableRTL();

  }

  changeLtrLayout(flage: boolean) {
    if (flage) {
      document.querySelector('body').classList.add('able-pro-rtl');
    } else {
      document.querySelector('body').classList.remove('able-pro-rtl');
    }
    this.isButtonVisible = true;
    this.langservice.enableEnglish();
    this.layout.disableRTL();

  }

  ngOnInit() {
    this.styleSelectorToggle = false;

  }

  //oauth 
  public login() {
    this.context.accountService.login();
    window.scrollTo(0,0);
  }

  public logoff() {
    // this.oauthService.redirectUri = window.location.origin + "/auth/login"
    this.context.accountService.logout(true);
    this.context.httpService.post(environment.accounturl + '/Account/sjp-signout').subscribe(
      (results) => {    
      }
    )
  }

  get loggedUser(): string {
    const claims = this.oauthService.getIdentityClaims();
    if (!claims) return null;
    return claims['given_name'];
  }

  get idToken(): string {
    return this.oauthService.getIdToken();
  }

  get accessToken(): string {
    var access_token = this.oauthService.getAccessToken();
    return access_token;
  }
  Routeprofile(){
    let userdetails = this.context.getUserDetails();
    if(userdetails && userdetails.roles){
      this.userrole = userdetails.roles[0];
    }
    if(this.userrole){
      this.checkadminrole();
      if(this.userrole && this.isinternaladmin){
        this.router.navigate(['/admin/manage-users/my-profile']);
      }else{
        this.router.navigate(['user/profile']);
      }
    }
  }
  Routepassword(){
    let userdetails = this.context.getUserDetails();
    if(userdetails && userdetails.roles){
      this.userrole = userdetails.roles[0];
    }
    if(this.userrole){
      this.checkadminrole();
      if(this.userrole && this.isinternaladmin){
        this.router.navigate(['/admin/manage-users/change-mypassword']);
      }else{
        this.router.navigate(['user/change-password']);
      }
    }

  }
  checkadminrole(){
    if(this.userrole == Role.ContentApprover || this.userrole == Role.SuperAdmin || this.userrole == Role.CXO ||this.userrole == Role.InternshipCounsellor ||this.userrole == Role.HEI || this.userrole == Role.GEI || this.userrole == Role.Employer){
      this.isinternaladmin = true;
    }else{
      this.isinternaladmin = false;
    }
  }
}
