import {Component, EventEmitter, Input, OnInit, Output, ViewChild} from '@angular/core';
import {NextConfig} from '@app/app-config';
import { AuthenticationService } from '@app/services/authentication.service';
import {LayoutService} from '@services/layout.service'
import { AdminConfig } from 'app/layout/sj-admin/admin-config';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.scss']
})
export class NavBarComponent implements OnInit {
  public nextConfig: any;
  public aConfig: any;
  public menuClass: boolean;
  public collapseStyle: string;
  public windowWidth: number;
  public accountType:any;
  public generalUser:boolean;
 
  @Output() onNavCollapse = new EventEmitter();
  @Output() onNavHeaderMobCollapse = new EventEmitter();
  isEn: boolean = true;
  layoutChange: boolean = true;

  constructor(private LayoutService: LayoutService, private authenticationservice:AuthenticationService) {
    this.nextConfig = NextConfig.config;
    this.aConfig = AdminConfig.config;
    this.menuClass = false;
    this.collapseStyle = 'none';
    this.windowWidth = window.innerWidth;

    this.accountType=this.authenticationservice.getAccountType();
    if(this.accountType.source.value =="HES" || this.accountType.source.value =="NAN"){
      this.generalUser=true;
    }
    else{
      this.generalUser=false;
    }
  }


  ngOnInit() {
    this.LayoutService.languageimgchangeObserver.subscribe(navbarImage => {
      if (navbarImage) {
        this.isEn = true;
      }
      else {
        this.isEn = false;
      }
    });
  }

  toggleMobOption() {
    this.menuClass = !this.menuClass;
    this.collapseStyle = (this.menuClass) ? 'block' : 'none';
  }

  navCollapse() {
    if (this.windowWidth >= 992) {
      this.onNavCollapse.emit();
    } else {
      this.onNavHeaderMobCollapse.emit();
    }
  }

 

}
