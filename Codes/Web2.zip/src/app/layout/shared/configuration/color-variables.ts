export interface ColorVariable {
    light: string;
    
}

export const colorVariables: Record<string, ColorVariable> = {
    golden: {
      light: '#ba9a3a',
    },
    blue: {
      light: '#46657F',
    },
    green: {
      light: '#006e27',
    },
    gray: {
      light: '#4c4c4c ',
    },
}