import { Component, ElementRef, Inject, inject, NgZone, OnInit, ViewChild } from '@angular/core';
import { NextConfig } from '../../app-config';
import { DOCUMENT, Location } from '@angular/common';
import { LangService } from '@services/lang.service';
import { AuthenticationService } from '@app/services/authentication.service';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent extends BaseComponent implements OnInit {
  
  public nextConfig: any;
  public navCollapsed: boolean;
  public navCollapsedMob: boolean;
  public windowWidth: number;
  logIn:Observable<boolean>;
  url:string;

  constructor(private zone: NgZone, private location: Location, context: ContextContainer,
    private authenticationService: AuthenticationService,private router:Router,
    private langservice: LangService,
    @Inject(DOCUMENT) private document: Document) {
    super(context);
    this.nextConfig = NextConfig.config;
    let currentURL = this.location.path();
    const baseHerf = this.location['_baseHref'];
    if (baseHerf) {
      currentURL = baseHerf + this.location.path();
    }


    this.windowWidth = window.innerWidth;



    if ((currentURL === baseHerf + '/layout/collapse-menu'
      || currentURL === baseHerf + '/layout/box')
      && (this.windowWidth >= 992 && this.windowWidth <= 1024)) {
      this.nextConfig.collapseMenu = true;
    }

    this.navCollapsed = (this.windowWidth >= 992) ? this.nextConfig.collapseMenu : false;
    this.navCollapsedMob = false;

  }


  ngOnInit() {
    if (this.windowWidth < 992) {
      this.nextConfig.layout = 'vertical';
      setTimeout(() => {
        document.querySelector('.pcoded-navbar').classList.add('menupos-static');
        (document.querySelector('#nav-ps-next') as HTMLElement).style.maxHeight = '100%'; // 100% amit
      }, 500);
    }
    this.url = this.router.url;
   if(this.url =='/home-page'){
     var body = document.getElementById('breadcrumb');
     body.classList.add('login')
   }
   else{
    body.classList.remove('login')
   }
    // this.firstRegistation();
  }

  // firstRegistation() {
  //   var body = document.getElementById('breadcrumb');
  //   if (localStorage.getItem('currentUser')) {
  //     body.classList.remove('login');
  //   }
  //   else {
  //     body.classList.add('login');
  //   }
  // }

  navMobClick() {
    if (this.windowWidth < 992) {
      if (this.navCollapsedMob && !(document.querySelector('app-navigation.pcoded-navbar').classList.contains('mob-open'))) {
        this.navCollapsedMob = !this.navCollapsedMob;
        setTimeout(() => {
          this.navCollapsedMob = !this.navCollapsedMob;
        }, 100);
      } else {
        this.navCollapsedMob = !this.navCollapsedMob;
      }
    }
  }

}
