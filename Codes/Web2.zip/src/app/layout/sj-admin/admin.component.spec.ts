import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminComponentUser } from './admin.component';

describe('AdminComponentUser', () => {
  let component: AdminComponentUser;
  let fixture: ComponentFixture<AdminComponentUser>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminComponentUser ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminComponentUser);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
