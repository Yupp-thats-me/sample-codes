import { NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminPageRoutingModule } from './admin-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { AdminComponentUser } from './admin.component';
//import { AdminlayoutComponent } from '../adminlayout/adminlayout.component';
//import { BreadcrumbModule } from '../shared/components';
//import { AdminfooterComponent } from './adminfooter/adminfooter.component';
//import { MessagesComponent } from '../layout/admin/messages/messages.component';

import { HttpClient, HttpClientModule } from '@angular/common/http';
//import { QuillModule } from 'ngx-quill';
//import { EditorModule } from "@tinymce/tinymce-angular";
//import { AdminnavbarComponent } from './adminnavbar/adminnavbar.component';
import { SharedModule } from '@shared/shared.module';
import { DataTablesModule } from 'angular-datatables';

@NgModule({
  declarations: [],

  imports: [
    CommonModule,
    AdminPageRoutingModule,
   // BreadcrumbModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
   // EditorModule,
    SharedModule,
    DataTablesModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: httpTranslateLoader,
        deps: [HttpClient]
      }
    })
  ]

})

export class AdminModule { }

export function httpTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http);
}
