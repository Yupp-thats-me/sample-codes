import { Component, OnInit } from '@angular/core';
import { AdminserviceService } from './services/adminservice.service';

@Component({
  selector: 'app-adminpage',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})

export class AdminComponentUser implements OnInit {

   menuadmin: any;

  constructor(private adminService: AdminserviceService) {
     this.menuadmin =adminService.menuHide();
   }

  ngOnInit(): void {
  }

}
