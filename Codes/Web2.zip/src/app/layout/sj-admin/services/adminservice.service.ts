import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminserviceService {

  private isMenu = new BehaviorSubject<boolean>(false);


  constructor() { }

  // isMenuHide(): Observable<boolean> {
  //   return this.isMenu.asObservable(); 
  // }

  menuHide(){
    this.isMenu.next(false);
  }

}
