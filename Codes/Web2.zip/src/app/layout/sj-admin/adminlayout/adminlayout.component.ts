import { DOCUMENT, Location } from '@angular/common';
import { Component, Inject, NgZone, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { AdminConfig } from '../admin-config';

@Component({
  selector: 'app-adminlayout',
  templateUrl: './adminlayout.component.html',
  styleUrls: ['./adminlayout.component.scss']
})

export class AdminlayoutComponent extends BaseComponent implements OnInit {

  public adminConfig: any;
  public windowWidth: number;
  public navCollapsed: boolean;
  public navCollapsedMob: boolean;
  loggedIn:any
  role:any;

  constructor(private zone: NgZone, private location: Location,context:ContextContainer, public router: Router,
    @Inject(DOCUMENT) private document: Document) {
      super(context)
    this.adminConfig = AdminConfig.config;
    let currentURL = this.location.path();
    const baseHerf = this.location['_baseHref'];
    if (baseHerf) {
      currentURL = baseHerf + this.location.path();
    }
    this.windowWidth = window.innerWidth;
    this.loggedIn = this.context.accountService.getUserRole();
    this.role = this.loggedIn.source.value;
    let userRole = this.role[0];
    if( userRole == 'SuperAdmin'){
     this.router.url != '/home-page'
    }


    if ((currentURL === baseHerf + '/layout/collapse-menu'
      || currentURL === baseHerf + '/layout/box')
      && (this.windowWidth >= 992 && this.windowWidth <= 1024)) {
      this.adminConfig.collapseMenu = true;
    }

    this.navCollapsed = (this.windowWidth >= 992) ? this.adminConfig.collapseMenu : false;
    this.navCollapsedMob = false;
  }

  ngOnInit(): void { 
    if (this.windowWidth < 992) {
      this.adminConfig.layout = 'vertical';
      setTimeout(() => {
        document.querySelector('.pcoded-navbar').classList.add('menupos-static');
        (document.querySelector('#nav-ps-next') as HTMLElement).style.maxHeight = '100%'; // 100% amit
      }, 500);
    }
  }

  navMobClick() {
    if (this.windowWidth < 992) {
      if (this.navCollapsedMob && !(document.querySelector('app-navigation.pcoded-navbar').classList.contains('mob-open'))) {
        this.navCollapsedMob = !this.navCollapsedMob;
        setTimeout(() => {
          this.navCollapsedMob = !this.navCollapsedMob;
        }, 100);
      } else {
        this.navCollapsedMob = !this.navCollapsedMob;
      }
    }
  }

}
