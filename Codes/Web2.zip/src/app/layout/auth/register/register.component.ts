import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, MaxLengthValidator, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Register } from '@models/register';
import { BaseComponent } from '@app-core/base.component';
import { ContextContainer } from '@app-core/context-container';
import { LangChangeEvent } from '@ngx-translate/core';
import { environment } from 'environments/environment';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent extends BaseComponent implements OnInit {

  registerForm: FormGroup;
  options: any;
  btndisabled: boolean = false;
  modelValue : FormControl = new FormControl('');
  public date: { year: number, month: number };
  emi = [];
  dp = [];
  submitted: boolean;
  slang: string = 'en'
  isValidAccountType: number = 0;

  registerDetails: Register = {

    Id: '',
    AccountType: '',
    UserName: '',
    Email: '',
    Password: '',
    FirstName: '',
    MiddleName: '',
    LastName: '',
    Gender: '',
    AddressL1: '',
    AddressL2: '',
    POBoxNumber: '',
    Emirate: '',
    MobileNo: 0,
    PhoneNo: '',
    PhoneCode: '',
    Residency: '',
    EmirateId: '',
    CountryId: '',
    PassportNo: '',
    DocumentNo: '',
    SecurityQuestionId: '',
    SecurityQuestionAnswer: '',
    InstituteName: '',
    EducationalZone: '',
    LicenseNumber: '',
    LicenseExpDate: null,
    EducationalActivities: '',
    CXOcompanyName: '',
    CXOEmployerCatgory: '',
    CXOEmployeeId: '',
    CXOEmployerZone: '',
    CXOLicenseNumber: '',
    CXOLicenseExpiryDate: null,
    EmployerName: '',
    EmployerEmpId: '',
    EmployerCatgory: '',
    EmployerZone: '',
    EmpLicenseNumber: '',
    EmpLicenseExpiryDate: null

  }

  constructor(private router: Router, context: ContextContainer)
  { super(context); }

  ngOnInit(): void {
    this.getEmirates();

    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang
    });

    this.registerForm = new FormGroup({
      accountType: new FormControl('', Validators.required),
      userName: new FormControl('', Validators.required),
      emailId: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [Validators.required,
      Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]),
      confirmPassword: new FormControl('', [Validators.required,
      Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]),
      firstName: new FormControl('', Validators.required),
      middleName: new FormControl('', Validators.required),
      lastName: new FormControl('', Validators.required),
      gender: new FormControl('', Validators.required),
      Emirate: new FormControl(''),
      emirateId: new FormControl('', Validators.compose([Validators.required,
      ])),
      mobileNumber: new FormControl('',),
      addressline: new FormControl('', Validators.required),
      addressline2: new FormControl('', Validators.required),
      po: new FormControl('', Validators.required),
      phone: new FormControl('', Validators.required),
      securityAnswer: new FormControl(''),
      selectionQuestion: new FormControl(''),
      instituteName: new FormControl(''),
      educationalZone: new FormControl(''),
      licenseNumber: new FormControl(''),
      licenseExpDate: new FormControl(''),
      educationalActivities: new FormControl(''),
      companyName: new FormControl(''),
      employerCatgory: new FormControl(''),
      employeeId: new FormControl(''),
      employerZone: new FormControl(''),
      CXOlicenseNumber: new FormControl(''),
      licenseExpiryDate: new FormControl(''),
      employeeName: new FormControl(''),
      employeeId2: new FormControl(''),
      employerCatgory2: new FormControl(''),
      employerZone2: new FormControl(''),
      licenseNumber2: new FormControl(''),
      licenseExpiryDate2: new FormControl(''),
      secondvalid: new FormControl(false),
      newreg: new FormControl(false),
      residency: new FormControl('1')
    });
    this.registerForm.get('securityAnswer').disable();
    this.registerForm.get('selectionQuestion').disable();

  }

  getEmirates() {
    this.context.httpService.get(environment.academicsUrl + '/DropdownDetails/Acadropdowns').subscribe(
      (response) => {
        this.dp = response.data
        this.emi = response.data.emirates;
      });
  }

  onChange(data) {
    this.modelValue.setValue(data.value)
  }

  get register() {
    return this.registerForm.controls;
  }


  resetAccTypeValidation() {

    this.registerForm.controls.instituteName = new FormControl('');
    this.registerForm.controls.educationalZone = new FormControl('');
    this.registerForm.controls.licenseNumber = new FormControl('');
    this.registerForm.controls.licenseExpDate = new FormControl('');
    this.registerForm.controls.educationalActivities = new FormControl('');

    this.registerForm.controls.companyName = new FormControl('');
    this.registerForm.controls.employerCatgory = new FormControl('');
    this.registerForm.controls.employeeId = new FormControl('');
    this.registerForm.controls.employerZone = new FormControl('');
    this.registerForm.controls.CXOlicenseNumber = new FormControl('');
    this.registerForm.controls.licenseExpiryDate = new FormControl('');

    this.registerForm.controls.employeeName = new FormControl('');
    this.registerForm.controls.employeeId2 = new FormControl('');
    this.registerForm.controls.employerCatgory2 = new FormControl('');
    this.registerForm.controls.employerZone2 = new FormControl('');
    this.registerForm.controls.licenseNumber2 = new FormControl('');
    this.registerForm.controls.licenseExpiryDate2 = new FormControl('');
    this.isValidAccountType = 0;
  }

  onSubmit() {
    this.submitted = true;
    this.resetAccTypeValidation();

    if (this.registerForm.value.accountType == 2)
    {

      if (this.registerForm.value.instituteName == '') {
        this.registerForm.controls.instituteName = new FormControl('', Validators.required);
        this.isValidAccountType = 1;
      }

      if (this.registerForm.value.educationalZone == '') {

        this.registerForm.controls.educationalZone = new FormControl('', Validators.required);
        this.isValidAccountType = 1;
      }

      if (this.registerForm.value.licenseNumber == '') {
        this.registerForm.controls.licenseNumber = new FormControl('', Validators.required);
        this.isValidAccountType = 1;
      }

      if (this.registerForm.value.licenseExpDate == '') {
        this.registerForm.controls.licenseExpDate = new FormControl('', Validators.required);
        this.isValidAccountType = 1

      }

      if (this.registerForm.value.educationalActivities == '') {
        this.registerForm.controls.educationalActivities = new FormControl('', Validators.required);
        this.isValidAccountType = 1;
      }

    }

    if (this.registerForm.value.accountType == 3) {

      if (this.registerForm.value.companyName == '') {
        this.registerForm.controls.companyName = new FormControl('', Validators.required);
        this.isValidAccountType = 1;
      }

      if (this.registerForm.value.employerCatgory == '') {
        this.registerForm.controls.employerCatgory = new FormControl('', Validators.required);
        this.isValidAccountType = 1;
      }

      if (this.registerForm.value.employeeId == '') {
        this.registerForm.controls.employeeId = new FormControl('', Validators.required);
        this.isValidAccountType = 1;
      }

      if (this.registerForm.value.employerZone == '') {
        this.registerForm.controls.employerZone = new FormControl('', Validators.required);
        this.isValidAccountType = 1;
      }

      if (this.registerForm.value.CXOlicenseNumber == '') {
        this.registerForm.controls.CXOlicenseNumber = new FormControl('', Validators.required);
        this.isValidAccountType = 1
      }

      if (this.registerForm.value.licenseExpiryDate == '') {
        this.registerForm.controls.licenseExpiryDate = new FormControl('', Validators.required);
        this.isValidAccountType = 1;
      }
    }

    if (this.registerForm.value.accountType == 4) {

      if (this.registerForm.value.employeeName == '') {
        this.registerForm.controls.employeeName = new FormControl('', Validators.required);
        this.isValidAccountType = 1;
      }

      if (this.registerForm.value.employeeId2 == '') {
        this.registerForm.controls.employeeId2 = new FormControl('', Validators.required);
        this.isValidAccountType = 1;
      }

      if (this.registerForm.value.employerCatgory2 == '') {
        this.registerForm.controls.employerCatgory2 = new FormControl('', Validators.required);
        this.isValidAccountType = 1;
      }

      if (this.registerForm.value.employerZone2 == '') {
        this.registerForm.controls.employerZone2 = new FormControl('', Validators.required);
        this.isValidAccountType = 1;
      }

      if (this.registerForm.value.licenseNumber2 == '') {
        this.registerForm.controls.licenseNumber2 = new FormControl('', Validators.required);
        this.isValidAccountType = 1;
      }

      if (this.registerForm.value.licenseExpiryDate2 == '') {
        this.registerForm.controls.licenseExpiryDate2 = new FormControl('', Validators.required);
        this.isValidAccountType = 1;
      }
    }

    if (this.isValidAccountType == 1) {
      return;
    }

    if (this.registerForm.invalid) {
      return;

    }

    const formValues = { ...this.registerForm.value };

    if (formValues.licenseExpDate == '')
      formValues.licenseExpDate = '1900-01-01';

    if (formValues.licenseExpiryDate == '')
      formValues.licenseExpiryDate = '1900-01-01';

    if (formValues.licenseExpiryDate2 == '')
      formValues.licenseExpiryDate2 = '1900-01-01';

    const user: Register = {

      Id: 0,
      AccountType: formValues.accountType,
      UserName: formValues.userName,
      Email: formValues.emailId,
      Password: formValues.password,
      FirstName: formValues.firstName,
      MiddleName: formValues.middleName,
      LastName: formValues.lastName,
      Gender: formValues.gender,
      AddressL1: formValues.addressline,
      AddressL2: formValues.addressline2,
      MobileNo: formValues.mobileNumber,
      PhoneNo: formValues.phone,
      PhoneCode: formValues.countryCode,
      POBoxNumber: formValues.po,
      Emirate: formValues.Emirate,
      Residency: formValues.residency,
      EmirateId: formValues.emirateId,
      CountryId: '',
      PassportNo: formValues.PassportNo,
      DocumentNo: formValues.DocumentNo,
      SecurityQuestionId: '',
      SecurityQuestionAnswer: '',
      InstituteName: formValues.instituteName,
      EducationalZone: formValues.educationalZone,
      LicenseNumber: formValues.licenseNumber,
      LicenseExpDate: new Date(formValues.licenseExpDate),
      EducationalActivities: formValues.educationalActivities,
      CXOcompanyName: formValues.companyName,
      CXOEmployerCatgory: formValues.employerCatefory,
      CXOEmployeeId: formValues.employeeId,
      CXOEmployerZone: formValues.employerZone,
      CXOLicenseNumber: formValues.CXOlicenseNumber,
      CXOLicenseExpiryDate: new Date(formValues.licenseExpiryDate),
      EmployerName: formValues.employeeName,
      EmployerEmpId: formValues.employeeId2,
      EmployerCatgory: formValues.employerCatgory2,
      EmployerZone: formValues.employerZone2,
      EmpLicenseNumber: formValues.licenseNumber2,
      EmpLicenseExpiryDate: new Date(formValues.licenseExpiryDate2)
    };

    this.context.httpService.post(environment.apiUrl + '/identity/Register', user).subscribe(
      (response) => {
        this.router.navigate(['/auth/login']);
        this.resetForm();
      })
  }

  resetForm() {

    this.registerDetails = {
      Id: '',
      AccountType: '',
      UserName: '',
      Email: '',
      Password: '',
      FirstName: '',
      MiddleName: '',
      LastName: '',
      Gender: '',
      AddressL1: '',
      AddressL2: '',
      POBoxNumber: '',
      Emirate: '',
      MobileNo:0,
      PhoneNo: '',
      PhoneCode: '',
      Residency: '',
      EmirateId: '',
      CountryId: '',
      PassportNo: '',
      DocumentNo: '',
      SecurityQuestionId: '',
      SecurityQuestionAnswer: '',
      InstituteName: '',
      EducationalZone: '',
      LicenseNumber: '',
      LicenseExpDate: null,
      EducationalActivities: '',
      CXOcompanyName: '',
      CXOEmployerCatgory: '',
      CXOEmployeeId: '',
      CXOEmployerZone: '',
      CXOLicenseNumber: '',
      CXOLicenseExpiryDate: null,
      EmployerName: '',
      EmployerEmpId: '',
      EmployerCatgory: '',
      EmployerZone: '',
      EmpLicenseNumber: '',
      EmpLicenseExpiryDate: null
    };
  }

  onSecondValidation(event) {
    if (event.target.checked) {
      this.registerForm.get('securityAnswer').enable();
      this.registerForm.get('selectionQuestion').enable();
    }
    else {
      this.registerForm.get('securityAnswer').disable();
      this.registerForm.get('selectionQuestion').disable();
    }
  }

  onSecondValidation1(event) {
    if (event.target.checked) {
      this.btndisabled = true;
    }
    else {
      this.btndisabled = false;
    }
  }

}
