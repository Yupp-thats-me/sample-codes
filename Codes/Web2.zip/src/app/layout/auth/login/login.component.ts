import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/internal/operators/first';
import { BaseComponent } from '@app-core/base.component';
import { ContextContainer } from '@app-core/context-container';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent extends BaseComponent implements OnInit {
  loginForm: FormGroup;
  submitted: Boolean = false;

  constructor(contextContainer: ContextContainer) {
    super(contextContainer)
  }

  ngOnInit(): void {

    this.loginForm = new FormGroup({
      emailId: new FormControl(localStorage.getItem('emailId'), Validators.compose([Validators.required, Validators.email])),
      password: new FormControl(localStorage.getItem('password'), [Validators.required, Validators.minLength(3)]),
      rememberMe: new FormControl(true)
    });
    //this.context.authenticationService.logout();
  }

  get f() {
    return this.loginForm.controls;
  }

  onsubmit() {
    this.submitted = true;
    if (this.loginForm.invalid) {
      return
    }

    //this.context.authenticationService.login(this.loginForm.value.emailId, this.loginForm.value.password, this.loginForm.value.rememberMe)
    //  .pipe(first())
    //  .subscribe(
    //    data => {
    //    });
  }
}
