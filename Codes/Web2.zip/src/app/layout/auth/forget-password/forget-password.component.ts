import { HttpParams } from '@angular/common/http';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { BaseComponent } from '@app-core/base.component';
import { ContextContainer } from '@app-core/context-container';
import { environment } from 'environments/environment';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.scss']
})
export class ForgetPasswordComponent extends BaseComponent implements OnInit, OnDestroy {
  private _destroyed$ = new Subject();
  emailId: string;

  constructor(context: ContextContainer) {
    super(context)
  }

  ngOnInit(): void {
  }

  onSubmit() {

    var t = this;
    var params = new HttpParams();
    params = params.set('email', this.emailId);
    this.context.httpService.post(environment.apiUrl+"/identity/forgotPassword",null, { handleResponse: false, params: params }).subscribe(
      (response) => {
        if (response.success) {
          if (response.data.validEmailId) {
            this.notifySuccess(response.msg)
          }
          else {
            this.notifyError(response.msg)
          }
        }
      });
  }

  public ngOnDestroy(): void {
    this._destroyed$.next();
    this._destroyed$.complete();
  }
}







