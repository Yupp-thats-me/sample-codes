import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { ChangePassword } from '@app/models/changepassword-model';
import { environment } from 'environments/environment';


@Component({
  selector: 'app-resetpassword',
  templateUrl: './resetpassword.component.html',
  styleUrls: ['./resetpassword.component.scss']
})
export class ResetpasswordComponent extends BaseComponent implements  OnInit {


  resetPassword: ChangePassword = {
    Id: 1,
    CurrentPassword:'',
    NewPassword: '',
    ConfirmPassword: '',
  }

  constructor(public contextContainer:ContextContainer) {
    super(contextContainer);
    }

  ngOnInit(): void {

  }


  onSubmit(form: NgForm) {
    if (form.invalid) {
      return;
    }
    this.contextContainer.httpService.post(environment.apiUrl + '/identity/ChangePassword',this.resetPassword).
    subscribe(
      (response)=> {
        this.resetForm(form);
      }
    )
  }

  resetForm(form: NgForm) {
    form.resetForm();
    this.resetPassword = {
      Id: 1,
      CurrentPassword:'',
      NewPassword: '',
      ConfirmPassword: '',
    }
  }

}










