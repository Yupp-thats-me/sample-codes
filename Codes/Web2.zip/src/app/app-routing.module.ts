/// <reference path="layout/sj-admin/admin.module.ts" />
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './layout/admin/admin.component';
import { AdminComponentUser } from './layout/sj-admin/admin.component';
import { Role } from '@models/role.enum';
import { Authorize } from './app-core/identity/auth.guard';


const routes: Routes = [
  {
    path: '',
    component: AdminComponent,
    children: [
      {
        path: '',
        redirectTo: 'home-page',
        pathMatch: 'full',
        
      },
      {
        path: 'home-page',
        loadChildren: () => import('./pages/home-page/home-page.module').then(module => module.HomePageModule),
      },
      {
        path: 'profileview',
        loadChildren: () => import('./pages/profileview/profileview.module').then(module => module.ProfileviewModule),
        canActivate: [Authorize],
        data: { roles: [Role.Student] }
      },
      {
        path: 'cxouser',
        loadChildren: () => import('./pages/cxo/cxo.module').then(module => module.CxoModule),
        canActivate: [Authorize],
        data: { roles: [] }
      },
      {
        path: 'scholarship',
        loadChildren: () => import('./pages/scholarship/scholarship.module').then(module => module.ScholarshipModule)
        //canActivate: [authorizationcheck]
      },
      {
        path: 'mediacenter',
        loadChildren: () => import('./pages/mediacenter/mediacenter.module').then(module => module.MediacenterModule)
      },
      {
        path: 'auth',
        loadChildren: () => import('./layout/auth/auth.module').then(module => module.AuthModule)
      },
      {
        path: 'credittransfer',
        loadChildren: () => import('./pages/credittransfer/credittransfer.module').then(module => module.CredittransferModule)
        //canActivate: [authorizationcheck]
      },
      {
        path: 'internship',
        loadChildren: () => import('./pages/internship/internship.module').then(module => module.InternshipModule)
      },
      {
        path: 'counselling',
        loadChildren: () => import('./pages/counselling/counselling.module').then(module => module.CounsellingModule)
      },
      {
        path: 'user',
        loadChildren: () => import('./pages/user-management/user-management.module').then(module => module.UserManagementModule)
      },
    ]
  },

  {
    path: '',
    component: AdminComponentUser,
    children: [
      {
        path: 'admin',
        loadChildren: () => import('./pages/sj-admin/sj-admin.module').then(module => module.sjAdminModule)
        // canActivate: [authorizationcheck]
      },
      {
        path: 'cxo',
        loadChildren: () => import('./pages/sj-admin/cxo/cxo.module').then(module => module.CxoModule),
      //  canActivate: [authorizationcheck],
       // data: { roles: [Role.Admin] }
      },
      {
        path: 'credittransfer',
        loadChildren: () => import('./pages/sj-admin/credittransfer/credittransfer.module').then(module => module.CredittransferModule)
        // canActivate: [authorizationcheck]
      },
      // {
      //   path:'admin-counsellor',
      //   loadChildren: () => import('./pages/sj-admin/counselling/counselling.module').then(module => module.CounsellingModule)
      // },
      {
        path: 'admin/internship',
        loadChildren: () => import('./pages/sj-admin/internship/internship.module').then(module => module.InternshipModule)
      },
      
      {
        path: '**',
        redirectTo: '/home-page'
      },
      
    ]
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    relativeLinkResolution: 'legacy',
    anchorScrolling: 'enabled'
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
