import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpResponse, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { catchError, filter, finalize, switchMap, take, tap } from 'rxjs/operators';
import { RequestType } from './request-type';
import { ContextContainer } from '../app-core/context-container';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { ErrorObservable } from 'rxjs-compat/observable/ErrorObservable';
import { NextStepDirective } from 'angular-archwizard';
import { environment } from 'environments/environment';


@Injectable()
export class httpInterceptor implements HttpInterceptor {

  context: ContextContainer;
  activatedRoute: ActivatedRoute;
  route: Route;
  private userToken: string;
  isRefreshingToken: boolean = false;
  tokenSubject: BehaviorSubject<string> = new BehaviorSubject<string>(null);
  private isRefreshing = false;
  constructor(activatedRoute: ActivatedRoute, context: ContextContainer, private router: Router) {
    this.activatedRoute = activatedRoute;
    this.context = context;

  }

  intercept(request: HttpRequest<any>, newRequest: HttpHandler): Observable<HttpEvent<any>> {
    // add authorization header to request


    //Get Token data from local storage


    //let tokenKeycloakInfo = localStorage.getItem('keycloakSession');

    let token: any = this.context.accountService.getUserToken();
    var access_token = token.source.value;
    this.userToken = access_token;

    if (this.userToken) {
      if (request.body instanceof FormData) {
        request = request.clone({
          setHeaders: {
            Authorization: `Bearer ${this.userToken}`
          }
        });
      }
      else {
        request = request.clone({
          setHeaders: {
            Authorization: `Bearer ${this.userToken}`,
            'Content-Type': 'application/x-www-form-urlencoded;',
            'Content-type': 'application / json'
          }
        });
      }
    }

    if (!(request.body instanceof FormData) && !request.headers.has('Content-Type')) {
      request = request.clone({ headers: request.headers.set('Content-Type', 'application/json') });
    }

    let handleResponse = request.params.get('handleResponse');

    if (typeof (handleResponse) == 'undefined' || handleResponse == null)
      handleResponse = 'true';

    // Use post response here
    return newRequest.handle(request).pipe(tap(data => {
      // window.scrollTo(0, 0);
      // console.log(data);
      // if (data instanceof HttpResponse && handleResponse == "true") {
      //  var title = this.activatedRoute.snapshot['_routerState'].url.replace('/', '')
      //  var response = data.body;
      //  if (response && response.success && requestType != RequestType.GET) {
      //    this.context.notificationService.success(response.msg,'');
      //  }
      //  else if (response && response.error) {
      //    this.context.notificationService.error(response.msg,'');
      //  }
      // }
    },
      catchError(
        (err, caught) => {
          if (err.status === 401) {
            this.handleAuthError();
            return of(err);
          }
          throw err;
        }
      ))
    );
  }
  private handleAuthError() {
    //localStorage.delete(this.userToken);
    //this.context.accountService.logout();
    //this.router.navigate(['/login']);
  }
}

