import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpErrorResponse } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { catchError, filter, map, switchMap, take, tap } from 'rxjs/operators';
import { AccountService } from "../services/account.service";
// import { AuthenticationService } from '@services/authentication.service';
import { Router } from '@angular/router';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { ContextContainer } from '@app/app-core/context-container';
import { environment } from 'environments/environment';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
  constructor(private context: ContextContainer,
    private router: Router) { }
  private isRefreshing = false;
  private refreshTokenSubject: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  intercept(request: HttpRequest<any>, newRequest: HttpHandler): Observable<HttpEvent<any>> {

    const tokenData: any = this.context.accountService.getUserToken();
    const token = tokenData.source.value;


    return newRequest.handle(this.addTokenHeader(request, token)).pipe(
      catchError(error => {

        if (error instanceof HttpErrorResponse) {

          if (error.status == 401) {
            return this.handle401Error(request, newRequest, error);
          }
          else if (error.status == 403) {
            this.handle403Error();
          }
          else {
            return ErrorObservable.create(error);
          }
        }
        return ErrorObservable.create(error);
      }));
  }


  private handle403Error() {

    this.context.accountService.logout();
  }

  private handle401Error(request: HttpRequest<any>, next: HttpHandler, error: HttpErrorResponse) {

    if(!request.url.includes('refresh-token') || !(request.url.includes('login')))
    {
      if (!this.isRefreshing) {
        this.isRefreshing = true;
        this.refreshTokenSubject.next(null);
  
        return this.refreshToken().pipe(
          switchMap((response: any) => {
            this.isRefreshing = false;
  
            if (response.error) {
              this.context.accountService.logout();
            }
            else {
              this.context.accountService.onRefreshToken(response.data.token, response.data.refreshToken);
  
              window.location.reload();
  
              return next.handle(this.addTokenHeader(request, response.data.token));
            }
          }));
      }
      else {
        return this.context.accountService._userRefreshtoken.pipe(
          filter(token => token != null),
          take(1),
          switchMap(jwt => {
            return next.handle(this.addTokenHeader(request, jwt));
          }));
      }
    }
  }

  private addTokenHeader(request: HttpRequest<any>, token: string) {

    if (token) {
      if (request.body instanceof FormData) {
        request = request.clone({
          setHeaders: {
            Authorization: `Bearer ${token}`
          }
        });
      }
      else {
        request = request.clone({
          setHeaders: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/x-www-form-urlencoded;',
            'Content-type': 'application / json'
          }
        });
      }
    }

    if (!(request.body instanceof FormData) && !request.headers.has('Content-Type')) {
      request = request.clone({ headers: request.headers.set('Content-Type', 'application/json') });
    }

    return request.clone({ headers: request.headers.set('Authorization', `Bearer ${token}`) });
  }

  refreshToken() {

    const tokenData: any = this.context.accountService.getUserToken();
    const token = tokenData.source.value;

    let refreshTokenData: any = this.context.accountService.getUserRefreshToken();
    let refreshToken = refreshTokenData.source.value;
    // let refreshToken = localStorage.getItem('userRefreshToken')


    if (!token || !refreshToken) {
      this.context.accountService.logout();

    }

    const credentials = { token: token, refreshToken: refreshToken };
    return this.context.httpService.post(environment.accounturl + '/account/refresh-token', credentials).pipe(
      tap((response) => {

        // this.context.accountService.setUserToken(response.data.token);

        // this.context.accountService.setUserRefreshToken(response.data.refreshToken);
      }));
  }
}