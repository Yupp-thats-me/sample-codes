import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exportprofile',
  templateUrl: './exportprofile.component.html',
  styleUrls: ['./exportprofile.component.scss']
})
export class ExportprofileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
