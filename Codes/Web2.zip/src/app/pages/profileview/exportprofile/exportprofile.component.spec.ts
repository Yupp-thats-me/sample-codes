import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExportprofileComponent } from './exportprofile.component';

describe('ExportprofileComponent', () => {
  let component: ExportprofileComponent;
  let fixture: ComponentFixture<ExportprofileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExportprofileComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExportprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
