import { AfterViewInit, Component, ElementRef, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { DataTableDirective } from 'angular-datatables';
import { ContextContainer } from '@app-core/context-container';
import { BaseComponent } from '@app-core/base.component';
import { Volunteering } from '@models/volunteering-model.service';
import { environment } from 'environments/environment';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { Subject } from 'rxjs';
import * as moment from 'moment';

@Component({
  selector: 'app-volunteering',
  templateUrl: './volunteering.component.html',
  styleUrls: ['./volunteering.component.scss']
})
export class VolunteeringComponent extends BaseComponent implements AfterViewInit {

  dtTrigger: Subject<any> = new Subject<any>();
  @ViewChild(DataTableDirective) dtElement: DataTableDirective;
  @ViewChild('search', { static: false }) searchElement: ElementRef;
  @ViewChild('input') dateInput: ElementRef;
  isFormVisible: boolean = false;
  saveInProgress: boolean
  volunteeringDetails: volunteeringDetails[];
  studentId: any;
  createdBy: any;
  updatedBy: any;
  volunteeringUrl: string = '/StudentProfile/Volunteering/';
  dateInputFormat: string
  bsConfig: Partial<BsDatepickerConfig>;
  maxDate: Date;
  minDate: Date;
  duplicateOrganisation: boolean = false;
  duplicateDate: boolean = false;
  futureDate: boolean = false
  zerohours: boolean = false

  selectedVolunteering: Volunteering =
    {
      Id: 0,
      StudentId: 0,
      ReferenceId: 0,
      Organization: '',
      DateOfEvent: '',
      NameOfEvent: '',
      Description: '',
      Hours: 0,
      CreatedBy: '',
      UpdatedBy: ''
    };

  VoluntDet = {
    DOE: ''
  };

  constructor(context: ContextContainer) {
    super(context);
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate());
    this.minDate = new Date(2000, 0, 1);
  }

  get getStudentId(): number {
    this.studentId = this.context.accountService.getUserId();
    var access_token = this.studentId.source.value;
    return access_token;
    //return 2;
  }

  ngOnInit(): void {

    this.getVolunteering();
    this.volunteeringDetails = [];
    this.saveInProgress = false;
    this.bsConfig = Object.assign({}, {
      dateInputFormat: 'MM/DD/YYYY',
      showWeekNumbers:false,
      customTodayClass: 'custom-today-class'
    });

  }

  ngAfterViewInit() {
    this.context.datatableService.init(this.dtElement);
  }


  onSubmit(form: NgForm) {

    if (form.invalid) {
      this.notifyError('Please enter all the mandatory fields');
      return;
    }
    this.initDuplicateValidations();
    if(this.duplicateOrganisation){
      this.notifyError("Data already exists");
      return;
    }



    this.saveInProgress = true;
    var  y: number = +this.selectedVolunteering.Hours;

    this.selectedVolunteering.Hours = y;

    var doe = this.VoluntDet.DOE;
    this.selectedVolunteering.DateOfEvent = moment(doe).format("YYYY-MM-DD").toString();

    this.selectedVolunteering.StudentId = this.getStudentId;

    var created_By = this.getStudentId;
    this.selectedVolunteering.CreatedBy = created_By.toString();

    var updated_By = this.getStudentId;
    this.selectedVolunteering.UpdatedBy = updated_By.toString();
    this.showCardProgress('form-card')
  if(this.selectedVolunteering.Hours == 0){
    this.zerohours = true;
    this.saveInProgress = false;
    return
    }

    if (this.selectedVolunteering.Id == 0 || this.selectedVolunteering.Id == null) {
      this.context.httpService.post(environment.academicsUrl + this.volunteeringUrl + this.selectedVolunteering.Id, this.selectedVolunteering).subscribe(
        (response) => {
          this.hideCardProgress('form-card');
          if (response.success) {
            this.notifySuccess('Saved Succesfully');
            this.resetForm(form);
            this.getVolunteering();
            this.selectedVolunteering.Id = 0;
            this.isFormVisible = false;
            this.saveInProgress = false;

          } else {
            this.notifyError('Failed to save data');
            this.isFormVisible = true;
            this.saveInProgress = false;

          }
        }, (error) => {
          this.saveInProgress = false;
          this.hideCardProgress('form-card')
        });
    }

    else {
      this.initDuplicateValidations();

      if (form.invalid || this.duplicateOrganisation) {
        return;
      }
      var date = new Date(this.selectedVolunteering.DateOfEvent);
      this.selectedVolunteering.DateOfEvent = moment(date).format("YYYY-MM-DD").toString();
      this.context.httpService.put(environment.academicsUrl + this.volunteeringUrl + this.selectedVolunteering.Id, this.selectedVolunteering)
        .subscribe(
          (response) => {
            if (response.success) {
            this.notifySuccess('Saved Succesfully');
              this.resetForm(form);
              this.getVolunteering();
              this.selectedVolunteering.Id = 0;
              this.saveInProgress = false;
              this.isFormVisible = false;
              this.hideCardProgress('form-card')
            } else {
              this.saveInProgress = false;
              this.isFormVisible = true;
              this.hideCardProgress('form-card')
            }
          }, (error) => {
            this.saveInProgress = false;
            this.hideCardProgress('form-card')
          });
    }
  }

  resetForm(form: NgForm) {
    this.selectedVolunteering = {
      Id: 0,
      StudentId: 0,
      ReferenceId: 0,
      Organization: '',
      NameOfEvent: '',
      Description: '',
      Hours: 0,
      DateOfEvent: null,
      CreatedBy: '',
      UpdatedBy: ''
    };
    form.resetForm();
    this.duplicateOrganisation = false;
    this.saveInProgress = false;
    this.hideForm();
  }
  public showForm(form: NgForm) {
    this.saveInProgress = false;
    this.resetForm(form);
    this.isFormVisible = true;
    this.duplicateOrganisation = false;
  }

  public hideForm() {
    this.isFormVisible = false;
    this.duplicateOrganisation = false;
    this.saveInProgress = false;
  }

  getVolunteering() {
    this.showCardProgress('grid-card')
    this.context.httpService.get(environment.academicsUrl + this.volunteeringUrl + this.getStudentId).
      subscribe(
        (response) => {
          if(response.success){
            this.hideCardProgress('grid-card')
            this.volunteeringDetails = response.data;
            this.context.datatableService.reRender('datatable');
          }else{
            this.hideCardProgress('grid-card')
          }
        },(error) =>{
            this.hideCardProgress('grid-card')
        })
  }


  deleteRow(x) {
    this.context.notificationService.confirmAlert((confirm) => {
      if (!confirm.dismiss) {
        this.context.httpService.delete(environment.academicsUrl + this.volunteeringUrl + x).
          subscribe(
            (response) => {
              if(response.success){
                this.notifySuccess('Deleted Successfully')
                this.getVolunteering();
              }else{
                this.notifyError('Failed to delete')
              }
            });
      }
    }, 'Delete?')
  }

  editRow(volunteering) {
    setTimeout(() => {
      this.searchElement.nativeElement.focus();
    }, 0);
    this.isFormVisible = true;
    this.duplicateOrganisation = false;
    var myStartDate = new Date(volunteering.dateOfEvent);
    this.VoluntDet.DOE = moment(myStartDate).format('MM-DD-YYYY');
    this.selectedVolunteering.Id = volunteering.id;
    this.selectedVolunteering.Organization = volunteering.organization;
    this.selectedVolunteering.NameOfEvent = volunteering.nameOfEvent;
    this.selectedVolunteering.Description = volunteering.description;
    this.selectedVolunteering.Hours = volunteering.hours;
  }

  initDuplicateValidations() {
    let organisation = this.selectedVolunteering.Organization.toLocaleLowerCase();
    let currentDate = moment(this.VoluntDet.DOE).format('MM/DD/YYYY');
    this.duplicateOrganisation = false;
      this.volunteeringDetails.forEach(element => {
        var dateOfEvent = moment(element.dateOfEvent).format('MM/DD/YYYY');
        if (element.organization.toLocaleLowerCase() == organisation && moment(dateOfEvent).isSame(moment(currentDate)) && (!element.id || element.id != this.selectedVolunteering.Id)) {
          this.duplicateOrganisation = true;
        }
      });
  }

  clr()
  {
    if (moment(this.VoluntDet.DOE).isAfter(new Date())) {
      this.futureDate = true
      this.VoluntDet.DOE = '';
    }
    else
    {
      this.futureDate = false
    }
    this.duplicateOrganisation = false;
  }
  checkhours(event){
    var item = event.target.value;
    var  y: number = +item;
    if(y <= 0){
    this.zerohours = true;
    }else{
      this.zerohours = false;
    }
  }

  textWrap(word:string) {
    return word.length > 30 ? word.substring(0, 30) + "..." : word;
  }
}

export class volunteeringDetails {
  organization: string;
  nameOfEvent: string;
  description: string;
  hours: number;
  dateOfEvent: Date;
  id: number;
}
