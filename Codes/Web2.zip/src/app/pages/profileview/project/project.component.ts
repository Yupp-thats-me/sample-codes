import { AfterViewInit, Component, ElementRef, ViewChild } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { ProjectService } from '@services/project.service';
import { ContextContainer } from '@app-core/context-container';
import { AccomplishmentsComponent } from '@pages/profileview/accomplishments/accomplishments.component';
import { NgForm } from '@angular/forms';
import { AccomplishmentModel } from '@models/accomplishment.model';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import * as moment from 'moment';
import { DatatableService } from '@app/services/datatable.service';

@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.scss']
})
export class ProjectComponent extends AccomplishmentsComponent implements AfterViewInit {


  @ViewChild(DataTableDirective) dtElement: DataTableDirective;

  @ViewChild("isWorkingOn", { static: false }) isWorkingOn: ElementRef;
  bsConfig: Partial<BsDatepickerConfig>;
  public modelPopup: any;
  public modelPopupE: any;
  endDateChecks: boolean = false;
  maxDate: Date;
  minDate: Date;
  minDate1: Date;
  maxDate1: Date;
  isFormVisible: boolean = false;

  gridData: gridData[];
  model: AccomplishmentModel = new AccomplishmentModel();

  saveInProgress: boolean;
  isSaving:boolean;

  accopmlishmentTypeId: number;
  titleValidate: boolean;
  endDateValidate: boolean = false;
  startDateValidate: boolean = false;
    startDt: Date;
    endDt: Date;

  Project = {
    StartDate: '',
    EndDate: ''
  };
    proDet: string ;
    datatableService:DatatableService;
  constructor(context: ContextContainer, private service: ProjectService, datatableService:DatatableService) {
    super(context);
    this.endDateChecks = false;
    this.accopmlishmentTypeId = 1;
    this.saveInProgress = false;
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate());
    this.maxDate1 = new Date();
    this.maxDate1.setDate(this.maxDate.getDate());
    this.minDate = new Date(2000, 0, 1);

    this.titleValidate = false;
    this.endDateValidate = false;
    this.startDateValidate = false;
    this.isSaving= false;
  }

  ngOnInit(): void {
    this.gridData = [];
    this.loadProjectGrid();
    this.bsConfig = Object.assign({}, {
      dateInputFormat: 'MM/DD/YYYY',
      showWeekNumbers:false,
      customTodayClass: 'custom-today-class'
    });

  }

  ngAfterViewInit() {
    this.context.datatableService.init(this.dtElement);
  }

  onSubmit(form: NgForm) {

    if (this.Project.EndDate) {
      this.checkDate();
    } else {
      this.Project.EndDate = ''
      this.endDateValidate = false
    }

    if (form.invalid ) {
      return this.notifyError('Please enter all the mandatory fields');
    }
    this.checkTitle();
    if(this.titleValidate){
      this.notifyError("Data already exists");
      return;
    }
    this.saveInProgress = true;
    this.showCardProgress('form-card')
    this.model.startDate = this.Project.StartDate;
    this.model.endDate = this.Project.EndDate;

    var date = new Date(this.model.startDate);
    this.model.startDate = moment(date).format("YYYY-MM-DD").toString();

    if (this.model.isWorkingOn == true) {
      this.model.endDate = null;
      this.model.isWorkingOn = true;
    }
    else {
      var edate = new Date(this.model.endDate);
      this.model.endDate = moment(edate).format("YYYY-MM-DD").toString();
      this.model.isWorkingOn = false;
    }

    var data = this.model;
    if (this.model.endDate == '' || this.model.endDate== null) {
      data.endDate = null;
    }
    else
    {
      var date = new Date(this.model.endDate);
      data.endDate = moment(date).format();
    }
    var date1 = new Date(this.model.startDate);
    data.startDate = moment(date1).format();

    data.isWorkingOn = data.isWorkingOn || false;

    data.accomplishmentTypeId = this.accopmlishmentTypeId;


    this.saveData(data).subscribe(
      (response) => {
        this.saveInProgress = false;
        if (response.success) {
          this.hideCardProgress('form-card')
          this.notifySuccess('Saved Succesfully');
          this.saveInProgress = false;

          this.resetForm(form);
          this.loadProjectGrid();
          this.hideForm();
        }
        else{
          this.notifyError('Failed to save data');
          this.hideCardProgress('form-card');
        }
      },(error) => {
        this.saveInProgress = false;
        this.hideCardProgress('form-card')
      },
    );
  }

  onEdit(data: any) {
    this.isFormVisible = true;
   this.bindData(data);



    // if(this.dtElement)
    // {
    //   //this.dtOptions.language.url = '//cdn.datatables.net/plug-ins/1.10.9/i18n/Arabic.json';
    //   this.dtElement.dtOptions.language.url = '//cdn.datatables.net/plug-ins/1.10.9/i18n/Arabic.json';
    //   this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
    //     dtInstance.table('#datatable').i18n('buttons.edit', 'Copy to clipboard')
    //     dtInstance.destroy(false);
    //     console.log("init", dtInstance.init())
    //     dtInstance.draw();

    //   });
    //   this.dtTrigger.next();
    // }
  }


  onCheckboxChange(form) {

    if (this.model.isWorkingOn) {
        this.Project.EndDate = '';
        form.controls.EndDate.setValue('');
         this.endDateChecks = false;
         this.model.isWorkingOn = true;
         this.endDateValidate= false;
    }
    else {
      this.model.isWorkingOn = false;
      var stdt = this.Project.StartDate
      this.minDate1 = new Date(stdt);
    }
  }
  inprogress(date){
    if(date != null || ''){
      let enddate = moment(date).format('MM-DD-yyyy');
      return enddate;
    }else{
      return 'In progress';
    }
  }
  onDelete(id: number) {
    let accomplishmentTypeId = this.accopmlishmentTypeId;
    this.context.notificationService.confirmAlert((confirm) => {
      if (!confirm.dismiss) {
        this.deleteRow(id, accomplishmentTypeId).subscribe(
          (response) => {
            if (response.success) {
              this.notifySuccess('Deleted Successfully')
              this.loadProjectGrid();
            }
            else{
              this.notifyError('Failed to delete')
            }
          }
        );
      }
    }, 'Delete?')
  }

  bindData(data) {
    this.saveInProgress = false;
    this.model = new AccomplishmentModel();

    this.model.title = data.title;
    var myDOB = new Date(data.startDate);
    this.Project.StartDate = moment(myDOB).format('MM-DD-YYYY');

    if (data.isWorkingOn == false) {
      var myDOB = new Date(data.endDate);
      this.Project.EndDate = moment(myDOB).format('MM-DD-YYYY');
    }
    else {
      this.Project.EndDate = "";
      this.model.isWorkingOn = true;
    }
    this.model.urlLink = data.urlLink;
    this.model.id = data.id;
    this.model.accomplishmentTypeId = data.accomplishmentTypeId;
    this.model.description = data.description;
    this.model.isWorkingOn = data.isWorkingOn;
  }

  loadProjectGrid() {
    this.showCardProgress('grid-card')
    this.loadGrid(this.accopmlishmentTypeId).subscribe(

      (response) => {
        if (response.success) {
          this.gridData = response.data || [];
          this.context.datatableService.reRender('datatable');
          this.hideCardProgress('grid-card')
          // this.destroyDatatable();
          // this.dtTrigger.next();
          // this.gridData.forEach(res => {
          //   if (res.isWorkingOn == true) {
          //     res.endDat = 'In Progress';
          //   }
          // });
        }else{
          this.hideCardProgress('grid-card')
        }
      },(error)=>{
        this.hideCardProgress('grid-card')
      }
    );
  }
  resetForm(form: NgForm) {
    this.model.id = 0;
    this.model.title = '';
    this.model.urlLink = '';
    this.model.description = '';
    this.model.isWorkingOn = false;
    this.Project.StartDate ='';
    this.Project.EndDate ='';
    form.resetForm();
    this.hideForm()
  }

  public showForm(form: NgForm) {

    this.resetForm(form);
    this.isFormVisible = true;
    this.saveInProgress = false;
  }

  public hideForm() {
    this.titleValidate = false;
    this.isFormVisible = false;
    this.saveInProgress = false;
  }


  checkTitle() {
    let title = this.model.title.toLocaleLowerCase();
    this.titleValidate = false;
    this.gridData.forEach(element => {
      if ((element.title.toLocaleLowerCase()== title) && (!element.id || element.id != this.model.id)) {
        this.titleValidate = true;

      }
    });
  }

  checkDate() {
    this.model.startDate = this.Project.StartDate;
    this.model.endDate = this.Project.EndDate;
    var StartDate = this.model.startDate;
    var EndDate = this.model.endDate;
    var eDate = new Date(EndDate);
    this.endDt = eDate;
    var sDate = new Date(StartDate);
    if (sDate > eDate) {
      this.endDateValidate = true;
      this.Project.EndDate = '';
      this.model.endDate = '';
    }
    else {
      this.endDateValidate = false;
      this.minDate1 = new Date(StartDate);
    }
  }

  checkStartDate() {
    this.model.startDate = this.Project.StartDate;
    this.model.endDate = this.Project.EndDate;
    var StartDate = this.model.startDate;
    var sDate = new Date(StartDate);
    this.startDt = sDate;
    this.minDate1 = new Date(this.startDt);
    var CurrentDate = new Date();
    if (sDate != CurrentDate && CurrentDate < sDate) {
      this.startDateValidate = true;
      this.model.startDate = '';
    }
    else {
      this.startDateValidate = false;
    }
    this.checkDate();
  }

  dateValid(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if ((charCode > 46 && charCode < 58) || charCode == 46) {
      var sDate = new Date(this.model.startDate);
      this.startDt = sDate;
      return true;
    }
    return false;
  }
  EdateValid(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if ((charCode > 46 && charCode < 58) || charCode == 46) {
      var sDate = new Date(this.model.endDate);
      this.endDt = sDate;
      return true;
    }
    return false;
  }

  clr() {
    this.titleValidate = false;
  }

  textWrap(word: string) {
    return word.length > 50? word.substring(0, 50) + "..." : word;
  }

}


export class gridData {
  title: string;
  startDate: Date;
  endDate: Date;
  urlLink: any;
  description: string;
  isWorkingOn: boolean;
  endDat: any;
  id: number
}
