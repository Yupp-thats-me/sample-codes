import { Component, OnDestroy, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { FileUploadValidators } from '@iplab/ngx-file-upload';
import { BaseComponent } from 'app/app-core/base.component';
import { ContextContainer } from 'app/app-core/context-container';
import { DocumentService } from '@services/document.service';
import { environment } from 'environments/environment';
import { DataTableDirective } from 'angular-datatables';

@Component({
  selector: 'app-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DocumentsComponent extends BaseComponent implements OnInit, OnDestroy {
  @ViewChild(DataTableDirective) dtElement: DataTableDirective;
  studentId: any;
  submitted: Boolean = false;
  titleValid: boolean = false;
  dtRouterLinkOptions: any = {};
  public multiple: boolean = false;
  docValidate: boolean = false;
  titMaxLenVal: boolean = false
  private filesControl = new FormControl(null, FileUploadValidators.filesLimit(1));
  isFormVisible: boolean = false;
  gridData: any;
  public documentForm = new FormGroup({
    files: this.filesControl,
    documentType: new FormControl(1, Validators.required),
    titleOfDocs: new FormControl('')
  });
  public titleForResume: string = 'Title for Resume';
  initialFormValue;
  constructor(private service: DocumentService, context: ContextContainer) {
    super(context);
  }

  public showForm() {
    this.isFormVisible = true;
    this.resetForm();
  }

  public hideForm() {
    this.isFormVisible = false;
    this.resetForm();
  }

  ngOnInit() {
    this.gridData = []
    var t = this;
    this.baseInit();
    this.service.initialFormValue = this.documentForm.value;
    let params = { params: { studentId: this.getStudentId.toString(), documentTypeId: this.documentForm.value.documentType } };
    this.showCardProgress('grid-card');
    this.context.httpService.get(environment.academicsUrl + '/Document/LoadGridData/', params).subscribe(
      response => {
        this.hideCardProgress('grid-card');
        $.map(response.data || [], function () {
        })
        t.gridData = response.data || [];
        this.context.datatableService.reRender('datatable');
      },
      (error) => { this.notifyError('Error occured', 'Title') },
      () => { }
    );
  }

  ngAfterViewInit() {
    this.context.datatableService.init(this.dtElement);
  }

  get f() {
    return this.documentForm.controls;
  }

  public toggleStatus() {
    this.filesControl.disabled ? this.filesControl.enable() : this.filesControl.disable();
  }

  change() {
    this.titleValid = false;
    if (this.documentForm.controls['documentType'].value == 1) {
      var value = 'Resume';
    } else if (this.documentForm.controls['documentType'].value == 2) {
      var value = 'Cover Letter';
    } else {
      var value = 'Others';
    }
    this.titleForResume = 'Title for ' + value;
    if (this.documentForm.value.titleOfDocs != null) {
      this.docValid();
    }
  }
  titlevalid(event: any) {
    this.docValid();
    var title = event.target.value
    if (title != "") {
      return this.titleValid = false
    }
  }
  onSubmit() {
  this.submitted = true;
  if(this.documentForm.status == 'INVALID'){
    return
  }
    if (this.documentForm.value.titleOfDocs === "" || this.documentForm.value.titleOfDocs === null) {
      this.saveInProgress = false;
      return this.titleValid = true

    }
    if (this.documentForm.value.files == null || this.documentForm.value.files.length == 0) {
      this.saveInProgress = false;
      this.notifyError('No Files are uploaded');
      return;
    }
    this.saveInProgress = true;
    var data = this.documentForm.value;
    const formData = new FormData();
    var i = 0;
    data.files.forEach(file => {
      formData.append('files[' + i + ']', data.files[i]);
      i++;
    });
    formData.append('model.StudentId', this.getStudentId.toString());
    formData.append('model.Title', data.titleOfDocs);
    formData.append('model.DocumentTypeId', data.documentType);
    formData.append('model.CreatedBy', this.getStudentId.toString());
    this.transformFiles(data.files);
    this.docValid();
    if (!this.docValidate) {
      this.showCardProgress('form-card');
      this.context.httpService.post<any>(environment.academicsUrl + '/Document/UploadDocuments/', formData).subscribe(
        response => {
          this.hideCardProgress('form-card');
          this.saveInProgress = false;
          if (response.success) {
            this.notifySuccess('Saved Succesfully');
            this.gridData = response.data;
            this.resetForm();
            this.hideForm();
            this.context.datatableService.reRender('datatable');

            this.filesControl.setValue([]);
            this.submitted = false;
          } else {
            this.notifyError('Failed to save data');
          }
        }, (error) => {
          this.saveInProgress = false;
        });
    }
  }

  transformFiles(files) {
    files.forEach(element => {
      element.FileName = element.name;
      element.ContentType = element.type;
      element.Length = element.size;
    });
  }

  downloadFile(fileName, id) {
    const options = { params: { id: id, filePath: fileName } };
    this.showCardProgress('form-card');
    this.context.httpService.get(environment.academicsUrl + '/Document/DownloadFile', options).subscribe(
      (response) => {
        if (response.success) {
          this.hideCardProgress('form-card');
          var file = this.createFile(response.data, fileName);
          if (file) {
            //saveAs(file, fileName);
            this.context.fileUtility.download(response.data,fileName);
          }
        }
        else {
          this.notifyError('Failed to download the file');
        }
      }
    );
    //this.context.httpService.downloadFile(fileName, environment.academicsUrl + '/Document/DownloadFile', options)
  }

  deleteRow(id: number) {
    this.context.notificationService.confirmAlert((confirm) => {
      if (!confirm.dismiss)
        this.context.httpService.delete(environment.academicsUrl + '/Document/DeleteDocumentData/' + id).subscribe(
          (response: any) => {
            if (response) {
              this.notifySuccess('Deleted Successfully');
            } else {
              this.notifyError('Failed to delete');
            }
            this.gridData = response.data;
            this.context.datatableService.reRender('datatable');
          }
        );
    }, 'Delete?');
  }
  textWrap(word: string) {
    return word.length > 20 ? word.substring(0, 20) + "..." : word;
  }
  resetForm() {
    this.documentForm.reset();
    this.documentForm.patchValue({
      documentType: 1,
      title:''
    });
    this.change()
    this.titleValid = false;
    this.titMaxLenVal = false;
    this.saveInProgress = false;
    this.docValidate = false;
    this.filesControl.setValue([]);
    this.documentForm.value.title = '';
    this.submitted = false;
  }

  get getStudentId(): number {
    this.studentId = this.context.accountService.getUserId();
    var access_token = this.studentId.source.value;
    return access_token;

    //return 2;
  }
  docValid() {

    this.docValidate = false;
    var tit = this.documentForm.value.titleOfDocs;
    var doc = this.documentForm.value.documentType;
    this.gridData.forEach(element => {
      if (element.title == tit && element.documentTypeId == doc) {
        this.saveInProgress = false;
        this.notifyError('file already updated');
        return this.docValidate = true;

      }
    });
  }

}
