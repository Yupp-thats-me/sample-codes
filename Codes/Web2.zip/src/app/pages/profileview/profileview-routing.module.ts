import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProfileviewComponent } from './profileview.component';
import { Role } from '../../models/role.enum';
import { Authorize } from '@app/app-core/identity/auth.guard';

const routes: Routes = [{
  path: '',
  component: ProfileviewComponent,
  children: [
    {
      path: '',
      redirectTo: 'myprofile',
      pathMatch: 'full'
    },
    {
      path: 'education',
      loadChildren: () => import('./education/education.module').then(module => module.EducationModule),
      canActivate : [Authorize],
      data:{roles:[Role.Student]}
    },
    {
      path: 'accomplishments',
      loadChildren: () => import('./accomplishments/accomplishments.module').then(module => module.AccomplishmentsModule),
      canActivate : [Authorize],
      data:{roles:[Role.Student]}
    },
    {
      path: 'courses',
      loadChildren: () => import('./courses/courses.module').then(module => module.CoursesModule),
      canActivate : [Authorize],
      data:{roles:[Role.Student]}
    },
    {
      path: 'documents',
      loadChildren: () => import('./documents/documents.module').then(module => module.DocumentsModule),
      canActivate : [Authorize],
      data:{roles:[Role.Student]}
    },
    {
      path: 'myprofile',
      loadChildren: () => import('./myprofile/myprofile.module').then(module => module.MyprofileModule),
      canActivate : [Authorize],
      data:{roles:[Role.Student]}  
    },
    {
      path: 'personals',
      loadChildren: () => import('./personal-detail/personal-detail.module').then(module => module.PersonalDetailModule),
      canActivate : [Authorize],
      data:{roles:[Role.Student]}
    },
    {
      path: 'skills',
      loadChildren: () => import('./skills/skills.module').then(module => module.SkillsModule),
      canActivate : [Authorize],
      data:{roles:[Role.Student]}
    },
    {
      path: 'volunteering',
      loadChildren: () => import('./volunteering/volunteering.module').then(module => module.VolunteeringModule),
      canActivate : [Authorize],
      data:{roles:[Role.Student]}
    },
    {
      path: 'workingexperience',
      loadChildren: () => import('./workexperience/workexperience.module').then(module => module.WorkexperienceModule),
      canActivate : [Authorize],
      data:{roles:[Role.Student]}
    }

  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProfileviewRoutingModule { }
