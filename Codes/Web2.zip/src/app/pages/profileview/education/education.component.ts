import { Component, OnInit, ViewChild, ElementRef, HostListener, OnDestroy, AfterViewInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { BaseComponent } from '@app-core/base.component';
import { ContextContainer } from '@app-core/context-container';
import { DegreeDetails } from '@models/education';
import { LangChangeEvent } from '@ngx-translate/core';
import { environment } from 'environments/environment';
import { BsDatepickerViewMode, BsDatepickerConfig, BsDatepickerDirective } from 'ngx-bootstrap/datepicker';
import { InstituteNameMasterModel } from '@models/InstituteNameMasterModel';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { MyprofileService } from '@services/myprofile.service';
import { variable } from '@angular/compiler/src/output/output_ast';




@Component({
  selector: 'app-education',
  templateUrl: './education.component.html',
  styleUrls: ['./education.component.scss'],
  providers: []
})


export class EducationComponent extends BaseComponent implements AfterViewInit {

  datePickerValue: Date = new Date();
  minMode: BsDatepickerViewMode = 'month';
  dateInputFormat: string
  bsConfig: Partial<BsDatepickerConfig>;
  dtTrigger: Subject<any> = new Subject<any>();
  @ViewChild(DataTableDirective) dtElement: DataTableDirective;

  @ViewChild(BsDatepickerDirective, { static: false }) datepicker: BsDatepickerDirective;
  degreeMaster: any = [];
  specMaster: any = [];

  @HostListener('window:scroll')
  onScrollEvent() {
    this.datepicker.hide();
  }
  @ViewChild('search', { static: false }) searchElement: ElementRef;
  isFormVisible: boolean = false;
  saveInProgress: boolean;
  IsGpaSelected: boolean = false;
  gpaPercentSelected: boolean = true;
  edu: any=[]
  edudetail: edudetail [];
  model: any = {};
  majorMaster = [];
  specs = [];
  unfilteredMajorMaster= [];
  UnfilterSpecMaster = [];
  courseType = [];
  data: any = [];
  degreeMajor = [];
  specialization = [];
  degreeDetailUrl: string = '/StudentProfile/DegreeDetails/';
  courseTypeUrl: string = '/DropdownDetails/CourseTypeMaster';
  instituteNameUrl: string = '/StudentProfile/InstituteMaster';
  instituteUrl: string ='/DropdownDetails/instituteNameMaster';
  degreeUrl: string ='/DropdownDetails/DegreeMaster';
  MajorUrl: string ='/DropdownDetails/MajorMaster';
  specUrl: string ='/DropdownDetails/SpecializationMaster';
  instituteNameMaster: any = [];
  instituteNameArray: any = [];
  degDetail: DegreeDetails = {

    Id: 0,

    StudentId: 0,

    DegreeId: null,

    MajorId: null,

    CompletionYear: '',

    CourseTypeId: null,
    CourseNameEn:'',
    CourseNameAr:'',

    Institute: '',

    GPA: '',

    SpecializationId: null,

    Percentage: '',

    IsGpaSelected: true,

    CreatedBy: '',

    UpdatedBy: ''
  };

  Qualification= {
    YearOfCompletion: ''
  }
  saveInstituteCombo: InstituteNameMasterModel = {
    Institute: '',
  }
  studentId: any;
  slang: string = 'en'
  show: boolean = false;
  gpaError: boolean = false;
  percentageError: boolean = false;
  keyword: string = 'institute';
  userId: any;
  eduDuplicateValidate: boolean = false;


  constructor(contextContainer: ContextContainer, private myprofileService: MyprofileService) {
    super(contextContainer);
  }

  ngOnInit(): void {
    this.getDegreeDetail();
    this.getDropDown();
    this.getInstituteName();
    this.getMajor();
    this.getSpec();
    this.getDegree();
    this.saveInProgress = false;
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang
    });
    this.bsConfig = Object.assign({}, {
      minMode: this.minMode,
      dateInputFormat: 'MM-YYYY'
    });
  }

  ngAfterViewInit() {
    this.context.datatableService.init(this.dtElement);
  }

  getInstituteName() {
    this.context.httpService.get(environment.academicsUrl + this.instituteUrl)
      .subscribe(
        (response) => {
          this.instituteNameArray = [];
          this.instituteNameMaster = response.data || [];
          for (let ins of this.instituteNameMaster) {
            this.instituteNameArray.push(ins.institute)
          }
        });
  }

  myTrim(x) {
    return x.replace(/^\s+|\s+$/gm, '');
  }

  change(event: any) {
    this.saveInstituteCombo.Institute = this.saveInstituteCombo.Institute != null ? this.myTrim(this.saveInstituteCombo.Institute) : null;
    if (this.saveInstituteCombo.Institute != '' && this.saveInstituteCombo.Institute != null ) {
      var arrayContains = (this.instituteNameArray.indexOf(this.saveInstituteCombo.Institute) > -1);
      if (!arrayContains) {
        this.context.httpService.post(environment.academicsUrl + this.instituteNameUrl, this.saveInstituteCombo, { params: { handleResponse: false } })
          .subscribe(
            (response) => {
              this.getInstituteName();
            }
          );
      }
    }
  }

  dateValid(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if ((charCode > 46 && charCode < 58) || charCode == 46) {
      return true;
    }
    return false;
  }
  // get getStudentId(): number {
  //   this.studentId = this.context.authenticationService.getStudentId();
  //   var access_token = this.studentId.source.value;
  //   return access_token;
  //   //return 2;
  // }
  // get getUserId(): string {
  //   this.userId = this.context.authenticationService.getUserId()
  //   var access_token = this.userId.source.value;
  //   return access_token;
  // }

  onChangeGetMajorDp(value: any) {
    this.eduDuplicate();
    if (this.degDetail.DegreeId == null) {
      this.majorMaster = [];
      this.specMaster = [];
    }
    else {
      this.majorMaster = [];
      this.degDetail.MajorId = null;
      this.specMaster = [];
      this.degDetail.SpecializationId = null;
      if (this.degDetail.DegreeId == 5 || this.degDetail.DegreeId == 6) {
        this.majorMaster = [];
        this.specMaster = [];
        this.degDetail.CourseTypeId = null;
      }
      else {
        this.majorMaster = this.unfilteredMajorMaster.filter( item => this.degDetail.DegreeId == item.degreeId);

        if (this.degDetail.MajorId != null) {
          this.specMaster = [];
          this.degDetail.SpecializationId = null;
          this.onChangeGetSpecializationDp(this.degDetail.MajorId)
        }
        else {
          this.specMaster = [];
        }
      }
    }
  }

  onChangeGetSpecializationDp(value: any) {
    if (this.degDetail.MajorId == null) {
      this.specMaster = [];
      this.degDetail.SpecializationId = null;
    } else {
      this.specMaster = [];
      this.degDetail.SpecializationId = null;
      this.specMaster = this.UnfilterSpecMaster.filter(item => this.degDetail.MajorId == item.majorId);
    }

  }

  degreeDropDown(index: number, degreeMaster: any): number {
    return degreeMaster.degreeId;
  }

  majorDropDown(index: number, majorMaster: any): number {
    return majorMaster.majorId;
  }

  specializationDropDown(index: number, specMaster: any): number {
    return specMaster.specializationId;
  }

  courseTypeDropDown(index: number, courseType: any): number {
    return courseType.id;
  }

  tableIndexBy(index: number, eduDetail: any): number {
    return eduDetail.id
  }
  gpaPercentage(event){
    this.gpaPercentSelected = !this.gpaPercentSelected;
    if(this.gpaPercentSelected){
      this.degDetail.GPA=''
    }else{
      this.degDetail.Percentage=''
    }
  }
  // focusInput() {
  //   setTimeout(() => {
  //     this.searchElement.nativeElement.focus();
  //   }, 0);
  // }
  gpaValid(event: any) {
    var gpa = event.target.value;
    if ((gpa <= 10.00)&& ((gpa!==69)&&(gpa!==189)) ){

      this.gpaError = false;
      var gapstr = gpa.toString();
      this.degDetail.GPA = gapstr;
    }
    else {
      this.gpaError = true;
      this.degDetail.GPA = ''
    }
  }
  percentageValid(event: any) {


    var percentage = event.target.value

    if ((percentage <= 100.00) && ((percentage!==69)&&(percentage!==189) )){
      this.percentageError = false;
      this.degDetail.Percentage = percentage.toString();

    }
    else {
      this.percentageError = true;
      this.degDetail.Percentage = ''
    }
  }
  isInvalidGPA(){


    if(this.degDetail.IsGpaSelected && isNaN(parseInt(this.degDetail.Percentage)))
    {
      return true;
    }

    else if(!this.degDetail.IsGpaSelected && isNaN(parseInt(this.degDetail.GPA)))
    {
      return true;
    }

    if(this.degDetail.IsGpaSelected && ((parseInt(this.degDetail.Percentage)>100) || (parseInt(this.degDetail.GPA)<0)))
    {
      return true;
    }
    else if((parseInt(this.degDetail.GPA)>10) || (parseInt(this.degDetail.GPA)<0))
    {
      return true;
    }
    return false;
  }

  isNotANumber(val){
    return isNaN(val);
  }
  onSubmit(form: NgForm) {


    if (form.invalid) {
      this.notifyError('Please enter all the mandatory fields')
      return;
    }
if(this.degDetail.IsGpaSelected == true){
  this.degDetail.GPA = ''
}else{
  this.degDetail.Percentage =''
}
    if(this.isInvalidGPA())
    {
      return;
    }


    this.eduDuplicate();
    if(this.eduDuplicateValidate){
      this.notifyError("Data already exists");
      return;
    }

   // this.degDetail.Percentage = this.degDetail.Percentage
    this.degDetail.StudentId = this.context.getUserId();
    this.degDetail.CompletionYear = this.Qualification.YearOfCompletion
    this.degDetail.Institute = this.saveInstituteCombo.Institute;
    var compYear = new Date(this.degDetail.CompletionYear);
    if (compYear.toString() == 'Invalid Date') {
      var date = this.degDetail.CompletionYear.toString();
      var month = date.substring(0, 2);
      var year = date.substring(3, 7);
      this.degDetail.CompletionYear = year + '-' + month + '-04';
    } else {
      var edate = compYear;
      edate.setDate(edate.getDate() + 1);
      this.degDetail.CompletionYear = edate.toISOString();
    }
    if (this.degDetail.DegreeId == 5) {
      this.degDetail.CourseTypeId = 0;
      this.degDetail.CourseNameEn = null;
      this.degDetail.CourseNameAr = null;
      this.degDetail.MajorId = 50;
      this.degDetail.SpecializationId = 236;

    }
    if (this.degDetail.DegreeId == 6){
      this.degDetail.CourseTypeId = 0;
      this.degDetail.CourseNameEn = null;
      this.degDetail.CourseNameAr = null;
      this.degDetail.MajorId = 51;
      this.degDetail.SpecializationId = 237;
    }
    if (this.eduDuplicateValidate == false) {

      if (this.degDetail.IsGpaSelected == false) {
        this.degDetail.Percentage = null;
      }
      else {
        this.degDetail.GPA = null;
      }

      this.saveInProgress = true;

      if (this.degDetail.Id == 0 || this.degDetail.Id == null) {

        this.degDetail.CreatedBy = this.context.getUserId().toString();
        this.showCardProgress('form-card');
        this.context.httpService.post(environment.academicsUrl + this.degreeDetailUrl, this.degDetail).subscribe(
          (response) => {
            this.hideCardProgress('form-card');
            if (response.success) {
              this.notifySuccess('Saved Succesfully');
              this.resetForm(form);
              this.getDegreeDetail();
              this.isFormVisible = false;
              this.saveInProgress = false;
              this.myprofileService.persEmit(true);
            } else {
              this.notifyError('Failed to save data');
              this.isFormVisible = true;
              this.saveInProgress = false;
            }

          }, (error) => {
            this.saveInProgress = false;
          }
        );
      }
      else {
        var id = this.degDetail.Id;
        this.degDetail.UpdatedBy = this.context.getUserId().toString();
        this.context.httpService.put(environment.academicsUrl + this.degreeDetailUrl + id,
          this.degDetail).subscribe(
            (response) => {
              if (response.success) {
                this.getDegreeDetail();
                this.notifySuccess('Saved Succesfully');
                this.resetForm(form);
                this.isFormVisible = false;
                this.saveInProgress = false;
                this.myprofileService.persEmit(true);
              } else {
                this.notifyError('Failed to save data');
                this.isFormVisible = true;
                this.saveInProgress = false;
              }
            }, (error) => {
              this.saveInProgress = false;
            }
          );
      }
    }
  }
  getDegreeDetail() {
    this.showCardProgress('grid-card');
    this.context.httpService.get(environment.academicsUrl + this.degreeDetailUrl + this.context.getUserId()).subscribe(
      (response) => {
        this.hideCardProgress('grid-card');
        this.edudetail = response.data || [];
        this.context.datatableService.reRender('datatable');
        this.edudetail.forEach(edu => {
          if (edu.courseTypeId == 0  && (edu.majorId ==50 || edu.majorId ==51)&& (edu.specializationId == 236 || edu.specializationId == 237)) {
            edu.courseNameEn = 'Not Applicable';
            edu.courseTypeId = null;
            edu.specializationName = 'Not Applicable';
            edu.specializationId = null;
            edu.majorName = 'Not Applicable';
            edu.majorId = null;

          }
          if (edu.gpa == null) {
            edu.gpa = edu.percentage+('%')
          }
          var date = edu.completionYear.toString();
          var month = date.substring(5, 7);
          var year = date.substring(0, 4);
          edu.completionYear = month + '-' + year
        })
      }
    );

  }

  getDropDown() {
    this.context.httpService.get(environment.academicsUrl + this.courseTypeUrl).subscribe(
      (response) => {
        this.courseType = response.data || [];
      });

  }
getDegree(){
  this.context.httpService.get(environment.academicsUrl + this.degreeUrl).subscribe(
    (response) => {
      this.degreeMaster = response.data || [];
    });
}
getMajor(){
  this.context.httpService.get(environment.academicsUrl + this.MajorUrl).subscribe(
    (response) => {
      this.majorMaster = response.data || [];
      this.unfilteredMajorMaster = response.data || [];
    });
}
getSpec(){
  this.context.httpService.get(environment.academicsUrl + this.specUrl).subscribe(
    (response) => {
      this.specMaster = response.data || [];
      this.UnfilterSpecMaster = response.data || [];
    });
}
  editRow(edu) {
    this.show = !this.show;
    this.isFormVisible = true;
    this.eduDuplicateValidate= false
    this.Qualification.YearOfCompletion = edu.completionYear
    this.saveInstituteCombo.Institute = edu.institute
    this.degDetail.CourseTypeId = edu.courseTypeId
    this.degDetail.Id = edu.id
    this.degDetail.DegreeId = edu.degreeId
    this.onChangeGetMajorDp(edu.degreeId)
    if (edu.degreeId == null || edu.degreeId == 5 || edu.degreeId == 6) {
      this.degDetail.MajorId = null;
      this.degDetail.SpecializationId = null;
    }
    else {
      this.degDetail.MajorId = edu.majorId;
      this.onChangeGetSpecializationDp(edu.majorId);
      this.degDetail.SpecializationId = edu.specializationId
    }
    var percent = edu.percentage+("%")
    if (edu.gpa == percent) {
      this.degDetail.IsGpaSelected = true;
      var per = edu.percentage.split("%");
      var perc = +per[0];
      var percen = perc.toLocaleString();
      this.degDetail.Percentage = percen;
    }
    else {
      this.degDetail.IsGpaSelected = false;
      this.degDetail.GPA = edu.gpa;
    }
  }
  courseChange(event: any){
     this.courseType.forEach(element => {
      if(element.id == this.degDetail.CourseTypeId){
        this.degDetail.CourseNameAr =element.arCourseTypeName
        this.degDetail.CourseNameEn =element.courseTypeIdName
      }
    });
  }
  deleteRow(x) {
    this.context.notificationService.confirmAlert((confirm) => {
      if (!confirm.dismiss)
        this.context.httpService.delete(environment.academicsUrl + this.degreeDetailUrl + x).subscribe(
          data => {
            if(data){
              this.notifySuccess('Deleted Successfully');
              this.myprofileService.persEmit(true);
            }else{
              this.notifyError('Failed to delete');
            }
            this.getDegreeDetail();
          }
        );
    }, 'Delete?');
   }

  public showForm(form: NgForm) {
    this.eduDuplicateValidate = false;
    this.saveInProgress = false;
    this.resetForm(form);
    this.isFormVisible = true;
  }

  public hideForm() {
    this.eduDuplicateValidate = false;
    this.isFormVisible = false;
    this.saveInProgress = false;
  }
  eduDuplicate() {
    let de = this.degDetail.DegreeId;
    let maj = this.degDetail.MajorId;
    let spec = this.degDetail.SpecializationId;
    let inst = this.saveInstituteCombo.Institute
    this.eduDuplicateValidate = false;
    if ( de === 5 || de === 6) {
      this.edudetail.forEach(element => {
        if ((element.degreeId === de) && (!element.id || element.id != this.degDetail.Id)) {
         return this.eduDuplicateValidate = true;
        }
      });
    } else {
      this.edudetail.forEach(element => {
        if (element.degreeId === de && element.majorId === maj && element.specializationId === spec && element.institute === inst
          && (!element.id || element.id != this.degDetail.Id)) {
          return this.eduDuplicateValidate = true;
        }
      });
    }
  }
  resetForm(form: NgForm) {

    this.degDetail = {
      Id: 0,
      StudentId: 0,
      DegreeId: null,
      MajorId: null,
      CompletionYear: '',
      CourseTypeId: null,
      CourseNameEn:'',
      CourseNameAr:'',
      Institute: '',
      SpecializationId: null,
      GPA: '',
      Percentage: '',
      IsGpaSelected: false,
      CreatedBy: '',
      UpdatedBy: '',
    };
    form.resetForm();
    this.degDetail.DegreeId = null;
    this.majorMaster = [];
    this.degDetail.MajorId = null;
    this.specMaster = [];
    this.degDetail.SpecializationId = null;
    this.degDetail.CourseTypeId = null;
    this.degDetail.IsGpaSelected = false;
    this.gpaError = false;
    this.percentageError = false;
    this.saveInProgress = false;
    this.eduDuplicateValidate = false;
    this.isFormVisible = false;
  }


  //ngOnDestroy(): void {
  //  // Do not forget to unsubscribe the event
  //  this.dtTrigger.unsubscribe();
  //}

  //destroyDatatable() {

  //  if (this.dtElement.dtInstance) {
  //    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
  //      dtInstance.destroy();
  //    });
  //  }
  //}
}


export class edudetail{
  degreeName: string;
  majorName: string;
  specializationName: string;
  completionYear: string;
  institute: string;
  courseTypeIdName: string;
  gpa: string;
  courseTypeId: number;
  majorId: number;
  specializationId: number;
  percentage: string;
  degreeId: number;
  id: number
  courseNameEn: string;
}
