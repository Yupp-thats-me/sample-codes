import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { PersonalDetail } from '@models/personalDetail';
import {  NgForm } from '@angular/forms';
import { LangService } from '@services/lang.service';
import { BaseComponent } from '@app-core/base.component';
import { ContextContainer } from '@app-core/context-container';
import { LangChangeEvent } from '@ngx-translate/core';
import { environment } from 'environments/environment';
import {  BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { MyprofileService } from '@services/myprofile.service';
import * as moment from 'moment';
import { ErrorCode } from '@app/app-core/constants/constants';
import { Router } from '@angular/router';


@Component({
  selector: 'app-personal-detail',
  templateUrl: './personal-detail.component.html',
  styleUrls: ['./personal-detail.component.scss']
})
export class PersonalDetailComponent extends BaseComponent implements OnInit {

  emirates = [];
  model: any = {};
  LanguageKnown = [];
  emirateValidate: boolean;
  phoneValidate: boolean;
  studentId: any;
  slang: string = "en"
  dateInputFormat: string;
  dropDownUrl: string = '/DropdownDetails/Emirates';
  personalDetailUrl: string = '/StudentProfile/PersonalDetails/';
  bsConfig: Partial<BsDatepickerConfig>;
  futureDate: boolean = false
  personalForm = {
    userId: 0,
    firstName: '',
    lastName: '',
    dob: '',
    gender: null,
    phone: null,
    emailId:'',
    identityId: '',

    language: '',
    currentAddress: '',
    poBox: '',
    IsCurrentAddress: false,
    permanentAddress: '',
  }
  perdet = {
    LanguageKnown: [],
    dateofbirth:''
  }

  previosFormValue: any;

  public profile: boolean = false;
    userId: any;
  emailValidate: boolean = false;keyPress: number;
  datval: boolean = false;
  isFormVisible: boolean = false;
  thumbnail: any;
  userid: number;
  array: any[];


  constructor(el:ElementRef, private langservice: LangService, contextContainer: ContextContainer, private myprofileService: MyprofileService,private router: Router) {
    super(contextContainer, el);
  }
  public maskMobileNo = [/\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/];
  public maskTelNo = [/\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/];
  public maskEmirate = [/\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, '-', /\d/];
  maxDate: Date;



  ngOnInit(): void {
    this.getpersonalForm()
    //this.getEmirates()
    this.profile = false;
    this.emirateValidate = false;
    this.phoneValidate = false;
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang
    });
    this.bsConfig = Object.assign({}, {

      dateInputFormat: 'MM-DD-YYYY'

    });
    this.maxDate = new Date();
    //this.maxDate.setDate(this.maxDate.getDate() - 1);
  }


  editProfile(form: NgForm) {
    if (!this.profile) {
      this.profile = !this.profile
      this.editfield();
    }
    else {
      this.closeEdit(form);
    }
  }

  get getStudentId(): number {
    this.studentId = this.context.authenticationService.getStudentId();
    var access_token = this.studentId.source.value;
    return access_token;
  }

  get getUserId(): string {
    this.userId = this.context.authenticationService.getUserId();
    var access_token = this.userId.source.value;
    return access_token;
  }

  onSubmit(form: NgForm) {

    if (form.invalid || this.phoneValidate) {
      this.notifyError('Please enter all the mandatory fields')
      return;
    }
    this.changesInPersonal(form)
  }

  changesInPersonal(form: NgForm) {
    //this.clr()
    this.array = this.perdet.LanguageKnown;
    if (this.array != []) {
      var arraylanguage = [];
      var array = '';
      this.array.forEach(lang => {
        arraylanguage.push(lang.value);
        })

        array = arraylanguage.join(',');
    } else {
      array = '';
    }


    var id = this.getStudentId;


    if (this.datval) {
      var DOB = this.personalForm.dob;
      this.personalForm.dob = moment(DOB).format("YYYY-MM-DD").toString();
    }
    const formData = new FormData();
    formData.append('model.UserId', this.personalForm.userId.toString());
    formData.append('model.IdentityId', this.personalForm.identityId);
    formData.append('model.FirstName', this.personalForm.firstName);
    formData.append('model.Lastname', this.personalForm.lastName);
    formData.append('model.Gender', this.personalForm.gender.toString());
    formData.append('model.Phone', this.personalForm.phone);
    formData.append('model.EmailId', this.personalForm.emailId);
    formData.append('model.DOB', this.personalForm.dob);

    formData.append('model.Language', array);
    formData.append('model.CurrentAddress', this.personalForm.currentAddress);
    formData.append('model.PermanentAddress', this.personalForm.permanentAddress);
    formData.append('model.POBox', this.personalForm.poBox);

    if(this.emailValidate != true){
      this.showCardProgress('form-card')
    this.context.httpService.post(environment.accounturl + '/User/personal-details',
      formData).subscribe(
        (response) => {
          form.reset
          this.getpersonalForm();

          if (response.success) {
            this.isFormVisible = false;
            this.hideCardProgress('form-card')
            this.notifySuccess('Saved Succesfully')
            this.myprofileService.persEmit(true);
          }
          else {
            this.hideCardProgress('form-card')
            this.isFormVisible = true;
            if (response.errorCode == ErrorCode.Duplicate) {
              this.notifyError("Emirate Id already exists");
            } else {
              this.notifyError('Failed to save data');
            }
          }
        }, (error) => {
          this.isFormVisible = true;
          this.hideCardProgress('form-card')
        } );
    }
  }

  editfield() {
    this.isFormVisible = true;
    if(this.personalForm.dob){
    var myDOB = new Date(this.personalForm.dob);
      var dat = moment(myDOB).format('MM-DD-YYYY');
    this.datval =  true;
    }
    else{
     this.datval = false;
    }
    if (this.personalForm.language) {
      var array = this.personalForm.language.split(',');
      var arraylanguage = [];
      array.forEach(lang => {
        var data = {
          display: lang,
          value: lang
        }

        arraylanguage.push(data)
        this.perdet.LanguageKnown = arraylanguage;
      });
    } else {
      this.perdet.LanguageKnown = [];
    }
 if(this.personalForm.gender == 1){
   this.personalForm.gender ='Male';
 }
 else{
  this.personalForm.gender ='Female';
 }
    this.personalForm.firstName = this.personalForm.firstName
    this.personalForm.lastName = this.personalForm.lastName
    this.personalForm.gender = this.personalForm.gender

    this.personalForm.phone = this.personalForm.phone
    this.personalForm.identityId = this.personalForm.identityId
    this.personalForm.emailId = this.personalForm.emailId
    this.personalForm.dob = dat
    this.personalForm.currentAddress = this.personalForm.currentAddress
    this.personalForm.IsCurrentAddress = this.personalForm.IsCurrentAddress
    this.personalForm.poBox = this.personalForm.poBox
    this.personalForm.permanentAddress = this.personalForm.permanentAddress
    this.personalForm.poBox = this.personalForm.poBox
    this.personalForm.userId = this.personalForm.userId
  }


  closeEdit(form: NgForm) {
    if (!this.previosFormValue) this.previosFormValue = form.value;
    if(JSON.stringify(this.previosFormValue) !== JSON.stringify(form.value)) {
      this.context.notificationService.editDeleteALert((confirm) => {
        if (confirm.dismiss) {
          this.isFormVisible = true;
        } else {
          this.previosFormValue = form.value;
          this.onSubmit(form)
        }
      });
    }
    else {
      this.getpersonalForm();
      this.isFormVisible = false;
    }

  }

  dateValid(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if ((charCode > 46 && charCode < 58) || charCode == 46) {
      return true;
    }
    return false;
  }
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  getpersonalForm() {
    this.showCardProgress('form1-card')
    this.userid = this.context.getUserId();
    this.context.httpService.get(environment.accounturl + '/User/personal-details').subscribe(
      (results) => {
        if (results && results.success) {
          if (results.data) {
            this.personalForm = results.data;
            this.personalForm.poBox = this.personalForm.poBox ? this.personalForm.poBox : '';
            this.hideCardProgress("form1-card");
            this.personalForm.dob = moment(this.personalForm.dob).format('MM/DD/yyyy');
            //this.thumbnail = this.personalForm.profilePic;
          }
        }
      }
    )
  }

  getEmirates() {
    this.context.httpService.get(environment.academicsUrl + this.dropDownUrl).subscribe(
      (response) => {
        this.emirates = response.data || [];
      }
    );
  }

  trackById(index: number, emirates: any): number {
    return emirates.emiratesId;
  }

  copyaddress(event, form) {

    if (event.target.checked) {
      this.personalForm.permanentAddress = this.personalForm.permanentAddress
      this.personalForm.poBox = this.personalForm.poBox
    } else {
      this.personalForm.permanentAddress = ''
      this.personalForm.poBox = ''
    }

  }
  navigateMyProfile()
  {
    this.router.navigate(['user/profile'], { queryParams: { returnUrl: this.router.url } });
  }
  addressChange()
  {
    if (this.personalForm.IsCurrentAddress == true)
    {
      this.personalForm.permanentAddress = this.personalForm.currentAddress
      this.personalForm.poBox = this.personalForm.poBox
    }
  }

  clr(form:NgForm)

  {
    //this.perdet.dateofbirth = event.target.value;
    this.personalForm.dob = moment(this.perdet.dateofbirth).format('MM-DD-YYYY');
    // var date = new Date();
    // var setmaxdate = moment(date).format('MM-DD-YYYY');
    if (moment(this.personalForm.dob).isSameOrAfter(new Date())) {
      this.personalForm.dob=null;
      this.perdet.dateofbirth=null;
      form.form.value.dateofbirth= null;
      this.futureDate = true
    }
    else {
      this.futureDate = false
    }
  }

  clrEmail() {
    this.emailValidate = false;
  }

  clremirate() {
    this.emirateValidate = false;
  }
  clrPhonNo() {
    this.phoneValidate = false;
  }
   checkLang(event){
     var charCode;
     charCode = event.charCode;
     return ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123));
   }

  textWrap(word: string) {
    if(word){
    return word.length > 30 ? word.substring(0, 30) + "..." : word;
    }
  }
  textWrap1(word: string) {
    if(word){
    return word.length > 30 ? word.substring(0, 30) + "..." : word;
    }
  }
}
