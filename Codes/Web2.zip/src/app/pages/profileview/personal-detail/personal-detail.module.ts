import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PersonalDetailRoutingModule } from './personal-detail-routing.module';
import { BsDatepickerModule, DatepickerModule } from 'ngx-bootstrap/datepicker';
import { AngularDualListBoxModule } from 'angular-dual-listbox';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient } from '@angular/common/http';
import { baseModule } from '@app-core/Common Modules/baseModule';
import { PersonalDetailComponent } from './personal-detail.component';
import { NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';


@NgModule({
  declarations: [PersonalDetailComponent],
  imports: [
    CommonModule,
    PersonalDetailRoutingModule,
    BsDatepickerModule.forRoot(),
    DatepickerModule.forRoot(),
    AngularDualListBoxModule,
    NgbTooltipModule,
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: httpTranslateLoader,
        deps: [HttpClient]
      }
    }),
    baseModule
  ],
  exports: [PersonalDetailComponent]
})
export class PersonalDetailModule { }

export function httpTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http);
}
