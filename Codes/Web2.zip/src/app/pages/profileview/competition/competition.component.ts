import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { ContextContainer } from 'app/app-core/context-container';
import { NgForm } from '@angular/forms';
import { AccomplishmentModel } from '@models/accomplishment.model';
import { AccomplishmentsComponent } from '@pages/profileview/accomplishments/accomplishments.component';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { Subject } from 'rxjs';
import { DataTableDirective } from 'angular-datatables';
import * as moment from 'moment';

@Component({
  selector: 'app-competition',
  templateUrl: './competition.component.html',
  styleUrls: ['./competition.component.scss']
})
export class CompetitionComponent extends AccomplishmentsComponent implements AfterViewInit {

  dtTrigger: Subject<any> = new Subject<any>();
  @ViewChild(DataTableDirective) dtElement: DataTableDirective;
  bsConfig: Partial<BsDatepickerConfig>;
  model:AccomplishmentModel=new AccomplishmentModel();
  public modelPopup: any;
  maxDate: Date;
  minDate: Date;
  gridData: gridData[];
  accomplishmentTypeId:number;
  isFormVisible: boolean;
  saveInProgress: boolean;
  duplicateTitle: boolean = false;
  duplicateDate: boolean = false;
  futureDate: boolean = false
  comp = {
    compDate:''
  }
  constructor(context:ContextContainer) { super(context);

    this.accomplishmentTypeId = 4;
    this.hideForm();
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate());
    this.minDate = new Date(2000, 0, 1);
    this.saveInProgress = false;
  }

  ngOnInit(): void {
    this.gridData = [];
    this.bsConfig = Object.assign({}, {
      dateInputFormat: 'MM/DD/YYYY',
      showWeekNumbers:false,
      customTodayClass: 'custom-today-class'
    });

    this.loadCompetitionGrid();
  }

  ngAfterViewInit() {
    this.context.datatableService.init(this.dtElement);
  }

  onSubmit(form: NgForm) {
    if (form.invalid) {
      return this.notifyError('Please enter all the mandatory fields');
    }
    this.initDuplicateValidations();
    if(this.duplicateTitle){
      this.notifyError("Data already exists");
      return;
    }

    this.saveInProgress = true;
    this.showCardProgress('form-card');
    this.model.startDate = this.comp.compDate;
    if (this.model.id == 0 || this.model.id == null) {
      var data = this.model;
      data.accomplishmentTypeId = this.accomplishmentTypeId;
      var date = new Date(this.model.startDate);
      data.startDate = moment(date).format("YYYY-MM-DD").toString();
      this.saveData(data).subscribe(
        (response) => {
          if (response.success) {
            this.hideCardProgress('form-card');
            this.notifySuccess('Saved Succesfully');
            this.hideForm();
            this.loadCompetitionGrid();
            this.saveInProgress = false;
          }
          else{
            this.notifyError('Failed to save data');
            this.hideCardProgress('form-card');
          }
        },(error)=>{
          this.saveInProgress= false;
          this.hideCardProgress('form-card');
        }
      );
    }

    else {
      var data = this.model;
      data.accomplishmentTypeId = this.accomplishmentTypeId;
      var date = new Date(this.model.startDate);
      data.startDate = moment(date).format("YYYY-MM-DD").toString();
    this.showCardProgress('form-card');
      this.saveData(data).subscribe(

        (response) => {
          if (response.success) {
            this.notifySuccess('Saved Succesfully');
            this.hideForm();
            this.loadCompetitionGrid();
            this.saveInProgress = false;
            this.hideCardProgress('form-card');
          }
          else{
            this.hideCardProgress('form-card');
            this.notifyError('Failed to save data');
          }
        },(error)=>{
          this.hideCardProgress('form-card');
          this.saveInProgress= false;
        }
      );
    }
  }

  onEdit(data: any) {
    this.bindData(data);
    this.isFormVisible = true;
  }

  onDelete(id: number) {

    let accomplishmentTypeId = this.accomplishmentTypeId;

    this.context.notificationService.confirmAlert((confirm) => {
      if (!confirm.dismiss) {
        this.deleteRow(id, accomplishmentTypeId).subscribe(
          (response) => {
            if (response.success) {
              this.notifySuccess('Deleted Successfully')
              this.loadCompetitionGrid();
            }else{
              this.notifyError('Failed to delete')
            }
          }
        );
      }
    }, 'Delete?')
  }

  bindData(data) {
    this.saveInProgress = false;
    this.model = new AccomplishmentModel();
    this.model.title = data.title;
    var myStartDate = new Date(data.startDate);
    var dat = moment(myStartDate).format('MM-DD-YYYY');
    this.comp.compDate = dat;
    this.model.id = data.id;
    this.model.testScore = data.testScore;
    this.model.description = data.description;
  }

  loadCompetitionGrid() {

   this.showCardProgress('grid-card')
    this.loadGrid(this.accomplishmentTypeId).subscribe(

      (response) => {
        if (response.success) {
          this.hideCardProgress('grid-card')
          this.gridData = response.data || [];
          this.context.datatableService.reRender('datatable');
        }else{
          this.hideCardProgress('grid-card')
        }
      },(error)=>{
        this.hideCardProgress('grid-card')
      },
    );
  }

  initDuplicateValidations() {
    let title = this.model.title.toLocaleLowerCase();
    let currentDate = moment(this.comp.compDate).format('MM/DD/YYYY');
    this.duplicateTitle = false;
      this.gridData.forEach(element => {
        var dateOfEvent = moment(element.startDate).format('MM/DD/YYYY');
        if (element.title.toLocaleLowerCase() == title && moment(dateOfEvent).isSame(moment(currentDate)) && (!element.id || element.id != this.model.id)) {
          this.duplicateTitle = true;
          this.saveInProgress = false;
        }
      });
  }

  clr()
  {
    if (moment(this.comp.compDate).isAfter(new Date())) {
      this.futureDate = true
      this.comp.compDate = '';
    }
    else {
      this.futureDate = false
    }
    this.duplicateTitle = false;
  }


  resetForm(form:NgForm){

    this.model.id = 0;
    this.model.startDate = '';
    this.model.title = '';
    this.model.testScore = '';
    this.model.description = '';
    this.duplicateTitle = false;
    this.saveInProgress = false;
    form.resetForm();
    this.hideForm();
  }


  public showForm(form:NgForm){
    this.saveInProgress = false;
    this.resetForm(form);
    this.isFormVisible = true;
    this.duplicateTitle = false;
  }

  public hideForm() {
    this.saveInProgress = false;
    this.isFormVisible = false;
    this.duplicateTitle = false;
  }

  textWrap(word: string) {
    return word.length > 30 ? word.substring(0, 30) + "..." : word;
  }

}


export class gridData {
  title: string;
  testScore: string;
  startDate: Date;
  description: string;
  id: number;
}
