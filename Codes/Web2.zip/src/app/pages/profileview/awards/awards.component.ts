import { Component, AfterViewInit, ViewChild, OnDestroy } from '@angular/core';
import { ContextContainer } from 'app/app-core/context-container';
import { AwardService } from '@services/award.service';
import { AccomplishmentModel } from '@models/accomplishment.model';
import { NgForm } from '@angular/forms';
import { AccomplishmentsComponent } from '@pages/profileview/accomplishments/accomplishments.component';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { Subject } from 'rxjs';
import { DataTableDirective } from 'angular-datatables';
import * as moment from 'moment';

@Component({
  selector: 'app-awards',
  templateUrl: './awards.component.html',
  styleUrls: ['./awards.component.scss']
})
export class AwardsComponent extends AccomplishmentsComponent implements AfterViewInit, OnDestroy {

  dtTrigger: Subject<any> = new Subject<any>();
  @ViewChild(DataTableDirective) dtElement: DataTableDirective;

  model:AccomplishmentModel=new AccomplishmentModel();
  public modelPopup: any;
  accomplishmentTypeId:number;
  gridData: gridData[];
  isFormVisible: boolean;
  bsConfig: Partial<BsDatepickerConfig>;
  maxDate: Date;
  minDate: Date;
  saveInProgress: boolean;
  duplicateTitle: boolean = false;
  duplicateDate: boolean = false;
  futureDate: boolean = false
  award = {
    awdDate: ''
  }

  constructor(context:ContextContainer, private service:AwardService) { super(context);
    this.gridData = [];
    this.accomplishmentTypeId = 5;
    this.hideForm();
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate());
    this.minDate = new Date(2000, 0, 1);
    this.saveInProgress = false;
  }

  ngOnInit(): void {
    this.gridData = [];
    this.loadTestScoreGrid()
    this.bsConfig = Object.assign({}, {
      dateInputFormat: 'MM/DD/YYYY',
      showWeekNumbers:false,
      customTodayClass: 'custom-today-class'
    });

  }

  ngAfterViewInit() {
    this.context.datatableService.init(this.dtElement);
  }

  onSubmit(form: NgForm) {
    if (form.invalid) {
      return this.notifyError('Please enter all the mandatory fields');

    }
    this.initDuplicateValidations();
    if(this.duplicateTitle){
      this.notifyError("Data already exists");
      return;
    }

    this.showCardProgress('form-card')

    this.saveInProgress = true;
    this.model.startDate = this.award.awdDate;
    if (this.model.id == 0 || this.model.id == null) {
      var data = this.model;
      data.accomplishmentTypeId = this.accomplishmentTypeId;
      var date = new Date(this.model.startDate);
      data.startDate = moment(date).format("YYYY-MM-DD").toString();
      this.saveData(data).subscribe(

        (response) => {
          if (response.success) {
            this.notifySuccess('Saved Succesfully');
            this.hideForm();
            this.loadTestScoreGrid();
            this.saveInProgress = false;
            this.hideCardProgress('form-card')
          }
          else{
            this.notifyError('Failed to save data');
            this.hideCardProgress('form-card')
          }
        },(error)=>{
          this.saveInProgress= false;
          this.hideCardProgress('form-card')
        }
      );
    }
    else
    {
      var data = this.model;
      data.accomplishmentTypeId = this.accomplishmentTypeId;
      var date = new Date(this.model.startDate);
      data.startDate = moment(date).format("YYYY-MM-DD").toString();
      this.showCardProgress('form-card')
      this.saveData(data).subscribe(
        (response) => {
          if (response.success) {
            this.notifySuccess('Saved Succesfully');
            this.hideForm();
            this.loadTestScoreGrid();
            this.saveInProgress = false;
            this.hideCardProgress('form-card')
          }
          else{
            this.notifyError('Failed to save data');
            this.hideCardProgress('form-card')
          }
        },(error)=>{
          this.saveInProgress= false;
          this.hideCardProgress('form-card')
        }
      );
    }
  }

  onEdit(data: any) {

    this.bindData(data);
    this.isFormVisible = true;
  }

  onDelete(id: number) {
    let accomplishmentTypeId = this.accomplishmentTypeId;

    this.context.notificationService.confirmAlert((confirm) => {
      if (!confirm.dismiss) {
        this.deleteRow(id, accomplishmentTypeId).subscribe(
          (response) => {
            if (response.success) {
              this.notifySuccess('Deleted Successfully')
              this.loadTestScoreGrid();
            }
            else{
              this.notifyError('Failed to delete')
            }
          }
        );
      }
    }, 'Delete?')
  }

  bindData(data) {
    this.saveInProgress = false;
    this.model = new AccomplishmentModel();
    this.model.title = data.title;
    var myStartDate = new Date(data.startDate);
    this.award.awdDate = moment(myStartDate).format('MM-DD-YYYY');
    this.model.id = data.id;
    this.model.description = data.description;
  }

  loadTestScoreGrid() {
    this.showCardProgress('grid-card')
    this.loadGrid(this.accomplishmentTypeId).subscribe(
      (response) => {
        if (response.success) {
          this.gridData = response.data || [];
          this.context.datatableService.reRender('datatable');
          this.hideCardProgress('grid-card');
        }else{
          this.hideCardProgress('grid-card')
        }
      },(error) =>{
        this.hideCardProgress('grid-card')
      },
    );
  }

  initDuplicateValidations() {
    let title = this.model.title.toLocaleLowerCase();
    let currentDate = moment(this.award.awdDate).format('MM/DD/YYYY');
    this.duplicateTitle = false;
      this.gridData.forEach(element => {
        var dateOfEvent = moment(element.startDate).format('MM/DD/YYYY');
        if (element.title.toLocaleLowerCase() == title && moment(dateOfEvent).isSame(moment(currentDate)) && (!element.id || element.id != this.model.id))
        {
          this.duplicateTitle = true;
          this.saveInProgress = false
        }
      });
  }

  clr() {
    if (moment(this.award.awdDate).isAfter(new Date())) {
      this.futureDate = true
      this.award.awdDate = '';
    }
    else {
      this.futureDate = false
    }
    this.duplicateTitle = false;
  }

  resetForm(form:NgForm){

    this.model.id = 0;
    this.model.startDate = '';
    this.model.title = '';
    this.model.testScore = '';
    this.model.description = '';
    this.duplicateTitle = false;
    this.saveInProgress = false;
    form.resetForm();
    this.hideForm();
  }

  public showForm(form:NgForm){
    this.saveInProgress = false;
    this.resetForm(form);
    this.isFormVisible = true;
    this.duplicateTitle = false;
  }

  public hideForm() {
    this.saveInProgress = false;
    this.isFormVisible = false;
    this.duplicateTitle = false;
  }


  textWrap(word: string) {
    return word.length > 30 ? word.substring(0, 30) + "..." : word;
  }

}


export class gridData {
  title: string;
  startDate: Date;
  description: string;
  id: number;
}
