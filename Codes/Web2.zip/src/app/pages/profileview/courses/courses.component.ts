import { Component, OnInit, ViewChild, ElementRef, HostListener, OnDestroy, AfterViewInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { CertificationDetails } from '@models/certificationDetail-model';
import { ContextContainer } from 'app/app-core/context-container';
import { BaseComponent } from 'app/app-core/base.component';
import { environment } from 'environments/environment';
import { BsDatepickerViewMode, BsDatepickerConfig, BsDatepickerDirective } from 'ngx-bootstrap/datepicker';
import { InstituteNameMasterModel } from '@models/InstituteNameMasterModel';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';


@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.scss'],
  providers: []
})
export class CoursesComponent extends BaseComponent implements AfterViewInit {
  dtTrigger: Subject<any> = new Subject<any>();
  @ViewChild(DataTableDirective) dtElement: DataTableDirective;
  @ViewChild('search', { static: false }) searchElement: ElementRef;
  isFormVisible: boolean = false;
  saveInProgress: boolean;
  certificationDetailUrl: string = '/StudentProfile/CertificationDetail/';
  certificationDetail: certificationDetail[];
  studentId: any
  show: any = false;
  datePickerValue: Date = new Date(2020, 7);
  minMode: BsDatepickerViewMode = 'month';
  dateInputFormat: string
  bsConfig: Partial<BsDatepickerConfig>;
  userId: any;
  instituteNameUrl: string = '/StudentProfile/InstituteMaster';
  dropDownUrl: string ='/DropdownDetails/instituteNameMaster';
  instituteNameMaster: any = [];
  instituteNameArray: any = [];
  certificateValidate: boolean = false;
  minDate: Date;

  @ViewChild(BsDatepickerDirective, { static: false }) datepicker: BsDatepickerDirective;


  @HostListener('window:scroll')
  onScrollEvent() {
    this.datepicker.hide();
  }

  public maskDateSlash = [/\d/, /\d/, '/', /\d/, /\d/, /\d/, /\d/];
  keyword: string = 'institute';
  NotExpire: boolean = false

  constructor(contextContainer: ContextContainer) {
    super(contextContainer);
    this.minDate = new Date();
    this.minDate.setMonth(this.minDate.getMonth()+1);
    this.minDate.setDate(1);

  }
  Courses = {
    CompletedYeardp: '',
  }

  CoursesDetail: CertificationDetails = {

    Id: 0,

    StudentId: 0,

    CertificationName: '',

    CompletedYear: '',

    IssuingAuthority: '',

    Institute: '',

    NotExpire: false,

    CreatedBy: '',

    UpdatedBy: ''
  };

  saveInstituteCombo: InstituteNameMasterModel = {
    Institute: '',
  }
  ngOnInit(): void {
    this.getInstituteName();
    this.getCertificationDetail()
    this.certificationDetail = [];
    this.CoursesDetail.NotExpire = false;
    this.saveInProgress = false;
    this.bsConfig = Object.assign({}, {
      minMode: this.minMode,
      dateInputFormat: 'MM /YYYY',
      customTodayClass: 'custom-today-class'

    });
  }

  ngAfterViewInit() {
    this.context.datatableService.init(this.dtElement);
  }

  // get getStudentId(): number {
  //   this.studentId = this.context.accountService.getUserId();
  //   var access_token = this.studentId.source.value;
  //   return access_token;

  //   //return 2;
  // }
  // get getUserId(): string {
  //   this.userId = this.context.accountService.getUserId();
  //   var access_token = this.userId.source.value;
  //   return access_token;
  // }
  focusInput() {
    setTimeout(() => {
      this.searchElement.nativeElement.focus();
    }, 0);
  }

  tableIndexBy(index: number, certificationDetail: any): number {
    return certificationDetail.id
  }

  onSubmit(form: NgForm) {

    if (form.invalid ) {
      this.notifyError('Please enter all the mandatory fields');
      return;
    }
    this.checkCertification();
    if(this.certificateValidate){
      this.notifyError("Data already exists");
      return;
    }

    this.CoursesDetail.StudentId = this.context.getUserId();
    this.CoursesDetail.Institute = this.saveInstituteCombo.Institute
    this.CoursesDetail.CompletedYear = this.Courses.CompletedYeardp
    this.saveInProgress = true;
    if (this.CoursesDetail.NotExpire == true)
    {
      this.CoursesDetail.CompletedYear = "1900-01-01"
    }
    else {
      var compYear = new Date(this.CoursesDetail.CompletedYear);
      if (compYear.toString() == 'Invalid Date') {
        var date = this.CoursesDetail.CompletedYear.toString();
        var month = date.substring(0, 2);
        var year = date.substring(3, 7);
        this.CoursesDetail.CompletedYear = year + '-' + month + '-04';
      }
      else {
        var edate = compYear;
        edate.setDate(edate.getDate() + 1);
        this.CoursesDetail.CompletedYear = edate.toISOString();
      }
    }

    if (this.CoursesDetail.Id == 0 || this.CoursesDetail.Id == null) {

        this.CoursesDetail.CreatedBy = this.context.getUserId().toString();
        this.showCardProgress('form-card');
          this.context.httpService.post(environment.academicsUrl + this.certificationDetailUrl, this.CoursesDetail).subscribe(
            (response) => {
              this.hideCardProgress('form-card');
              if (response.success) {
                this.notifySuccess('Saved Succesfully');
                this.resetForm(form);
                this.CoursesDetail.CompletedYear = '';
                this.CoursesDetail.NotExpire = false;
                this.getCertificationDetail();
                this.isFormVisible = false;
                this.saveInProgress = false;
              } else {
                this.notifyError('Failed to save data');
                this.isFormVisible = true;
                this.saveInProgress = false;
              }

            }, (error) => {
              this.saveInProgress = false;
            });
       }
      else {
        var id = this.CoursesDetail.Id;
        this.CoursesDetail.UpdatedBy = this.context.getUserId().toString();
        this.showCardProgress('form-card');
        this.context.httpService.put(environment.academicsUrl + this.certificationDetailUrl + id,
          this.CoursesDetail).subscribe(
            (response) => {
              this.hideCardProgress('form-card');
              if (response.success) {
                this.notifySuccess('Saved Succesfully');
                this.resetForm(form);
                this.CoursesDetail.CompletedYear = '';
                this.CoursesDetail.NotExpire = false;
                this.getCertificationDetail();
                this.isFormVisible = false;
                this.saveInProgress = false;
              } else {
                this.notifyError('Failed to save data');
                this.isFormVisible = true;
                this.saveInProgress = false;
              }
            }, (error) => {
              this.saveInProgress = false;
            }
          );
      }


  }


  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  public showForm(form: NgForm) {
    this.certificateValidate = false;
    this.saveInProgress = false;
    this.resetForm(form);
    this.isFormVisible = true;
  }

  public hideForm() {
    this.isFormVisible = false;
    this.certificateValidate = false;
    this.saveInProgress = false;
  }

  getInstituteName() {
    this.context.httpService.get(environment.academicsUrl + this.dropDownUrl)
      .subscribe(
        (response) => {
          this.instituteNameArray = [];
          this.instituteNameMaster = response.data || [];

          for (let ins of this.instituteNameMaster) {
            this.instituteNameArray.push(ins.institute)
          }
        });
  }

  myTrim(x) {
    return x.replace(/^\s+|\s+$/gm, '');
  }
  textWrap(word: string) {
    return word.length > 20 ? word.substring(0, 20) + "..." : word;
  }

  change(event: any) {
    this.saveInstituteCombo.Institute = this.saveInstituteCombo.Institute != null ? this.myTrim(this.saveInstituteCombo.Institute) : null;
    if(this.saveInstituteCombo.Institute!=null){
    this.checkCertification();
    }
    if (this.saveInstituteCombo.Institute != '' && this.saveInstituteCombo.Institute != null) {
      var arrayContains = (this.instituteNameArray.indexOf(this.saveInstituteCombo.Institute) > -1);
      if (!arrayContains) {
        this.context.httpService.post(environment.academicsUrl + this.instituteNameUrl, this.saveInstituteCombo, { params: { handleResponse: false } })
          .subscribe(
            (response) => {
              this.getInstituteName();
            }
          );
      }
    }
  }

  completedYear() {
    if (this.CoursesDetail.NotExpire) {
      this.Courses.CompletedYeardp = '';
    }
  }

  getCertificationDetail() {
    this.showCardProgress('grid-card');
    this.context.httpService.get(environment.academicsUrl + this.certificationDetailUrl + this.context.getUserId()).subscribe(
      (response) => {
        this.hideCardProgress('grid-card');
        this.certificationDetail = response.data || [];
        this.context.datatableService.reRender('datatable');

        this.certificationDetail.forEach(courses => {
          if (courses.notExpire == true) {
            courses.completedYear = 'No Expiry';
          } else {
            var date = courses.completedYear.toString();
            var month = date.substring(5, 7);
            var year = date.substring(0, 4);
            courses.completedYear = month + '-' + year
          }

        });
      }
    );
  }


  deleteRow(x) {
    this.context.notificationService.confirmAlert((confirm) => {
      if (!confirm.dismiss) {
        this.context.httpService.delete(environment.academicsUrl + this.certificationDetailUrl + x).subscribe(
          data => {
            if (data != undefined) {
              this.notifySuccess('Deleted Successfully');
            } else {
              this.notifyError('Failed to delete');
            }
            this.getCertificationDetail();
          }
        );
      }
    }, 'Delete?');
  }

  dateValid(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if ((charCode > 46 && charCode < 58) || charCode != 46) {
      return true;
    }
    return false;
  }

  editRow(courses) {
    this.show = !this.show;
    this.focusInput();
    this.isFormVisible = true;
    this.certificateValidate = false;
    this.CoursesDetail.Id = courses.id
    this.CoursesDetail.CertificationName = courses.certificationName
    this.saveInstituteCombo.Institute = courses.institute
    this.CoursesDetail.IssuingAuthority = courses.issuingAuthority
    this.CoursesDetail.NotExpire = courses.notExpire
    if (this.CoursesDetail.NotExpire) {
      this.CoursesDetail.CompletedYear = '';
    }
    else {
      this.Courses.CompletedYeardp = courses.completedYear
    }
  }

  checkCertification() {

    let certifate = this.CoursesDetail.CertificationName.toLocaleLowerCase();
    let institute = this.saveInstituteCombo.Institute.toLocaleLowerCase();


    this.certificateValidate = false;
    this.certificationDetail.forEach(element => {


      if ((element.certificationName.toLocaleLowerCase() === certifate &&
        element.institute.toLocaleLowerCase() === institute) && (!element.id || element.id != this.CoursesDetail.Id)
       ) {
        this.certificateValidate = true;
      }
    });
  }
  cousesValid(event) {
    if (this.certificateValidate) {
      this.checkCertification();
    }
  }
  resetForm(form: NgForm) {

    this.CoursesDetail = {
      Id: 0,

      StudentId: 0,

      CertificationName: '',

      CompletedYear: '',

      IssuingAuthority: '',

      Institute: '',

      NotExpire: false,

      CreatedBy: '',

      UpdatedBy: ''

    };
    form.resetForm();
    this.Courses.CompletedYeardp = '';
    this.CoursesDetail.NotExpire = false;
    this.certificateValidate = false;
    this.saveInProgress = false;
    this.hideForm();
  }

}


export class certificationDetail {
  certificationName: string;
  completedYear: string;
  institute: string;
  issuingAuthority: string;
  notExpire: boolean;
  id: number;
}
