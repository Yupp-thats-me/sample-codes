import { AfterViewInit, Component, ElementRef, HostListener, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { DataTableDirective } from 'angular-datatables';
import { ContextContainer } from 'app/app-core/context-container';
import { BaseComponent } from 'app/app-core/base.component';
import { Internship } from '@models/internship.model';
import { LangChangeEvent } from '@ngx-translate/core';
import { environment } from 'environments/environment';
import { BsDatepickerConfig, BsDatepickerDirective } from 'ngx-bootstrap/datepicker';
import { Subject } from 'rxjs';
import * as moment from 'moment';




@Component({
  selector: 'app-workexperience',
  templateUrl: './workexperience.component.html',
  styleUrls: ['./workexperience.component.scss']
})
export class WorkExperienceComponent extends BaseComponent implements AfterViewInit, OnDestroy {
  dtTrigger: Subject<any> = new Subject<any>();
  @ViewChild(DataTableDirective) dtElement: DataTableDirective;
  @ViewChild('search', { static: false }) searchElement: ElementRef;
  @ViewChild(BsDatepickerDirective, { static: false }) datepicker: BsDatepickerDirective;
  isFormVisible: boolean = false;
  datePickerValue: Date = new Date();
  edatePickerValue: Date = new Date();
  dateInputFormat: string
  saveInProgress: boolean
  bsConfig: Partial<BsDatepickerConfig>;
  studentId: any;
  createdBy: any;
  updatedBy: any;
  workType: any;
  slang: string = 'en';
  internURL: string = '/StudentProfile/WorkExperience/';
  dropDownUrl: string = '/DropdownDetails/workType';
  endDate: boolean = false;
  maxDate: Date;
  minDate: Date;
  futureDate: boolean = false;
  userId: any;
  @HostListener('window:scroll')
  onScrollEvent() {
    this.datepicker.hide();
  }
  workTypeDetails: Internship =

    {
      Id: 0,
      StudentId: 0,
      ReferenceId: 0,
      WorkTypeId: null,
      Organization: '',
      StartDate: '',
      EndDate: '',
      JobDescription: '',
      CreatedBy: '',
      UpdatedBy: '',
      CurrentWork: false
    }
  wrk = {
    startDt: '',
    endDt: ''
  }
  workTypesDetail: workTypesDetail[];
  myString: any;
  show: boolean = false;
  form: NgForm;
  endDateValidate: boolean = false;
  startDateValidate: boolean = false;
  organisationValidate: boolean = false;
  startDt: Date;
  endDt: Date;
  minDate1: Date;
  maxDate1: Date;
  constructor(context: ContextContainer) {
    super(context);
    this.endDateValidate = false;
    this.startDateValidate = false;
    this.organisationValidate = false;
    this.endDate = false;
    this.saveInProgress = false;
    //this.workType =
    //  [{ id: 2, name: "Internships" }, { id: 3, name: "Professional Experience" }, { id: 1, name: "Work Placement" }]
  }

  ngOnInit(): void {
    this.workTypesDetail = [];
    this.getWorkExperience();
    this.getWorkType();
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang
    });
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate());
    this.maxDate1 = new Date();
    this.maxDate1.setDate(this.maxDate.getDate());
    this.minDate = new Date(2000, 0, 1);
    this.bsConfig = Object.assign({}, {
      dateInputFormat: 'MM/DD/YYYY',
      showWeekNumbers:false,
      customTodayClass: 'custom-today-class'
    });
  }

  ngAfterViewInit() {
    this.context.datatableService.init(this.dtElement);
  }
  public showForm(form: NgForm) {
    this.resetForm(form);
    this.saveInProgress = false;
    this.isFormVisible = true;
    this.organisationValidate = false;
  }

  public hideForm() {
    this.isFormVisible = false;
    this.saveInProgress = false;
  }
  onSubmit(form: NgForm) {
    
    if (this.wrk.endDt) {
      this.clrEd(this.form);
    } else {
      this.wrk.endDt = ''
       this.endDateValidate = false;
    }

    if (form.invalid) {
      return this.notifyError('Please enter all the mandatory fields');
    }

    this.checkOrganisation();
    if(this.organisationValidate){
      this.notifyError("Data already exists");
      return;
    }

    this.saveInProgress = true;

    var startDate = this.wrk.startDt;
    var endate = this.wrk.endDt
    this.workTypeDetails.StudentId = this.getStudentId;

    this.workTypeDetails.CreatedBy = this.getUserId.toString();

    this.workTypeDetails.UpdatedBy = this.getUserId.toString();
    this.showCardProgress('form-card')
    if (this.workTypeDetails.Id == 0 || this.workTypeDetails.Id == null) {

      this.workTypeDetails.StartDate = moment(startDate).format("YYYY-MM-DD").toString();
      if (this.workTypeDetails.CurrentWork == true) {
        this.workTypeDetails.EndDate = '1900-01-01';
        this.workTypeDetails.CurrentWork = true;
      }
      else {
        this.workTypeDetails.EndDate = moment(endate).format("YYYY-MM-DD").toString();
        this.workTypeDetails.CurrentWork = false;
      }
      this.context.httpService.post(environment.academicsUrl + this.internURL + this.workTypeDetails.StudentId, this.workTypeDetails).subscribe(
        (response) => {
          if (response.success) {
            this.resetForm(form);
            this.getWorkExperience();
            this.notifySuccess('Saved Succesfully');
            this.isFormVisible = false;
            this.saveInProgress = false;
            this.hideCardProgress('form-card')
          } else {
            this.isFormVisible = true;
            this.saveInProgress = false;
            this.notifyError('Failed to save data');
            this.hideCardProgress('form-card')
          }
        }, (error) => {
          this.saveInProgress = false;
          this.hideCardProgress('form-card')
        });
    }
    else {
      this.checkOrganisation();
      if (form.invalid || this.organisationValidate) {
        return;
      }
      var date = new Date(this.wrk.startDt);
      this.workTypeDetails.StartDate = moment(date).format("YYYY-MM-DD").toString();
      if (this.workTypeDetails.CurrentWork == true) {
        this.workTypeDetails.EndDate = '1900-01-01';
        this.workTypeDetails.CurrentWork = true;
      }
      else {
        var edate = new Date(this.wrk.endDt);
        this.workTypeDetails.EndDate = moment(edate).format("YYYY-MM-DD").toString();
        this.workTypeDetails.CurrentWork = false;
      }
      this.context.httpService.put(environment.academicsUrl + this.internURL + this.workTypeDetails.Id, this.workTypeDetails)
        .subscribe(
          (response) => {
            if (response.success) {
              this.resetForm(form);
              this.getWorkExperience();
              this.isFormVisible = false;
              this.saveInProgress = false;
              this.hideCardProgress('form-card')
              this.notifySuccess('Saved Succesfully');
            } else {
              this.isFormVisible = true;
              this.saveInProgress = false;
              this.hideCardProgress('form-card')
              this.notifyError('Failed to save data');
            }

          }, (error) => {
            this.saveInProgress = false;
            this.hideCardProgress('form-card')
          });
    }
  }

  resetForm(form: NgForm) {
    this.workTypeDetails = {
      Id: 0,
      StudentId: 0,
      ReferenceId: 0,
      Organization: '',
      WorkTypeId: 0,
      JobDescription: '',
      StartDate: '',
      EndDate: '',
      CreatedBy: '',
      UpdatedBy: '',
      CurrentWork: false
    };
    this.wrk.startDt = '';
    this.wrk.endDt = '';
    this.organisationValidate = false;
    this.saveInProgress = false;
    form.resetForm();
    this.hideForm();
  }

  getWorkExperience() {
    
    this.showCardProgress('grid-card')
    this.context.httpService.get(environment.academicsUrl + this.internURL + this.getStudentId).
      subscribe(
        (response) => {
          if (response.success) {
            this.hideCardProgress('grid-card')
            this.workTypesDetail = response.data;
            this.context.datatableService.reRender('datatable');
            //this.workType.forEach(element => {
            this.workTypesDetail.forEach(res => {
              //if (element.id == res.workTypeId) {
              //  res.workTypeName = element.name;
              if (res.currentWork == true) {
                res.endDat = 'Till Working';
              }
              //}
            });
            //});
            //this.SetDataTable();
          }else{
            this.hideCardProgress('grid-card')
          }
        },(error) =>{
          this.hideCardProgress('grid-card')
        });
  }
  getWorkType() {
    this.context.httpService.get(environment.academicsUrl + this.dropDownUrl).subscribe(
      (response) => {
        this.workType = response.data || [];
      }
    );
  }

  workTypes(index: number, workType: any): number {
    return workType.workTypeId;
  }

  get getStudentId(): number {
    this.studentId = this.context.accountService.getUserId();
    var access_token = this.studentId.source.value;
    return access_token;
  }
  get getUserId(): string {
    this.userId = this.context.accountService.getUserId();
    var access_token = this.userId.source.value;
    return access_token;
  }

  deleteRow(x) {
    this.context.notificationService.confirmAlert((confirm) => {
      if (!confirm.dismiss) {
        this.context.httpService.delete(environment.academicsUrl + this.internURL + x).subscribe(
          (response) => {
            if (response.success) {
              this.notifySuccess('Deleted Successfully');
              this.getWorkExperience();
              this.workTypeDetails =
              {
                Id: 0,
                StudentId: 0,
                ReferenceId: 0,
                WorkTypeId: null,
                Organization: '',
                StartDate: '',
                EndDate: '',
                JobDescription: '',
                CreatedBy: '',
                UpdatedBy: '',
                CurrentWork: false
              }
            } else {
              this.notifyError('Failed to delete');
            }
          }
        );
      }
    }, 'Delete?');

  }

  editRow(workexperience, name) {

    this.show = !this.show;
    setTimeout(() => {
      this.searchElement.nativeElement.focus();
    }, 0);
    this.isFormVisible = true;
    this.organisationValidate = false;
    this.saveInProgress = false;
    this.startDt = new Date(workexperience.startDate);
    this.endDt = new Date(workexperience.endDate);
    if (workexperience.currentWork != true) {
      var dates = moment(this.endDt).format('MM-DD-YYYY');
    }
    else {
      var dates = '';
    }
    this.wrk.startDt = moment(this.startDt).format('MM-DD-YYYY');
    this.wrk.endDt = dates;
    this.workTypeDetails.Id = workexperience.id;
    this.workTypeDetails.Organization = workexperience.organization;
    this.workTypeDetails.JobDescription = workexperience.jobDescription;
    this.workTypeDetails.WorkTypeId = workexperience.workTypeId;
    this.workTypeDetails.CurrentWork = workexperience.currentWork;
  }

  //SetDataTable() {
  //  $(() => {
  //    $('#internship').DataTable({
  //      pagingType: 'full_numbers',
  //      pageLength: 5,
  //      processing: true,
  //      lengthMenu: [5, 10, 25],
  //      order: [[5, "desc"]]
  //    });
  //  })
  //}

  Cancel(form: NgForm) {
    this.resetForm(form);
    this.startDateValidate = false;
    this.endDateValidate = false;
    this.organisationValidate = false;
  }

  checkOrg() {
    this.organisationValidate = false;
  }
  checkOrganisation() {
    
    let organisation = this.workTypeDetails.Organization.toLocaleLowerCase();
    var srtdt = this.wrk.startDt
    var sdat = moment(srtdt).format('MM/DD/YYYY');
    this.organisationValidate = false;
    this.workTypesDetail.forEach(element => {
      var dat = moment(element.startDate).format('MM/DD/YYYY');

      if (element.organization.toLocaleLowerCase() == organisation && sdat == dat && (!element.id || element.id != this.workTypeDetails.Id)) {
        return this.organisationValidate = true;
      }
    });
  }
  onCheckboxChange(form) {
    if (this.workTypeDetails.CurrentWork) {
      this.wrk.endDt = '';
      form.controls.endDt.setValue('')
      //this.workTypeDetails.StartDate = '';
      this.endDateValidate = false;
      this.workTypeDetails.CurrentWork = true;
    }
    else {
      this.workTypeDetails.CurrentWork = false;
      this.minDate1 = new Date(this.wrk.startDt);
    }
  }
  clrSt(form) {

    this.organisationValidate = false;
    var stdt = this.wrk.startDt;
    var endt = this.wrk.endDt
    var sDate = new Date(stdt);
    var CurrentDate = new Date();
    this.minDate1 = new Date(stdt);
    if (sDate != CurrentDate && CurrentDate < sDate) {
      this.startDateValidate = true;
      this.wrk.startDt = '';
    }
    else {
      this.startDateValidate = false;
    }
    if (endt) {
      this.clrEd(this.form);
    }
  }
  clrEd(form) {
    //console.log(event)
    this.organisationValidate = false;
    var stdt = this.wrk.startDt;
    var endt = this.wrk.endDt
    var eDate = new Date(endt);
    this.endDt = eDate;
    var sDate = new Date(stdt);
    if (sDate > eDate) {
      this.endDateValidate = true;
      this.wrk.endDt = '';
      //form.controls.endDt.setValue('')
    }
    else {
      this.endDateValidate = false;
    }

  }
  checkOrganization(event) {
    var k;
    k = event.charCode;
    return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));

  }

  textWrap(word: string) {
    return word.length > 30 ? word.substring(0, 30) + "..." : word;
  }

}

export class workTypesDetail {
  id: number;
  workTypeName: string;
  organization: string;
  startDate: Date;
  endDate: Date;
  jobDescription: string;
  workTypeId: number;
  currentWork: any;
  endDat: any;
}
