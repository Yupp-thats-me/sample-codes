import { AfterViewInit, Component, ElementRef, OnDestroy, OnInit, Optional, Renderer2, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { DataTableDirective } from 'angular-datatables';
import { Skill } from '@models/skill-model.service';
import { ContextContainer } from '@app-core/context-container';
import { BaseComponent } from '@app-core/base.component';
import { environment } from 'environments/environment';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs';
import { SkillComboModel } from '@models/skillcombomodel.service';
import { rating } from "@services/enumfiles";
import { LangChangeEvent } from '@ngx-translate/core';

@Component({
  selector: 'app-skills',
  templateUrl: './skills.component.html',
  styleUrls: ['./skills.component.scss']
})

export class SkillsComponent extends BaseComponent implements AfterViewInit {
  public enumrating = rating
  skillDetails: SkillDetails[];
  dtTrigger: Subject<any> = new Subject<any>();
  @ViewChild(DataTableDirective) dtElement: DataTableDirective;
  isFormVisible: boolean = false;

  skillForm = false;
  model: any = {};
  studentId: any;
  createdBy: any;
  updatedBy: any;
  public someRange3: number[] = [10];
  public rateStar = 5;
  min: number;
  max: number;
  step: number;
  slang: string = 'en';
  skillUrl: string = '/StudentProfile/Skill/';
  DropDownUrl: string = '/DropdownDetails/skillMaster'
  skillNameUrl: string = '/StudentProfile/SkillMaster'

  skillCombo: any = [];
  skillNameArray: any = [];
  keyword = "name";
  duplicateSkill: boolean = false;
  saveInProgress: boolean

  selectedSkill: Skill = {
    Id: 0,
    StudentId: 0,
    ReferenceId: 0,
    SkillName: '',
    Experience: '',
    ExpInYears: 0,
    ExpInMonths: 0,
    SelfRating: null,
    Created_By: '',
    Updated_By: '',
  }

  saveSkillCombo: SkillComboModel = {
    SkillName: '',
  }

  a: boolean;
  datatableElement: any;
  test : any = {
    range: {
      'min': 1,
      'max': 30,
    },
    steps : 1
    // pips: {
    //   mode: 'values',
    //   values: [1, 3, 6, 12, 18, 24, 30],
    //   density: 4,
    // }
  }
  constructor(context: ContextContainer, private http: HttpClient, private renderer: Renderer2) {
    super(context);
  }

  get getStudentId(): number {
    this.studentId = this.context.accountService.getUserId();
    var access_token = this.studentId.source.value;
    return access_token;
    //return 2;
  }

  ngOnInit(): void {
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang
    });
    this.getSkillNameCombo();
    this.skillDetails = [];
    this.getSkill();
    this.saveInProgress = false;
  }

  ngAfterViewInit() {
    this.context.datatableService.init(this.dtElement);
  }

  onSubmit(form: NgForm) {

    if (form.invalid) {
      this.notifyError('Please enter all the mandatory fields')
      return;
    }

    this.initDuplicateValidations();
    if(this.duplicateSkill){
      this.notifyError("Data already exists");
      return;
    }

        // this must be called first before the duplicateSkill check.

    this.saveInProgress = true;

    //this.studentId = this.getStudentId;
    this.selectedSkill.StudentId = this.getStudentId;

    var created_By = this.getStudentId;
    this.selectedSkill.Created_By = created_By.toString();

    var updated_By = this.getStudentId;
    this.selectedSkill.Updated_By = updated_By.toString();

    this.selectedSkill.SkillName = this.saveSkillCombo.SkillName;

    this.selectedSkill.ExpInYears = parseFloat(this.selectedSkill.ExpInYears+'.'+this.selectedSkill.ExpInMonths);

    // delete this.selectedSkill.ExpInMonths;

     this.showCardProgress('form-card')


    if (this.selectedSkill.Id == 0 || this.selectedSkill.Id == null) {
      this.context.httpService.post(environment.academicsUrl + this.skillUrl + this.selectedSkill.Id, this.selectedSkill).
        subscribe(
          (response) => {
            if (response.success) {
              this.resetForm(form);
              this.getSkill();
              this.notifySuccess('Saved Succesfully');
              this.selectedSkill.Id = 0;
              this.isFormVisible = false;
              this.saveInProgress = false;
              this.hideCardProgress('form-card')
            } else {
              this.notifyError('Failed to save data')
              this.saveInProgress = false;
              this.isFormVisible = true;
              this.hideCardProgress('form-card')
            }

          }, (error) => {
            this.saveInProgress = false;
            this.hideCardProgress('form-card')
          }
        );
    }

    else {

      this.context.httpService.put(environment.academicsUrl + this.skillUrl + this.selectedSkill.Id, this.selectedSkill).
        subscribe(
          (response) => {
            if (response.success) {
              this.resetForm(form);
              this.getSkill();
              this.notifySuccess('Saved Succesfully');
              this.selectedSkill.Id = 0;
              this.isFormVisible = false;
              this.saveInProgress = false;
              this.hideCardProgress('form-card')
            } else {
              this.notifyError('Failed to save data')
              this.saveInProgress = false;
              this.isFormVisible = true;
              this.hideCardProgress('form-card')
            }
          }, (error) => {
            this.saveInProgress = false;
            this.hideCardProgress('form-card')
          }
        );
    }
  }


  resetForm(form: NgForm) {
    this.selectedSkill = {
      Id: 0,
      StudentId: 0,
      ReferenceId: 0,
      SkillName: '',
      Experience: '',
      ExpInYears: 0,
      ExpInMonths: 0,
      SelfRating: 0,
      Created_By: '',
      Updated_By: ''
    };
    form.resetForm();
    this.selectedSkill.ExpInYears = 0;
    this.selectedSkill.ExpInMonths = 0;
    this.duplicateSkill = false;
    this.saveInProgress = false;
    this.hideForm();
  }

  getSkill() {
    this.showCardProgress('grid-card')
    this.context.httpService.get(environment.academicsUrl + this.skillUrl + this.getStudentId)
      .subscribe(Response => {
        this.skillDetails = Response.data;
        this.context.datatableService.reRender('datatable');
      });
      this.hideCardProgress('grid-card')
  }

  getSkillNameCombo() {
    this.context.httpService.get(environment.academicsUrl + this.DropDownUrl)
      .subscribe(
        (response) => {
          this.skillNameArray = [];
          this.skillCombo = response.data || [];
          for (let skill of this.skillCombo) {
            this.skillNameArray.push(skill.skillName)
          }
        });
  }

  myTrim(x) {
    return x.replace(/^\s+|\s+$/gm, '');
  }

  change(event: any) {
    this.saveSkillCombo.SkillName = this.saveSkillCombo.SkillName != null ? this.myTrim(this.saveSkillCombo.SkillName) : null;
    if(this.saveSkillCombo.SkillName!=null){
    this.initDuplicateValidations()
    }
    if (this.saveSkillCombo.SkillName != '' &&  this.saveSkillCombo.SkillName != null) {
      var arrayContains = (this.skillNameArray.indexOf(this.saveSkillCombo.SkillName) > -1);
      if (!arrayContains) {
        this.context.httpService.post(environment.academicsUrl + this.skillNameUrl, this.saveSkillCombo, { params: { handleResponse: false } })
          .subscribe(
            (response) => {
              this.getSkillNameCombo();
            }
          );
      }
    }
  }

  deleteRow(x) {
    this.context.notificationService.confirmAlert((confirm) => {
      if (!confirm.dismiss) {
        this.context.httpService.delete(environment.academicsUrl + this.skillUrl + x).
          subscribe(
            (response) => {
              if(response.success){
                this.notifySuccess('Deleted Successfully')
                this.getSkill();
              }else{
                this.notifyError('Failed to delete')
              }
            });
      }
    }, 'Delete?')
  }



  editRow(skills) {
    this.isFormVisible = true;
    this.duplicateSkill = false;
    this.selectedSkill.Id = skills.id;
    this.saveSkillCombo.SkillName = skills.skillName;
    this.selectedSkill.SelfRating = skills.selfRating;
    let x = skills.expInYears.toString().split('.');
    this.selectedSkill.ExpInYears = parseInt(x[0]);
    this.selectedSkill.ExpInMonths = parseInt(x[1]);
  }

  public showForm(form: NgForm) {

    this.resetForm(form);
    this.isFormVisible = true;
    this.duplicateSkill = false;
    this.saveInProgress = false;
  }

  public hideForm() {
    this.isFormVisible = false;
    this.duplicateSkill = false;
    this.saveInProgress = false;
  }

  trackById(index: number, skillDetails: any): number {
    return skillDetails.id;
  }

  // formatScore(score: number) {
  //   return (score).toString() + "/5";
  // }

  textWrap(word: string) {
    return word.length > 30 ? word.substring(0, 30) + "..." : word;
  }

  onChange(value: any) {
  }

  //ngOnDestroy(): void {
  //  // Do not forget to unsubscribe the event
  //  this.dtTrigger.unsubscribe();
  //}

  //destroyDatatable() {

  //  if (this.dtElement.dtInstance) {
  //    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
  //      dtInstance.destroy();
  //    });
  //  }
  //}


  initDuplicateValidations() {
    let skill = this.saveSkillCombo.SkillName.toLocaleLowerCase();
    this.duplicateSkill = false;
      this.skillDetails.forEach(element => {
        if ((element.skillName.toLocaleLowerCase() == skill) && (!element.id || element.id != this.selectedSkill.Id)) {
          this.duplicateSkill = true;
          return false;
        }
      });
  }

  formatExperience(value){
    let experience = '';

    if(value)
    {
      var val = value.toString().split('.');

    let years = parseInt(val[0]);
    let month = 0;
    if(val.length>0)
      month = parseInt(val[1]);

      if(years){
        if(years == 1){
          experience = years+ ' year';
        }else{
          experience = years+ ' years';
        }
      }

      if(month){
        if(month==1){
          experience+=' '+ month + ' month';
        }else{
          experience+=' '+ month + ' months';
        }
      }

    }



return experience;

  }


}

export class SkillDetails {
  skillName: String;
  experience: string;
  selfRating: string;
  createdDate: Date;
  updatedDate: Date;
  id: number
}
