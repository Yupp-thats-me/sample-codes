import { AfterViewInit, Component, OnDestroy, ViewChild } from '@angular/core';
import { ContextContainer } from '@app-core/context-container';
import { AccomplishmentsComponent } from '@pages/profileview/accomplishments/accomplishments.component';
import { AccomplishmentModel } from '@models/accomplishment.model';
import { NgForm } from '@angular/forms';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { Subject } from 'rxjs';
import { DataTableDirective } from 'angular-datatables';
import * as moment from 'moment';

@Component({
  selector: 'app-tests',
  templateUrl: './tests.component.html',
  styleUrls: ['./tests.component.scss']
})
export class TestsComponent extends AccomplishmentsComponent implements AfterViewInit {

  dtTrigger: Subject<any> = new Subject<any>();
  @ViewChild(DataTableDirective) dtElement: DataTableDirective;
  model: AccomplishmentModel = new AccomplishmentModel();
  public modelPopup: any;
  saveInProgress: boolean;
  gridData: gridData[];
  accomplishmentTypeId: number;
  isFormVisible: boolean;
  bsConfig: Partial<BsDatepickerConfig>;
  maxDate: Date;
  minDate: Date;
  duplicateTitle: boolean = false;
  duplicateDate: boolean = false;
  futureDate: boolean = false;
  Test = {
    TestDate:''
  }
  constructor(context: ContextContainer) {
    super(context);
    this.accomplishmentTypeId = 3;
    this.hideForm();
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate());
    this.minDate = new Date(2000, 0, 1);
  }

  ngOnInit(): void {
    this.gridData = [];
    this.loadTestScoreGrid();
    this.bsConfig = Object.assign({}, {
      dateInputFormat: 'MM/DD/YYYY',
      showWeekNumbers:false,
      customTodayClass: 'custom-today-class'
    });

  }

  ngAfterViewInit() {
    this.context.datatableService.init(this.dtElement);
  }

  onSubmit(form: NgForm)
  {

    if (form.invalid) {
       this.notifyError('Please enter all the mandatory fields')
       return;
    }
    this.initDuplicateValidations();
    if(this.duplicateTitle){
      this.notifyError("Data already exists");
      return;
    }


    this.saveInProgress = true;
    this.model.startDate = this.Test.TestDate
    if (this.model.id == 0 || this.model.id == null) {
      var data = this.model;
      data.accomplishmentTypeId = this.accomplishmentTypeId;
      var date = new Date(this.model.startDate);
      data.startDate = moment(date).format("YYYY-MM-DD").toString();
      this.showCardProgress('form-card')
      this.saveData(data).subscribe(
        (response) => {
          if (response.success) {
            this.notifySuccess('Saved Succesfully');
            this.hideForm();
            this.loadTestScoreGrid();
            this.saveInProgress = false;
            this.hideCardProgress('form-card')
          }
        },(error)=>{
          this.saveInProgress= false;
          this.hideCardProgress('form-card')
        }
      );
    }

    else {
      var data = this.model;
      data.accomplishmentTypeId = this.accomplishmentTypeId;
      var date = new Date(this.model.startDate);
      this.showCardProgress('form-card')
      data.startDate = moment(date).format("YYYY-MM-DD").toString();
      this.saveData(data).subscribe(
        (response) => {
          if (response.success) {
            this.notifySuccess('Saved Succesfully');
            this.hideForm();
            this.loadTestScoreGrid();
            this.saveInProgress = false;
            this.hideCardProgress('form-card')
          }
        },(error)=>{
          this.saveInProgress= false;
          this.hideCardProgress('form-card')
        }
      );
    }
  }


  onEdit(data: any) {
    this.isFormVisible = true;
    this.bindData(data);
  }

  onDelete(id: number) {
    let accomplishmentTypeId = this.accomplishmentTypeId;
    this.context.notificationService.confirmAlert((confirm) => {
      if (!confirm.dismiss) {
        this.deleteRow(id, accomplishmentTypeId).subscribe(
          (response) => {
            if (response.success) {
              this.notifySuccess('Deleted Successfully')
              this.loadTestScoreGrid();
            }else{
              this.notifyError('Failed to delete')

            }
          }
        );
      }
    }, 'Delete?')
  }


  bindData(data) {
    this.saveInProgress = false;
    this.model = new AccomplishmentModel();
    this.model.title = data.title;
    this.model.testScore = data.testScore;
    var myStartDate = new Date(data.startDate);
    this.Test.TestDate = moment(myStartDate).format('MM-DD-YYYY');
    this.model.id = data.id;
    this.model.description = data.description;
  }

  loadTestScoreGrid() {
    this.showCardProgress('grid-card')
    this.loadGrid(this.accomplishmentTypeId).subscribe(

      (response) => {
        if (response.success) {
          this.gridData = response.data || [];
          this.context.datatableService.reRender('datatable');
          this.hideCardProgress('grid-card')
        } else{
          this.hideCardProgress('grid-card')
        }
      },(error) =>{
        this.hideCardProgress('grid-card')
      }
    );
  }

  initDuplicateValidations() {
    let title = this.model.title.toLocaleLowerCase();
    let currentDate = moment(this.Test.TestDate).format('MM/DD/YYYY');
    this.duplicateTitle = false;
      this.gridData.forEach(element => {
        var dateOfEvent = moment(element.startDate).format('MM/DD/YYYY');
        if (element.title.toLocaleLowerCase() == title && moment(dateOfEvent).isSame(moment(currentDate)) && (!element.id || element.id != this.model.id)) {
          this.duplicateTitle = true;
          this.saveInProgress = false;
        }
      });
  }

  clr()
  {
    if (moment(this.Test.TestDate).isAfter(new Date())) {
      this.futureDate = true
      this.Test.TestDate = '';
    }
    else {
      this.futureDate = false
    }
    this.duplicateTitle = false;
  }


  resetForm(form: NgForm) {

    this.model.id = 0;
    this.model.startDate = '';
    this.model.title = '';
    this.model.testScore = '';
    this.model.description = '';
    this.saveInProgress = false;
    this.duplicateTitle = false
    form.resetForm();
    this.hideForm();
  }

  public showForm(form: NgForm) {
    this.saveInProgress = false;
    this.resetForm(form);
    this.isFormVisible = true;
    this.duplicateTitle = false;
  }

  public hideForm() {
    this.isFormVisible = false;
    this.duplicateTitle = false;
    this.saveInProgress = false;
  }

  textWrap(word: string) {
    return word.length > 30 ? word.substring(0, 30) + "..." : word;
  }
}


export class gridData {
  title: string;
  testScore: string;
  startDate: Date;
  description: string;
  id: number
}
