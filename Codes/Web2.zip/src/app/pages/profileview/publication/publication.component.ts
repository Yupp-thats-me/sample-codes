import { AfterViewInit, Component, HostListener, OnDestroy, ViewChild } from '@angular/core';
import { PublicationService } from '@services/publication.service';
import { ContextContainer } from 'app/app-core/context-container';
import { AccomplishmentsComponent } from '../accomplishments/accomplishments.component';
import { AccomplishmentModel } from '@models/accomplishment.model';
import { NgForm } from '@angular/forms';
import { BsDatepickerConfig, BsDatepickerDirective } from 'ngx-bootstrap/datepicker';
import { formatDate } from '@angular/common';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import * as moment from 'moment';


@Component({
  selector: 'app-publication',
  templateUrl: './publication.component.html',
  styleUrls: ['./publication.component.scss']
})
export class PublicationComponent extends AccomplishmentsComponent implements AfterViewInit {

  dtTrigger: Subject<any> = new Subject<any>();
  @ViewChild(DataTableDirective) dtElement: DataTableDirective;

  datePickerValue: Date = new Date();
  dateInputFormat: string
  bsConfig: Partial<BsDatepickerConfig>;

  //------------------
  @ViewChild(BsDatepickerDirective, { static: false }) datepicker: BsDatepickerDirective;
  startDateValidate: boolean;
  startDt: any;
  maxDate: Date;
  minDate: Date;
  studentId: any;
  saveInProgress: boolean;
  @HostListener('window:scroll')
  onScrollEvent() {
    this.datepicker.hide();
  }
  model: AccomplishmentModel = new AccomplishmentModel();

  public modelPopup: any;

  data: any;
  isFormVisible: boolean;

  gridData: gridData[];

  actionButtons: string = null;
  accomplishmentTypeId: number;
  createdBy: any;
  updatedBy: any;
  titleValidate: boolean;
  pub = {
    pubDt: ''
  }

  constructor(private service: PublicationService, context: ContextContainer) {
    super(context);

    this.accomplishmentTypeId = 2;
    this.isFormVisible = false;
    this.startDateValidate = false;
    this.titleValidate = false;
    this.saveInProgress = false;
  }

  ngOnInit(): void {

    this.gridData = [];
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate());
    this.minDate = new Date(2000, 0, 1);
    this.loadPublicationGrid();
    this.bsConfig = Object.assign({}, {
      dateInputFormat: 'MM/DD/YYYY',
      showWeekNumbers:false,
      customTodayClass: 'custom-today-class'
    });

  }

  ngAfterViewInit() {
    this.context.datatableService.init(this.dtElement);
  }

  onSubmit(form: NgForm) {
    
    if (form.invalid ) {
      return this.notifyError('Please enter all the mandatory fields');
    }
    this.checkTitle();
    if(this.titleValidate){
      this.notifyError("Data already exists");
      return;
    }
    this.saveInProgress = true;
    var data = this.model;
    data.accomplishmentTypeId = this.accomplishmentTypeId;
    data.startDate = this.pub.pubDt
    // data.studentId = this.getStudentId();
    if (data.id == 0 || data.id == null) {
      data.startDate = moment(form.value.pubDt).format("YYYY-MM-DD").toString();

      if (!this.titleValidate && !this.startDateValidate) {
        this.showCardProgress('form-card')
        this.saveData(data).subscribe(
          (response) => {
            if (response.success) {
              this.notifySuccess('Saved Succesfully');
              this.hideCardProgress('form-card')
              this.loadPublicationGrid();
              this.hideForm();
              this.resetForm(form);
              this.saveInProgress = false;
            }
            else{
              this.notifyError('Failed to save data');
              this.hideCardProgress('form-card')
            }
          },(error)=>{
            this.saveInProgress = false;
            this.hideCardProgress('form-card')
          }
        );
      }
    }
    else {
      this.checkTitle();
      if (!this.titleValidate && !this.startDateValidate) {
      var date = new Date(form.value.pubDt);
      data.startDate = moment(date).format("YYYY-MM-DD").toString();
      this.showCardProgress('form-card')
        this.saveData(data).subscribe(
          (response) => {
            if (response.success) {
              this.notifySuccess('Saved Succesfully');
              this.loadPublicationGrid();
              this.hideCardProgress('form-card')
              this.hideForm();
              this.resetForm(form);
              this.saveInProgress = false;
            }
            else{
              this.notifyError('Failed to save data');
              this.hideCardProgress('form-card')
            }
          },(error)=>{
            this.saveInProgress = false;
            this.hideCardProgress('form-card')
          }
        );

    }
  }
  }

  onEdit(data: any) {
    this.isFormVisible = true;
    this.bindData(data);
  }

  onDelete(id: number) {

    let accomplishmentTypeId = this.accomplishmentTypeId;
    this.context.notificationService.confirmAlert((confirm) => {
      if (!confirm.dismiss) {
        this.deleteRow(id, accomplishmentTypeId).subscribe(

          (response) => {

            if (response.success) {
              this.notifySuccess('Deleted Successfully')
              this.loadPublicationGrid();
            }
            else{
              this.notifyError('Failed to delete')
            }
          }
        );
      }
    }, 'Delete?');
  }

  bindData(data) {
    
    this.saveInProgress = false;
    this.model = new AccomplishmentModel();

    this.model.title = data.title;
    this.model.publisher = data.publisher;
    var myStartDate = new Date(data.startDate);
    var dat = moment(myStartDate).format('MM-DD-YYYY');
    this.pub.pubDt = dat;
    this.model.urlLink = data.urlLink;
    this.model.id = data.id;
  }

  loadPublicationGrid() {
this.showCardProgress('grid-card')
    this.loadGrid(this.accomplishmentTypeId).subscribe(

      (response) => {
        if (response.success) {
          this.hideCardProgress('grid-card')
          this.gridData = response.data || [];
          this.context.datatableService.reRender('datatable');

        }else{
          this.hideCardProgress('grid-card')
        }
      },(error) =>{
        this.hideCardProgress('grid-card')
      }
    );
  }
  resetForm(form: NgForm) {
    this.model.id = 0;
    this.model.title = '';
    this.model.urlLink = '';
    form.resetForm();
    this.saveInProgress = false;
    this.hideForm();
  }

  public showForm(form: NgForm) {
    this.saveInProgress = false;
    this.resetForm(form);
    this.isFormVisible = true;
  }

  public hideForm() {
    this.isFormVisible = false;
    this.saveInProgress = false;
  }
  checkStartDate() {
    
    if (this.pub.pubDt) {
      var StartDate = this.pub.pubDt;
      var sDate = new Date(StartDate);
      var CurrentDate = new Date();
      if (sDate != CurrentDate && CurrentDate < sDate) {
        this.startDateValidate = true;
      }
      else {
        this.startDateValidate = false;
      }
    }
  }

  checkTitle() {
    
    let title = this.model.title.toLocaleLowerCase();
    var sdat = moment(this.pub.pubDt).format('MM/DD/YYYY');
    this.titleValidate = false;
    this.gridData.forEach(element => {
      var ndat = moment(element.startDate).format('MM/DD/YYYY');
      if (element.title.toLocaleLowerCase()== title && ndat == sdat && (!element.id || element.id != this.model.id)) {
        this.titleValidate = true;
        this.saveInProgress = false;
      }
    });
  }

  dateValid(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if ((charCode > 46 && charCode < 58) || charCode == 46) {
      var sDate = new Date(this.model.startDate);
      this.startDt = sDate;
      return true;
    }
    return false;
  }

  clr() {
    this.titleValidate = false;
  }

  textWrap(word: string) {
    return word.length > 40? word.substring(0, 40) + "..." : word;
  }

}


export class gridData {
  id: number;
  title: string;
  publisher: string;
  startDate: Date;
  urlLink: any;
}
