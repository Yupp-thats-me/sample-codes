import { Component, OnInit, ViewChild } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { BaseComponent } from '@app-core/base.component';
import { HttpParams, HttpClient, HttpHeaders } from '@angular/common/http';
import { ContextContainer } from '@app-core/context-container';
import { Myprofile } from '@models/myprofilemodel';
import { PersonalDetail } from '@models/personalDetail';
import { environment } from 'environments/environment';
import { Router } from '@angular/router';
import { NgbModal, NgbModalRef, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { DialogPopupComponent } from '../common-reg/component/dialog-popup/dialog-popup.component';
import { MyprofileService } from '@services/myprofile.service';



@Component({
  selector: 'app-profileview',
  templateUrl: './profileview.component.html',
  styleUrls: ['./profileview.component.scss']
})

export class ProfileviewComponent extends BaseComponent implements OnInit {
  closeResult: string;
  profile1: any = Myprofile;
  personalDetailsProfile: any = PersonalDetail;
  files: any[] = [];
  myImage: string;
  thumbnail: any;
  public activeTab: string;
  urlLink: any;
  studentId: any;
  private httpClient: HttpClient;
  public tab: string;
  profilePicPath: string
  myprof: Myprofile = {
    StudentId: 0,
    Mobile: 0,
    EmailId: '',
    EmirateId: 0,
    Qualification: '',
    Skills: '',
    OnlineProfileURL: '',
    CertificationName: '',
    IssuingAuthority: '',
    CompletedDate: '',
    NameOfEvent: '',
    Organization: '',
    Title: '',
    IsWorkingOn: '',
    Publisher: '',
    PublicationURL: ''
  }
  userId: any;
  dialog: NgbModalRef;
  picurl: string = 'http://13.233.41.227:8086/api/v1/StudentProfile/postProfilepic/'
  ProfilePicUrl: string = '/StudentProfile/postProfilepic/';
  personalDetailsUrl: string = '/StudentProfile/PersonalDetails/';
  getProfileUrl: string = '/StudentProfile/GetMyProfiles/'
  constructor(
    private modalService: NgbModal, config: NgbModalConfig,
    contextContainer: ContextContainer,
    private domSanitizer: DomSanitizer, httpClient: HttpClient, private router: Router, private myprofileService: MyprofileService) {
    super(contextContainer);
    this.httpClient = httpClient;
    config.backdrop = 'static';
    config.keyboard = false;
    router.events.subscribe((url: any) => {
      if (url.hasOwnProperty('url')) {
        var aturl = url.url.split('/');
        this.activeTab = aturl[aturl.length - 1]
      }
    })

  }

  ngOnInit(): void {
    this.activeTab = 'myprofile';
    this.router.navigate(['/profileview/myprofile']);

    this.myprofileService.myPersonalEmit.subscribe(res => {
      if (res) {
        this.getProfile()
        this.getPersonals()
      }
    });


  }


  //textWrap(word: string) {
  //  return word.length > 30 ? word.substring(0, 30) + "..." : word;
  //}

  open() {
    this.dialog = this.modalService.open(DialogPopupComponent, { ariaLabelledBy: 'modal-basic-title', size: 'xl' });
    (<DialogPopupComponent>this.dialog.componentInstance).data = 'hi';

    this.dialog.result.then((result) => {
      if (result) {
        this.context.authenticationService.checkKeycloakLoginDetail();
        this.ngOnInit();

      }
    }, (reason) => {
      ;
    });
  }



  get getStudentId(): Number {
    this.studentId = this.context.authenticationService.getStudentId();
    var access_token = this.studentId.source.value;
    return access_token;
  }

  get getUserId(): string {
    this.userId = this.context.authenticationService.getUserId();
    var access_token = this.userId.source.value;
    return access_token;
  }
  getProfile() {
    this.context.httpService.get(environment.academicsUrl + this.getProfileUrl + this.getStudentId).subscribe(
      (response) => {
        this.profile1 = response.data || [];
      }
    );
  }

  getPersonals() {
    this.showCardProgress('form-card')
    this.context.httpService.get(environment.academicsUrl + this.personalDetailsUrl + this.getStudentId.toString()).subscribe(
      (response) => {
        if (response.success) {
          this.hideCardProgress('form-card')
          this.personalDetailsProfile = response.data || [];
          this.personalDetailsProfile.firstName
          this.getProfilePic(response.data.profilePic, response.data.fileName);
        }
        if (this.personalDetailsProfile.emirateId === null || this.personalDetailsProfile.emirateId == '') {
          this.open();
        }
      }
    );
  }
  fileSelect(event) {
    var src = this.thumbnail;
    if (src) {
      window.open(src.changingThisBreaksApplicationSecurity, '_blank')
    }
  }

  selectFile(event) {
    if (event.target.files && event.target.files.length > 0) {
      var reader = new FileReader()
      reader.readAsDataURL(event.target.files[0])
      reader.onload = (event: any) => {
        this.urlLink = event.target.result
      };
      var size = event.target.files[0].size
      if (size > 1048576) {
        this.context.notificationService.error('Upload the image less than 1 MB')
        return;
      }
      const formData = new FormData();

      formData.append('files[0]', event.target.files[0]);
      formData.append('profilePicDetails.studentId', this.getStudentId.toString());

      formData.append('profilePicDetails.updatedBy', this.getUserId.toString());

      let file = event.target.files[0];

      let url = window.URL.createObjectURL(file);

      let tokenKeycloakInfo = localStorage.getItem('keycloakSession');

      const httpOptions = {
        headers: new HttpHeaders({
          "Authorization": "Bearer " + tokenKeycloakInfo
        })
      };
      //this.httpClient.post(this.picurl, formData, httpOptions).subscribe(
      this.showCardProgress('form-card')
      this.context.httpService.post(environment.academicsUrl + this.ProfilePicUrl, formData, httpOptions).subscribe(
        (response: any) => {

          if (response.success) {
            //this.profilePicPath = response.data.fileName;
            this.hideCardProgress('form-card')
            this.context.notificationService.success('Image Uploded Sucessfully')
            this.getProfilePic(response.data.profilePic, response.data.fileName);
          }

        },
        // (error) => { },
        // () => { this.getProfilePic(file.name);}

      );
    }
    this.getProfile()
    this.getPersonals()
  }

  getProfilePic(data, fileName) {

    if (data) {

      let file = this.createFile(data, fileName);

      let url = window.URL.createObjectURL(file);

      this.thumbnail = this.domSanitizer.bypassSecurityTrustUrl(url);
    }
  }

  getImageHTML(url) {
    return '<img src = "' + url + '" />';
  }

  sanitize(url) {
    return this.domSanitizer.bypassSecurityTrustUrl(url);
  }

  exportPdf(i) {
    if (i == 1) {
      this.context.httpService.get(environment.academicsUrl + '/StudentProfile/ProfileExportsPdf/' + this.getStudentId.toString(), {
        responseType: 'blob'
      }).subscribe(
        (response) => {
          var filename = 'Profile';
          var blob = new Blob([response], { type: "application/pdf;charset=utf-8" });
        //  saveAs(blob, filename + ".pdf");
        this.context.fileUtility.download(response,filename);

        });
    }
    else {
      this.context.httpService.get(environment.academicsUrl + '/StudentProfile/ProfileExportsDoc/' +
        this.getStudentId.toString(), {
        responseType: 'blob'
      }).subscribe(
        (response) => {
          var filename = 'Profile';
          var blob = new Blob([response], { type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document;charset=utf-8" });
         // saveAs(blob, filename + ".doc");
         this.context.fileUtility.download(response, filename);
        });
    }
  }

  setTab(tabname: string) {
    this.router.navigate([tabname]);
  }
  onWheel(event) {
    (<Element>event.target).parentElement.scrollLeft += event.deltaY;
    event.preventDefault();
  }
}

