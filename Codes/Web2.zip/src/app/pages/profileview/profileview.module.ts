import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProfileviewRoutingModule } from './profileview-routing.module';
import { ProfileviewComponent } from './profileview.component';
import { NgbCarouselModule, NgbDatepickerModule, NgbDropdownModule, NgbTooltipModule, NgbModal, NgbModalModule, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LightboxModule } from 'ngx-lightbox';
import { FileUploadModule } from '@iplab/ngx-file-upload';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TextMaskModule } from 'angular2-text-mask';
import { NgNumberFormatterModule } from 'ng-number-formatter';
import { SharedModule } from '@shared/shared.module';
import { DataTablesModule } from 'angular-datatables';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HomePageModule } from '../home-page/home-page.module';
import { SnotifyModule } from 'ng-snotify';
import { ExportprofileComponent } from './exportprofile/exportprofile.component';
import { TagInputModule } from 'ngx-chips';
import { AngularDualListBoxModule } from 'angular-dual-listbox';
import { AutocompleteLibModule } from 'angular-ng-autocomplete';
import { InputTrimModule } from 'ng2-trim-directive';
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { NouisliderModule } from 'ng2-nouislider';
import { BarRatingModule } from 'ngx-bar-rating';
import { EducationModule } from './education/education.module';
import { AccomplishmentsModule } from './accomplishments/accomplishments.module';
import { CoursesModule } from './courses/courses.module';
import { DocumentsModule } from './documents/documents.module';
import { MyprofileModule } from './myprofile/myprofile.module';
import { PersonalDetailModule } from './personal-detail/personal-detail.module';
import { SkillsModule } from './skills/skills.module';
import { VolunteeringModule } from './volunteering/volunteering.module';
import { WorkexperienceModule } from './workexperience/workexperience.module';
import { CommonRegModule } from '../common-reg/common-reg.module';
import { DialogPopupComponent } from '../common-reg/component/dialog-popup/dialog-popup.component';

@NgModule({
  declarations: [ProfileviewComponent, ExportprofileComponent],
  imports: [
    CommonModule,
    ProfileviewRoutingModule,
    NgbDropdownModule,
    NgbTooltipModule,
    NgbCarouselModule,
    LightboxModule,
    TextMaskModule,
    NgNumberFormatterModule,
    NgbDatepickerModule,
    HttpClientModule,
    FileUploadModule,
    SharedModule,
    ReactiveFormsModule,
    FormsModule,
    DataTablesModule,
    HomePageModule,
    SnotifyModule,
    TagInputModule,
    AutocompleteLibModule,
    InputTrimModule,
    NouisliderModule,
    BarRatingModule,
    BsDatepickerModule.forRoot(),
    DatepickerModule.forRoot(),
    NgbModule,
    AngularDualListBoxModule,
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: httpTranslateLoader,
        deps: [HttpClient]
      }
    }),
    EducationModule,
    AccomplishmentsModule,
    CoursesModule,
    DocumentsModule,
    MyprofileModule,
    PersonalDetailModule,
    SkillsModule,
    VolunteeringModule,
    WorkexperienceModule,
    CommonRegModule,
  ],
  entryComponents:[DialogPopupComponent],
  providers: [DialogPopupComponent],
})
export class ProfileviewModule { }

export function httpTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http);
}


