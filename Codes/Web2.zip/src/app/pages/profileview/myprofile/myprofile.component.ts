import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '@app-core/base.component';
import { ContextContainer } from '@app-core/context-container';
import { Router } from '@angular/router';
import { environment } from 'environments/environment';
import { MyprofileService } from '@services/myprofile.service';
import * as moment from 'moment';
import { LangChangeEvent } from '@ngx-translate/core';

@Component({
  selector: 'app-myprofile',
  templateUrl: './myprofile.component.html',
  styleUrls: ['./myprofile.component.scss']
})
export class MyprofileComponent extends BaseComponent implements OnInit {


  studentId: any;
    myProfile: [];
    profile: any;
   personalForm:any;
  userid: number;
  thumbnail: any;
  educationlist =[];
  certificationDetail =[];
  certificationDetailUrl: string = '/StudentProfile/CertificationDetail/';
  volunteeringDetails = [];
  volunteeringUrl: string = '/StudentProfile/Volunteering/';
  skillDetails =[];
  skillUrl: string = '/StudentProfile/Skill/';
  internURL: string = '/StudentProfile/WorkExperience/';
  workTypesDetail = [];
  slang = 'en';





  constructor(contextContainer: ContextContainer, private router: Router, private myprofileService: MyprofileService ) {
    super(contextContainer);
  }

  ngOnInit(): void {
    //this.getProfile();
    this.getcurrentuser();
    // this.getCertificationDetail();
    // this.getVolunteering();
    // this.getSkill();
    // this.getWorkExperience();
    // this.myprofileService.myProfileEmit.subscribe(res => {
    //   if (res) {
    //     this.getProfile();
    //   }
    // });
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang
    });
  }

  get getStudentId(): number {
    this.studentId = this.context.accountService.getUserId();
    var access_token = this.studentId.source.value;
    return access_token;

    //return 2;
  }
  setTab(tabname: string) {
    this.router.navigate([tabname]);
  }
  getProfile() {
    this.showCardProgress('form-card');
    this.context.httpService.get(environment.academicsUrl+'/StudentProfile/GetMyProfiles/' + this.context.getUserId()).subscribe(
      (response) => {
        if(response.success){
          this.profile = response.data;
          this.hideCardProgress('form-card');
          if (this.profile.completedDate === null) {
            this.profile.completedDate = 'No Expiry';
          }
          else {
            var date = this.profile.completedDate.toString();
            var year = date.substring(6, 11);
            var month = date.substring(0, 4);
            this.profile.completedDate = month + '-' + year
          }
          if (this.profile.isWorkingOn == 0 ) {
            this.profile.isWorkingOn = this.context.notificationService.translate('Completed');
          } else {
            this.profile.isWorkingOn = this.context.notificationService.translate('In Progress');
          }
        }else{
          this.hideCardProgress('form-card');
        }
      },(error) =>{
        this.hideCardProgress('form-card');
      });
  }
  exportPdf(i) {
    if (i == 1) {
      this.context.httpService.get(environment.academicsUrl + '/StudentProfile/ProfileExportsPdf/' + this.context.getUserId(), {
        responseType: 'blob'
      }).subscribe(
        (response) => {
          var filename = 'Profile';
          var blob = new Blob([response], { type: "application/pdf;charset=utf-8" });
          //saveAs(blob, filename + ".pdf");
          this.context.fileUtility.download(response,filename);
        });
    }
    else {
      this.context.httpService.get(environment.academicsUrl + '/StudentProfile/ProfileExportsDoc/' +
        this.context.getUserId(), {
        responseType: 'blob'
      }).subscribe(
        (response) => {
          var filename = 'Profile';
          var blob = new Blob([response], { type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document;charset=utf-8" });
        //  saveAs(blob, filename + ".doc");
        this.context.fileUtility.download(response,filename);
        });
    }
  }
  addCourses() {
    this.router.navigateByUrl('/profileview/courses');
  }
  addVolunteering() {
    this.router.navigateByUrl('/profileview/volunteering');
  }
  addSkills() {
    this.router.navigateByUrl('/profileview/skills')
  }
  addAcc() {
    this.router.navigateByUrl('/profileview/accomplishments');
  }
  getcurrentuser() {
    this.userid = this.context.getUserId();

    this.context.httpService.get(environment.accounturl + '/User/personal-details').subscribe(
      (results) => {
        if (results && results.success) {
          if (results.data) {
            this.personalForm = results.data;
            this.personalForm.dob = moment(this.personalForm.dob).format('MM/DD/yyyy');
            this.thumbnail = this.personalForm.profilePic;
          }
        }
      }
    )

    this.context.httpService.get(environment.accounturl + '/User/educational-details').subscribe(
      (results) => {
        if(results && results.success == true){
          this.educationlist = [];
          this.educationlist.push(results.data[0]);
        }
      }
    )
    this.context.httpService.get(environment.academicsUrl + this.certificationDetailUrl + this.context.getUserId()).subscribe(
      (response) => {
        for(var i = 0; i < 1; i++){
          if(response.data[i]){
        this.certificationDetail.push(response.data[i]) || [];
          }
        }
      }
    );
    this.context.httpService.get(environment.academicsUrl + this.volunteeringUrl + this.getStudentId).
    subscribe(
      (response) => {
        if(response.success){
          for(var i = 0; i < 1; i++){
            if(response.data[i]){
          this.volunteeringDetails.push(response.data[i])
            }
          }
        }
      })
      this.context.httpService.get(environment.academicsUrl + this.skillUrl + this.getStudentId)
      .subscribe(Response => {
        for(var i = 0; i < 1; i++){
          if(Response.data[i]){
        this.skillDetails.push(Response.data[i])
          }
        }
      });
      this.context.httpService.get(environment.academicsUrl + this.internURL + this.getStudentId).
      subscribe(
        (response) => {
          for(var i = 0; i < 1; i++){
            if(response.data[i]){
          this.workTypesDetail.push(response.data[i])
            }
          }
          });

  }
  getCertificationDetail() {
    this.showCardProgress('grid-card');
    this.context.httpService.get(environment.academicsUrl + this.certificationDetailUrl + this.context.getUserId()).subscribe(
      (response) => {
        for(var i = 0; i < 1; i++){
          if(response.data[i]){
        this.certificationDetail.push(response.data[i]) || [];
          }
        }
      }
    );
  }
  getVolunteering() {
    
    this.context.httpService.get(environment.academicsUrl + this.volunteeringUrl + this.getStudentId).
      subscribe(
        (response) => {
          if(response.success){
            for(var i = 0; i < 1; i++){
              if(response.data[i]){
            this.volunteeringDetails.push(response.data[i])
              }
            }
          }
        })
  }
  getSkill() {
    
    this.context.httpService.get(environment.academicsUrl + this.skillUrl + this.getStudentId)
      .subscribe(Response => {
        for(var i = 0; i < 1; i++){
          if(Response.data[i]){
        this.skillDetails.push(Response.data[i])
          }
        }
      });
  }
  getWorkExperience() {
    
    
    this.context.httpService.get(environment.academicsUrl + this.internURL + this.getStudentId).
      subscribe(
        (response) => {
          for(var i = 0; i < 1; i++){
            if(response.data[i]){
          this.workTypesDetail.push(response.data[i])
            }
          }
          this.hideCardProgress("grid-card");
          });
        }
  selectFile(event) {
    if (event.target.files && event.target.files.length > 0) {
      var reader = new FileReader()
      reader.readAsDataURL(event.target.files[0])
      reader.onload = (event: any) => {
        //this.urlLink = event.target.result
      };
      var size = event.target.files[0].size
      if (size > 1048576) {
        this.context.notificationService.error('Upload the image less than 1 MB')
        return;
      }
      const formData = new FormData();
      var i = 0;
      var data = event.target.files[0];
      
      formData.append('files[0]', data);
      formData.append('id', '1');
        
      this.context.httpService.post(environment.accounturl + '/User/profile-pic', formData).subscribe(
        (response: any) => {

          if (response.success) {
           this.getcurrentuser();
          }

        },
      

      )}
  }
}
