import { HttpParams } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { BaseComponent } from 'app/app-core/base.component';
import { ContextContainer } from 'app/app-core/context-container';
import { AccomplishmentService } from '@services/accomplishment.service';
import { EMPTY, Observable, ObservableLike } from 'rxjs';
import { observeOn } from 'rxjs-compat/operator/observeOn';
import { environment } from 'environments/environment';
import { param } from 'jquery';


@Component({
  selector: 'app-accomplishments',
  templateUrl: './accomplishments.component.html',
  styleUrls: ['./accomplishments.component.scss'],
  providers: [AccomplishmentService]
})

export class AccomplishmentsComponent extends BaseComponent {

  svalue: FormControl = new FormControl('');
  context:ContextContainer;
  studentId: any;
  constructor(context:ContextContainer){ super(context);

    this.svalue.setValue("Project");
  }

  getStudentId(): number {
    this.studentId = this.context.getUserId();
    var access_token = this.studentId.source.value;
    return access_token;
    //return 2;
  }


  ngOnInit(): void {
    $.fn.dataTable.ext.errMode = 'throw'; // temporary. Must be
    //this.service.reloadDefaultData();
  }


  onChange(data) {

    this.svalue.setValue(data.value)

  }

  loadGrid(accomplishmentTypeId:number):Observable<any>{
    let studentId = this.context.getUserId();
    var options = {params: { accomplishmentTypeId: accomplishmentTypeId, studentId: studentId}};
    return this.context.httpService.get(environment.academicsUrl+'/Accomplishment/LoadGrid', options);
  }

  protected saveData(data):Observable<any>{
    var created_By = this.context.getUserId();
    data.createdBy = created_By.toString();
    var updated_By = this.context.getUserId();
    data.updatedBy = updated_By.toString();
    data.studentId = this.context.getUserId();
    return this.context.httpService.post(environment.academicsUrl+'/Accomplishment/SaveStudentAccomplishment',data);

  }

  protected deleteRow(id:number, accomplishmentTypeId:number){

    let params = new HttpParams();
    params = params.set('id', id.toString());

    return this.context.httpService.delete(environment.academicsUrl+'/Accomplishment/DeleteStudentAccomplishment',{params:params});

    // if(confirm('Are you sure you want to delete?'))
    // {
    //   let params = new HttpParams();
    //   params = params.set('id', id.toString());

    //   return this.context.httpService.delete(environment.academicsUrl+'/Accomplishment/DeleteStudentAccomplishment');
    // }

    return EMPTY;
  }

}
