import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AwardsComponent } from '../awards/awards.component';
import { CompetitionComponent } from '../competition/competition.component';
import { ProjectComponent } from '../project/project.component';
import { PublicationComponent } from '../publication/publication.component';
import { TestsComponent } from '../tests/tests.component';
import { AccomplishmentsComponent } from './accomplishments.component';

const routes: Routes = [
  {
    path: '', component: AccomplishmentsComponent,

    children: [

      {
        path: '', component: AwardsComponent
      },
      {
        path: '', component: CompetitionComponent
      },
      {
        path: '', component: ProjectComponent
      },
      {
        path: '', component: PublicationComponent
      },
      {
        path: '', component: TestsComponent
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccomplishmentsRoutingModule { }
