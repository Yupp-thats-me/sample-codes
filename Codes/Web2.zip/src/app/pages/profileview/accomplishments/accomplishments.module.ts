import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BsDatepickerModule, DatepickerModule } from 'ngx-bootstrap/datepicker';
import { AngularDualListBoxModule } from 'angular-dual-listbox';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

import { AccomplishmentsRoutingModule } from './accomplishments-routing.module';
import { baseModule } from '@app-core/Common Modules/baseModule';
import { HttpClient } from '@angular/common/http';
import { AccomplishmentsComponent } from './accomplishments.component';
import { AwardsComponent } from '../awards/awards.component';
import { CompetitionComponent } from '../competition/competition.component';
import { ProjectComponent } from '../project/project.component';
import { PublicationComponent } from '../publication/publication.component';
import { TestsComponent } from '../tests/tests.component';


@NgModule({
  declarations: [AccomplishmentsComponent, AwardsComponent, CompetitionComponent, ProjectComponent, PublicationComponent, TestsComponent],
  imports: [
    CommonModule,
    AccomplishmentsRoutingModule,
    BsDatepickerModule.forRoot(),
    DatepickerModule.forRoot(),
    AngularDualListBoxModule,
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: httpTranslateLoader,
        deps: [HttpClient]
      }
    }),
    baseModule
  ],
  exports: [AccomplishmentsComponent, AwardsComponent, CompetitionComponent, ProjectComponent, PublicationComponent, TestsComponent]
})
export class AccomplishmentsModule { }

export function httpTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http);
}
