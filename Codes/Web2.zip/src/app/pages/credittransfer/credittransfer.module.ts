import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CredittransferRoutingModule } from './credittransfer-routing.module';
import { SharedModule } from '@app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DataTablesModule } from 'angular-datatables';
import { SnotifyModule } from 'ng-snotify';
import { AutocompleteLibModule } from 'angular-ng-autocomplete';
import { InputTrimModule } from 'ng2-trim-directive';
import { BsDatepickerModule, DatepickerModule } from 'ngx-bootstrap/datepicker';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { HomeComponent } from './home/home.component';
import { ViewComponent } from './view/view.component';


@NgModule({
  declarations: [HomeComponent
  ,ViewComponent],
  imports: [
    CommonModule,
    CredittransferRoutingModule,
    SharedModule,
    ReactiveFormsModule,
    FormsModule,
    DataTablesModule,
    SnotifyModule,
    AutocompleteLibModule,
    InputTrimModule,
    PdfViewerModule,
    BsDatepickerModule.forRoot(),
    DatepickerModule.forRoot(),
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: httpTranslateLoader,
        deps: [HttpClient]
      }
    }),
  

  ]
})
export class CredittransferModule { }

export function httpTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http);
}