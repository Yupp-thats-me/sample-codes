import { HttpParams } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { LangChangeEvent, TranslateService } from '@ngx-translate/core';
import { environment } from 'environments/environment';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss']
})
export class ViewComponent extends BaseComponent implements OnInit {
  creditURL: string = '/CreditTransfer/';
  formInput: string;
  userId: any;
  creditTransferList: any;
  dropDownUrl: string = '/CreditDropdown/creditdropdowns';
  instituteName: any = [];
  readOnly: boolean = false;
  uploadFile = [];
  startDt: Date;
  onbehalfCred: any;
  show: boolean = false;
  isFormVisible: boolean = false;
  editFile: boolean = false;
  file: any;
  courses: any;
  view: boolean = false;
  files: any;
  totalPages: number;
  page: number = 1;
  isLoaded: boolean = false;
  credit: CreditTransferStudent =
    {
      id:0,
      academicYears: null,
      fromHEI: null,
      toHEI: null,
      department: '',
      course: '',
      major: '',
      totalViews:0
    }
  departList: any = [];
  majorList: any = [];
  departListEn: any = [];
  departListAr: any = [];
  majorListEn: any = [];
  majorListAr: any = [];
  creditlist: any;
  pdfFilePath: string;
  academicList: any;
  keyword: string = 'name';
  department: any;
  major: any;
  courseList: any;
  courseListEn: any = [];
  slang: string = "en";
  closeResult = '';
  pdfType: PDF = {
    view: 1,
    download: 2
  };
  creditGet: any;
  existingcount: any = 0;
  totalcount: any = 0;
  existingloggedincount: any = 0;
  totalloggedincount: any = 0; 


  constructor(context: ContextContainer, private translateService: TranslateService,private route: ActivatedRoute,
    private modalService: NgbModal) {
    super(context);
    this.readOnly = false;
  }

  ngOnInit(): void {
     this.userId = this.context.getUserId();
    this.getAllDropdown();
    this.getCourses();
   // this.getCreditDetails(id);
  // this.updatetotalviews();
    this.onbehalfCred = [{
      id: 1, name: "HEI Admin"
    }, { id: 2, name: "MoE Admin" }]
    this.view = false;
    var lang = this.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang;
    });
  }


  getAllDropdown() {
    this.context.httpService.get(environment.creditTransferUrl + this.dropDownUrl)
      .subscribe(
        (response) => {
          if (response.success) {
            this.instituteName = response.data.institute || [];
            this.departListEn = [];
            this.departListAr = [];
            this.departList = response.data.department || [];
            for (let depart of this.departList) {
              this.departListEn.push({ "name": depart.departmentNameEn, "id": depart.departmentId });
              this.departListAr.push({ "name": depart.departmentNameAr, "id": depart.departmentId });
            }

            this.departListEn = Array.from(this.departListEn.reduce((m, t) => m.set(t.name, t), new Map()).values());

            this.majorListEn = [];
            this.majorListAr = [];
            this.majorList = response.data.major || [];
            for (let major of this.majorList) {
              this.majorListEn.push({ "name": major.majorNameEn, "id": major.majorId });
              this.majorListAr.push({ "name": major.majorNameAr, "id": major.majorId });
            }

            this.majorListEn = Array.from(this.majorListEn.reduce((m, t) => m.set(t.name, t), new Map()).values());

            this.academicList = response.data.academic || [];
          }
        });
  }

  getCourses() {
    this.context.httpService.get(environment.creditTransferUrl + this.creditURL + 'courses')
      .subscribe(
        (response) => {

          if (response.success) {
            this.courseList = response.data.insct || [];
            for (let course of this.courseList) {
              this.courseListEn.push({ "name": course.courseFromEn });
            }
            var result = [];
            result = Array.from(this.courseListEn.reduce((m, t) => m.set(t.name, t), new Map()).values());
            this.courseListEn = result;
          }
        });
  }
  nextPage() {
    this.page += 1;
  }

  previousPage() {
    this.page -= 1;
  }

  afterLoadComplete(pdfData: any) {
    this.totalPages = pdfData.numPages;
    this.isLoaded = true;
  }

  Clear(form: NgForm) {
    this.courses = [];
    form.resetForm();
    this.pdfFilePath = '';
    this.view = false;
  }

  onSubmit(form: NgForm) {
    if (!form.valid) {
      return;
    }

    if ((this.invalidAutoComplete(form.controls.department))
      || (this.invalidAutoComplete(form.controls.major))
      || (this.invalidAutoComplete(form.controls.course))
    ) {
      return;
    }

    this.readOnly = true;
    var fromdep = this.credit.department;
    if (fromdep['id']) {
      this.department = fromdep['id'];
    }
    else {
      this.departList.forEach(element => {
        var depart1 = element.departmentNameEn.trim();
        if (depart1 == this.credit.department) {
          this.department = element.departmentId
        }
      });
    }
    var major = this.credit.major;
    if (major['id']) {
      this.major = major['id'];
    }
    else {
      this.majorList.forEach(ele => {
        var major1 = ele.majorNameEn.trim();
        if (major1 == this.credit.major) {
          this.major = ele.majorId
        }
      })
    }
    var course = this.credit.course;
    if (course['name']) {
      var courses = course['name'];
    }
    else {
      var courses = this.credit.course;
    }
    let params = new HttpParams();
    params = params.append('FromHEI', this.credit.fromHEI.toString());
    params = params.append('ToHEI', this.credit.toHEI.toString());
    params = params.append('AcademicYear', this.credit.academicYears.toString());
    params = params.append('Department', this.department);
    params = params.append('Major', this.major);
    params = params.append('Course', courses);

    this.context.httpService.get(environment.creditTransferUrl + this.creditURL + "view", { params: params }).
      subscribe(
        (response) => {
          if (response.data) {
            this.view = true;

            this.creditlist = response.data;
            this.courses = [];
            this.courses = response.data.courses;
            this.files = this.creditlist.uploadFile;
            if (response.data.id != 0 && response.data.courses.length != 0) {
              this.viewCourse(this.pdfType.view);
            }
            else {
              this.view = false;
              this.notifyError('No matched record found');
            }
            this.updatetotalviews();
          }
        });
  }
  viewCourse(active) {
    const options = { params: { file: this.files, id: this.creditlist.id } };
    this.context.httpService.get(environment.creditTransferUrl + '/CreditTransfer/download-file/' + this.files + '/' + this.creditlist.id).subscribe(
      (response) => {
        if (response.data) {
          let document = this.createFile(response.data, this.files);

          let file = new Blob([document], { type: document.type });
          var fileURL = URL.createObjectURL(file);
          this.pdfFilePath = fileURL;
          if (active == this.pdfType.download) {
           // saveAs(file, this.files);
           this.context.fileUtility.download(response.data);
          }
        }
      });

  }

  invalidAutoComplete(control: any) {

    if (control) {
      return typeof (control.value) == 'string';
    }
    return false;
  }

  open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title',size: 'xl'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
     // this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

//   getCreditDetails(id) {
//     this.context.httpService.get(environment.creditTransferUrl + this.creditURL + id).subscribe(
//       (response) => {
//         this.creditGet = response.data || [];
//           this.existingloggedincount = this.creditGet[0].totalViews;
//           this.totalloggedincount = this.existingloggedincount + 1;
//           this.totalcount = this.totalloggedincount;
//         this.updatetotalviews();
//     });
// }

  updatetotalviews() {
    this.credit.id = this.creditlist.id;
    this.existingloggedincount = this.creditlist.totalViews;
    this.totalloggedincount = this.existingloggedincount + 1;
    this.totalcount = this.totalloggedincount;
    this.credit.totalViews = this.totalcount;
   // this.feedbackModel.loggedinViews = this.totalloggedincount;
    let CreditTransferDto = {
      id: this.credit.id,
      totalViews: this.credit.totalViews,
     // loggedinViews: this.feedbackModel.loggedinViews
    };
     this.context.httpService.put(environment.creditTransferUrl + '/CreditTransfer/update/' + CreditTransferDto.id, CreditTransferDto).subscribe(
          (Response) => {
         if (Response.success) {   
         }
 
     }    );
 
  }

  // private getDismissReason(reason: any): string {
  //   if (reason === ModalDismissReasons.ESC) {
  //     return 'by pressing ESC';
  //   } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
  //     return 'by clicking on a backdrop';
  //   } else {
  //     return `with: ${reason}`;
  //   }
  // }

}

export class CreditTransferStudent {
  id:number;
  academicYears: number;
  fromHEI: number;
  toHEI: number;
  department: string;
  course: string;
  major: string;
  totalViews:number;
}

export class FilterCredit {
  academicYears: number;
  fromHEI: number;
  toHEI: number;
  department: string;
  course: string;
  major: string;
}

export class PDF {
  view: 1;
  download: 2;
}
