import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Role } from '@app/models/role.enum';
import { Authorize } from '@app/app-core/identity/auth.guard';
import { HomeComponent } from './home/home.component';
import { ViewComponent } from './view/view.component';

const routes: Routes = [
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'view',
   component: ViewComponent,
   canActivate: [Authorize],
   data: { roles: [Role.Student, Role.General] }
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CredittransferRoutingModule { }
