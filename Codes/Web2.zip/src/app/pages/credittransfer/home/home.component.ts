import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LangChangeEvent, TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  slang: string = "en";

  constructor(private router: Router,private translateService: TranslateService) {
   }

  ngOnInit(): void {
    var lang = this.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang;
    });
  }
  setTab(tabname: string) {
    this.router.navigate([tabname]);
  }
}
