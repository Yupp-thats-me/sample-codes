import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LangChangeEvent } from '@ngx-translate/core';
import { CarouselConfig } from 'ngx-bootstrap/carousel';
import { TreeviewConfig } from 'ngx-treeview';
import { environment } from '../../../../environments/environment';
import { BaseComponent } from '../../../app-core/base.component';
import { ContextContainer } from '../../../app-core/context-container';
import { ScholarshipModel } from '../../../models/scholarshipModel';
import { LangService } from "@app/services/lang.service";

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  providers: [
    { provide: CarouselConfig, useValue: { interval: 1500, noPause: false, showIndicators: true } }
  ],
  styleUrls: ['./home.component.scss']
})
export class home extends BaseComponent implements OnInit {
  ScholarshipDetails: any;
  selectedRecordArray: any = [];
  scholarshipURL = '/Scholarship/GetScholarshipDetailsUser'
  index: number = 0;
  slang: string = 'en'
  mobileCarousel: boolean

  sponsorshipModel: ScholarshipModel = {
    TitleEn: '',
    TitleAr: '',
    DescriptionEn: '',
    DescriptionAr: ''
  };

  constructor(context: ContextContainer, private router: Router, private defaultConfig: TreeviewConfig, private LangService: LangService ) {
    super(context);
    if (window.screen.width < 500) {
      this.mobileCarousel = true
    }
  }

  ngOnInit(): void {
    this.slang = this.LangService.currentlang();
    
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {

      if (this.slang != event.lang) {
        this.slang = event.lang;
      }
    });
    this.getScholarshipDetails();
  }

  top1: 0;
  top2: any;
  top3: any;
  top4: any;
  top5: any;
  top6: any;
  

  getScholarshipDetails() {
    this.showCardProgress('data-card');
    this.context.httpService.get(environment.scholarshipUrl + this.scholarshipURL).
      subscribe(
        (response) => {
          this.hideCardProgress('data-card');

          if (response.success) {
            this.selectedRecordArray = [];
            this.selectedRecordArray = response.data;
            for (var i = 0; i < this.selectedRecordArray.length; i++) {
              if (i == 0) {
                this.top1 = this.selectedRecordArray[0]
              }
              if (i == 1) {
                this.top2 = this.selectedRecordArray[1]
              }
              if (i == 2) {
                this.top3 = this.selectedRecordArray[2]
              }
              if (i == 3) {
                this.top4 = this.selectedRecordArray[3]
              }
              if (i == 4) {
                this.top5 = this.selectedRecordArray[4]
              }
              if (i == 5) {
                this.top6 = this.selectedRecordArray[5]
              }
            }
          }
          else {
            this.notifyError('Failed to load data');
          }
        })
  }


  setTab(tabname: string) {
    this.router.navigate([tabname]);
  }

  navigate(data) {
    this.router.navigate(['/scholarship/view'], { queryParams: { id: data } });
  }

  textWrap(word: string) {
    return word.length > 125 ? word.substring(0, 125) + "..." : word;
  }
}