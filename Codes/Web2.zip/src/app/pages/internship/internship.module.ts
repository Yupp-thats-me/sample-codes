import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InternshipRoutingModule } from './internship-routing.module';
import { InternshipviewComponent } from './internship-view/internship-view.component';
import { baseModule } from '../../app-core/Common Modules/baseModule';
import { TreeviewModule } from 'ngx-treeview';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient } from '@angular/common/http';
import { HomepageComponent } from './home-page/home-page.component';
import { BsDatepickerModule, DatepickerModule } from 'ngx-bootstrap/datepicker';
import { AmazingTimePickerModule } from 'amazing-time-picker';
import { InternshipFilterComponent } from './internship-filter/internship-filter.component';
import { ApplicationsListComponent } from './applications-list/applications-list.component';
import { AcceptedPositionsComponent } from './accepted-positions/accepted-positions.component';
import { ProvideFeedbackComponent } from './provide-feedback/provide-feedback.component';
import { FeedbackReceivedComponent } from './feedback-received/feedback-received.component';
import { NgxSummernoteModule } from 'ngx-summernote';
import { SharedemailModule } from '../sharedemail/sharedemail.module';
import { HomePageModule } from '../home-page/home-page.module';


@NgModule({
  declarations: [HomepageComponent,InternshipviewComponent, InternshipFilterComponent, ApplicationsListComponent, AcceptedPositionsComponent, ProvideFeedbackComponent, FeedbackReceivedComponent],
  imports: [
    CommonModule,
    InternshipRoutingModule,
    baseModule,
    AmazingTimePickerModule,
    BsDatepickerModule.forRoot(),
    DatepickerModule.forRoot(),
    TreeviewModule.forRoot(),
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: httpTranslateLoader,
        deps: [HttpClient]
      }
    }),
    NgxSummernoteModule,
    SharedemailModule,
    HomePageModule
  ]
})
export class InternshipModule { }

export function httpTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http);
}
