import { Component, Input, OnInit } from '@angular/core';
import { BaseComponent } from '@app-core/base.component';
import { ContextContainer } from '@app-core/context-container';
import { LangChangeEvent } from '@ngx-translate/core';
import * as moment from 'moment';
import { environment } from 'environments/environment';
import { Feedback } from '@models/feedback.model';
import { ActivatedRoute, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Gender, GenderAr, InternshipType, InternshipTypeAr } from '@services/enumfiles';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { FileUploadControl } from '@iplab/ngx-file-upload';

@Component({
  selector: 'app-internship-view',
  templateUrl: './internship-view.component.html',
  styleUrls: ['./internship-view.component.scss']
})

export class InternshipviewComponent extends BaseComponent implements OnInit {
  internshipUrl: string = '/Internship/GetInternshipDetailsUserviewById/';
  SaveApplyDetails = '/Internship/apply-details';
  SaveAnswerDetails = '/Internship/answer-details';
  dropDownUrl = '/InternshipDropdown/InternshipDropdown';
  slang: string = 'en';
  urlId: number;
  firstParamKey: string;
  internshipDetails: any;
  Edate: string;
  Jdate: string;
  Probabledate: string;
  userId: any;
  studentId: any;
  HigherEducation: any;
  GeneralEducationLevel: any;
  Country: any;
  Emirate: any;
  selectededucation: any;
  selectedcountry: any;
  selectedemirate: any;
  joinDateMin: Date;
  joinDateMax: Date;
  ProbableJoiningDate: string;
  IsStudentProfile: boolean = true;
  IsDocument: boolean = true;
  noquestion: boolean; 
  uploadDocument: Array<File> = [];
  file: any = [];
  answers: any = [];
  objective: boolean = false;
  subjective: boolean = false;
  nextbuttonReadonly: boolean = false;
  ansbuttonReadonly: boolean = false;
  userRole: string = '';
  isShown: boolean = false;
  isHide: boolean = false;
  isHideFeedback: boolean = false;

  public enumGender = Gender;
  public enumGenderAr = GenderAr;
  public enumInternshipType = InternshipType;
  public enumInternshipTypeAr = InternshipTypeAr;
  bsConfig: Partial<BsDatepickerConfig>;
  public documentControl = new FileUploadControl(null);
  validstudent: boolean = false;

  feedbackModel: Feedback = {
    Id: 0,
    InternshipId: 0,
    StudentId: 0,
    Content: 0,
    Design: 0,
    Functionality: 0,
    Personalization: 0,
    UploadDocument: '',
    DocumentTitle: '',
    KeySkills: '',
    ProbableJoiningDate: '',
    IsStudentProfile: false,
    CreatedBy: '',
    AnswerDetails: this.answers,
    StatusId :0
  }

  constructor(context: ContextContainer, private route: ActivatedRoute, private modalService: NgbModal, private router: Router) {
    super(context);
    this.joinDateMin = new Date();
    this.joinDateMin.setDate(this.joinDateMin.getDate());
  }

  get getUserId(): string {
    this.userId = this.context.getUserId();
    var access_token = this.userId.source.value;
    return access_token;
  }

  getStudentId(): number {
    this.studentId = this.context.getUserId();
    var access_token = this.studentId.source.value;
    return access_token;
  }

  ngOnInit(): void {
    this.userId = this.context.getUserId();
    this.studentId= this.context.getUserId();
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang
    });
    this.firstParamKey = this.route.snapshot.queryParamMap.get('id');
    this.urlId = parseInt(this.firstParamKey);
    this.getInternshipdetails();
    this.getDropdowndetails();
  }

  getInternshipdetails() {
    this.context.httpService.get(environment.internshipUrl + this.internshipUrl + this.urlId)
      .subscribe(
        (Response) => {
          this.internshipDetails = Response.data || [];
          this.Jdate = moment.utc(this.internshipDetails.joiningDate).format('MM-DD-YYYY')
          this.Edate = moment.utc(this.internshipDetails.applicationDeadline).format('MM-DD-YYYY')
          this.Probabledate = moment.utc(this.internshipDetails.probableJoiningDate).format('MM-DD-YYYY')
          this.joinDateMin = new Date(this.internshipDetails.joiningDate);
          this.joinDateMax = new Date(this.internshipDetails.lastProbableJoiningDate);
          if (this.internshipDetails.higherEducationId == "11" ||
              this.internshipDetails.higherEducationId == "12" ||
              this.internshipDetails.higherEducationId == "13" ||
              this.internshipDetails.higherEducationId == "29") {
            let education = this.internshipDetails.higherEducationId.split(',');
            this.selectededucation = this.HigherEducation.filter(x => {
              if (education.includes(x.dropdownId.toString())) {
                return x;
              }
            });
          }
          if (this.internshipDetails.higherEducationId == "83" ||
              this.internshipDetails.higherEducationId == "84" ||
              this.internshipDetails.higherEducationId == "85" ||
              this.internshipDetails.higherEducationId == "86") {
            let generaleducation = this.internshipDetails.higherEducationId.split(',');
            this.selectededucation = this.GeneralEducationLevel.filter(x => {
              if (generaleducation.includes(x.dropdownId.toString())) {
                return x;
              }
            });
          }
          let country = this.internshipDetails.countryId.split(',');
          this.selectedcountry = this.Country.filter(x => {
            if (country.includes(x.dropdownId.toString())) {
              return x;
            }
          });
          let emirate = this.internshipDetails.emirateId.split(',');
          this.selectedemirate = this.Emirate.filter(x => {
            if (emirate.includes(x.dropdownId.toString())) {
              return x;
            }
          });
          if (this.internshipDetails.studentId == this.studentId && this.internshipDetails.id == this.internshipDetails.id) {
            this.isShown = false;
            this.isHide = true;
          }
          else {
            this.isShown = true;
            this.isHide = false;
          }
          if (this.internshipDetails.internshipQuestionnaireDetails[0] && this.internshipDetails.internshipQuestionnaireDetails[0].type == 27) {
            this.objective = true;
            this.subjective = false;
          }
          else if (this.internshipDetails.internshipQuestionnaireDetails[0] && this.internshipDetails.internshipQuestionnaireDetails[0].type == 28) {
            this.subjective = true;
            this.objective = false;
          }
          this.answers = this.internshipDetails.internshipQuestionnaireDetails;
          if (this.internshipDetails.internshipQuestionnaireDetails.length <= 0) {
            this.noquestion = false;
          } else {
            this.noquestion = true;
          }
          if (this.internshipDetails.studentId == this.studentId) {
            this.isHideFeedback = true;
          }
          else {
             this.isHideFeedback = false;
          }
        }
    )
  }

  getDropdowndetails() {
    this.context.httpService.get(this.environment.internshipUrl + this.dropDownUrl)
      .subscribe(
        (Response) => {
          this.HigherEducation = Response.data.filter(x => x.category == "HigherEducation");
          this.GeneralEducationLevel = Response.data.filter(x => x.category == "GeneralEducationLevel");
          this.Country = Response.data.filter(x => x.category == "Country");
          this.Emirate = Response.data.filter(x => x.category == "Emirate");
        }
    );
  }

  CheckIsStudentProfile(event: any) {
    this.feedbackModel.UploadDocument = '';
    this.validstudent = event.target.checked;
    if (this.validstudent == true) {
      this.IsDocument = false;
    }
    else {
      this.IsDocument = true;
    }    
  }

  onApply(content) {
    // this.userRole = localStorage.getItem('KCRegistrationRes');
    // if (this.userRole == null) {
    //   localStorage.setItem('redirectUrl', '/internship/view');
    //   localStorage.setItem('queryParamid', this.urlId.toString());
    //   this.context.authenticationService.loginKeyCloak();
    // }
    // else {
      this.modalService.open(content, { ariaLabelledBy: 'modal-primary-title' });
    // } 
  }

  transformFiles(files) {
    files.forEach(element => {
      element.FileName = element.name;
      element.ContentType = element.type;
      element.Length = element.size;
      this.file = element.name;
    });
  }

  onFocusOutEvent($event) {
    if (this.feedbackModel.Content == 0 || this.feedbackModel.Design == 0 || this.feedbackModel.Personalization == 0 || this.feedbackModel.Functionality == 0) {
      this.nextbuttonReadonly = false;
    }
    else {
      this.nextbuttonReadonly = true;
    }
  }
 
  onTextEvent($event) {
    if (this.answers.length == 0 ) {
      this.ansbuttonReadonly = false;
    }
    else {
      this.ansbuttonReadonly = true;
    }
  }

  onSubmit(applicationForm: NgForm) {
    if (applicationForm.invalid) {
        this.notifyError('Please enter all the fields');
        return;
    }

    this.feedbackModel.InternshipId = this.internshipDetails.id;
    this.feedbackModel.CreatedBy = this.userId;
    this.feedbackModel.StudentId = this.studentId;
    this.feedbackModel.StatusId = 1

    var data = this.uploadDocument;
    const formData = new FormData();
    var i = 0;
    data.forEach(file => {
      formData.append('files[' + i + ']', data[i]);
      i++;
    });
    this.transformFiles(data);
    this.feedbackModel.UploadDocument = this.file;

    formData.append('applyDetails.uploadDocument', this.feedbackModel.UploadDocument);
    formData.append('applyDetails.InternshipId', this.feedbackModel.InternshipId == 0 ? "0" : this.feedbackModel.InternshipId.toString());
    formData.append('applyDetails.CreatedBy', this.feedbackModel.CreatedBy);
    formData.append('applyDetails.StudentId', this.feedbackModel.StudentId.toString());
    formData.append('applyDetails.Content', this.feedbackModel.Content.toString());
    formData.append('applyDetails.Design', this.feedbackModel.Design.toString());
    formData.append('applyDetails.Personalization', this.feedbackModel.Personalization.toString());
    formData.append('applyDetails.Functionality', this.feedbackModel.Functionality.toString());
    formData.append('applyDetails.DocumentTitle', this.feedbackModel.DocumentTitle == null || this.feedbackModel.DocumentTitle == '' ? '' : this.feedbackModel.DocumentTitle.toString());
    formData.append('applyDetails.KeySkills', this.feedbackModel.KeySkills == null || this.feedbackModel.KeySkills == '' ? '' : this.feedbackModel.KeySkills.toString());
    formData.append('applyDetails.IsStudentProfile', this.feedbackModel.IsStudentProfile.toString());
    formData.append('applyDetails.ProbableJoiningDate', moment(this.feedbackModel.ProbableJoiningDate).format("YYYY/MM/DD").toString());
    formData.append('applyDetails.StatusId', this.feedbackModel.StatusId.toString());

    this.feedbackModel.AnswerDetails = this.answers;
    (this.answers || []).forEach(item => {
      formData.append('applyDetails.AnswerDetails[i].', item.Answers);
    });
    let questionnaire = this.answers.filter(a => a.Answers);
    for (var i = 0; i < questionnaire.length; i++) {
      let ans = this.answers[i];
      formData.append('applyDetails.AnswerDetails[' + i + '].QuestionnaireId', ans.questionnaireId ? ans.questionnaireId : 0);
      formData.append('applyDetails.AnswerDetails[' + i + '].Answers', ans.Answers);
    }

    if (this.feedbackModel.Id == 0 || this.feedbackModel.Id == null) {
      this.context.httpService.post(environment.internshipUrl + this.SaveApplyDetails, formData).subscribe(
        (Response) => {
          if (Response.success) {
            this.notifySuccess('Applied successfully.Thank you!');
            this.router.navigate(['/internship/home']);
            this.modalService.dismissAll();
          }
          else {
            this.notifyError('Failed to save data');
          }
        }
      );
    }
  }
}
