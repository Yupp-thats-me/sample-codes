import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InternshipviewComponent } from './internship-view.component';

describe('InternshipviewComponent', () => {
  let component: InternshipviewComponent;
  let fixture: ComponentFixture<InternshipviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InternshipviewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InternshipviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
