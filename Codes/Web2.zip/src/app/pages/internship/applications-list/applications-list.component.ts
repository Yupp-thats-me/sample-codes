import { AfterViewInit, Component, ElementRef, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { BaseComponent } from '@app-core/base.component';
import { ContextContainer } from '@app-core/context-container';
import { LangChangeEvent } from '@ngx-translate/core';
import { environment } from 'environments/environment';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { StatusWorkflow, StatusWorkflowAr } from '../../sj-admin/internship/status-workflow';

@Component({
  selector: 'app-applications-list',
  templateUrl: './applications-list.component.html',
  styleUrls: ['./applications-list.component.scss']
})
export class ApplicationsListComponent extends BaseComponent implements AfterViewInit {
  @ViewChildren(DataTableDirective) dtElements: QueryList<DataTableDirective>;
  @ViewChild('search', { static: false }) searchElement: ElementRef;

  public enumStatusWorkflow = StatusWorkflow;
  public enumStatusWorkflowAr = StatusWorkflowAr;
  slang: string = 'en';
  applications: any;
  studentId: any;
  userId: any;
  Status = StatusWorkflow;
  badgeStyle: { [id: string]: string; } = {};
  showData: boolean = false;
  id: any;
  updatedBy: any;
  statusId: any;
  InternshipId: any;

  constructor(context: ContextContainer, private modalService: NgbModal) {
    super(context);
    this.setDTTriggers(['datatable']);
  }

  ngOnInit(): void {
    this.userId = this.context.getUserId();
    this.studentId= this.context.getUserId();
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang
    });
    this.getapplicationslist();
  }

  ngAfterViewInit() {
    this.context.datatableService.init(this.dtElements);
  }

  getStudentId(): number {
    this.studentId = this.context.getUserId();
    var access_token = this.studentId.source.value;
    return access_token;
  }
  get getUserId(): string {
    this.userId = this.context.authenticationService.getUserId();
    var access_token = this.userId.source.value;
    return access_token;
  }

  getapplicationslist() {
    this.context.httpService.get(environment.internshipUrl + '/Internship/application-list/' + this.studentId).subscribe(
      (Response) => {
        if (Response.success) {
          this.applications = Response.data;
          this.context.datatableService.reRender('datatable');
        }
        else {
          this.notifyError('Failed to get data');
        }
      }
    );
  }

  editRow(content, list) {
    
    this.modalService.open(content, { ariaLabelledBy: 'modal-primary-title' });
    this.showData = true;
    this.id = list.id;
    this.updatedBy = this.userId;
    this.statusId = list.statusId
    this.InternshipId = list.userInternshipId
  }

  textWrap(word: string) {
    if (word != null || '') {
      return word.length > 30 ? word.substring(0, 30) + "..." : word;
    }
  }


}
