import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomepageComponent } from './home-page/home-page.component';
import { InternshipviewComponent } from './internship-view/internship-view.component';
import { InternshipFilterComponent } from './internship-filter/internship-filter.component';
import { ApplicationsListComponent } from './applications-list/applications-list.component';
import { AcceptedPositionsComponent } from './accepted-positions/accepted-positions.component';
import { ProvideFeedbackComponent } from './provide-feedback/provide-feedback.component';
import { FeedbackReceivedComponent } from './feedback-received/feedback-received.component';
import { Authorize } from '@app/app-core/identity/auth.guard';
import { Role } from '@app/models/role.enum';

const routes: Routes = [

  {
    path: 'home',
    component: HomepageComponent
  },

  {
    path: 'view',
    component: InternshipviewComponent,
    canActivate: [Authorize],
    data: { roles: [Role.Student] }
  },

  {
    path: 'filter',
    component: InternshipFilterComponent,
    canActivate: [Authorize],
    data: { roles: [Role.Student] }
  },

  {
    path: 'applicationslist',
    component: ApplicationsListComponent,
    canActivate: [Authorize],
    data: { roles: [Role.Student] }
  },

  {
    path: 'acceptedpositions',
    component: AcceptedPositionsComponent,
    canActivate: [Authorize],
    data: { roles: [Role.Student] }
  },
  {
    path: 'provide-feedback',
    component: ProvideFeedbackComponent,
    canActivate: [Authorize],
    data: { roles: [Role.Student,Role.InternshipCounsellor] }
  },
  {
    path: 'feedback-received',
    component: FeedbackReceivedComponent,
    canActivate: [Authorize],
    data: { roles: [Role.Student] }
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InternshipRoutingModule { }
