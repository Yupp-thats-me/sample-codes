import { AfterViewInit, Component, ElementRef, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { BaseComponent } from '@app-core/base.component';
import { LangChangeEvent } from '@ngx-translate/core';
import { ContextContainer } from '@app-core/context-container';
import { environment } from 'environments/environment';
import { Internships } from '@models/internships.model';
import { StatusWorkflow } from '../../sj-admin/internship/status-workflow';

@Component({
  selector: 'app-accepted-positions',
  templateUrl: './accepted-positions.component.html',
  styleUrls: ['./accepted-positions.component.scss']
})

export class AcceptedPositionsComponent extends BaseComponent implements AfterViewInit {
  @ViewChildren(DataTableDirective) dtElements: QueryList<DataTableDirective>;
  @ViewChild('search', { static: false }) searchElement: ElementRef;

  slang: string = 'en';
  accepted: any;
  studentId: any;

  update: Internships = {
    id: 0,
    userinternshipId: 0,
    statusId: 0,
    updatedBy: '',
    status: ''
  } 
  userId: number;

  constructor(context: ContextContainer) {
    super(context);
    this.setDTTriggers(['datatable']);
  }

  ngOnInit(): void {
    this.userId = this.context.getUserId();
    this.studentId= this.context.getUserId();
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang
    });
    this.getacceptedlist();
  }

  ngAfterViewInit() {
    this.context.datatableService.init(this.dtElements);
  }

  getStudentId(): number {
    this.studentId = this.context.getUserId();
    var access_token = this.studentId.source.value;
    return access_token;
  }

  getacceptedlist() {
    this.context.httpService.get(environment.internshipUrl + '/Internship/accepted-list/' + this.studentId).subscribe(
      (Response) => {
        if (Response.success) {
          this.accepted = Response.data;
          this.context.datatableService.reRender('datatable');
        }
        else {
          this.notifyError('Failed to get data');
        }
      }
    );
  }

  editRow(list) {
    this.update.id = list.id;
    this.update.updatedBy = list.updatedBy
    let UserApplyDetailsDto = {
      id: this.update.id,
      statusId: StatusWorkflow.Confirmed,
      updatedBy: this.update.updatedBy
    };
    this.context.notificationService.confirmAlert((confirm) => {
      if (!confirm.dismiss) {
        this.context.httpService.put(environment.internshipUrl + '/Internship/update/' + UserApplyDetailsDto.id, UserApplyDetailsDto).subscribe(
          (Response) => {
            if (Response.success) {
              this.notifySuccess('Confirmed Successfully');
              this.getacceptedlist();
            }
            else {
              this.notifyError('Failed to Confirm');
            }
          });
      }
    }, 'Are you sure to Accept?');
  }

  textWrap(word: string) {
    if (word != null || '') {
      return word.length > 30 ? word.substring(0, 30) + "..." : word;
    }
  }

}
