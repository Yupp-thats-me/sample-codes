import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AcceptedPositionsComponent } from './accepted-positions.component';

describe('AcceptedPositionsComponent', () => {
  let component: AcceptedPositionsComponent;
  let fixture: ComponentFixture<AcceptedPositionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AcceptedPositionsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AcceptedPositionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
