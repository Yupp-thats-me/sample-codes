import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LangChangeEvent } from '@ngx-translate/core';
import { TreeviewConfig, TreeviewItem } from 'ngx-treeview';
import { environment } from 'environments/environment';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { FilterDetails } from '@app/models/internshipsFilter.model';
import { InternshipDuration, PostDate, Age, OrgName } from '@services/enumfiles';
import * as moment from 'moment';

@Component({
  selector: 'app-internship-filter',
  templateUrl: './internship-filter.component.html',
  styleUrls: ['./internship-filter.component.scss']
})

export class InternshipFilterComponent extends BaseComponent implements OnInit {
  InternshipDetails: any;
  dropDownUrl = '/InternshipDropdown/InternshipDropdown';
  internshipURL = '/internship/GetUserInternshipDetailsList/';
  internshipRoleNameUrl = '/Internship/InternshipRoleMaster';
  public enumInternshipDuration = InternshipDuration;
  public internshipDuration = Object.values(InternshipDuration).filter(value => typeof value === 'number');

  page = 1;
  pageSize = 9;
  collectionSize = 0;
  searchText: string;
  isShown: boolean = true;
  dropdown: any;
  countryList: TreeviewItem[];
  emirateList: TreeviewItem[];
  roleList: TreeviewItem[];
  higherEducationList: TreeviewItem[];
  orgDetails: TreeviewItem[];
  ageList: TreeviewItem[];
  dropdowndetails: any = [];
  dropdownSettings = {};
  requiredField: boolean = false;
  limitSelection = false;
  treeviewConfig = TreeviewConfig.create({
    hasAllCheckBox: true,
    hasFilter: true,
    hasCollapseExpand: true,
    decoupleChildFromParent: false,
    maxHeight: 400
  });
  filter: FilterModel = new FilterModel([]);
  slang: string = 'en';
  firstParamKey: any;
  urlId1: number;

  startdDateJoining: any;
  endDateJoining: any;
  startdDateDeadline: any;
  endDateDeadline: any;

  intern: FilterDetails = {
    uploadImage: '',
    internshipRoleNameEn: '',
    internshipRoleNameAr: '',
    eligibilityEn: '',
    eligibilityAr: '',
    countryId: '',
    emirateId: '',
    roleId: '',
    educationId: '',
    higherEducationId: '',
    orgId: null,
    companyNameEn: '',
    companyNameAr: '',
    joiningDate: null,
    applicationDeadline: null,
    ageId: null,
    duration: null,
    postedDays: null,
    internshipTitleEn: '',
    internshipTitleAr: ''
  };

  constructor(context: ContextContainer, private ref: ChangeDetectorRef, private changedetector: ChangeDetectorRef, private router: Router, private route: ActivatedRoute) {
    super(context);
  }

  ngOnInit(): void {
    this.firstParamKey = this.route.snapshot.queryParamMap.get('enumInternshipFor');
    this.urlId1 = parseInt(this.firstParamKey);
    this.getOrgdetails();
    this.getInternshipRoleName();
    this.getdropdowndetails();
    this.getInternshipDetails();
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang
    });
  }

  ngAfterContentChecked() {
    this.ref.detectChanges();
  }

  reInit() {
    this.isShown = false;
    setTimeout(() => {
      this.isShown = true;
    });
  }

  getdropdowndetails() {
    this.context.httpService.get(this.environment.internshipUrl + this.dropDownUrl)
      .subscribe(
        (Response) => {
          this.dropdowndetails = Response.data;
          this.dropdowndetails.map((x: any) => {
            {
              const data = {
                dropdownId: x.dropdownId,
                dropdownValueEn: x.dropdownValueEn,
                dropdownValueAr: x.dropdownValueAr,
                category: x.category,
                isActive: x.isActive,
              };
            }
          })
          this.dropdowns();
        });
  }

  getOrgdetails() {
    this.context.httpService.get(this.environment.internshipUrl + "/InternshipDropdown" + "/OrgDropdown")
      .subscribe(
        (Response) => {
          this.orgDetails = Response.data.map(value => {
            return new TreeviewItem({ text: value.companyNameEn, value: value.companyNameEn, collapsed: true, checked: false });
          });
        });
  }

  getInternshipRoleName() {
    this.context.httpService.get(environment.internshipUrl + this.internshipRoleNameUrl)
      .subscribe
      (Response => {
        this.roleList = Response.data.map(value => {
          return new TreeviewItem({ text: value.internshipRoleNameEn, value: value.internshipRoleId, collapsed: true, checked: false });
        });
      });
  }

  dropdowns() {
    this.countryList = this.binddropdown('Country');
    this.emirateList = this.binddropdown('Emirate');
    this.higherEducationList = this.binddropdown('HigherEducation');
    this.higherEducationList = this.binddropdown('GeneralEducationLevel');
    this.ageList = this.binddropdown('Age');
    this.ageList = this.binddropdown('GeneralEducationAge');
  }

  onSelectedChange($event) { }

  binddropdown(categorystr) {
    let filterdata = this.dropdowndetails.filter(x => x.category == categorystr)
    this.dropdown = filterdata.map(value => {
      return new TreeviewItem({ text: value.dropdownValueEn, value: value.dropdownId, collapsed: true, checked: false });
    });
    return this.dropdown;
  }

  getInternshipDetails() {
    this.context.httpService.get(environment.internshipUrl + this.internshipURL + this.urlId1).
      subscribe(
        (response) => {
          this.filter = new FilterModel(response.data);
          this.filter.reset();
          this.InternshipDetails = response.data
          if (this.urlId1 == 1) {
            this.higherEducationList = this.binddropdown('GeneralEducationLevel');
            this.ageList = this.binddropdown('GeneralEducationAge');
          }
          else if (this.urlId1 == 2) {
            this.higherEducationList = this.binddropdown('HigherEducation');
            this.ageList = this.binddropdown('Age');
          }
        })
  }

  navigate(data) {
    this.router.navigate(['/internship/view'], { queryParams: { id: data } });
  }

  textWrap(word: string) {
    if (word != null || '') {
      return word.length > 70 ? word.substring(0, 70) + "..." : word;
    }
  }

  reset() {
    this.dropdowns();
    this.getInternshipRoleName();
    this.getOrgdetails();
    this.intern.ageId = null;
    this.intern.duration = null;
    this.intern.postedDays = null;
    this.filter.filteredData = [];
    this.startdDateJoining = null;
    this.endDateJoining = null;
    this.startdDateDeadline = null;
    this.endDateDeadline = null;

    this.searchText = '';
    $('#searchText').val('');
  }
}

export class FilterModel {
  countryId: string[] = [];
  emirateId: string[] = [];
  higherEducationId: string[] = [];
  internshipRoleNameEn: string[] = [];
  companyNameEn: string[] = [];
  durationId: number;
  postDateId: number;
  ageId: string[] = [];
  data: any = [];
  filteredData: any = [];
  collectionSize: number;
  myArray: any = [];
  JoiningFromDate: Date;
  JoiningToDate: Date;
  DeadlineFromDate: Date;
  DeadlineToDate: Date;

  constructor(data: any) {
    this.data = data || [];
    this.filteredData = data;
    this.resetCollectionSize();
  }

  resetCollectionSize() {
    this.collectionSize = this.filteredData.length;
  }

  reset() {
    // costly... need to enhance in future.
    for (var item of this.data) {
      item.isVisible = true;
    }
    this.filteredData;
  }

  val: string;
  searchByName(val) {
    this.filteredData = this.data.filter(a =>
      a.internshipTitleEn.toLocaleLowerCase().startsWith(val) || a.internshipTitleEn.toLocaleLowerCase().endsWith(val) || a.internshipTitleEn.toLocaleLowerCase().includes(val) ||
      a.internshipTitleEn.toLocaleUpperCase().startsWith(val) || a.internshipTitleEn.toLocaleUpperCase().endsWith(val) || a.internshipTitleEn.toLocaleUpperCase().includes(val) ||
      a.internshipTitleEn.toLocaleString().startsWith(val) || a.internshipTitleEn.toLocaleString().endsWith(val) || a.internshipTitleEn.toLocaleString().includes(val));
    this.resetCollectionSize();
  }

  updateCountryFilter(data: any) {
    this.countryId = $.map(data, function (d, i) {
      return d.toString();
    });
    this.applyFilter();
  }

  updateEmirateFilter(data: any) {
    this.emirateId = $.map(data, function (d, i) {
      return d.toString();
    });
    this.applyFilter();
  }

  updateRoleFilter(data: any) {
    this.internshipRoleNameEn = $.map(data, function (d, i) {
      return d.toString();
    });
    this.applyFilter();
  }

  updateEducationFilter(data: any) {
    this.higherEducationId = $.map(data, function (d, i) {
      return d.toString();
    });
    this.applyFilter();
  }

  updateOrgFilter(data: any) {
    this.companyNameEn = $.map(data, function (d, i) {
      return d.toString();
    });
    this.applyFilter();
  }

  updateDurationFilter(data: any) {
    this.durationId = data.value;
    this.applyFilter();
  }

  updateAgeFilter(data: any) {
    this.ageId = $.map(data, function (d, i) {
      return d.toString();
    });
    this.applyFilter();
  }

  updateStartDateJoiningFilter(value: any) {
    this.JoiningFromDate = value;
    this.applyFilter();
  }

  updateEndDateJoiningFilter(value: any) {
    this.JoiningToDate = value;
    this.applyFilter();
  }

  updateStartDateDeadlineFilter(value: any) {
    this.DeadlineFromDate = value;
    this.applyFilter();
  }

  updateEndDateDeadlineFilter(value: any) {
    this.DeadlineToDate = value;
    this.applyFilter();
  }

  applyFilter() {

    let data = [];
    let JoiningFromDate = null;
    let JoiningToDate = null;
    if (this.JoiningFromDate && this.JoiningToDate) {
      JoiningFromDate = moment(this.JoiningFromDate).format('MM-DD-YYYY');
      JoiningToDate = moment(this.JoiningToDate).format('MM-DD-YYYY');
    }
    let DeadlineFromDate = null;
    let DeadlineToDate = null;
    if (this.DeadlineFromDate && this.DeadlineToDate) {
      DeadlineFromDate = moment(this.DeadlineFromDate).format('MM-DD-YYYY');
      DeadlineToDate = moment(this.DeadlineToDate).format('MM-DD-YYYY');
    }

    for (let item of this.data || []) {

      let countryIdItems = item.countryId ? (item.countryId.toString()).split(',') : [];
      let emirateIdItems = item.emirateId ? (item.emirateId.toString()).split(',') : [];
      let roleIdItems = item.internshipRoleNameEn ? (item.internshipRoleNameEn.toString()).split(',') : [];
      let educationIdItems = item.higherEducationId ? (item.higherEducationId.toString()).split(',') : [];
      let companyIdItems = item.companyNameEn ? (item.companyNameEn).split(',') : [];
      let ageIdItems = item.ageId ? (item.ageId.toString()).split(',') : [];

      let joiningDate = moment(item.joiningDate).format('MM-DD-YYYY');
      let applicationDeadline = moment(item.applicationDeadline).format('MM-DD-YYYY');

      if (
        ((this.countryId.some(item => countryIdItems.includes(item))) || this.countryId.length == 0)
        && ((this.emirateId.some(item => emirateIdItems.includes(item))) || this.emirateId.length == 0)
        && ((this.internshipRoleNameEn.some(item => roleIdItems.includes(item)) || this.internshipRoleNameEn.length == 0))
        && (this.higherEducationId.some(item => educationIdItems.includes(item)) || this.higherEducationId.length == 0)
        && ((this.companyNameEn.some(item => companyIdItems.includes(item)) || this.companyNameEn.length == 0))
        && ((this.ageId.some(item => ageIdItems.includes(item)) || this.ageId.length == 0))
        && (
          (!JoiningFromDate && !JoiningToDate)
          || ((moment(joiningDate).isSameOrAfter(moment(JoiningFromDate)))
            && moment(joiningDate).isSameOrBefore(moment(JoiningToDate)))
        )
        && (
          (!DeadlineFromDate && !DeadlineToDate)
          || ((moment(applicationDeadline).isSameOrAfter(moment(DeadlineFromDate)))
            && moment(applicationDeadline).isSameOrBefore(moment(DeadlineToDate)))
        )

      ) {
        data.push(item);
      }
      else {
      }
    }
    this.filteredData = data;
    this.resetCollectionSize();
  }
}
