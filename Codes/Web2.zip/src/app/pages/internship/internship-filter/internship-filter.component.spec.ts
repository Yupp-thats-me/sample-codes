import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InternshipFilterComponent } from './internship-filter.component';

describe('InternshipFilterComponent', () => {
  let component: InternshipFilterComponent;
  let fixture: ComponentFixture<InternshipFilterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InternshipFilterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InternshipFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
