import { AfterViewInit, Component, ElementRef, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { ContextContainer } from '@app/app-core/context-container';
import { DataTableDirective } from 'angular-datatables';
import { BaseComponent } from '@app/app-core/base.component';
import { LangChangeEvent } from '@ngx-translate/core';
import { environment } from 'environments/environment';
import * as moment from 'moment';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService } from '@app/services/authentication.service';
import { InternshipFeedback } from '@app/models/internshipFeedback.model';


@Component({
  selector: 'app-provide-feedback',
  templateUrl: './provide-feedback.component.html',
  styleUrls: ['./provide-feedback.component.scss']
})
export class ProvideFeedbackComponent extends BaseComponent implements AfterViewInit {
  @ViewChildren(DataTableDirective) dtElements: QueryList<DataTableDirective>;
  @ViewChild('search', { static: false }) searchElement: ElementRef;
  isFormVisible: boolean;

  slang: string = 'en';
  expDateMin: Date;
  expDateMax: Date;
  joinDateMin: Date;
  joinDateMax: Date;
  newDateMax: Date;
  newDateMin: Date;
  CurrentDate = new Date();

  candidates: any = [];
  candidateList: any;

  adminrating = [];
  rate = [];
  studentrating = [];
  studentrate = [];


  fall: boolean = false;
  spring: boolean = false;
  summer: boolean = false;

  feedback: InternshipFeedback = {
    Id: 0,
    StudentId: 0,
    InternshipId: 0,
    ScientificLiteracy: 0,
    TechLiteracy: 0,
    FinancialLiteracy: 0,
    CriticalThinking: 0,
    Creativity: 0,
    Communication: 0,
    Collaboration: 0,
    Adaptability: 0,
    Leadership: 0,
    SocialAwarness: 0,
    Empathy: 0,
    GrowthMindset: 0,
    OverallSatisfaction: 0,
    ShortDescription: '',
    Strength: '',
    DevelopmentAreas: '',
    Comments: '',
    Term: 0,
    SupervisorName: '',
    SupervisorDesignation: '',
    SupervisorEmailId: '',
    joiningDate: '',
    expiryDate: '',
    Fall: 0,
    Spring: 0,
    Summer: 0,
    NewDate: '',
    id: 0,
    UserId: 0,
    employerId:0,
    employerName: '',
    location: '',
    accountTYpe: '',
    minimumHoursRequiredId: 0,
    duration: 0,
    internshipId: 0,
    studentId: 0,
    createdDate: '',
    studentName: '',
    email: '',
    mobileNo: 0,
    studentLocation: '',
    institute: '',
    degreeName: '',
    majorName: '',
    status: 0,
    updatedBy: 0,
    internshipRoleNameEn: '',
    monthlySalaryRangeId: '',
    AdminFeedbackRatingModel: this.adminrating,
    createdBy: '',
    Rating:0,
    IsApplicable:0,
    anyFeedback:'',
    StudentFeedbackRatingModel: this.studentrating,
    feedbackAdmin:'',
    department:''
  }
  //  studentId = 146;
  //  internshipId = 417;
  // userId = 219;
  studentDatas: any;
  employerData: any;
  monthlySalaryRangeId: number;
  test1: any;
  test2: any;
  feedbackdata: any;
  readOnly: boolean=false;
  isEditable: boolean;
  //studentFeedbackId=7;
  feedbackDetails: any;
  userId: any;
  intern: any;
  //internshipId: any;
  studentId: any;
  buttonDisabled: boolean = false;

  constructor(context: ContextContainer,private route: ActivatedRoute, private router: Router,private authenticateService: AuthenticationService) {
    super(context);
   this.setDTTriggers(['pendingdatatable', 'feedbackdatatable']);

  }

   ngAfterViewInit() {
   this.context.datatableService.init(this.dtElements);
  }

  reloadCurrentPage() {
    location.reload();
   }


  ngOnInit(): void {
    this.userId = this.context.getUserId();
    this.studentId= this.context.getUserId();
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang
    });
    this.getDetails();
   this.getProvidedDetails();
  }
  public hide() {
    this.isFormVisible = false;
    this.reloadCurrentPage();
  }
  get getUserId(): string {
    this.userId = this.context.getUserId();
    var access_token = this.userId.source.value;
    return access_token;
  }
  get getStudentId(): number {
    this.studentId = this.context.getUserId();
    var access_token = this.studentId.source.value;
    return access_token;
  }

  getDetails() {
    this.context.httpService.get(environment.internshipUrl + '/Internship/pendinglist-students/' + this.studentId).subscribe(
      (Response) => {
        if (Response.success) {
          this.candidates = Response.data;
          this.candidates = this.candidates.filter(x => x.createdBy== this.userId.toString());
          this.context.datatableService.reRender('pendingdatatable');
        } else {
          this.notifyError('Failed to get data');
        }
      });
  }

  getProvidedDetails() {
    
    this.context.httpService.get(environment.internshipUrl + '/Internship/providedlist-student/' + this.studentId + '/' + this.userId).subscribe(
      (Response) => {
        if (Response.success) {
          this.feedbackDetails = Response.data;
          this.context.datatableService.reRender('feedbackdatatable');
        } else {
          this.notifyError('Failed to get data');
        }
      });
  }

   getStudentsDetails(internshipId,studentId,value) { 
    this.showCardProgress("grid-card");
    this.context.httpService.get(this.environment.internshipUrl + '/Internship/feedback-details-student/' + internshipId + '/' + studentId)
      .subscribe(
        (Response) => {
          this.hideCardProgress("grid-card");
          if (Response.success) {
            this.studentDatas = Response.data || [];
            if (value == 0) {
              //this.isEditable = false;
              this.readOnly = false;
            }
            this.isFormVisible = true;
            this.feedback.studentName = this.studentDatas[0].studentName;
            this.feedback.studentLocation = this.studentDatas[0].studentLocation;
            this.feedback.email = this.studentDatas[0].email;
            this.feedback.institute = this.studentDatas[0].institute;
            this.feedback.majorName = this.studentDatas[0].majorEn;
            this.feedback.internshipRoleNameEn = this.studentDatas[0].internshipRoleNameEn;
            this.feedback.monthlySalaryRangeId = this.studentDatas[0].monthlySalaryRangeId;
            if (this.feedback.monthlySalaryRangeId == '1') {
              this.test1 = true;
              this.test2 = false;
            }
            else {
              this.test1 = false;
              this.test2 = true;
            }
            this.feedback.employerName = this.studentDatas[0].employerName;
            this.feedback.location = this.studentDatas[0].location;
            this.feedback.minimumHoursRequiredId = this.studentDatas[0].minimumHoursRequiredId;
            this.feedback.joiningDate = moment(this.studentDatas[0].joiningDate).format('YYYY/MM/DD');
            this.adminrating = this.studentDatas[0].studentFeedbackRatingModel;
            this.feedback.duration = this.studentDatas[0].duration;
            this.feedback.expiryDate = moment(this.feedback.joiningDate, 'YYYY/MM/DD').add(this.feedback.duration, 'weeks').format("YYYY/MM/DD").toString();
          }

        });
  }

  onSubmit(feedbackform) {
 
    this.feedback.studentId = this.candidates[0].studentId;
    this.feedback.internshipId = this.candidates[0].internshipId;
    this.feedback.employerId = this.studentDatas[0].userId;
    this.feedback.createdBy = this.candidates[0].createdBy;

    if (feedbackform.invalid) {
      this.notifyError('Please enter all the mandatory fields');
      this.buttonDisabled = false;
      return;
    }

    let data = new FormData();

    this.feedback.StudentFeedbackRatingModel = this.adminrating;
    (this.adminrating || []).forEach(item => {
      data.append('feedbackrating.StudentFeedbackRatingModel[i].', item.adminrating);
    });


    for (var i = 0; i < this.adminrating.length; i++) {
      if(this.adminrating[i].rating==0 && this.adminrating[i].isApplicable==false || this.adminrating[10].rating==0){
        this.notifyError('Please Provide Feedback');
        return;
      }
      }

    for (var i = 0; i < this.adminrating.length; i++) {
      let item = this.adminrating[i];
      data.append('feedbackrating.StudentFeedbackRatingModel[' + i + '].Id', item.id ? item.id : 0);  
      data.append('feedbackrating.StudentFeedbackRatingModel[' + i + '].ParameterId', item.dropdownId);
      data.append('feedbackrating.StudentFeedbackRatingModel[' + i + '].Rating', item.rating);
      data.append('feedbackrating.StudentFeedbackRatingModel[' + i + '].IsApplicable', item.isApplicable);
      data.append('feedbackrating.StudentFeedbackRatingModel[' + i + '].CreatedBy', item.createdBy);
     // data.append('feedbackrating.StudentFeedbackRatingModel[' + i + '].CreatedBy', this.feedback.createdBy.toString());

    }
    data.append('feedbackrating.StudentFeedbackId', this.feedback.Id == 0 ? "0" : this.feedback.Id.toString());
    data.append('feedbackrating.studentId', this.feedback.studentId.toString());
    data.append('feedbackrating.internshipId', this.feedback.internshipId.toString());
    data.append('feedbackrating.EmployerId', this.feedback.employerId.toString());
    data.append('feedbackrating.Department',this.feedback.department.toString());
    data.append('feedbackrating.anyFeedback', this.feedback.anyFeedback.toString());
    data.append('feedbackrating.expiryDate', moment(this.feedback.expiryDate).format("YYYY/MM/DD").toString());
    data.append('feedbackrating.SupervisorName', this.feedback.SupervisorName.toString());
    data.append('feedbackrating.SupervisorDesignation', this.feedback.SupervisorDesignation.toString());
    data.append('feedbackrating.SupervisorEmailId', this.feedback.SupervisorEmailId.toString());
    data.append('feedbackrating.CreatedBy', this.feedback.createdBy.toString());
    data.append('feedbackrating.Term', this.feedback.Term.toString());
    this.context.httpService.post(this.environment.internshipUrl + '/Internship/studentfeedback-details', data).subscribe(
      (Response) => {
        this.hideCardProgress('form-card');
        if (Response.success) {
          this.notifySuccess('Data Saved Succesfully');
          this.isFormVisible = false;
          this.getDetails();
          this.getProvidedDetails();
          this.buttonDisabled = false;
        }
        else {
          this.notifyError('Failed to update')
          this.buttonDisabled = false;
          this.getDetails();
          this.getProvidedDetails();
        }
        // this.buttonDisabled = false;
        window.scrollTo(0, 100);
        this.buttonDisabled = false;
        
      });
  }

  getStudentFeedbackDetails(intern,value) {
    var studentFeedbackId = intern.studentFeedbackId;   
    this.showCardProgress("grid-card");
    this.context.httpService.get(this.environment.internshipUrl + '/Internship/students-details/' + studentFeedbackId)
      .subscribe(
        (Response) => {
          this.hideCardProgress("grid-card");
          if (Response.success) {
            this.studentDatas = Response.data || [];
            if(value==1){
            this.readOnly = true;
            this.buttonDisabled=true;
           // this.isEditable = true;
            }      
            this.isFormVisible = true;
            this.feedback.studentName = this.studentDatas.studentName;
            this.feedback.studentLocation = this.studentDatas.studentLocation;
            this.feedback.email = this.studentDatas.email;
            this.feedback.institute = this.studentDatas.institute;
            this.feedback.majorName = this.studentDatas.majorEn;
            this.feedback.internshipRoleNameEn = this.studentDatas.internshipRoleNameEn;
            this.feedback.Term = this.studentDatas.term;
            this.feedback.monthlySalaryRangeId = this.studentDatas.monthlySalaryRangeId;
            if (this.feedback.monthlySalaryRangeId == '1') {
              this.test1 = true;
              this.test2 = false;
            }
            else {
              this.test1 = false;
              this.test2 = true;
            }
            this.feedback.employerName = this.studentDatas.employerName;
            this.feedback.location = this.studentDatas.location;
            this.feedback.department=this.studentDatas.department;
            this.feedback.accountTYpe = this.studentDatas.accountTYpe;
            this.feedback.minimumHoursRequiredId = this.studentDatas.minimumHoursRequiredId;
            this.feedback.joiningDate = moment(this.studentDatas.joiningDate).format('YYYY/MM/DD');
            this.feedback.duration = this.studentDatas.duration;
            this.feedback.expiryDate = moment(this.feedback.joiningDate, 'YYYY/MM/DD').add(this.feedback.duration, 'weeks').format("YYYY/MM/DD").toString();
            this.feedback.SupervisorName = this.studentDatas.supervisorName;
            this.feedback.SupervisorDesignation = this.studentDatas.supervisorDesignation;
            this.feedback.SupervisorEmailId = this.studentDatas.supervisorEmailId;
            this.feedback.anyFeedback = this.studentDatas.anyFeedback;
            this.adminrating=this.studentDatas.studentFeedbackRatingModel
            if(this.studentDatas.term == '1'){
              this.fall = true;
            }
            else if(this.studentDatas.term == '2'){
              this.spring = true;
            }
            else if(this.studentDatas.term == '3'){
              this.summer = true;
            }
          }
        });
  }
 
  resetRating(i: number) {
    this.adminrating[i].rating = 0;
  }
  resetApplicable(i: number) {
    if (this.adminrating[i].rating > 0) {
      this.adminrating[i].isApplicable = false;
    }
  }


}
