import { AfterViewInit, Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import { BaseComponent } from '@app-core/base.component';
import { LangChangeEvent } from '@ngx-translate/core';
import { DataTableDirective } from 'angular-datatables';
import { ContextContainer } from '@app-core/context-container';
import { environment } from 'environments/environment';
import { InternshipFeedback } from '../../../models/internshipFeedback.model';
import * as moment from 'moment';

@Component({
  selector: 'app-feedback-received',
  templateUrl: './feedback-received.component.html',
  styleUrls: ['./feedback-received.component.scss']
})

export class FeedbackReceivedComponent extends BaseComponent implements AfterViewInit {
  @ViewChild(DataTableDirective) dtElement: DataTableDirective;
  @ViewChild('search', { static: false }) searchElement: ElementRef;

  slang: string = 'en';
  feedbacklist: any;
  studentId: any;
  isFormVisible: boolean;
  showData: boolean = false;
  feedbackId: any;
  studentDatas: any;
  adminrating: any = [];
  CurrentDate = new Date();

  fall: boolean = false;
  spring: boolean = false;
  summer: boolean = false;

  feedback: InternshipFeedback = {
    Id: 0,
    joiningDate: '',
    expiryDate: '',
    id: 0,
    UserId: 0,
    employerId: 0,
    internshipId: 0,
    studentId: 0,
    AdminFeedbackRatingModel: this.adminrating,
    FeedbackId: 0
  }
  monthlySalaryRangeId: number;
  test1: any;
  test2: any;
  userId:any;

  constructor(context: ContextContainer) {
    super(context);
    this.setDTTriggers(['datatable']);
  }

  ngOnInit(): void {
    this.userId = this.context.getUserId();
    this.studentId = this.context.getUserId();
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang;
    });
    this.getfeedbacklist();
  }

  ngAfterViewInit() {
    this.context.datatableService.init(this.dtElement);
  }

  get getUserId(): string {
    this.userId = this.context.getUserId();
    var access_token = this.userId.source.value;
    return access_token;
  }
  get getStudentId(): number {
    this.studentId = this.context.getUserId();
    var access_token = this.studentId.source.value;
    return access_token;
  }

  getfeedbacklist() {
    this.context.httpService.get(environment.internshipUrl + '/Internship/studentfeedback-received/' + this.studentId).subscribe(
      (Response) => {
        if (Response.success) {
          this.feedbacklist = Response.data;
          this.context.datatableService.reRender('datatable');
        }
        else {
          this.notifyError('Failed to get data');
        }
      }
    );
  }
 
  textWrap(word: string) {
    if (word != null || '') {
      return word.length > 30 ? word.substring(0, 30) + "..." : word;
    }
  }

  public hide(feedbackform) {
    this.isFormVisible = false;
    this.resetForm(feedbackform);
  }

  resetForm(feedbackform) {
    feedbackform.resetForm();
    window.scrollTo(0, 100);
  }

  sendData(feedback) {
    this.showCardProgress("grid-card");
    var feedbackId = feedback.feedbackId;
    var internshipid = feedback.internshipId;

    this.context.httpService.get(this.environment.internshipUrl + '/Internship/admin-details/' + internshipid + '/' + feedbackId)
      .subscribe(
        (Response) => {
          this.hideCardProgress("grid-card");
          if (Response.success) {
            this.studentDatas = Response.data || [];
            this.isFormVisible = true;
            this.showData = true;
            this.feedback.joiningDate = moment(this.studentDatas.joiningDate).format('YYYY/MM/DD');
            this.feedback.duration = this.studentDatas.duration;
            this.feedback.monthlySalaryRangeId = this.studentDatas.monthlySalaryRangeId;
            if (this.feedback.monthlySalaryRangeId == '24') {
              this.test1 = true;
              this.test2 = false;
            }
            else {
              this.test1 = false;
              this.test2 = true;
            }
            this.feedback.expiryDate = moment(this.feedback.joiningDate, 'YYYY/MM/DD').add(this.feedback.duration, 'weeks').format("YYYY/MM/DD").toString();
            this.adminrating = this.studentDatas.adminFeedbackRatingModel;
            if(this.studentDatas.term == '1'){
              this.fall = true;
            }
            else if(this.studentDatas.term == '2'){
              this.spring = true;
            }
            else if(this.studentDatas.term == '3'){
              this.summer = true;
            }
          }
          
        });
  }
}
