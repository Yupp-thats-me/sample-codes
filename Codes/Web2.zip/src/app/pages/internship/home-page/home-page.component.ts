import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BaseComponent } from '../../../app-core/base.component';

import { ContextContainer } from '../../../app-core/context-container';
import { UserDetails } from '../../../models/user-details.model';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss']
})
export class HomepageComponent extends BaseComponent{

  studentCategory: null;

  constructor(context: ContextContainer, private router: Router) {
    super(context);
  }

  ngOnInit(): void {
    const userDetails = this.context.getUserDetails();
    this.studentCategory = userDetails.educationCategoryId;
  }

  setTab(tabname: string) {
    this.router.navigate([tabname]);
  }

  navigate(data) {
    this.router.navigate(['/internship/filter'], { queryParams: { enumInternshipFor: data } });
  }

}
