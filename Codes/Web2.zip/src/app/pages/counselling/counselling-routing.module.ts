import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CounsellingComponent } from './counselling.component';
import { authorizationcheck } from '@services/AuthorizationCheck';
import { Role } from '@models/role.enum';
import { LandingPageComponent } from './student/landing-page/landing-page.component';
import { ListComponent } from './student/list/list.component';
import { FaqListComponent } from './student/faq-list/faq-list.component';
import { ViewComponent } from './student/view/view.component';
import { Authorize } from '@app/app-core/identity/auth.guard';

const routes: Routes = [
  {
    path: '',
    component: CounsellingComponent,
    children: [
      {
        path: '',
        redirectTo: 'student',
        pathMatch: 'full'
      },
      {
        path: 'student',
        loadChildren: () => import('./student/student-routing.module').then(module => module.StudentRoutingModule),
        canActivate: [Authorize],
        data: { roles: [Role.Student] }
      },
      {
        path: 'counsellors',
        loadChildren: () => import('./counsellor/counsellor-routing.module').then(module => module.CounsellorRoutingModule),
        canActivate: [Authorize],
        data: { roles: [Role.Counsellor] }
      },
      {
        path: 'home',
        component: LandingPageComponent
      },
      {
      path: 'list',
      component: ListComponent
      },

  {
    path: 'view/:id',
    component: ViewComponent
  },
  {
    path: 'faq-list',
    component: FaqListComponent
  }

    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CounsellingRoutingModule { }
