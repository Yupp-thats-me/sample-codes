import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FaqListComponent } from './faq-list/faq-list.component';
import { ListComponent } from './list/list.component';

import { LandingPageComponent } from "./landing-page/landing-page.component";
import { StudentComponent } from './student.component';
import { ConnectCounsellorComponent } from './connect-counsellor/connect-counsellor.component';
import { ViewComponent } from './view/view.component';
import { InboxStudentComponent } from './inbox-student/inbox-student.component';
import { MyCounsellingComponent } from './my-counselling/my-counselling.component';
import { CalenderComponent } from './calender/calender.component';
import { authorizationcheck } from '@app/services/AuthorizationCheck';
import { Role } from '@app/models/role.enum';
import { Authorize } from '@app/app-core/identity/auth.guard';

const routes: Routes = [
  {
    path: '',
    component: StudentComponent
  },

  {
    path: 'connect-counsellor/:id',
    component: ConnectCounsellorComponent,
    canActivate: [Authorize],
    data: { roles: [Role.Student]}
  },

  {
    path: 'inbox',
    component: InboxStudentComponent,
    canActivate: [Authorize],
    data: { roles: [Role.Student]}
  },
  {
    path: 'my-counselling',
    component: MyCounsellingComponent,
    canActivate: [Authorize],
    data: { roles: [Role.Student]}
  },
  {
    path: 'calendar',
    component:CalenderComponent,
    canActivate: [Authorize],
    data: { roles: [Role.Student]}
  },
 ];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StudentRoutingModule { }
