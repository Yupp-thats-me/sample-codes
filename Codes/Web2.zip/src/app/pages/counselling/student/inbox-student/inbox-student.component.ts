import { HttpParams } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { ConnectCounsellor } from '@app/models/connectcounsellor.model';
import { PostFaq } from '@app/models/postfaq.model';
import { Status } from '@app/models/status';
import { FileUploadControl } from '@iplab/ngx-file-upload';
import { environment } from 'environments/environment';
import * as moment from 'moment';
import { Questions } from '../faq-list/faq-list.component';

@Component({
  selector: 'app-inbox-student',
  templateUrl: './inbox-student.component.html',
  styleUrls: ['./inbox-student.component.scss']
})
export class InboxStudentComponent extends BaseComponent implements OnInit {

  activeTab = 'search';
  connectCounsellor: ConnectCounsellor =
    {
      Id: 0,
      StudentId: 0,
      CounsellorId: 0,
      Status: false,
      Category: null,
      Service: null,
      Subject: '',
      AskQuestion: '',
      Purpose: '',
      Option: 0,
      PreferredLanguage: null,
      UploadFile: '',
      CreatedBy: '',
      UpdatedBy: '',
      Duration: null,
      SelectedDate: '',
      StartTime: '',
      EndTime: '',
      PostedDate: '',
      ReplayDate: '',
      Pinned: false,
      Answer: '',
      IsActive: true
    }
  readonly Status: typeof Status = Status;

  uploadFile: Array<File> = [];
  answerQues: '';
  ansValidation: boolean = false
  counsellingURL: string = '/Counselling/QandA';
  filterURL: string = '/Counselling/FilterQandA';
  askUrl: string = '/Counselling/QandAResponse';
  markUrl: string = '/Counselling/QandAPin';
  public documentControl = new FileUploadControl(null);
  qaList = [];
  filterList = [];
  pagination: Pagination = new Pagination(1, 0, 10, [10, 20, 30, 40]);
  serverPage: number = 1;
  clickCount: number = 5;
  visibleRecentview: boolean = false;
  visibleRecent: boolean = false;
  visibleAnswerview: boolean = false;
  visibleAnswer: boolean = false;
  config: any;
  answerList = [];

  mark: boolean = false;
  answer: boolean = false;
  filterAnswerList = [];
  clickCountanswer: number = 5;
  pinnedList = [];
  isFormVisible: boolean;
  postFaq: PostFaq = {
    Id: 0,
    CounsellorId: 0,
    QuestionEn: '',
    AnswerEn: '',
    QuestionAr: '',
    AnswerAr: '',
    CategoryId: null,
    RejectReason: '',
    PostedDate: '',
    StatusId: 0,
    CreatedDate: '',
    UpdatedDate: '',
    CreatedBy: '',
    UpdatedBy: '',
    IsActive: true
  }
  dropURL: string = '/Dropdown/dropdowns';
  faqUrl: string = '/Counselling/FaqDetails';
  postfaqUrl: string = '/Counselling/FaqDetail';
  categoryList: any;
  faqList = [];
  userId: any;
  badgeStyle: { [id: string]: string; } = {};
  file: any;
  fieldsetDisabled: boolean = false;
  active: boolean = false;
  list: boolean = true;
  listSample: any;
  listId: any;
  searchText: string;
  postedDate: string;
  subject: any;

  constructor(context: ContextContainer) {
    super(context);
    this.config = {
      itemsPerPage: 10,
      currentPage: this.pagination.page,
      totalItems: 0
    };
  }

  ngOnInit(): void {
    this.getQuestionList();
    this.getdropdown();
    this.initBadgeStyle();
  }

  onSelect(): void {
    this.list = false;
  }
  initBadgeStyle() {

    this.badgeStyle[Status.Draft] = 'badge badge-info';
    this.badgeStyle[Status.Pending] = 'badge badge-warning';
    this.badgeStyle[Status.Approved] = 'badge badge-success';
    this.badgeStyle[Status.Rejected] = 'badge badge-danger';
  }
  listClick(a, id) {
    this.list = false;
    this.subject = a.subject;
    this.postedDate = moment(a.postedDate).format("ll");
    let params = new HttpParams();
    params = params.append('Id', id.toString());
    params = params.append('StudentId', a.studentId.toString());
    this.qaList.forEach(element => {
      if (element.id == id) {
        element.active = true;
        element.date = moment(a.postedDate).format("ll");
      }
    })
    this.context.httpService.get(environment.counsellingUrl + '/Counselling/QandAbyId', { params: params }).
      subscribe(
        (response) => {
          this.listId = response.data;
        });
  }

  search(activeTab) {
    this.visibleRecent = false;
    this.visibleAnswer = false;
    this.activeTab = activeTab;
    this.config = {
      itemsPerPage: 10,
      currentPage: this.pagination.page,
      totalItems: 0
    };
    this.getQuestionList();
  }
  back() {
    this.getQuestionList();
    this.list = true;
  }
  markPin(id) {

    this.listId.forEach(element => {
      if (element.id == id) {
        element.pinned = true
      }
    });
  }
  expand() {
    this.active = true;
  }
  download(item, name) {

    let document = this.createFile(item, name);
    //let file = new Blob([document], { type: document.type });
    //saveAs(document, name);
    this.context.fileUtility.download(item, name);
  }
  fileChange(e) {

    this.uploadFile = e.target.files;
  }
  getQuestionList() {

    this.visibleRecentview = true;
    this.visibleAnswerview = true;
    this.visibleRecent = true;
    this.visibleAnswer = false;
    this.filterList = [];

    let params = new HttpParams();
    params = params.append('studentId', this.context.getUserId().toString());

    params = params.append('page', this.serverPage.toString());
    params = params.append('pagesize', this.pagination.pageSize.toString());
    this.context.httpService.get(environment.counsellingUrl + this.filterURL, { params: params }).
      subscribe(
        (response) => {
          if (response.data.items) {
            if (this.config.currentPage == 1) {
              this.qaList = [];
              this.qaList = response.data.items;
              this.qaList.forEach(ele => {
                ele.active = false;
              })
            }
            else {
              var items = [];
              items = response.data.items;
              items.forEach((ele) => {
                this.qaList.push(ele);
              })
            }
          }
        });

  }
  onPageChangeRecent(e) {

    this.config.currentPage = e;
    this.pagination.page = e;
    //this.getQuestionList(this.active);
    if (this.pagination.page == this.clickCount) {
      this.serverPage = this.pagination.page + 1;
      this.getQuestionList();
      this.clickCount = this.clickCount + 5;
    }
  }




  send(e) {
    if (this.answerQues == undefined ) {
     this.notifyError("Please send the response")
      return
    }
    e.status = false;
    this.ansValidation=false;
    var data = this.uploadFile;

    var date = new Date();
    const formData = new FormData();
    var i = 0;
    if (data) {

      formData.append('files[' + i + ']', data[i]);

    }
    formData.append('qandAdetail.id', '0');
    formData.append('qandAdetail.studentId', e.studentId.toString());
    formData.append('qandAdetail.counsellorId', e.counsellorId.toString());
    formData.append('qandAdetail.status', e.status.toString());
    formData.append('qandAdetail.qandAListId', e.qandAListId.toString());
    formData.append('qandAdetail.question', this.answerQues);
    formData.append('qandAdetail.categoryId', e.categoryId.toString());
    formData.append('qandAdetail.serviceId', e.serviceId.toString());
    formData.append('qandAdetail.subject', e.subject.toString());
    formData.append('qandAdetail.language', e.language.toString());
    formData.append('qandAdetail.createdBy', this.context.getUserId().toString());
    formData.append('qandAdetail.createdDate', moment(date).format());
    formData.append('qandAdetail.postedDate', moment(date).format());
    formData.append('qandAdetail.updatedDate', moment(date).format());
    formData.append('qandAdetail.updatedBy', this.context.getUserId().toString());
    formData.append('qandAdetail.isActive', 'true');


    this.context.httpService.post(environment.counsellingUrl + this.counsellingURL, formData).subscribe(
      (response) => {
        var successmsg = "Response send successfully";
        if (response.error != true) {
          this.notifySuccess(successmsg);
          this.documentControl.clear();
          this.answerQues = '';
          this.listClick(e, e.qandAListId);
        }
      });
  }

  getdropdown() {
    this.context.httpService.get(environment.counsellingUrl + this.dropURL).
      subscribe(
        (response) => {
          if (response.data.categoryMaster) {
            this.categoryList = response.data.categoryMaster;
          }
        });
  }

  textWrap(word: string) {
    if (word)
      return word.length > 30 ? word.substring(0, 30) + "..." : word;
    else return "";
  }

  bindQues(item) {
    this.postFaq.CategoryId = item.categoryId;
    this.postFaq.QuestionEn = item.questionEn;
    this.postFaq.QuestionAr = item.questionAr;
    this.postFaq.AnswerEn = item.answerEn;
    this.postFaq.AnswerAr = item.answerAr;
  }
  cancel(f: NgForm) {
    this.postFaq = {
      Id: 0,
      CounsellorId: 0,
      QuestionEn: '',
      AnswerEn: '',
      QuestionAr: '',
      AnswerAr: '',
      CategoryId: null,
      RejectReason: '',
      PostedDate: '',
      StatusId: 0,
      CreatedDate: '',
      UpdatedDate: '',
      CreatedBy: '',
      UpdatedBy: '',
      IsActive: true
    }
    f.resetForm();
  }
  public hideForm() {
    this.isFormVisible = false;
  }
  public showForm(form: NgForm) {

    //this.resetForm(form);
    this.isFormVisible = true;
  }

}

export class PageResult<T>{
  Count: number;
  PageIndex: number;
  PageSize: number;
  Items: T[];
}
export class Pagination {
  page: number;
  count: number;
  pageSize: number;
  pageSizes: number[];
  constructor(page?: number, count?: number, pageSize?: number, pageSizes?: number[]) {
    this.page = page;
    this.count = count;
    this.pageSize = pageSize;
    this.pageSizes = pageSizes;
  }
}
export class BadgeStyle {
  Pending: string;
  Approved: string;
  Rejected: string;
  OnHold: string;
}

