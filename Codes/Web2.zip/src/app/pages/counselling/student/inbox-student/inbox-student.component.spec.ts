import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InboxStudentComponent } from './inbox-student.component';

describe('InboxStudentComponent', () => {
  let component: InboxStudentComponent;
  let fixture: ComponentFixture<InboxStudentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InboxStudentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InboxStudentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
