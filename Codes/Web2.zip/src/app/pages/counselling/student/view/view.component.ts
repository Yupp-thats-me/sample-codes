import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { LangChangeEvent } from '@ngx-translate/core';
import { ActivatedRoute, Router } from "@angular/router";
import { rating } from '@app/services/enumfiles';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { environment } from "../../../../../environments/environment";
import { Status } from '@app/models/status';
import { TreeviewItem } from 'ngx-treeview';

export interface NgbPanelChangeEvent {
  nextState: boolean;
  panelId: string;
  preventDefault: () => void;
}
@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss']
})
export class ViewComponent extends BaseComponent implements OnInit {
  public enumrating = rating
  treeViewItems: TreeviewItem[];
  imagepath: string = 'http://localhost:4200/assets/images/counselling/';
  slang: string = 'en';
  Counsellor: Counsellor
  show: boolean = false;
  reviews: any = [];
  experiencelist = [];
  educationlist = [];
  certificationlist = [];
  allreviews: any;
  achievementslist = [];
  counsellorid: any;
  categories: any;
  category = 1;
  questions = [];
  rawtreeview = [];
  page = 1;
  pageSize = 3;
  unfilteredquestions: any;
  categoryItems: any = [{ id: '1', name: 'Academic UAE/Overseas' },
  { id: '2', name: 'Wellbeing' },
  { id: '3', name: 'Career' }]
  sortby = null;
  averageRating: number;
  totalRating: any;
  constructor(context: ContextContainer,
    private route: ActivatedRoute,
    private modalService: NgbModal, private router: Router
  ) {
    super(context)
  }

  ngOnInit(): void {
    this.getThemeTree();
    this.getcounsellordata();
    this.getdropdown();
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang
    });
  }

  getThemeTree() {
    this.context.httpService.get(environment.counsellingUrl + "/Dropdown/theme-tree")
      .subscribe(
        (response) => {
          this.rawtreeview = response;
          this.treeViewItems = response.map(value => {
            return new TreeviewItem({
              text: value.text, value: value.id, collapsed: true,
              checked: true, children: value.children
            });
          })
        });
  }
  getcounsellordata() {
    this.counsellorid = this.route.snapshot.paramMap.get('id');
    this.context.httpService.get(environment.counsellingUrl + '/Counselling/' + this.counsellorid).subscribe(
      (results: any) => {
        if (results.success = true) {
          if (results.data) {
            this.Counsellor = results.data;
            this.reviews = this.Counsellor[0].reviewDetails;
            this.experiencelist = this.Counsellor[0].experienceDetail;
            this.educationlist = this.Counsellor[0].educationDetail;
            this.certificationlist = this.Counsellor[0].certificationDetail;
            this.achievementslist = this.Counsellor[0].achievementDetail;
            if (this.Counsellor[0].faqDetails.length != 0) {
              this.questions = this.Counsellor[0].faqDetails.filter(x => x.statusId == Status.Approved);
              this.unfilteredquestions = this.Counsellor[0].faqDetails.filter(x => x.statusId == Status.Approved);
              let y = 1
              this.questions = this.unfilteredquestions.filter(x => x.categoryId == y);
            }
            localStorage.setItem('name', this.Counsellor[0].name);
            // var array = this.Counsellor[0].categoryId.split(',');
            // var arrayCategory = []
            // // array.forEach(element => {
            //   console.log(this.treeViewItems)
            //   let obj = {}
            //   this.treeViewItems.forEach(item=>{
            //     let list = []
            //     list.push(item.value);
            //     if (item.children)
            //     list = this.getParentTree(item.children, list);
            //     obj[item.text] = list
            //   })
            //   for (let key in obj){
            //     const filteredArray = array.filter(value => obj[key].includes(parseInt(value)));
            //     if(filteredArray.length > 0){
            //       arrayCategory.push(key)
            //     }
            //   }
            //   this.Counsellor.servicesId = arrayCategory.toString();
            if (this.reviews.length > 0) {
              let averagerate = 0;
              this.averageRating = 0;
              this.totalRating = 0;
              for (let index = 0; index < this.reviews.length; index++) {
                const element = this.reviews[index];
                averagerate = averagerate + element.rateGiven;
              }
              this.averageRating = averagerate / this.reviews.length;
              this.totalRating = this.reviews.length;
            }else{
  
            }
            // results.data.forEach(element => {
            //   this.categoryItems.map(x => {
            //     if (element.categoryId != null) {
            //       var array = element.categoryId.split(',');
            //       let list = []
            //       array.forEach(item => {
            //         if (x.id == item) {
            //           item = x.name
            //         }
            //         list.push(item);
            //       });
            //       this.Counsellor[0].categoryId = list.toString();
            //     }
            //   });
            // });
            let items = []
            for (let index = 0; index < this.rawtreeview.length; index++) {
              items.push(this.rawtreeview[index]);
              const mainelement = this.rawtreeview[index].children;
              for (let index = 0; index < mainelement.length; index++) {
                const element = mainelement[index];
                items.push(element)
              }
            }
            results.data.forEach(element => {
              items.map(x => {
                if (element.categoryId != null) {
                  var array = element.categoryId.split(',');
                  let list = []
                  array.forEach(item => {
                    if (x.id == item) {
                      item = x.text
                    }
                    list.push(item);
                  });
                  this.Counsellor[0].categoryId = list.toString();
                  
                }
              });
            });
            results.data.forEach(element => {
              items.map(x => {
                if (element.servicesId != null) {
                  var array = element.servicesId.split(',');
                  let list = []
                  array.forEach(item => {
                    if (x.id == item) {
                      item = x.text
                    }
                    list.push(item);
                  });
                  this.Counsellor[0].servicesId = list.toString();
                  
                }
              });
            });
          }
         
        } else {

        }
      })
  }
  getParentTree(treeViewItems, list) {
    treeViewItems.forEach(treeView => {
      if (treeView.children) {
        this.getParentTree(treeView, list);
      } else {
        list.push(treeView.value)
      }
    })
    return list;
  }
  getdropdown() {
    this.context.httpService.get(environment.counsellingUrl + '/Dropdown/dropdowns').subscribe(
      (results: any) => {
        if (results.success = true) {
          this.categories = results.data.categoryMaster;
        }
      })
  }
  textwrap(text: string, value: number) {
    if (text != null) {
        return text.length > value ? text.substring(0, value) + "..." : text;

    }
  }

  showModal(reviewmodal) {
    this.context.httpService.get(environment.counsellingUrl + '/Counselling/Review/' + this.counsellorid).subscribe(
      (results) => {
        if (results.success = true) {
          this.allreviews = results.data;
          this.modalService.open(reviewmodal, { ariaLabelledBy: 'modal-primary-title' });
        } else {

        }
      })
  }
  SortByRate(event) {
    if (event.target.value == 'ascending') {
      this.allreviews = this.allreviews.sort((a, b) => (a.name < b.name ? -1 : 1));
    }
    else if (event.target.value == 'descending') {
      this.allreviews = this.allreviews.sort((a, b) => (a.name > b.name ? -1 : 1));
    }
    else if (event.target.value == 'rating') {
      this.allreviews = this.allreviews.sort((a, b) => (a.rateGiven > b.rateGiven ? -1 : 1));
    }
    else if (event.target.value == 'lowest') {
      this.allreviews = this.allreviews.sort((a, b) => (a.rateGiven < b.rateGiven ? -1 : 1));
    }
  }
  back() {
    this.router.navigate(['/counselling/list']);
  }
  categoryfilter(event) {
    if (event.target.value != '') {
      let y = +event.target.value;
      this.questions = this.unfilteredquestions.filter(x => x.categoryId == y);
    } else {
      this.questions = this.unfilteredquestions;
    }
  }
  Category(id: string) {
    if (id != null) {
      if (this.categories) {
        var array = ''
        let category = id.split(',');
        var catarr = {}
        for (let item of category) {
          var cat = this.categories.filter(x => x.categoryId == item);
          catarr = this.slang == 'ar' ? cat[0].categoryAr : cat[0].categoryEn;
          array += catarr + ',' + ' ';
        }
        return array;
      }
    }
  }
  connect() {

    this.router.navigate(['/counselling/student/connect-counsellor/' + this.counsellorid]);
  }
}
export class Counsellor {
  id: number;
  profilePic: string;
  name: string;
  categoryId: string;
  servicesId: string;
  // categoryAr: string;
  averageRating: number;
  totalRating: number;
  bio: string;
  languageKnown: string;
  documentFiles: any
}
