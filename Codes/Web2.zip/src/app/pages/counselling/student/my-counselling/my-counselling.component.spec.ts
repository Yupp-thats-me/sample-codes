import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyCounsellingComponent } from './my-counselling.component';

describe('MyCounsellingComponent', () => {
  let component: MyCounsellingComponent;
  let fixture: ComponentFixture<MyCounsellingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyCounsellingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MyCounsellingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
