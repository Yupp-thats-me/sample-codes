import { HttpParams } from '@angular/common/http';
import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { DataTableDirective } from 'angular-datatables';
import { environment } from 'environments/environment';
import { ActivatedRoute, Route } from "@angular/router";
import { appointmentstatus } from '@app/models/status';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-my-counselling',
  templateUrl: './my-counselling.component.html',
  styleUrls: ['./my-counselling.component.scss']
})
export class MyCounsellingComponent extends BaseComponent implements OnInit {

  @ViewChild(DataTableDirective) dtElement: DataTableDirective;
  StudentId: string;
  appointments: any;
  badgeStyle: { [id: string]: string; } = {};
  readonly Status: typeof appointmentstatus = appointmentstatus;
  buttonDisabled: boolean = false;
  reviewmodal: any;
  userId: any;
  constructor(
    context: ContextContainer,
    private route: ActivatedRoute,
    private ChangeDetectorRef: ChangeDetectorRef,
    private modalService: NgbModal
  ) {
    super(context)
  }

  ngOnInit(): void {
    this.StudentId = this.route.snapshot.paramMap.get('id')
    this.getcounsellingdetails();
    this.initBadgeStyle();

  }

  getcounsellingdetails() {
    let params = new HttpParams().set("studentId", this.context.getUserId().toString())

    this.context.httpService.get(environment.counsellingUrl + '/Counselling/VirtualAppointment', { params: params }).subscribe
      ((results) => {
        this.appointments = results.data;
        this.context.datatableService.reRender('datatable');
      })
  }
  initBadgeStyle() {
    this.badgeStyle[appointmentstatus.Waiting] = 'badge badge-warning';
    this.badgeStyle[appointmentstatus.ScheduleConfirmed] = 'badge badge-success';
    this.badgeStyle[appointmentstatus.Declined] = 'badge badge-danger';
    this.badgeStyle[appointmentstatus.Completed] = 'badge badge-info';
  }
  ngAfterViewInit() {
    this.context.datatableService.init(this.dtElement);
  }
  markattendance(item: any) {
    // debugger
    if (item.id != ('' || null)) {
      this.context.notificationService.confirmAlert((confirm) => {
        if (!confirm.dismiss) {
          this.buttonDisabled = true;
          let appointment = [{
            id: item.id,
            councellorAttandance: true
          }];
          this.context.httpService.put(environment.counsellingUrl + '/Counselling/VirtualAttandance', appointment).subscribe
            ((results) => {
              if (results.success == true) {
                this.notifySuccess('Attendance marked Successfully');
                this.getcounsellingdetails();
              } else {
                this.notifyError('Failed to mark attendance');
              }
              this.buttonDisabled = false;
            })
        } else {
          return item.councellorAttandance = 0;
        }
      }, 'Sure to mark attendance ? This action cannot be revoked!')
    }
  }
  provideRate(item: any, reviewmodal) {
    if (item.statusId != 6) {
      return
    } else {
      this.modalService.open(reviewmodal, { centered: true });
      this.reviewmodal = item;
    }
  }
  SortByRate(event) {
  }
  SubmitReview(reviewform: NgForm) {
    if(!reviewform.valid){
      return
    }
    let data = {
      AppointmentId: '',
      ReviewedBy: '',
      ReviewedFor: '',
      RateGiven: 0,
      CounsellorAttendSession: false,
      Reviewcontent: ' ',
      CreatedBy: '',
      UpdatedBy: '',
      IsActive: false
    }
    if(this.reviewmodal){
      data.AppointmentId = this.reviewmodal.id;
      data.ReviewedBy = this.reviewmodal.studentId;
      data.ReviewedFor = this.reviewmodal.counsellorId;
      data.RateGiven = reviewform.form.value.RateGiven;
      if(reviewform && reviewform.form.value.Reviewcontent){
        data.Reviewcontent = reviewform.form.value.Reviewcontent;
      }
      data.CounsellorAttendSession = reviewform.form.value.CounsellorAttendSession = "true" ? true : false;
      data.CreatedBy = this.reviewmodal.studentId.toString();
      data.IsActive = true;
    }
    this.context.httpService.post(environment.counsellingUrl + '/Counselling/Review', data).subscribe
    ((results)=>{
      if(results.success == true){
        this.notifySuccess('Thank you for your review');
        this.modalService.dismissAll();
      }else{
        this.notifyError('Failed to give review');
      }
    })
  }

}

export class BadgeStyle {
  Waiting:string;
  ScheduleConfirmed:string;
  Declined:string;
  Completed: string;
}
