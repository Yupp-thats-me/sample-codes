import { HttpClient, HttpParams } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { LangChangeEvent, TranslateService } from '@ngx-translate/core';
import { environment } from 'environments/environment';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { Status } from '@app/models/status';
export interface NgbPanelChangeEvent {
  nextState: boolean;
  panelId: string;
  preventDefault: () => void;
}
@Component({
  selector: 'app-faq-list',
  templateUrl: './faq-list.component.html',
  styleUrls: ['./faq-list.component.scss']
})

export class FaqListComponent extends BaseComponent implements OnInit {
  slang: string;
  questionApi: Questions[];
  questions: any;
  questionfilter = [];
  searchText: string;
  pagination: Pagination = new Pagination(1, 0, 10, [10, 20, 30, 40]);
  counsellingURL: string = '/Counselling/FilterFaq';
  dropdownURL: string = '/Dropdown/dropdowns';
  visible: boolean = false;
  active: any;
  lastPanelId: string = null;
  defaultPanelId: string = "1";
  quesFilter = [];
  i: number = 0;
  config: any;
  test: any;
  serverPage: number = 1;
  clickCount: number = 5;
  categoryList: any;
  constructor(private translateService: TranslateService, context: ContextContainer, private http: HttpClient,
    private router: Router) {
    super(context);
    this.config = {
      itemsPerPage: 10,
      currentPage: this.pagination.page,
      totalItems: 0
    };
  }

  ngOnInit(): void {
    var lang = this.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang;
    });
    this.getdropdown();


  }
  getdropdown() {
    this.context.httpService.get(environment.counsellingUrl + this.dropdownURL).
      subscribe(
        (response) => {
          this.categoryList = response.data.categoryMaster;
          this.categoryList.forEach(element => {
            element.active = true;
          });
          this.getQuestionList(1);
        });
  }
  getQuestionList(active) {
    

    this.onSelect(active);
    if (this.active != active) {
      this.serverPage = 1;
      this.pagination.page = 1;
      this.config.currentPage = 1;
      this.questionfilter = [];
    }
    this.active = active;
    let params = new HttpParams();
    params = params.append('searchText', this.searchText);
    params = params.append('category', this.active.toString());
    params = params.append('StatusId', Status.Approved.toString());
    params = params.append('page', this.serverPage.toString());
    params = params.append('pagesize', this.pagination.pageSize.toString());
    this.showCardProgress('form-card')
    this.context.httpService.get(environment.counsellingUrl + this.counsellingURL, { params: params }).
      subscribe(
        (response) => {
          this.hideCardProgress('form-card')
          if (response.data.items) {
            if (this.config.currentPage == 1) {
              this.questionfilter = response.data.items;
              //this.config.totalItems = response.count;
            }
            else {
              var items = [];
              items = response.data.items;
              items.forEach((ele) => {
                this.questionfilter.push(ele);
              })
            }
            this.visible = true;
          }
        },(error)=>{
          this.hideCardProgress('form-card')
        });


  }
  onPageChange(e) {
    
    this.config.currentPage = e;
    this.pagination.page = e;
    //this.getQuestionList(this.active);
    if (this.pagination.page == this.clickCount) {
      this.serverPage = this.pagination.page + 1;
      this.getQuestionList(this.active);
      this.clickCount = this.clickCount + 5;
    }
  }

  panelShadow($event: NgbPanelChangeEvent, shadow) {


    const { nextState } = $event;

    const activePanelId = $event.panelId;
    const activePanelElem = document.getElementById(activePanelId);

    if (!shadow.isExpanded(activePanelId)) {
      activePanelElem.parentElement.classList.add("open");
    }

    if (!this.lastPanelId) this.lastPanelId = this.defaultPanelId;

    if (this.lastPanelId) {
      const lastPanelElem = document.getElementById(this.lastPanelId);

      if (this.lastPanelId === activePanelId && nextState === false)
        activePanelElem.parentElement.classList.remove("open");
      else if (this.lastPanelId !== activePanelId && nextState === true) {
        lastPanelElem.parentElement.classList.remove("open");
      }

    }

    this.lastPanelId = $event.panelId;
  }
  onSelect(e) {

    this.categoryList.forEach(element => {
      if (e == element.categoryId) {
        if (element.active == true) {
          element.active = false;
        }
        else {
          element.active = true;
        }
      }
      else {
        element.active = true;
      }
    });
  }

  back() {
    this.router.navigate(['/counselling/home']);
  }
}

export class PageResult<T>{
  Count: number;
  PageIndex: number;
  PageSize: number;
  Items: T[];
}
export class Questions {
  Id: number;
  CategoryId: number;
  Question: string;
  Answer: string;
}
export class Pagination {
  page: number;
  count: number;
  pageSize: number;
  pageSizes: number[];
  constructor(page?: number, count?: number, pageSize?: number, pageSizes?: number[]) {
    this.page = page;
    this.count = count;
    this.pageSize = pageSize;
    this.pageSizes = pageSizes;
  }
}
