import { formatDate } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { ConnectCounsellor } from '@app/models/connectcounsellor.model';
import { Virtual } from '@app/models/reportsession-model';
import { environment } from 'environments/environment';
import { CalendarOptions } from '@fullcalendar/core';
import { BsDatepickerConfig, BsDatepickerInlineConfig, DatepickerDateCustomClasses } from 'ngx-bootstrap/datepicker';
import * as moment from 'moment';
import { appointmentstatus } from '../../../../models/status';


@Component({
  selector: 'app-calender',
  templateUrl: './calender.component.html',
  styleUrls: ['./calender.component.scss']
})
export class CalenderComponent extends BaseComponent implements OnInit {


  calendarOptions: CalendarOptions = {}
  virtualDetails:any[];
  events: any[] = [];
  eventCalendar: boolean = false;
  datesDisabled: Date[];
  dateCustomClasses: DatepickerDateCustomClasses[];
  bsConfig: Partial<BsDatepickerConfig>;
  dataSet = [];

  userId: any;
  mindate: Date = new Date()


  constructor(contextContainer: ContextContainer) {
    super(contextContainer);
   }

  ngOnInit(): void {
    this.getvirtualappointment();


  }

  getvirtualappointment() {
    let queryParams = 'StudentId=' + this.context.getUserId().toString() +  '&StatusId=' + appointmentstatus.ScheduleConfirmed +'&CheckExpiry=' + true
    this.context.httpService.get(environment.counsellingUrl + '/Counselling/VirtualAppointment?' + queryParams).subscribe(
      (response) => {
        if (response.success == true) {
          this.virtualDetails= response.data
          this.virtualDetails.forEach(data => {
            var exdate = moment(data.selectedDate).format("MM/DD/YYYY").toString();
          data.startTime = moment(data.startTime, ["HH:mm"]).format("h:mm A");
            data.endTime = moment(data.endTime, ["HH:mm"]).format("h:mm A");
            this.dataSet.push({'date':exdate,'isAvailable':true});
          });
          let dateArray = [];
          this.dataSet.forEach((data) => {
            if (data.isAvailable == false) {
              dateArray.push(new Date(data.date))
            }
          });
          this.datesDisabled = dateArray;
          this.dateCustomClasses = this.dataSet.map((data) => {
            return { date: new Date(data.date), classes: [data.isAvailable ? 'bg-success text-white' : 'bg-danger text-white'] }
          });
        }
      })
  }

  updateMyDate(event) {
    //this.eventCalendar = true;
    let SelectedDate = moment(event).format("YYYY-MM-DD");
    let queryParams = 'StudentId=' + this.context.getUserId().toString() +  '&StatusId=' + 3+'&SelectedDate='+SelectedDate
    this.context.httpService.get(environment.counsellingUrl + '/Counselling/VirtualAppointment?'+queryParams).subscribe(
      (response) => {
        if (response) {
         this.virtualDetails = response.data;
         this.virtualDetails.forEach(data => {
          data.startTime = moment(data.startTime, ["HH:mm"]).format("h:mm A");
          data.endTime = moment(data.endTime, ["HH:mm"]).format("h:mm A");
        });

        }
      }
    );
  }


}
