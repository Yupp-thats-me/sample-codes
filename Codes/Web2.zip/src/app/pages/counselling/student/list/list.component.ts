import { Component, OnInit, ViewChild } from '@angular/core';
import { LangChangeEvent } from '@ngx-translate/core';
import { BaseComponent } from '@app-core/base.component';
import { ContextContainer } from '../../../../app-core/context-container';
import { rating } from '@services/enumfiles';
import { Router } from '@angular/router';
import { environment } from '../../../../../environments/environment';
import { NgForm } from '@angular/forms';
import { HttpParams } from '@angular/common/http';
import { DropdownTreeviewComponent, TreeviewConfig, TreeviewHelper, TreeviewI18n, TreeviewItem } from 'ngx-treeview';
import { DropdownTreeviewI18n } from '@app/app-core/i18/dropdown-treeview-i18';
import { element } from 'protractor';
@Component({
  selector: 'app-test',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss'],

  providers: [{ provide: TreeviewI18n, useClass: DropdownTreeviewI18n }]
})
export class ListComponent extends BaseComponent implements OnInit {
  @ViewChild(DropdownTreeviewComponent, { static: false }) dropdownTreeviewComponent: DropdownTreeviewComponent;

  treeviewConfig = TreeviewConfig.create({
    hasAllCheckBox: true,
    hasFilter: true,
    hasCollapseExpand: true,
    decoupleChildFromParent: false,
    maxHeight: 400
  });
  treeViewItems: TreeviewItem[];
  buttonClass = "btn-outline-primary";
  public enumrating = rating;
  pagination: Pagination = new Pagination(1, 0, 6, [6, 12, 18, 24]);
  categoryItems: any = [{ id: '1', name: 'Academic UAE/Overseas' },
  { id: '2', name: 'Wellbeing' },
  { id: '3', name: 'Career' }]
  filteredData: any;
  data: any;
  searchText = '';
  customSearch;
  category = '';
  service = '';
  sortby = '';
  slang: string = 'en';
  counsellorslist: any = [];
  categories: TreeviewItem[];
  services: TreeviewItem[] = [];
  unfiltercounsellorslist: any = [];
  page: number = 1;
  serverPage: number = 1;
  clickCount: number = 8;
  active: any;
  config: any;
  selectedThemes: any = [];
  selectedcategory: string[];
  nonTreeViewservices: any;
  selectedservice: any[] = [];
  nonTreeViewcategory: any;
  serviceList: any;
  serveData: boolean;
  rawtreeview: any;
  sortEvent: any;
  constructor(
    context: ContextContainer,
    private router: Router
  ) {
    super(context);
    this.config = {
      itemsPerPage: 6,
      currentPage: this.pagination.page,
      totalItems: 0
    };
  }

  ngOnInit(): void {
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang
      this.getThemeTree();
    });
    this.getcategory();
    this.getThemeTree();
    this.getcounsellors();
  }
  getThemeTree() {
    this.context.httpService.get(environment.counsellingUrl + "/Dropdown/theme-tree")
      .subscribe(
        (response) => {
          this.rawtreeview = response;

          if (this.slang === 'ar') {
            let temp: any = [];
            this.treeviewPreparation(response, temp)
            this.treeViewItems = []
            this.treeViewItems = temp.map(value => {
              return new TreeviewItem({
                text: value.text, value: value.value, collapsed: true,
                checked: true, children: value.children
              });
            });
          } else {
            this.treeViewItems = response.map(value => {
              return new TreeviewItem({
                text: value.text, value: value.id, collapsed: true,
                checked: true, children: value.children
              });
            });
          }
        });
  }
  getcategory() {
    this.context.httpService.get(environment.counsellingUrl + "/Dropdown/dropdowns")
      .subscribe((res) => {
        this.nonTreeViewcategory = res.data.categoryMaster
        this.categories = this.nonTreeViewcategory.map((value: any) => {
          return new TreeviewItem({
            text: this.slang == 'ar' ?
              value.categoryAr : value.categoryEn, value: value.categoryId, collapsed: true, checked: false
          });
        });
      })
  }

  treeviewPreparation(data, temp) {
    data.map((dt, i) => {
      let obj = {
        text: dt.textAr,
        value: dt.id,
        children: [],
        collapsed: true,
        checked: dt.checked,
      };
      temp.push(obj);
      if (dt.hasOwnProperty('children') && dt.children.length > 0) {
        this.treeviewPreparation(dt.children, temp[i].children);
      }
    });
  }

  onSelectserviceChange(values): void {
    this.treeViewItems.forEach(i => {
      values.forEach(v => {
        let item = TreeviewHelper.findItemInList(this.treeViewItems, parseInt(v));
        let parent = TreeviewHelper.findParent(i, item);
        if (parent)
          if (parent.checked) {
            values.push(parent.value);
          }
      });
    });
    // this.isThemeSelected = true;
    values = values.filter((x, i) => i === values.indexOf(x))
    this.selectedservice = values;

  }
  onSelectedChange(values): void {

    this.treeViewItems.forEach(i => {
      values.forEach(v => {
        let item = TreeviewHelper.findItemInList(this.treeViewItems, parseInt(v));
        let parent = TreeviewHelper.findParent(i, item);
        if (parent)
          if (parent.checked) {
            values.push(parent.value);
          }
      });
    });
    // this.isThemeSelected = true;
    values = values.filter((x, i) => i === values.indexOf(x))
    this.selectedThemes = values;
    this.pagination.page = 1
  }

  getcounsellors() {


    // let param = new HttpParams().set("page", this.serverPage.toString()).set("pagesize", this.pagination.pageSize.toString()).set('searchCategory', this.selectedThemes.toString()).set('searchService', this.selectedservice.toString()).set('searchText', this.searchText);

    // this.context.httpService.get(environment.counsellingUrl + '/Counselling/FilterCounsellorView', { params: param })

    let queryParams = 'roleId=' + 6 + '&searchService=' + (this.selectedservice || []).toString() +
      '&searchCategory=' + (this.selectedThemes || []).toString() + '&page=' + 1 + '&serversize=' + 48 + '&searchText=' + this.searchText;
    this.context.httpService.get(environment.counsellingUrl + '/Counselling/FilterCounsellorView?' + queryParams)


      .subscribe(


        (results) => {


          if (results.success = true) {
            // this.totalItems = results.da
            if (this.config.currentPage == 1) {
              this.counsellorslist = results.data.items;
              this.unfiltercounsellorslist = results.data.items;
            } else {
              var items = [];
              items = results.data.items;
              items.forEach((ele) => {
                this.counsellorslist.push(ele);
                this.unfiltercounsellorslist = this.counsellorslist
              });
              // console.log(this.counsellorslist);
            }
            // this.counsellorslist.servicesId = this.counsellorslist.categoryId
            // this.counsellorslist.forEach(element => {
            //   this.categoryItems.map(x => {
            //     if (element.categoryId != null) {
            //       var array = element.servicesId.split(',');
            //       let list = []
            //       array.forEach(item => {
            //         if (x.id == item) {
            //           item = x.name
            //         }
            //         list.push(item);
            //       });
            //       element.servicesId = list.toString();
            //     }
            //   });
            // });
            let treeitems = []

            for (let index = 0; index < this.rawtreeview.length; index++) {
              treeitems.push(this.rawtreeview[index]);
              const mainelement = this.rawtreeview[index].children;
              for (let index = 0; index < mainelement.length; index++) {
                const element = mainelement[index];
                treeitems.push(element)
              }
            }
            this.counsellorslist.forEach(element => {
              treeitems.map(x => {
                if (element.categoryId != null) {
                  var array = (element.categoryId).split(',');
                  let list = []
                  array.forEach(item => {
                    if (x.id == item) {
                      item = this.slang == 'ar' ? x.textAr : x.text;
                    }
                    list.push(item);
                  });
                  element.categoryId = list.toString();
                }
              });
            });
          }
          if (this.sortEvent) {
            this.sortbyfunc(this.sortEvent);
          }
        });


  }
  getservice(item: Array<any>) {
    let cate = item
    let selectCategory = this.nonTreeViewcategory.filter(cat => item.indexOf(cat.categoryId) > -1);
    this.services = []
    if (selectCategory.length > 0) {
      this.serveData = true;
      selectCategory.forEach((selectedItem) => {
        let service = selectedItem.servicesMaster.map((value: any) => {
          return new TreeviewItem({
            text: this.slang == 'ar' ?
              value.servicesAr : value.servicesEn, value: value.servicesId,
            collapsed: true, checked: false
          });
        });
        this.services = [...this.services, ...service]
      });
      this.onSelectedChange(item)
    } else {
      this.serveData = false;
      this.selectedThemes = [];
      this.selectedservice = [];
    }

  }
  back() {
    this.router.navigate(['/counselling/home']);
  }
  getParentTree(treeViewItems, list) {
    treeViewItems.forEach(treeView => {
      if (treeView.children) {
        this.getParentTree(treeView, list);
      } else {
        list.push(treeView.value)
      }
    })
    return list;
  }

  resetCollectionSize() {
    throw new Error('Method not implemented.');
  }
  textwrap(text: string, value: number) {
    if (text != null) {
      return text.length > value ? text.substring(0, value) + "..." : text;
    }
  }
  viewdetail(id: number) {
    this.router.navigate(['/counselling/view/' + id])
  }
  sortbyfunc(event) {

    this.sortEvent = event;
    if (event.target.value == 'ascending') {
      //  this.counsellorslist = this.counsellorslist.sort(compareAsc);
      // this.counsellorslist = this.counsellorslist.sort((a,b)=> a.name.charCodeAt(0) - b.name.charCodeAt(0));
      this.counsellorslist.sort((b, a) => a.displayName.toLowerCase().trimStart().trimEnd() > b.displayName.toLowerCase().trimStart().trimEnd() ? -1 : a.displayName.toLowerCase().trimStart().trimEnd() < b.displayName.toLowerCase().trimStart().trimEnd() ? 1 : 0)

    }
    else if (event.target.value == 'descending') {
      //  this.counsellorslist = this.counsellorslist.sort((a,b)=> b.name.charCodeAt(0) - a.name.charCodeAt(0));
      this.counsellorslist.sort((a, b) => a.displayName.toLowerCase().trimStart().trimEnd() > b.displayName.toLowerCase().trimStart().trimEnd() ? -1 : a.displayName.toLowerCase().trimStart().trimEnd() < b.displayName.toLowerCase().trimStart().trimEnd() ? 1 : 0)
    }
    else if (event.target.value == 'rating') {
      this.counsellorslist = this.counsellorslist.sort((a, b) => (a.averageRating > b.averageRating) ? -1 : 1);

    }
    else if (event.target.value == "") {
      this.counsellorslist = this.unfiltercounsellorslist || [];
    }

  }



  onPageChange(e) {
    this.config.currentPage = e;
    this.pagination.page = e;
    //this.getQuestionList(this.active);
    if (this.pagination.page == this.clickCount) {
      this.serverPage = this.pagination.page + 1;
      this.getcounsellors();
      this.clickCount = this.clickCount + 8;
    }
  }

  reset() {
    
  
    this.searchText = '';
    this.sortby = '';   
    this.selectedThemes=[];
    this.selectedservice=[]; 
    this.counsellorslist = this.unfiltercounsellorslist;
    this.treeViewReset();
    this.getcounsellors();
   
  }

  treeViewReset() {
    let allChecked = this.dropdownTreeviewComponent.treeviewComponent.allItem.checked;
    if (allChecked) {
      this.dropdownTreeviewComponent.treeviewComponent.allItem.checked = false;

    }
    if (this.slang == "ar") {
      this.dropdownTreeviewComponent.buttonLabel = 'اشر على الخيارات'
    } else {
      this.dropdownTreeviewComponent.buttonLabel = 'Select Options'
    }
    this.treeViewItems.forEach(element => {
      element.checked = false;
      element.children.forEach(elem => {
        elem.checked = false;
        if (elem.children != null && elem.children.length > 0)
          elem.children.forEach(elem => {
            elem.checked = false;
          });
      });
    });
  }
  onSearch() {
    this.getcounsellors();
  }

}


export class PageResult<T>{
  Count: number;
  PageIndex: number;
  PageSize: number;
  Items: T[];
}
export class Pagination {
  page: number;
  count: number;
  pageSize: number;
  pageSizes: number[];
  constructor(page?: number, count?: number, pageSize?: number, pageSizes?: number[]) {
    this.page = page;
    this.count = count;
    this.pageSize = pageSize;
    this.pageSizes = pageSizes;
  }
}

