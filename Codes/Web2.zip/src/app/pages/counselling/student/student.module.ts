import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StudentRoutingModule } from './student-routing.module';
import { FaqListComponent } from './faq-list/faq-list.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SnotifyModule } from 'ng-snotify';
import { AutocompleteLibModule } from 'angular-ng-autocomplete';
import { DataTablesModule } from 'angular-datatables';
import { InputTrimModule } from 'ng2-trim-directive';
import { SharedModule } from '@app/shared/shared.module';
import { NgbAccordionModule, NgbCollapseModule, NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { baseModule } from '@app/app-core/Common Modules/baseModule';
import { LandingPageComponent } from './landing-page/landing-page.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { CarouselModule } from 'ngx-bootstrap/carousel';
import { StudentComponent } from './student.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { ListComponent } from "./list/list.component";
import { ConnectCounsellorComponent } from './connect-counsellor/connect-counsellor.component';
import { NgxSummernoteModule } from 'ngx-summernote';
import { FileUploadModule } from '@iplab/ngx-file-upload';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { ViewComponent } from './view/view.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { InboxStudentComponent } from './inbox-student/inbox-student.component';
import { MyCounsellingComponent } from './my-counselling/my-counselling.component';
import { CalenderComponent } from './calender/calender.component';
import { FullCalendarModule } from '@fullcalendar/angular';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';
import { TreeviewModule } from 'ngx-treeview';

FullCalendarModule.registerPlugins([ // register FullCalendar plugins added by Karthik M.
  dayGridPlugin,
  interactionPlugin
]);

@NgModule({
    declarations: [StudentComponent, ConnectCounsellorComponent, InboxStudentComponent, MyCounsellingComponent, CalenderComponent],
  imports: [
    NgxPaginationModule,
    CommonModule,
    SharedModule,
    StudentRoutingModule,
    baseModule,
    NgbCollapseModule,
    NgbAccordionModule,
    ReactiveFormsModule,
    FormsModule,
    CarouselModule.forRoot(),
    DataTablesModule,
    SnotifyModule,
    AutocompleteLibModule,
    FileUploadModule,
    TreeviewModule,
    InputTrimModule,
    NgxSummernoteModule,
    NgbTooltipModule,
    FullCalendarModule,
    BsDatepickerModule.forRoot(),
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: httpTranslateLoader,
        deps: [HttpClient]
      }
    }),
    Ng2SearchPipeModule,
    NgbModule

  ],
})
export class StudentModule { }

export function httpTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http);
}
