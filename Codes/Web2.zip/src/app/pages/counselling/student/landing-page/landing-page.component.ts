import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ContextContainer } from '../../../../app-core/context-container';
import { BaseComponent } from '../../../../app-core/base.component';
import { LangChangeEvent } from '@ngx-translate/core';
import { environment } from '../../../../../environments/environment';
import { category, rating } from "@services/enumfiles";
import { TreeviewItem } from 'ngx-treeview';
import { HttpParams } from '@angular/common/http';
import { Role } from '@app/models/role.enum';
import { map } from 'rxjs/operators';


@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.scss']
})
export class LandingPageComponent extends BaseComponent implements OnInit {
  public enumrating = rating;
  counsellorslist: any = [];
  index = 0;

  imagepath: string = 'http://localhost:4200/assets/images/counselling/';
  slang: string = 'en';
  categories: any;
  topRecordUrl: string = '/Counselling/CounsellorTopRecords';
  categoryItems: any = [{ id: 1, name: 'Academic UAE/Overseas' },
  { id: 2, name: 'Wellbeing' },
  { id: 3, name: 'Career' }];
  rawtreeview: any;
  constructor(
    context: ContextContainer,
    private router: Router
  ) {
    super(context);

  }

  ngOnInit(): void {
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang
    });
    this.getThemeTree();
    this.getcounsellors();
  }



  getcounsellors() {
    this.context.httpService.get(environment.counsellingUrl + this.topRecordUrl).subscribe(
      (results) => {
        if (results.success) {
          //this.counsellorslist = results.data
          this.counsellorslist = results.data;
          // this.counsellorslist.forEach(element => {
          //   this.categoryItems.map(x => {
          //     if(element.categoryId != null){
          //       var array = element.categoryId.split(',');
          //       let list = []
          //     array.forEach(item => {
          //       if (x.id == item) {
          //         item = x.name
          //       }
          //       list.push(item);
          //     });
          //     element.categoryId = list.toString();
          //     }
          //   });
          // });
          // this.counsellorslist.forEach(element => {

          //   this.categoryItems.map(x => {
          //     if (x.id == element.categoryId) {
          //       element.categoryId = x.name
          //     }
          //   });
          // });
          let treeitems = []
          for (let index = 0; index < this.rawtreeview.length; index++) {
            treeitems.push(this.rawtreeview[index]);
            const mainelement = this.rawtreeview[index].children;
            for (let index = 0; index < mainelement.length; index++) {
              const element = mainelement[index];
              treeitems.push(element)
            }
          }
          this.counsellorslist.forEach(element => {
            treeitems.map(x => {
              if (element.categoryId != null) {
                var array = element.categoryId.split(',');
                let list = []
                array.forEach(item => {
                  if (x.id == item) {
                    item = this.slang == 'ar' ? x.textAr : x.text;
                  }
                  list.push(item);
                });
                element.categoryId = list.toString();
              }
            });
          });
        }
      })

  }
  getThemeTree() {
    this.context.httpService.get(environment.counsellingUrl + "/Dropdown/theme-tree")
      .subscribe(
        (response) => {
          this.rawtreeview = response;
        })
  }
  textwrap(text: string, value: number) {
    if (text != null) {
      return text.length > value ? text.substring(0, value) + "..." : text;
    }
  }
  navigate() {
    this.router.navigateByUrl('/counselling/list')
  }
  navigateFaq() {
    this.router.navigateByUrl('/counselling/faq-list')
  }
  viewdetail(id) {
    this.router.navigate(['/counselling/view/' + id])
  }

}
