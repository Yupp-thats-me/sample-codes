import { HttpParams } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BaseComponent } from '@app/app-core/base.component';
import { ErrorCode } from '@app/app-core/constants/constants';
import { ContextContainer } from '@app/app-core/context-container';
import { ConnectCounsellor } from '@app/models/connectcounsellor.model';
import { appointmentstatus } from '@app/models/status';
import { AuthenticationService } from '@app/services/authentication.service';
import { FileUploadControl } from '@iplab/ngx-file-upload';
import { environment } from 'environments/environment';
import * as moment from 'moment';
import { BsDatepickerConfig, BsDatepickerInlineConfig, DatepickerDateCustomClasses } from 'ngx-bootstrap/datepicker';

@Component({
  selector: 'app-connect-counsellor',
  templateUrl: './connect-counsellor.component.html',
  styleUrls: ['./connect-counsellor.component.scss']
})
export class ConnectCounsellorComponent extends BaseComponent implements OnInit  {
  title = 'sampledatepicker';
  date: any;
  greenColor: boolean;
  bsValue: any;
  counsellingURL: string = '/Dropdown/dropdowns';
  timingUrl: string = '/Counselling/AvailableTiming';
  virtualUrl: string = '/Counselling/VirtualAppointment';
  askUrl: string = '/Counselling/QandA';
  datesDisabled: Date[];
  dateCustomClasses: DatepickerDateCustomClasses[];
  bsConfig: Partial<BsDatepickerConfig>;
  dataSet = [];
  counsellingTypes:boolean = true;
  UploadFile=[];
  selectedDate: any;
  public documentControl = new FileUploadControl(null);
  _bsDate: any;
  visible:boolean= false;
  connectCounsellor: ConnectCounsellor =
      {
        Id: 0,
        StudentId:0,
        CounsellorId: 0,
        Category: null,
        Service: null,
        Subject: '',
        AskQuestion:'',
        Purpose: '',
        Option: 0,
        PreferredLanguage: null,
        UploadFile: '',
        CreatedBy: '',
        UpdatedBy: '',
        Duration:null,
        SelectedDate: '',
        StartTime:'',
        EndTime:'',
        PostedDate: '',
  ReplayDate: '',
  Pinned: false,
  Answer: '',
  Status: false,
  IsActive:true
      }
      categoryList:any;
      serviceList:any;
      durationList:any;
      timeSlots: any;
      Language:any;
      //selectedStartDate:any;
  selectedval:any = 'Select';
  disable: boolean = true;
  availableList: any;
  uploadFile: Array<File> = [];
  file: any;
  userId: any;
  serviceFilter: any;
  datevalidate: boolean;
  availableid: any;
  mindate: Date = new Date();
  dates: any;
  active: boolean = false;
  approvedList: any;
  counsellorid: any;
  counsellorName: string;
  name: any;
  formdates: string;
  fileLimit: number;
  pdfSize: boolean;
  pdfSizezero: boolean;
  pdfUpload: boolean;
  languageList =[{id:"English",value:"English"},{id:"Arabic",value:"Arabic"}]
  constructor(context: ContextContainer,private route: ActivatedRoute, private router: Router,
  private authenticateService: AuthenticationService) {
      super(context);
   }
  ngOnInit(): void {
    this.counsellorid = this.route.snapshot.paramMap.get('id');
    this.getdropdown();
    //this.getdropdownlanguage();
    this.durationList=[{id:1,name:'30 mins'},{id:2,name:'60 mins'}];
    this.counsellorName = localStorage.getItem('name');
  }

  gettimeSlots(){
    
    this.dataSet =[];
    let params = new HttpParams();
    if(this.connectCounsellor.Duration){
    params = params.append('timeDuration', this.connectCounsellor.Duration.toString());
    params = params.append('counsellorId', this.counsellorid.toString());
    }
    this.context.httpService.get(environment.counsellingUrl + '/Counselling/Available-Date',{ params: params }).
    subscribe(
    (response) => {
      this.approvedList= response.data;
      this.approvedList.forEach(data => {
        var exdate = moment(data.selectedDate).format("MM/DD/YYYY").toString();
        if(data.approvedCount == data.dateCount){
          data.activeStatus = false;
        }
        else{
          data.activeStatus = true;
        }
        this.dataSet.push({'date':exdate,'isAvailable':data.activeStatus});
      });
      let dateArray = [];
      this.dataSet.forEach((data) => {
        if (data.isAvailable == false) {
          dateArray.push(new Date(data.date))
        }
      });
      this.datesDisabled = dateArray;
      this.dateCustomClasses = this.dataSet.map((data) => {
        return { date: new Date(data.date), classes: [data.isAvailable ? 'bg-success text-white' : 'bg-danger text-white'] }
      });
    });
  }
  onSelectDuration(){
    
    this.timeSlots = [];
    this.visible = false;
    this.active = true;
    let params = new HttpParams();
    if(this.connectCounsellor.Duration != null){
    params = params.append('timeDuration', this.connectCounsellor.Duration.toString());
    params = params.append('counsellorId', this.counsellorid.toString());
      this.context.httpService.get(environment.counsellingUrl + this.timingUrl,{ params: params }).
      subscribe(
      (response) => {
        this.availableList = response.data;
        this.gettimeSlots();
      });
    }
    else{
      this.dataSet =[];
    this.dateCustomClasses = [];
    this.datesDisabled =[];
    this.timeSlots=[];
    this.visible = false;

    }
  }
  getdropdown(){
    this.context.httpService.get(environment.counsellingUrl + this.counsellingURL).
      subscribe(
      (response) => {
        this.serviceList=response.data.servicesMaster;
        this.categoryList = response.data.categoryMaster;
      });
  }
  // getdropdownlanguage(){
  //   
  //   this.context.httpService.get(environment.counsellingUrl + '/Dropdown/Language/'+ this.counsellorid).
  //   subscribe(
  //   (response) => {
  //     console.log(response);
  //   var items= response.data[0].languageKnown;
  //   this.languageList = items.split(',');
  //   this.name = response.data[0].name;
  //   });
  // }
  onChangeGet(e){ 
    var val = e.target.value.split(':');
    this.categoryList.forEach(element => {
      if(val[1] != " null"){
      if(element.categoryId == val[1]){
        this.serviceFilter=element.servicesMaster;
      }
    }
    else{
      this.serviceFilter = [];
    }
    });
  }
  updateMyDate(event) {

this.datevalidate = false;
this.timeSlots =[];
this.dates = event;
this.connectCounsellor.SelectedDate = moment(this.dates).format();
this.formdates=moment(this.dates).format("YYYY/MM/DD");
this.visible = false;
    this.availableList.forEach(data => {
     var dtannounced = moment(event).format("YYYY/MM/DD").toString()
      var exdate = moment(data.selectedDate).format("YYYY/MM/DD").toString();
      if (moment(exdate).isSame(dtannounced)) {
        if (data.status) {
         this.timeSlots.push({'slot':data.startTime+'-'+data.endTime,'active':true,'Id':data.id,'status':data.status});
         this.visible = true;
        }
        else {
        }
      }
    });
  }
  onOptionsSelected(){
    this.disable =true;
    var val = this.connectCounsellor.Service;
    this.serviceList.forEach(element => {
    if(element.servicesId == val){
      this.selectedval = element.servicesEn;
      this.disable= false;
    }
  });
  }
  checkLang(event){
    var charCode;
    charCode = event.charCode;
    return ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123));
  }
  slots(){
    this.notifyError("This slot already booked by someone");
  }
  onSelect(e,id){
    
    var slot = e.split('-');
    this.connectCounsellor.StartTime = slot[0];
    this.connectCounsellor.EndTime = slot[1];
    this.availableid = id;
    this.timeSlots.forEach(element => {
      if(e == element.slot ){
        if(element.active ==  true){
        element.active = false;
        }
        else{
          element.active = true;
        }
      }
      else{
        element.active =  true;
      }
    });
  }
  // get getCounsellorId(): string {
  //   this.userId = this.context.authenticationService.getCounsellorId();
  //   var access_token = this.userId.source.value;
  //   return access_token;
  // }
  // get getStudentId(): string {
  //   this.userId = this.context.authenticationService.getStudentId();
  //   var access_token = this.userId.source.value;
  //   return access_token;
  // }

  schedule(f:NgForm){
    
    var file = this.context.appSettings;
    if(this.uploadFile.length > 0){
      this.fileLimit= file.fileLimit.thumbnail/1000000;
      if(this.uploadFile[0].size > file.fileLimit.pdf){
        this.pdfSize  =  true;
        return;
      }
      if(this.uploadFile[0].size == 0){
        this.pdfSizezero  =  true;
        return;
      }
    //   // if(this.uploadFile.length != 0){
    //   // if(this.uploadFile[0].type != 'application/pdf'){
    //   //   this.pdfUpload  =  true;
    //   //   return;
    //    }
    // }
  }
    if (f.invalid){
     return;
    }

    // this.checkdates();
    // if(this.datevalidate == true){
    //   return;
    // }
    var data = this.uploadFile;
    var id  =this.counsellorid;
   this.connectCounsellor.IsActive =  true;
    var date = new Date(this.connectCounsellor.SelectedDate);

    const formData = new FormData();
    var i = 0;
    data.forEach(file => {
      formData.append('files[' + i + ']', data[i]);
      i++;
    });
    if(this.counsellingTypes == false){
      formData.append('virtualappt.question', this.connectCounsellor.AskQuestion);
    }
    this.transformFiles(data);
    formData.append('virtualappt.id', this.connectCounsellor.Id.toString());
    formData.append('virtualappt.studentId', this.context.getUserId().toString());
    formData.append('virtualappt.counsellorId', id.toString());
    formData.append('virtualappt.category', this.connectCounsellor.Category.toString());
    formData.append('virtualappt.service', this.connectCounsellor.Service.toString());
    formData.append('virtualappt.subject', this.connectCounsellor.Subject.toString());
    formData.append('virtualappt.languages', this.connectCounsellor.PreferredLanguage.toString());
    formData.append('virtualappt.createdBy', this.context.getUserId().toString());
    formData.append('virtualappt.createdDate', moment(date).format());
    formData.append('virtualappt.updatedDate', moment(date).format());
    formData.append('virtualappt.updatedBy', this.context.getUserId().toString());
    formData.append('virtualappt.purpose', this.connectCounsellor.Purpose.toString());
    formData.append('virtualappt.duration', this.connectCounsellor.Duration.toString());
    formData.append('virtualappt.selectedDate', moment(date).format());
    formData.append('virtualappt.endTime', this.connectCounsellor.EndTime);
    formData.append('virtualappt.startTime', this.connectCounsellor.StartTime);
    formData.append('virtualappt.isActive', this.connectCounsellor.IsActive.toString());
    formData.append('virtualappt.AvailableTimeId', this.availableid.toString());
    formData.append('virtualappt.statusId', appointmentstatus.Waiting.toString() );
    this.context.httpService.post(environment.counsellingUrl + this.virtualUrl, formData).subscribe(
      (response) => {
    var successmsg = "A Confimation Email or Notification will be sent from counsellor soon.";
        if (response.error != true) {
          this.notifySuccess(successmsg);
          this.resetForm(f);
          this.documentControl.clear();
        }
        else if (response.errorCode == ErrorCode.Duplicate) {
          this.notifyError("Data already exists with same category and service");
        }else if (response.errorCode == ErrorCode.DateValidate) {
          this.notifyError("Select 5 days prior the session")
        }
        else{
          this.notifyError("Failed to schedule");
        }
        });
  }
  // checkdates(){
  //   this.datevalidate = false;
  //   var date  = new Date();
  //   date.setDate(date.getDate() + 5);
  //   var sDate = this.connectCounsellor.SelectedDate;
  // if(date > this.dates){
  // this.datevalidate = true;
  // this.notifyError("Selected date should be 5 days prior to current date")
  // return;
  //     }
  // }
  back(){
    this.router.navigate(['/counselling/view/' +this.counsellorid]);
  }
  send(f:NgForm){
    
    var file = this.context.appSettings;
      this.fileLimit= file.fileLimit.thumbnail/1000000;
      if(this.uploadFile.length > 0){
      if(this.uploadFile[0].size > file.fileLimit.pdf){
        this.pdfSize  =  true;
        return;
      }
      if(this.uploadFile[0].size == 0){
        this.pdfSizezero  =  true;
        return;
      }
    //   if(this.uploadFile.length != 0){
    //   if(this.uploadFile[0].type != 'application/pdf'){
    //     this.pdfUpload  =  true;
    //     return;
    //   }
    // }
  }
    if (f.invalid){
      return;
     }

    var data = this.uploadFile;
    var id  =this.counsellorid;
    this.connectCounsellor.IsActive = true;
    var date =new Date();
    const formData = new FormData();
    var i = 0;
    data.forEach(file => {
      formData.append('files[' + i + ']', data[i]);
      i++;
    });
      formData.append('qandAdetail.question', this.connectCounsellor.AskQuestion);
    this.transformFiles(data);
    formData.append('qandAdetail.id', this.connectCounsellor.Id.toString());
    formData.append('qandAdetail.studentId', this.context.getUserId().toString());
    formData.append('qandAdetail.counsellorId', id.toString());
    formData.append('qandAdetail.categoryId', this.connectCounsellor.Category.toString());
    formData.append('qandAdetail.serviceId', this.connectCounsellor.Service.toString());
    formData.append('qandAdetail.subject', this.connectCounsellor.Subject.toString());
    formData.append('qandAdetail.language', this.connectCounsellor.PreferredLanguage.toString());
    formData.append('qandAdetail.createdBy', this.context.getUserId().toString());
    formData.append('qandAdetail.createdDate', moment(date).format());
    formData.append('qandAdetail.postedDate', moment(date).format());
    formData.append('qandAdetail.updatedDate', moment(date).format());
    formData.append('qandAdetail.updatedBy', this.context.getUserId().toString());
    formData.append('qandAdetail.status', "false");
    formData.append('qandAdetail.isActive', this.connectCounsellor.IsActive.toString());

    this.context.httpService.post(environment.counsellingUrl + this.askUrl, formData).subscribe(
      (response) => {
    var successmsg = "Thank you. Your question have been sent to counsellor, you will get the answers soon.";
        if (response.error != true) {
          this.notifySuccess(successmsg);
          this.resetForm(f);
          this.documentControl.clear();
        }
        });

  }
  clrFile(){

    this.pdfUpload = false;
    this.pdfSize = false;
    this.pdfSizezero = false;
  }
  onChangeoption(e){
    this.connectCounsellor=
    {
      Id: 0,
      StudentId:0,
      CounsellorId: 0,
      Category: null,
      Service: null,
      Subject: '',
      AskQuestion:'',
      Purpose: '',
      Option: 0,
      PreferredLanguage: null,
      UploadFile: '',
      CreatedBy: '',
      UpdatedBy: '',
      Duration:null,
      SelectedDate: '',
      StartTime:'',
      EndTime:'',
      PostedDate: '',
      ReplayDate: '',
      Pinned: false,
      Answer: '',
      Status: false,
      IsActive:true
    }
  this.documentControl.clear();
  this.dataSet =[];
  this.visible = false;
  this.dateCustomClasses = [];
  this.datesDisabled = [];
  this.uploadFile=[];
  this.active = false;
  }
  transformFiles(files) {
    files.forEach(element => {
      element.FileName = element.name;
      element.ContentType = element.type;
      element.Length = element.size;
      this.file = element.name;
    });
  }
  resetForm(f:NgForm){
    this.connectCounsellor=
      {
        Id: 0,
        StudentId:0,
        CounsellorId: 0,
        Category: null,
        Service: null,
        Subject: '',
        AskQuestion:'',
        Purpose: '',
        Option: 0,
        PreferredLanguage: null,
        UploadFile: '',
        CreatedBy: '',
        UpdatedBy: '',
        Duration:null,
        SelectedDate: '',
        StartTime:'',
        EndTime:'',
        PostedDate: '',
        ReplayDate: '',
        Pinned: false,
        Answer: '',
        Status: false,
        IsActive:true
      }
    f.resetForm();
    this.documentControl.clear();
    this.dataSet =[];
    this.visible = false;
    this.dateCustomClasses = [];
    this.datesDisabled = [];
    this.uploadFile=[];
    this.active = false;
  }
}

export class DataSets{
  date: string;
  isAvailable: boolean;
  slots:any;
}
