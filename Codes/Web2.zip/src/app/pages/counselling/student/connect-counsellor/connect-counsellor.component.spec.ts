import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConnectCounsellorComponent } from './connect-counsellor.component';

describe('ConnectCounsellorComponent', () => {
  let component: ConnectCounsellorComponent;
  let fixture: ComponentFixture<ConnectCounsellorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConnectCounsellorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConnectCounsellorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
