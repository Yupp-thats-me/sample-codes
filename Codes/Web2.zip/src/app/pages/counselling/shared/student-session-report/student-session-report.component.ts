import { Component, ViewChild, AfterViewInit } from '@angular/core';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { CounsellingService } from '@app/services/counselling.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DataTableDirective } from 'angular-datatables';

@Component({
  selector: 'app-student-session-report',
  templateUrl: './student-session-report.component.html',
  styleUrls: ['./student-session-report.component.scss']
})
export class StudentSessionReportComponent extends BaseComponent  implements AfterViewInit {
  sessions: any;
  @ViewChild(DataTableDirective) dtElement: DataTableDirective;
  data: string;
  constructor(context:ContextContainer, private counselling: CounsellingService,private modalService:NgbModal) {
    super(context);
  }

  ngOnInit(): void {
  this.getData();
  }

  getData() {
      this.counselling.getHistory().subscribe((result: any)=>{
        this.sessions= result.data;
        this.context.datatableService.reRender('sessionhistory');
       });
  }

  closeModal() {
    this.modalService.dismissAll();
  }

  ngAfterViewInit() {
   //  this.context.datatableService.init(this.dtElement);
  }
}
