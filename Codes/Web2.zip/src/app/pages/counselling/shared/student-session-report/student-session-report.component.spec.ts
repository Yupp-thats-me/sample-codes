import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentSessionReportComponent } from './student-session-report.component';

describe('StudentSessionReportComponent', () => {
  let component: StudentSessionReportComponent;
  let fixture: ComponentFixture<StudentSessionReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StudentSessionReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentSessionReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
