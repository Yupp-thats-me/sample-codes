import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CounsellorRoutingModule } from './counsellor-routing.module';
import { InboxComponent } from './inbox/inbox.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SnotifyModule } from 'ng-snotify';
import { AutocompleteLibModule } from 'angular-ng-autocomplete';
import { DataTablesModule } from 'angular-datatables';
import { InputTrimModule } from 'ng2-trim-directive';
import { SharedModule } from '@app/shared/shared.module';
import { NgbAccordionModule, NgbCollapseModule, NgbDropdownModule, NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { baseModule } from '@app/app-core/Common Modules/baseModule';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { CarouselModule } from 'ngx-bootstrap/carousel';
import { NgxPaginationModule } from 'ngx-pagination';
import { NgxSummernoteModule } from 'ngx-summernote';
import { FileUploadModule } from '@iplab/ngx-file-upload';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TimeslotComponent } from './timeslot/timeslot.component';
import { AmazingTimePickerModule } from 'amazing-time-picker';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CalenderComponent } from './calender/calender.component';
import { FullCalendarModule } from '@fullcalendar/angular';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';
import { AppointmentsComponent } from "./appointments/appointments.component";
import { MyProfileComponent } from "./my-profile/my-profile.component";
import { ViewAppointmentsComponent } from "./view-appointments/view-appointments.component";
import { ReviewsComponent } from "./reviews/reviews.component";
import { TabsModule } from 'ngx-bootstrap/tabs';
import { TreeviewModule } from 'ngx-treeview';
import { StudentSessionReportComponent } from '../shared/student-session-report/student-session-report.component';
import { CounsellingModule } from '../counselling.module';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { HomePageModule } from '@app/pages/home-page/home-page.module';

FullCalendarModule.registerPlugins([ // register FullCalendar plugins added by Karthik M.
  dayGridPlugin,
  interactionPlugin
]);


@NgModule({
  declarations: [InboxComponent,DashboardComponent,TimeslotComponent, CalenderComponent, AppointmentsComponent,
     MyProfileComponent, ViewAppointmentsComponent, ReviewsComponent, StudentSessionReportComponent],
  imports: [
    NgxPaginationModule,
    CommonModule,
    SharedModule,
    CounsellorRoutingModule,
    baseModule,
    NgbCollapseModule,
    NgbAccordionModule,
    ReactiveFormsModule,
    FormsModule,
    CarouselModule.forRoot(),
    DataTablesModule,
    SnotifyModule,
    AutocompleteLibModule,
    FileUploadModule,
    InputTrimModule,
    HomePageModule,
    NgxSummernoteModule,
    NgbTooltipModule,
    NgbDropdownModule,
    NgMultiSelectDropDownModule,
    AmazingTimePickerModule,
    FullCalendarModule,
    BsDatepickerModule.forRoot(),
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: httpTranslateLoader,
        deps: [HttpClient]
      }
    }),
    Ng2SearchPipeModule,
    NgbModule,
    TabsModule.forRoot(),
    TreeviewModule.forRoot()
  ],

  entryComponents:[StudentSessionReportComponent],
  providers: [],

})
export class CounsellorModule { }
export function httpTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http);
}
