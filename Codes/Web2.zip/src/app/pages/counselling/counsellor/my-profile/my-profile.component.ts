import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { TabsetComponent, TabDirective } from 'ngx-bootstrap/tabs';
import { environment } from 'environments/environment';
import { ActivatedRoute, Router } from "@angular/router";
import * as moment from 'moment';
import { NgForm } from '@angular/forms';
import { TreeviewItem, TreeviewConfig, DropdownTreeviewComponent, TreeviewHelper, TreeviewI18n } from 'ngx-treeview';
import { LangChangeEvent } from '@ngx-translate/core';
import { DropdownTreeviewI18n } from '@app/app-core/i18/dropdown-treeview-i18';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.scss'],
  providers: [{ provide: TreeviewI18n, useClass: DropdownTreeviewI18n }]
})
export class MyProfileComponent extends BaseComponent implements OnInit {

  @ViewChild(DropdownTreeviewComponent, { static: false }) dropdownTreeviewComponent: DropdownTreeviewComponent;
  // @ViewChild('tabset') tabset: TabsetComponent;
  counsellorid: any;
  counsellor: any;
  genderMaster: any;
  emirateMaster: any;
  buttonClass = "btn-outline-secondary";
  imagepath: string = 'http://localhost:4200/assets/images/counselling/';
  experiencelist: any;
  educationlist: any;
  certificationlist: any;
  achievementslist: any;
  expform: boolean = false;
  eduform: boolean = false;
  certifiform: boolean = false;
  achievefrm: boolean = false;
  public maskEmirate = [/\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, '-', /\d/];
  today = new Date(); 1
  isFormVisible: boolean = false;
  @ViewChild('fileInput') fileInput;
  // counsellor = {
  //   id: 0,
  //   firstName: '',
  //   middleName: '',
  //   lastName: '',
  //   dob: '',
  //   gender: '',
  //   mobileNo: '',
  //   mobileCode: '',
  //   emirateId: '',
  //   addressLine1: '',
  //   addressLine2: '',
  //   zipCode: '',
  //   emiratesCityId: '',
  //   bio: '',
  //   categoryId: '',
  //   servicesId: '',
  //   languageKnown: '',
  //   documentFiles:'',
  //   UpdatedBy: '',
  //   IsActive: true
  // }
  personalform = {
    id: 0,
    firstName: '',
    middleName: '',
    lastName: '',
    dob: '',
    gender: '',
    mobileNo: '',
    mobileCode: '',
    emirateId: '',
    addressLine1: '',
    addressLine2: '',
    zipCode: '',
    emiratesCityId: '',
    bio: '',
    categoryId: '',
    servicesId: '',
    languageKnown: '',
    UpdatedBy: '',
    IsActive: true,
    cityId: 0
  }
  experience = {
    id: 0,
    counsellorId: 0,
    title: '',
    organizationName: '',
    descriptions: '',
    emirateId:'' as any,
    startDate: null as any,
    endDate: null as any,
    pursuing: false,   
    createdBy: '',
    updatedBy: '',
    isActive: true
  };
  education = {
    id: 0,
    counsellorId: 0,
    higherEducationId: null,
    majorId: null,
    instituteName: '' as any,
    startDate: null as any,
    endDate: null as any,
    pursuing: false,
    createdBy: '',
    updatedBy: '',
    isActive: true,
    instituteId: 0,
    institute: ''
  };
  certificate = {
    id: 0,
    counsellorId: 0,
    title: '',
    issuingAuthority: '',
    startDate: null as any,
    endDate: null as any,
    pursuing: false,    
    createdBy: '',
    updatedBy: '',
    isActive: true
  }
  achievement = {
    id: 0,
    counsellorId: 0,
    title: '',
    issuingAuthority: '',
    createdBy: '',
    updatedBy: '',
    isActive: true
  }
  activeTab = 'PersonalDetails';
  UploadImage: '';
  higherEducationmaster: any;
  majorMaster: any;
  treeviewI18n: TreeviewI18n;
  treeviewConfig = TreeviewConfig.create({
    hasAllCheckBox: true,
    hasFilter: true,
    hasCollapseExpand: true,
    decoupleChildFromParent: false,
    maxHeight: 400
  });

  slang: String = 'en';
  InstituteMaster: any = [];
  keyword: string = 'institute';
  selectedinstitute: any = [];
  userId: any;
  urlLink: any;
  //profilePic: any;
  // keyword = 'name';
  profilePic: Array<File> = [];
  emirateValidate: boolean = false;
  fileValidate: boolean;
  iseduFormVisible: boolean = false;
  isCertificateFormVisible: boolean;
  isAchiveFormVisible: boolean;
  treeViewItems: TreeviewItem[];
  themeArray: any = [];
  isThemeSelected: boolean;
  selectedThemes: any;
  languageRequired: boolean;
  constructor(
    context: ContextContainer,
    private route: ActivatedRoute,
    private Router: Router

  ) {
    super(context);
  }
  setTab(activeTab: string) {
    this.activeTab = activeTab
    if (this.activeTab === 'Experience') {
      this.hideForm()
    } else if (this.activeTab === 'education') {
      this.hideEduForm()
    } else if (this.activeTab === 'certificates') {
      this.hidecertificateForm();
    } else if (this.activeTab === 'achive') {
      this.hideAchiveForm()
    }
  }
  ngOnInit(): void {
    this.counsellorid = this.route.snapshot.paramMap.get('id');
    this.getThemeTree();
    this.getdropdowns();
    this.getemiratemaster();
    this.getcounsellor();
    this.getcounsellorpersonals();
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      if (this.slang != event.lang) {
        this.slang = event.lang;
        this.getThemeTree();
      }
    });
  }

  ngAfterViewInit(): void {
    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    //Add 'implements AfterViewInit' to the class.

  }
  keyPressNumberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if ((charCode > 46 && charCode < 58) || charCode == 46) {
      return true;
    }
    return false;
  }
  getThemeTree() {
    this.context.httpService.get(environment.counsellingUrl + "/Dropdown/theme-tree")
      .subscribe(
        (response) => {
          if (this.slang === 'ar') {
            let temp: any = [];
            this.treeviewPreparation(response, temp)
            this.treeViewItems = []
            this.treeViewItems = temp.map(value => {
              return new TreeviewItem({
                text: value.text, value: value.value, collapsed: true,
                checked: true, children: value.children
              });
            });
          } else {
            this.treeViewItems = response.map(value => {
              return new TreeviewItem({
                text: value.text, value: value.id, collapsed: true,
                checked: true, children: value.children
              });
            });
          }
          if (this.themeArray.length > 0) {
            this.bindArray(this.themeArray);
          }
        });
  }

  getdropdowns() {
    this.context.httpService.get(environment.counsellingUrl + '/Dropdown/dropdowns').subscribe(
      (results: any) => {
        if (results.success = true) {
          this.genderMaster = results.data.genderMaster;
          this.higherEducationmaster = results.data.higherEducation;
          this.majorMaster = results.data.majorMaster;
          this.InstituteMaster = results.data.instituteNameMaster;
        }
      })
  }
  getemiratemaster() {
    this.context.httpService.get(environment.accounturl + '/Data/elements/2').subscribe(
      (results) => {
        if (results.success == true) {
          this.emirateMaster = results.data;
        }
      });
  }
  getcounsellorpersonals() {
    this.context.httpService.get(environment.accounturl + '/User/personal-details/').subscribe(
      (results) => {
        if (results && results.success) {
          this.counsellor = results.data;
          this.counsellor.dob = moment(this.counsellor.dob).format('MM/DD/yyyy');

        }
      });
  }
  getcounsellor() {
    // this.showCardProgress('form-card');

    this.context.httpService.get(environment.counsellingUrl + '/Counselling/' + this.context.getUserId()).subscribe(
      (results) => {
        if (results.success == true) {
          // this.counsellor = results.data[0];
          // this.hideCardProgress('form-card')
          // this.counsellor.dob = moment(this.counsellor.dob).format('MM/DD/yyyy');
          // if(this.counsellor.zipCode === "null"){
          //   this.counsellor.zipCode ='';
          // }
          // if(this.counsellor.addressLine1 === "null"){
          //   this.counsellor.addressLine1 ='';
          // }
          // if(this.counsellor.addressLine2 === "null"){
          //   this.counsellor.addressLine2 ='';
          // }
          this.urlLink = results.data[0].documentFiles
          this.experiencelist = results.data[0].experienceDetail;
          this.educationlist = results.data[0].educationDetail;
          this.certificationlist = results.data[0].certificationDetail;
          this.achievementslist = results.data[0].achievementDetail;
          // if ( results.data[0].languageKnown) {
          //   var array = this.counsellor.languageKnown.split(',');
          //   var arraylanguage = [];
          //   array.forEach(lang => {
          //     var data = {
          //       display: lang,
          //       value: lang
          //     }
          //     arraylanguage.push(data)
          //     this.counsellor.languageKnown = arraylanguage;
          //   });
          // }
          // if ( results.data[0].servicesId != null) {
          //   this.themeArray =  results.data[0].categoryId +  results.data[0].servicesId;
          // } else {
          //   this.themeArray =  results.data[0].categoryId;
          // }
          // if (this.themeArray.length > 0) {
          //   this.bindArray(this.themeArray)
          // }
        }
      });
  }

  treeviewPreparation(data, temp) {
    data.map((dt, i) => {
      let obj = {
        text: dt.textAr,
        value: dt.id,
        children: [],
        collapsed: true,
        checked: dt.checked,
      };
      temp.push(obj);
      if (dt.hasOwnProperty('children') && dt.children.length > 0) {
        this.treeviewPreparation(dt.children, temp[i].children);
      }
    });
  }

  hideForm() {
    this.isFormVisible = false;
    //form.resetForm();
    this.experience = {
      id: 0,
      counsellorId: 0,
      title: '',
      organizationName: '',
      descriptions: '',
      emirateId: null,
      startDate: '',
      pursuing: false,
      endDate: '',
      createdBy: '',
      updatedBy: '',
      isActive: true
    };
  }
  showForm(form: NgForm) {
    this.isFormVisible = true;
    form.resetForm();
    this.experience.id = 0;
  }
  hideEduForm() {
    this.iseduFormVisible = false;
    this.education = {
      id: 0,
      counsellorId: 0,
      higherEducationId: null,
      majorId: null,
      instituteName: '',
      startDate: null,
      endDate: null,
      pursuing: false,
      createdBy: '',
      updatedBy: '',
      isActive: true,
      instituteId: 0,
      institute: ''
    };
  }
  showEduForm(form: NgForm) {
    this.iseduFormVisible = true;
    form.resetForm();
    this.education.id = 0;
  }
  hidecertificateForm() {

    this.isCertificateFormVisible = false;
    this.certificate = {
      id: 0,
      counsellorId: 0,
      title: '',
      issuingAuthority: '',
      startDate: '',
      pursuing: false,
      endDate: '',
      createdBy: '',
      updatedBy: '',
      isActive: true
    }
  }
  showCertificateForm(form: NgForm) {
    this.isCertificateFormVisible = true;
    form.resetForm();
    this.certificate.id = 0;
  }
  hideAchiveForm() {
    this.isAchiveFormVisible = false;
    //form.resetForm();
    this.achievement = {
      id: 0,
      counsellorId: 0,
      title: '',
      issuingAuthority: '',
      createdBy: '',
      updatedBy: '',
      isActive: true
    }
  }
  showAchiveForm(form: NgForm) {
    this.isAchiveFormVisible = true;
    form.resetForm();
    this.achievement.id = 0;
  }

  selectFile(event) {
    if (event.target.files && event.target.files.length > 0) {
      var reader = new FileReader()
      var size = event.target.files[0].size
      if (size > 1048576) {
        this.context.notificationService.error('Upload the image less than 1 MB')
        return;
      }
      reader.readAsDataURL(event.target.files[0])
      reader.onload = (event: any) => {
        this.urlLink = event.target.result
      };
      // var size = event.target.files[0].size
      // if ( size > 1048576) {
      //   this.context.notificationService.error('Upload the image less than 1 MB')
      //   return;
      // }
      this.profilePic = event.target.files;
    }
  }
  fileSelect(event) {
    var src = this.urlLink;
    if (src) {
      window.open(src.changingThisBreaksApplicationSecurity, '_blank')
    }
  }
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }


  bindArray(arr) {
    var themeArray = arr.split(',');
    themeArray.forEach(i => {
      var item = TreeviewHelper.findItemInList(this.treeViewItems, parseInt(i));
      if (item) {
        item.checked = true;
        item.correctChecked();
        item.setCheckedRecursive(true);
      }
    });
    // this.dropdownTreeviewComponent.treeviewComponent.raiseSelectedChange();
  }
  onSelectedChange(values): void {
    if (values.length > 0) {
      this.treeViewItems.forEach(i => {
        values.forEach(v => {
          let item = TreeviewHelper.findItemInList(this.treeViewItems, parseInt(v));
          let parent = TreeviewHelper.findParent(i, item);
          if (parent)
            if (parent.checked) {
              values.push(parent.value);
            }
        });
      });
      this.isThemeSelected = true;
      values = values.filter((x, i) => i === values.indexOf(x))
      this.selectedThemes = values;
      this.themeArray = this.selectedThemes.toString()
    }
    else {
      this.isThemeSelected = false;
      this.selectedThemes = "";
    }
  }

  clremirate() {
    this.emirateValidate = false;
  }
  nexttab(id) {
    this.activeTab = id;
  }
  checkLang(event) {
    var charCode;
    charCode = event.charCode;
    return ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123));
  }
  // Perosnal Save
  savepersonaldetails(personalform: NgForm) {

    let personalDetail = new FormData;

    this.emirateValidate = this.counsellor.emirateId && this.counsellor.emirateId.indexOf('_') > -1;
    if (!personalform.valid || this.emirateValidate) {
      return
    }
    if (this.counsellor.languageKnown == 0) {
      this.languageRequired = true;
      return
    }
    this.languageRequired = false
    var data = this.profilePic;
    var date = new Date();
    //const personalDetail = new FormData();
    var i = 0;
    if (data) {
      personalDetail.append('files[' + i + ']', data[i]);
    }
    personalDetail.append('personal.id', this.context.getUserId().toString());
    personalDetail.append('personal.firstName', this.counsellor.firstName);
    personalDetail.append('personal.middleName', this.counsellor.middleName);
    personalDetail.append('personal.lastName', this.counsellor.lastName);
    personalDetail.append('personal.gender', this.counsellor.gender);
    personalDetail.append('personal.dob', moment(this.counsellor.dob).format("YYYY-MM-DD").toString());
    personalDetail.append('personal.mobileNo', this.counsellor.mobileNo);
    personalDetail.append('personal.mobileCode', this.counsellor.mobileCode);
    personalDetail.append('personal.emirateId', this.counsellor.emirateId);
    personalDetail.append('personal.addressLine1', this.counsellor.addressLine1);
    personalDetail.append('personal.addressLine2', this.counsellor.addressLine2);
    personalDetail.append('personal.email', this.counsellor.email);
    personalDetail.append('personal.emiratesCityId', this.counsellor.emiratesCityId);
    personalDetail.append('personal.zipCode', this.counsellor.zipCode);
    personalDetail.append('personal.bio', this.counsellor.bio);
    personalDetail.append('personal.categoryId', this.themeArray.toString());
    personalDetail.append('personal.isactive', 'true');
    let language = [];
    this.counsellor.languageKnown.forEach(lang => {
      language.push(lang.value)
    });
    personalDetail.append('personal.languageKnown', language.toLocaleString());
    personalDetail.append('UpdatedBy', this.context.getUserId().toString());
    this.showCardProgress('form-card')
    this.context.httpService.post(environment.counsellingUrl + '/Counselling/personalDetail', personalDetail).subscribe
      ((results) => {
        if (results.success == true) {
          this.context.httpService.get(environment.counsellingUrl + '/Counselling/personalDetails/' + this.context.getUserId().toString()).subscribe
            ((results) => {
              if (results.success == true) {
                this.counsellor = results.data;
                this.urlLink = this.counsellor.profilePic
                var array = this.counsellor.languageKnown.split(',');
                var arraylanguage = [];
                array.forEach(lang => {
                  var data = {
                    display: lang,
                    value: lang
                  }
                  arraylanguage.push(data)
                  this.counsellor.languageKnown = arraylanguage;
                });
                this.themeArray = this.counsellor.categoryId + this.counsellor.servicesId
                if (this.counsellor.categoryId && this.counsellor.servicesId) {
                  //this.bindArray(this.themeArray)
                }
                this.hideCardProgress('form-card')
                this.notifySuccess('Personal details Updated');

              }
            })
        } else {
          this.notifyError('Failed to Update');
          this.hideCardProgress('form-card')
        }
      })
  }

  // Experience Save
  SaveExp(expform: NgForm) {
    if (expform.invalid) {
      return this.notifyError('Please enter all the mandatory fields');
    }
    let data = JSON.parse(JSON.stringify(this.experience));

    data.counsellorId = +this.context.getUserId();

    if (this.experience.id != 0 || this.experience.id != null) {
      data.updatedBy = this.context.getUserId().toString();
    }
    if (this.experience.startDate) {
      data.startDate = new Date(this.experience.startDate);

    }
    
    data.counsellorId = +this.context.getUserId();
    data.emirateId = +expform.form.value.EmirateId;
    if (expform.form.value.Pursuing == null) {
      data.pursuing = false;
    }
 
    data.createdBy = this.context.getUserId().toString();
    data.isActive = true;

    data.startDate = moment(this.experience.startDate).format(("YYYY-MM-DD").toString());
    data.endDate =this.experience.endDate ?  moment(this.experience.endDate).format(("YYYY-MM-DD").toString()):'1900-01-01';

    data.pursuing = data.pursuing || false;

    let formdata = [
      data
    ]

    
    this.context.httpService.post(environment.counsellingUrl + '/Counselling/ExperienceDetail', formdata).subscribe(
      (results) => {
        if (results.success == true) {
          this.notifySuccess('Experience Saved Successfully');
          this.hideForm()
          expform.resetForm();
          this.context.httpService.get(environment.counsellingUrl + '/Counselling/ExperienceDetails/' + this.context.getUserId()).subscribe
            ((results) => {
              if (results.success == true) {
                this.experiencelist = results.data;
              }
            })
        } else {
          this.notifyError('Failed to save Experience');
        }
      })
  }
  editExperience(data) {
    this.experience = data;
    data.startDate = new Date(this.experience.startDate)
    data.endDate = moment(data.endDate).format("MM/DD/YYYY");
    if (data.pursuing) {
      this.experience.endDate = null;
    }
    this.isFormVisible = true;
  }
  DeleteExperience(id: any) {
    this.context.notificationService.confirmAlert((confirm) => {
      if (!confirm.dismiss) {
        this.context.httpService.put(environment.counsellingUrl + '/Counselling/inactive-Experience/' + id).subscribe(
          data => {
            if (data != undefined) {
              this.notifySuccess('Deleted Successfully');
              this.context.httpService.get(environment.counsellingUrl + '/Counselling/ExperienceDetails/' + this.context.getUserId()).subscribe
                ((results) => {
                  if (results.success == true) {
                    this.experiencelist = results.data;
                  }
                })
            } else {
              this.notifyError('Failed to delete');
            }

          }
        );
      }
    }, 'Delete?');
  }
  // Save Education
  Saveedu(eduform: NgForm) {

    if (eduform.invalid) {
      return
    }
    let data = JSON.parse(JSON.stringify(this.education));

    data.counsellorId = +this.context.getUserId();

    if (this.education.id != 0 || this.education.id != null) {
      data.updatedBy = this.context.getUserId().toString();
    }
    if (this.education.startDate) {
      data.startDate = new Date(this.education.startDate);

    }

    
    data.createdBy = this.context.getUserId().toString();

    data.isActive = true;

    if (this.education.instituteName.instituteId) {
      data.instituteName = this.education.instituteName.institute;

    }

    if (data.instituteName.instituteId) {
      data.instituteName = data.instituteName.institute;

    }
    data.startDate = moment(this.education.startDate).format(("YYYY-MM-DD").toString());
    data.endDate =this.education.endDate ?  moment(this.education.endDate).format(("YYYY-MM-DD").toString()):'1900-01-01';

    data.pursuing = data.pursuing || false;

    let formdata = [
      data
    ]
    this.context.httpService.post(environment.counsellingUrl + '/Counselling/Education', formdata).subscribe(
      (results) => {
        if (results.success == true) {
          this.notifySuccess('Education Saved Successfully');
          this.iseduFormVisible = false;
          eduform.resetForm();
          this.getdropdowns()
          this.context.httpService.get(environment.counsellingUrl + '/Counselling/EducationDetail/' + this.context.getUserId()).subscribe
            ((results) => {
              if (results.success == true) {
                this.educationlist = results.data;

                this.selectedinstitute = []
              }

            })
          this.hideEduForm()
        } else {
          this.notifyError('Failed to save Education');
        }
      })
  }

  editEducation(data) {

    this.education = data;
    this.education.instituteName = data.institute;
    // this.education.startDate = moment(data.startDate).format("MM/DD/YYYY")
    this.education.startDate = new Date(data.startDate);
    this.education.endDate = moment(data.endDate).format("MM/DD/YYYY");
    if (data.pursuing) {
      this.education.endDate = null;
    }
    this.iseduFormVisible = true;
  }
  deleteEducation(id) {
    this.context.notificationService.confirmAlert((confirm) => {
      if (!confirm.dismiss) {
        this.context.httpService.put(environment.counsellingUrl + '/Counselling/inactive-Education/' + id).subscribe(
          data => {
            if (data != undefined) {
              this.notifySuccess('Deleted Successfully');
              this.context.httpService.get(environment.counsellingUrl + '/Counselling/EducationDetail/' + this.context.getUserId()).subscribe
                ((results) => {
                  if (results.success == true) {
                    this.educationlist = results.data;
                    this.selectedinstitute = []
                  }
                })
            } else {
              this.notifyError('Failed to delete');
            }

          }
        );
      }
    }, 'Delete?');
  }
  // Save Certificate
  savecertificate(certificateform: NgForm) {

    if (!certificateform.valid) {
      return
    }

    let data = JSON.parse(JSON.stringify(this.certificate));

    data.counsellorId = +this.context.getUserId();
 
    if (this.certificate.id != 0 || this.certificate.id != null) {
      data.updatedBy = this.context.getUserId().toString();
    }
    if (this.certificate.startDate) {
      data.startDate = new Date(this.certificate.startDate);

    }
    data.createdBy = this.context.getUserId().toString();
    data.isActive = true;

    // if (certificateform.form.value.Pursuing == null) {
    //   data.pursuing = false;
    // }

    // data.startDate = moment(certificateform.form.value.startDate).format("YYYY-MM-DD").toString();
    // data.endDate = certificateform.form.value.endDate ? moment(certificateform.form.value.endDate).format("YYYY-MM-DD").toString() : '1900-01-01';

    data.startDate = moment(this.certificate.startDate).format(("YYYY-MM-DD").toString());
    data.endDate =this.certificate.endDate ?  moment(this.certificate.endDate).format(("YYYY-MM-DD").toString()):'1900-01-01';

    
    data.pursuing = data.pursuing || false;
    let formdata = [
      data
    ]
    this.context.httpService.post(environment.counsellingUrl + '/Counselling/Certification', formdata).subscribe
      ((results) => {
        if (results.success == true) {
          this.notifySuccess('Certification Saved Successfully');
          this.isCertificateFormVisible = false
          certificateform.resetForm();
          this.context.httpService.get(environment.counsellingUrl + '/Counselling/CertificationDetail/' + this.context.getUserId()).subscribe
            ((results) => {
              if (results.success == true) {
                this.certificationlist = results.data;
              }
            })
        } else {
          this.notifyError('Failed to save Certification');
        }
      })
  }

  editCertification(data) {
    this.certificate = data;
    data.startDate = new Date(data.startDate);
    data.endDate = moment(data.endDate).format("MM/DD/YYYY");
    if (data.pursuing) {
      this.certificate.endDate = null;
    }
    this.iseduFormVisible = true;
    this.isCertificateFormVisible = true;
  }
  deleteCertification(id) {

    this.context.notificationService.confirmAlert((confirm) => {
      if (!confirm.dismiss) {
        this.context.httpService.put(environment.counsellingUrl + '/Counselling/inactive-Certification/' + id).subscribe(
          results => {
            if (results.success == true) {
              this.notifySuccess('Deleted Successfully');
              this.context.httpService.get(environment.counsellingUrl + '/Counselling/CertificationDetail/' + this.context.getUserId()).subscribe
                ((results) => {
                  if (results.success == true) {
                    this.certificationlist = results.data;
                  }
                })
            } else {
              this.notifyError('Failed to delete');
            }

          }
        );
      }
    }, 'Delete?');
  }
  // Save Achievement
  saveachieve(achievementform: NgForm) {
    if (!achievementform.valid) {
      return
    }
    this.achievement.counsellorId = +this.context.getUserId();
    if (this.achievement.id != 0 || this.achievement.id != null) {
      this.achievement.updatedBy = this.context.getUserId().toString();
    }
    this.achievement.createdBy = this.context.getUserId().toString();
    this.achievement.isActive = true;

    let data = [
      this.achievement
    ]
    this.context.httpService.post(environment.counsellingUrl + '/Counselling/Achievement', data).subscribe
      ((results) => {
        if (results.success == true) {
          this.notifySuccess('Achievement Saved Successfully');
          this.hideAchiveForm();
          achievementform.resetForm();
          this.context.httpService.get(environment.counsellingUrl + '/Counselling/Achievement/' + this.context.getUserId()).subscribe
            ((results) => {
              if (results.success == true) {

                this.achievementslist = results.data;
              }
            })
        } else {
          this.notifyError('Failed to save Achievement');
        }
      })
  }
  editAchive(data) {
    this.achievement = data
    this.isAchiveFormVisible = true
  }
  deleteAchive(id) {
    this.context.notificationService.confirmAlert((confirm) => {
      if (!confirm.dismiss) {
        this.context.httpService.put(environment.counsellingUrl + '/Counselling/inactive-achievement/' + id).subscribe(
          data => {
            if (data != undefined) {
              this.notifySuccess('Deleted Successfully');
              this.context.httpService.get(environment.counsellingUrl + '/Counselling/Achievement/' + this.context.getUserId()).subscribe
                ((results) => {
                  if (results.success == true) {
                    this.achievementslist = results.data;
                  }
                })
            } else {
              this.notifyError('Failed to delete');
            }

          }
        );
      }
    }, 'Delete?');
  }
  closeform(form: NgForm) {
    form.resetForm();
    this.expform = false;
    this.eduform = false;
    this.certifiform = false;
    this.achievefrm = false;
  }
  // CategorySelect(item: any) {
  //   this.selectedcategory = item;
  //   if (item != null) {
  //     this.servicechange(item, 1);
  //   }
  // }
  // ServiceSelect(item: any) {
  //   this.selectedservice = item;
  // }
  selectInstitueEvent(event) {

    if (event) {
      this.selectedinstitute = event;
      this.education.instituteName = event.institute
      this.education.instituteId = event.instituteId

    }
  }


  onChangeSearch(search) {
  }
  onFocused(event) {
  }


  completedYear(expform: NgForm) {
    if (expform.form.controls.Pursuing.value) {
      expform.form.controls.EndDate.setValue('');
      this.experience.pursuing = expform.form.controls.Pursuing.value;
    }
  }
  eduCompletedYear(eduform: NgForm) {
    if (eduform.form.controls.Pursuing.value) {
      eduform.form.controls.endDate.setValue('');
      this.education.pursuing = eduform.form.controls.Pursuing.value;
    }
  }
  certificateCompletedYear(cerform: NgForm) {
    if (cerform.form.controls.Pursuing.value) {
      cerform.form.controls.endDate.setValue('');
      this.certificate.pursuing = cerform.form.controls.Pursuing.value;
    }
  }
  editprofile() {
    this.Router.navigate(['user/profile'], { queryParams: { returnUrl: '/counselling/counsellors/my-profile' } });
    // this.router.navigate([returnUrl], { queryParams: { id: paramId } });

  }
}

