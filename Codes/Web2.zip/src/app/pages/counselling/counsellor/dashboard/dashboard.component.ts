import { Component, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { Reportsession, Virtual } from '@app/models/reportsession-model';
import { DataTableDirective } from 'angular-datatables';
import { environment } from 'environments/environment';
import * as moment from 'moment';
import { NgForm } from '@angular/forms';
import { ErrorCode } from '@app/app-core/constants/constants';
import { HttpParams } from '@angular/common/http';
import { BsDatepickerConfig, DatepickerDateCustomClasses } from 'ngx-bootstrap/datepicker';
import { AuthService } from '@app/services/auth.service';
import { GraphService } from '@app/services/graph.service';
import { newappointment } from '@app/pages/counselling/counsellor/modals/appointment';
import { User } from '@app/pages/counselling/counsellor/modals/user';
import { CounsellingService } from '@app/services/counselling.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { StudentSessionReportComponent } from '../../shared/student-session-report/student-session-report.component';
import { appointmentstatus, Status } from '@app/models/status';

@Component({
  selector: 'app-Dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent extends BaseComponent implements OnInit {
  @ViewChildren(DataTableDirective) dtElements: QueryList<DataTableDirective>;
  @ViewChild("ngFrm")
  ngFrm: NgForm;
  virtualDetails = []
  virtualUpcomingDetails = []
  student: number = 0;
  sessions = [];
  openSession: boolean;
  openSessionReport: boolean;
  openStudentHistory: boolean;
  timingUrl: string = '/Counselling/AvailableTiming';
  saveReportsUrl: string = '/Counselling/SessionReport';
  virtualUrl: string = '/Counselling/VirtualAppointment';
  meeting = {
    link: ''
  };
  appointmentId: string;
  appointment: any;

  outLookLogin: boolean = false;
  buttondisabled: boolean = false;
  reasonrequired: boolean = false;
  VirtualDetailById = [];
  dates: any;
  uploadFile: Array<File> = [];
  file: any;
  userId: any;
  availableid: any;
  appointmentById: any = [];
  dialog: any;
  approvedList: any;
  appointmentFormVisible: boolean = false;
  closeResult: string;
  hideDiv: boolean;
  totalApproved: any;
  totalRejected: any;
  totalPending: any;
  totalRecords: any;
  virtualCount: any;
  inboxCount: any;
  active: boolean;
  //  authService: AuthService
  //  graphService: GraphService
  get authenticated(): boolean {
    return this.authService.authenticated;
  }
  // The user
  get user(): User | undefined {
    return this.authService.user;
  }

  model = new newappointment();

  connectCounsellor: Virtual =
    {
      Id: 0,
      StudentId: 0,
      CounsellorId: 0,
      Category: null,
      Service: null,
      Subject: '',
      Purpose: '',
      Languages: '',
      Documents: '',
      CreatedBy: '',
      UpdatedBy: '',
      Duration: null,
      SelectedDate: '',
      StartTime: '',
      EndTime: '',
      StatusId: 0,
      IsActive: true,
      StudentQualification: '',
      VirtualLink: ''
    }
  reportsession: Reportsession = {
    Id: 0,
    StudentId: 0,
    CounsellorId: 0,
    AppointmentId: 0,
    Title: '',
    SessionDate: '',
    StartTime: '',
    EndTime: '',
    Description: '',
    Remarks: '',
    StudentAttandance: false,
    CreatedBy: '',
    UpdatedBy: '',
    IsActive: true
  }
  formReadOnly: boolean = false;
  addAppointmentdiv: boolean = false;
  addAppointmentdetails = [];
  durationList: { id: number; name: string; }[];
  timeSlots: any[];
  visible: boolean;
  datesDisabled: Date[];
  dateCustomClasses: DatepickerDateCustomClasses[];
  bsConfig: Partial<BsDatepickerConfig>;
  dataSet = [];
  availableList: any;
  datevalidate: boolean;
  reports: any;
  isFormVisible: boolean = false;
  mindate: Date = new Date();
  constructor(contextContainer: ContextContainer,
    private authService: AuthService,
    private graphService: GraphService,
    private counsellingService: CounsellingService,
    private modalservice: NgbModal
  ) {
    super(contextContainer);
    this.setDTTriggers(['virtualTodayDetails', 'virtualApptUpcoming']);
    this.durationList = [{ id: 1, name: '30 mins' }, { id: 2, name: '60 mins' }];
  }

  activeTab = 'todayAppt';
  ngOnInit(): void {
    this.getvirtualappointment();
    this.virtualApptUpcoming();
  }
  getvirtualappointment() {
    let SelectedDate = moment().format("YYYY-MM-DD");
    let multipleStatus: boolean = true;
    let queryParams = 'SelectedDate=' + SelectedDate + '&CounsellorId=' + this.context.getUserId() + '&multipleStatus=' + multipleStatus;
    this.showCardProgress('grid-card')
    this.context.httpService.get(environment.counsellingUrl + '/Counselling/VirtualAppointment?' + queryParams).subscribe
      ((response) => {
        this.hideCardProgress('grid-card')
        if (response.success == true) {
          this.virtualDetails = response.data;
          this.context.datatableService.reRender('virtualTodayDetails');
          if(this.virtualDetails.length> 0){
            this.inboxCount = this.virtualDetails[0].inboxCount;
            this.virtualCount= this.virtualDetails[0].virtualCount;
          }
        }
      },(error) => {
        this.hideCardProgress('grid-card')
      });
  }

  virtualApptUpcoming() {
    this.showCardProgress('grid-card')
    let checkExpiry: boolean = true;
    let queryParams = 'CounsellorId=' + this.context.getUserId()+ '&CheckExpiry=' + checkExpiry + '&StatusId=' + 3
    this.context.httpService.get(environment.counsellingUrl + '/Counselling/VirtualAppointment?' + queryParams).subscribe
      ((response) => {
        this.hideCardProgress('grid-card')
        if (response.success == true) {
          this.virtualUpcomingDetails = response.data
          this.context.datatableService.reRender('virtualApptUpcoming');
          if(this.virtualUpcomingDetails.length> 0){
            this.inboxCount = this.virtualUpcomingDetails[0].inboxCount;
            this.virtualCount= this.virtualUpcomingDetails[0].virtualCount;
          }
        }
      },(error) => {
        this.hideCardProgress('grid-card')
      });
  }

  ngAfterViewInit() {
    this.context.datatableService.init(this.dtElements);
  }


  sessionReport(appointmentDetails) {
    this.showCardProgress('form-card')
    this.hideDiv = false
    this.formReadOnly = false;
    this.appointment = appointmentDetails.id
    this.getVirtualApptById(this.appointment)
    if (appointmentDetails.statusId == 6) {
      let queryParams = 'AppointmentId=' + appointmentDetails.id
      this.context.httpService.get(environment.counsellingUrl + '/Counselling/SessionReport?' + queryParams).subscribe
        ((res) => {
          this.hideCardProgress('form-card')
          if (res.success) {
            this.reports = res.data;
            this.reportsession.Title = this.reports[0].title;
            this.reportsession.Description = this.reports[0].description
            this.reportsession.Remarks = this.reports[0].remarks
            this.reportsession.StudentAttandance = this.reports[0].studentAttandance
            var myDOB = new Date(appointmentDetails.selectedDate);
            var dat = moment(myDOB).format('MM-DD-YYYY');
            this.reportsession.SessionDate = dat;
            this.reportsession.StartTime = appointmentDetails.startTime;
            this.reportsession.EndTime = appointmentDetails.endTime;
            this.isFormVisible = true
            this.formReadOnly = true;
          }
        },(error) =>{
          this.hideCardProgress('form-card')
        });
    } else {
      this.addAppointmentdetails = appointmentDetails;
      var myDOB = new Date(appointmentDetails.selectedDate);
      var dat = moment(myDOB).format('MM-DD-YYYY');
      this.reportsession.SessionDate = dat;
      this.reportsession.Title = appointmentDetails.subject
      this.reportsession.StudentId = appointmentDetails.studentId;
      this.reportsession.CounsellorId = appointmentDetails.counsellorId;
      this.reportsession.AppointmentId = appointmentDetails.id;
      this.reportsession.StartTime = appointmentDetails.startTime;
      this.reportsession.EndTime = appointmentDetails.endTime;
      // this.reportsession.Description ='';
      // this.reportsession.StudentAttandance = false;
      // this.reportsession.Remarks = '';
      this.isFormVisible = true;
      this.hideCardProgress('form-card')
    }
  }

  getVirtualApptById(id: any) {
    this.context.httpService.get(environment.counsellingUrl + '/Counselling/VirtualAppointment/' + id).subscribe
      ((res) => {
        if (res.success) {
          this.appointmentById = res.data
        }
      });
  }

  addAppointment() {
    this.isFormVisible = true;
    this.appointmentFormVisible = true;
    this.hideDiv = true;
  }

  onSubmitSessionReport(ngFrm: NgForm) {
    //console.log(appointment)
    if (ngFrm.invalid) {
      this.notifyError('Please enter all the mandatory fields');
      return;
    }

    this.isFormVisible = true;
    this.hideDiv = false;
    //this.reportsession.StudentId = 3;
    this.reportsession.CreatedBy = this.context.getUserId().toString();
    var date = new Date(this.reportsession.SessionDate)
    this.reportsession.SessionDate = moment(date).format();
    this.reportsession.IsActive = true;
    this.showCardProgress('form-card')
    this.context.httpService.post(environment.counsellingUrl + this.saveReportsUrl,
      this.reportsession).subscribe(
        (response) => {
          this.hideCardProgress('form-card');
          if (response.success) {
            this.notifySuccess('Saved Succesfully');
            this.getvirtualappointment();
            this.resetForm(ngFrm);
            this.isFormVisible = false;
            this.appointmentFormVisible = false;
          } else {
            this.notifyError('Failed to save data');
          }
        }, (error) => {
          this.hideCardProgress('form-card');
        });
  }

  onSelectDuration() {
    this.timeSlots = [];
    this.visible = false;
    this.active = true;
    let params = new HttpParams();
    if(this.connectCounsellor.Duration != null){
      params = params.append('timeDuration', this.connectCounsellor.Duration.toString());
      params = params.append('counsellorId', this.context.getUserId().toString());
      this.context.httpService.get(environment.counsellingUrl + this.timingUrl, { params: params }).
      subscribe(
        (response) => {
          this.availableList = response.data;
          this.gettimeSlots();
        });
    }   else{
      this.dataSet =[];
    this.dateCustomClasses = [];
    this.datesDisabled =[];
    this.timeSlots=[];
    this.visible = false;

    }

  }

  gettimeSlots() {
    this.dataSet = [];
    let params = new HttpParams();
    if (this.connectCounsellor.Duration) {
      params = params.append('timeDuration', this.connectCounsellor.Duration.toString());
      params = params.append('counsellorId', this.context.getUserId().toString());
    }
    this.context.httpService.get(environment.counsellingUrl + '/Counselling/Available-date', { params: params }).
      subscribe(
        (response) => {
          this.approvedList = response.data;
          this.approvedList.forEach(data => {
            var exdate = moment(data.selectedDate).format("MM/DD/YYYY").toString();
            if (data.approvedCount == data.dateCount) {
              data.activeStatus = false;
            }
            else {
              data.activeStatus = true;
            }
            this.dataSet.push({ 'date': exdate, 'isAvailable': data.activeStatus });
          });
          let dateArray = [];
          this.dataSet.forEach((data) => {
            if (!data.isAvailable) {
              dateArray.push(new Date(data.date))
            }
          });
          this.datesDisabled = dateArray;
          this.dateCustomClasses = this.dataSet.map((data) => {
            return { date: new Date(data.date), classes: [data.isAvailable ? 'bg-success text-white' : 'bg-danger text-white'] }
          });
        });
  }
  open(id) {
    this.counsellingService.viewHistory(id);
    this.dialog = this.modalservice.open(StudentSessionReportComponent, { ariaLabelledBy: 'modal-basic-title', size: 'xl' });
    (<StudentSessionReportComponent>this.dialog.componentInstance).data = 'hi';
    this.dialog.result.then((result) => {
      if (result) {

        //this.ngOnInit();

      }
    }, (reason) => {
      ;
    });
  }

  updateMyDate(event) {
    
    this.datevalidate = false;
    this.dates = event;
    this.timeSlots = [];
    this.visible = false;
    this.availableList.forEach(data => {
      var dtannounced = moment(event).format("YYYY/MM/DD").toString()
      var exdate = moment(data.selectedDate).format("YYYY/MM/DD").toString();
      this.connectCounsellor.SelectedDate = new Date(exdate).toISOString();
      if (moment(exdate).isSame(dtannounced)) {
        if (data.status) {
          this.timeSlots.push({ 'slot': data.startTime + '-' + data.endTime, 'active': true, 'id': data.id, 'status': data.status });
          this.visible = true;
        }
        else {
        }
      }
    });
  }

  slots() {
    this.notifyError("This slot already booked by someone");
  }
  onSelect(e, id) {
    
    var slot = e.split('-');
    this.connectCounsellor.StartTime = slot[0];
    this.connectCounsellor.EndTime = slot[1];
    this.availableid = id;
    this.timeSlots.forEach(element => {
      if (e == element.slot) {
        if (element.active == true) {
          element.active = false;
        }
        else {
          element.active = true;
        }
      }
      else {
        element.active = true;
      }
    });
  }

  resetForm(form: NgForm) {
    form.resetForm();
    this.isFormVisible = false
  }

  calcelAppt(form1: NgForm) {
    form1.resetForm();
    this.availableList = [];
    this.approvedList = [];
    this.dataSet = [];
    this.dateCustomClasses = [];
    this.timeSlots=[];
    this.isFormVisible = true;
    this.appointmentFormVisible = false;
    this.hideDiv = false;
    this.datesDisabled =[];
  }

  setTab(activeTab: string) {
    this.activeTab = activeTab
  }

  async signIn(f:NgForm): Promise<void> {
    await this.authService.signIn();
    this.submitform(1,f);
  }

  signOut(url:string): void {
    this.authService.signOut(url);
  }

  submitform(value,f:NgForm) {
    if (f.invalid) {
      this.notifyError('Please enter all the mandatory fields');
      return;
    }
    if (value == 1) {
      if (!this.authenticated) {
        this.signIn(f);
      } else {
        if(this.authService.user.email == null){
          this.notifyError('kindly login with your teams for Business Account')
          return this.signOut('/counselling/counsellors/dashboard')
        }
        const timeZone = this.authService.user?.timeZone ?? 'UTC';
        this.model.attendees = this.appointment.studentEmail;
        this.model.subject = this.appointment.subject;
        this.model.start = moment(this.appointment.selectedDate).toISOString();
        this.model.end = moment(this.appointment.selectedDate).toISOString();
        const graphEvent = this.model.getGraphEvent(timeZone);
        this.graphService.addEventToCalendar(graphEvent)
          .then((result: any) => {
            this.meeting = result;
            if (result.onlineMeetingProvider == "teamsForBusiness") {
              this.meeting.link = result.onlineMeeting.joinUrl;
              this.connectCounsellor.VirtualLink = this.meeting.link;
              this.schedule(value)
            }
          }).catch(error => {
            throw error;

          });
      }
    }
  }

  schedule(f: NgForm) {

    var data = this.appointmentById.documentFiles;

    const formData = new FormData();
    formData.append('virtualappt.studentId', this.appointmentById.studentId.toString());
    formData.append('virtualappt.counsellorId', this.appointmentById.counsellorId.toString());
    formData.append('virtualappt.category', this.appointmentById.category.toString());
    formData.append('virtualappt.service', this.appointmentById.service.toString());
    formData.append('virtualappt.subject', this.appointmentById.subject.toString());
    formData.append('virtualappt.languages', this.appointmentById.languages.toString());
    formData.append('virtualappt.createdBy', this.context.getUserId().toString());
    formData.append('virtualappt.updatedBy', this.context.getUserId().toString());
    formData.append('virtualappt.purpose', this.appointmentById.purpose.toString());
    formData.append('virtualappt.duration', this.connectCounsellor.Duration.toString());
    formData.append('virtualappt.selectedDate', moment(this.dates).format("YYYY-MM-DD").toString());
    formData.append('virtualappt.endTime', this.connectCounsellor.EndTime);
    formData.append('virtualappt.startTime', this.connectCounsellor.StartTime);
    formData.append('virtualappt.virtualLink', this.connectCounsellor.VirtualLink);
    formData.append('virtualappt.isActive', 'true');
    formData.append('virtualappt.statusId',appointmentstatus.ScheduleConfirmed.toString() );
    formData.append('virtualappt.AvailableTimeId', this.availableid.toString());
    this.showCardProgress('form-card');
    this.context.httpService.post(environment.counsellingUrl + this.virtualUrl, formData).subscribe(
      (response) => {
        var successmsg = "A Confimation Email or Notification will be sent from counsellor soon.";
        this.hideCardProgress('form-card');
        if (response.error != true) {
          this.notifySuccess(successmsg);
          this.availableList = [];
          this.approvedList = [];
          this.dataSet = [];
          this.timeSlots =[];
          this.dateCustomClasses = [];
          this.isFormVisible = false;
          this.appointmentFormVisible = false;
          this.dataSet =[];
          this.visible = false;
          this.datesDisabled = [];
          this.active = false;
          this.connectCounsellor.Duration = null
        }
        else if (response.errorCode == ErrorCode.Duplicate) {
          this.notifyError("Data already exists");
          this.hideCardProgress('form-card');
        }else if (response.errorCode == ErrorCode.DateValidate) {
          this.notifyError("Selected date should be 5 days prior to current date");
          this.hideCardProgress('form-card');
        }
        else {
          this.notifyError("Failed to schedule");
          this.hideCardProgress('form-card');
        }
      },(error) =>{
        this.hideCardProgress('form-card');
      });
  }
}
export class DataSets {
  date: string;
  isAvailable: boolean;
  slots: any;
}
