import { HttpParams } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { BaseComponent } from '@app/app-core/base.component';
import { ErrorCode } from '@app/app-core/constants/constants';
import { ContextContainer } from '@app/app-core/context-container';
import { TimeSlot } from '@app/models/timeslot.model';
import { CalendarOptions } from '@fullcalendar/core';
import { environment } from 'environments/environment';
import * as moment from 'moment';
import { DatepickerDateCustomClasses } from 'ngx-bootstrap/datepicker';

@Component({
  selector: 'app-timeslot',
  templateUrl: './timeslot.component.html',
  styleUrls: ['./timeslot.component.scss']
})
export class TimeslotComponent extends BaseComponent implements OnInit {
  timeSlot: TimeSlot = {
    Id: 0,
    CounsellorId: 0,
    SelectedDate: '',
    StartTime: '',
    EndTime: '',
    Duration: null,
    Status: 0,
    UpdatedBy: '',
    CreatedBy: '',
    IsActive: true


  }
  slot = [{
    Id: 0,
    CounsellorId: 0,
    SelectedDate: '',
    StartTime: '',
    EndTime: '',
    TimeDuration: null,
    Status: 0,
    UpdatedBy: '',
    CreatedBy: '',
    IsActive: true

  }]
  timeUrl: string = '/Counselling/AvailableTiming';
  timeslotList = [];
  mindate: Date = new Date();
  editEvent: true;
  durationList: any;
  showModal: boolean;
  selectDt: string;
  end: any;
  start: any;
  calendarOptions: CalendarOptions;
  stTimebefEndTime: boolean;
  stTimeSameEndTime: boolean;
  timeadd: boolean = false;
  event = {
    startTime: null,
    endTime: null,
  };
  timeslotarr = [];
  timeDetail: any;
  edit: boolean = false;
  userId: any;
  slotList = [];
  duplicate: boolean = false;
  availableList: any;
  calenderSlots = [];
  dates: any;
  id: any;
  datesDisabled: Date[];
  dateCustomClasses: DatepickerDateCustomClasses[];
  dataSet = [];
  approvedList: any;
  datevalidate: boolean = false;
  formdates: string;
  allTimeSlots: any;
  constructor(context: ContextContainer) {
    super(context);
    this.calendarOptions = {
      headerToolbar: {
        right: 'prev,next today',
        center: 'title',
        left: 'dayGridMonth,dayGridWeek'
      },
      //height: '50%',
      displayEventTime: true,
      editable: true,
      selectable: true,
      fixedWeekCount: false,
      displayEventEnd: true,
      lazyFetching: false,
      nowIndicator: false,
      eventTimeFormat: {
        hour: '2-digit',
        minute: '2-digit',
        //second: '2-digit',
        meridiem: 'short'
      },
      //dayCellClassNames: 'cell',
      dateClick: this.handleDateClick.bind(this),
      eventClick: this.eventClick.bind(this),
      eventChange: this.eventChange.bind(this),
      eventDisplay: 'display',
      eventTextColor: '#000000',
      events: this.calenderSlots,

    };
  }

  ngOnInit(): void {
    this.durationList = [{ id: 1, name: '30 mins' }, { id: 2, name: '60 mins' }];
    let params = new HttpParams();
    params = params.append('counsellorId', this.context.getUserId().toString());
    this.context.httpService.get(environment.counsellingUrl + this.timeUrl, { params: params }).
      subscribe(
        (response) => {
          this.allTimeSlots = response.data;
        });

  }
  eventClick(arg) {
    this.id = arg.event.id;
    this.selectDt = moment(arg.event.start).format('YYYY-MM-DD');
    this.start = moment(arg.event.start).format('HH:mm');
    this.end = moment(arg.event.end).format('HH:mm');
    this.show();
    this.editEvent = true;
  }
  handleDateClick(arg) {
    this.show();
    this.selectDt = arg.dateStr;
  }
  eventChange(arg) {

  }
  show() {
    this.showModal = true;
  }

  onSubmit() {
    
    var startDate = this.selectDt + 'T' + this.start + ':00';
    var endDate = this.selectDt + 'T' + this.end + ':00';
    this.showModal = false;
  }

  onSelectDuration() {
    
    this.formdates = '';
    this.event.startTime = '';
    this.event.endTime = '';
    let params = new HttpParams();
    if (this.timeSlot.Duration != null) {
      params = params.append('timeDuration', this.timeSlot.Duration.toString());
      params = params.append('counsellorId', this.context.getUserId().toString());
      this.context.httpService.get(environment.counsellingUrl + this.timeUrl, { params: params }).
        subscribe(
          (response) => {
            this.availableList = response.data;
            this.dataSet = [];
            this.dateCustomClasses = [];
            this.gettimeSlots();
          });
    }
    else {
      this.dataSet = [];
      this.dateCustomClasses = [];
      this.datesDisabled = [];
      this.timeslotarr = [];
      this.timeadd = false;
    }
  }

  gettimeSlots() {
    this.timeslotarr = [];
    this.timeadd = false;
    let params = new HttpParams();
    if (this.timeSlot.Duration) {
      params = params.append('timeDuration', this.timeSlot.Duration.toString());
      params = params.append('counsellorId', this.context.getUserId().toString());
    }
    this.context.httpService.get(environment.counsellingUrl + '/Counselling/Available-Date', { params: params }).
      subscribe(
        (response) => {
          if (response.data) {
            this.approvedList = response.data;
            this.approvedList.forEach(data => {
              var exdate = moment(data.selectedDate).format("MM/DD/YYYY").toString();
              if (data.approvedCount == data.dateCount) {
                data.activeStatus = false;
              }
              else {
                data.activeStatus = true;
              }
              this.dataSet.push({ 'date': exdate, 'isAvailable': data.activeStatus });
            });
            let dateArray = [];
            this.dataSet.forEach((data) => {
              if (data.isAvailable == false) {
                dateArray.push(new Date(data.date))
              }
            });
            this.datesDisabled = dateArray;
            this.dateCustomClasses = this.dataSet.map((data) => {
              return { date: new Date(data.date), classes: [data.isAvailable ? 'bg-success text-white' : 'bg-danger text-white'] }
            });
          }
        });
  }
  updateMyDate(event) {
    
    this.showModal = true;
    this.timeslotarr = [];
    this.timeSlot.SelectedDate = moment(event).format();
    this.dates = event;
    var formdates = moment(event).format("YYYY/MM/DD");
    this.formdates = formdates;
    if (this.availableList) {
      this.availableList.forEach(data => {
        var dates = moment(data.selectedDate).format("YYYY/MM/DD");
        if (dates == formdates) {
          this.timeslotarr.push({ 'id': this.timeslotarr.length + 1, 'itemId': data.id, 'start': data.startTime, 'end': data.endTime, 'status': data.status });

        }
        if (this.timeslotarr.length != 0) {
          this.timeadd = true;
        }
        else {
          this.timeadd = false;
        }
      });
    }
  }
  clrTimeValidate() {
    this.stTimebefEndTime = false;
    this.stTimeSameEndTime = false;
  }
  onPaste(event: ClipboardEvent) {
    event.preventDefault();
    return false;
  }
  timeValidation() {
    
    if (this.timeSlot.Duration == 1) {
      this.event.endTime = moment(this.event.startTime, 'hh:mm')
        .add(30, 'minutes');
      this.event.endTime = moment(this.event.endTime).format('HH:mm');
    }
    else {
      this.event.endTime = moment(this.event.startTime, 'hh:mm')
        .add(1, 'hour');
      this.event.endTime = moment(this.event.endTime).format('HH:mm');
    }
  }
  editTime(e) {
    this.edit = true;
    this.event.startTime = e.start;
    this.event.endTime = e.end;
    this.timeDetail = e;
  }
  removeTime(id, e) {
    
    if (e.status != 3) {
      if (e.itemId) {

        this.context.notificationService.confirmAlert((confirm) => {
          if (!confirm.dismiss) {
            this.context.httpService.put(environment.counsellingUrl + '/Counselling/inactive-FreeTime/' + e.itemId).subscribe(
              (response) => {
                if (response) {
                  this.timeslotarr.splice(id, 1);
                  this.notifySuccess("Deleted Successfully")
                }

                if (this.timeslotarr.length == 0) {
                  this.timeadd = false;
                  this.edit = false;
                }
                else {
                  this.timeadd = true;
                  this.edit = false;
                }

              });
          }
        }, 'Delete?');
      } else {
        this.timeslotarr.splice(id, 1);
        this.notifySuccess("Deleted Successfully")
        return;
      }
    }
    else {
      this.notifyError("This slot is scheduled by student");
    }
  }
  clearTime() {
    this.event.startTime = [];
    this.event.endTime = [];
  }
  cancel() {
    this.showModal = false;
  }

  addTime() {
    
    this.checkTimeslots();
    if (this.datevalidate || this.event.startTime == "" || this.event.endTime == "") {
      this.notifyError("All fields are required");
      return;
    }
    this.timeadd = true;
    this.duplicate = false;
    if (!this.edit) {
      if (this.timeslotarr.length == 0) {
        this.timeslotarr = [];
        this.timeslotarr.push({ id: this.timeslotarr.length + 1, start: this.event.startTime, end: this.event.endTime });
        this.event.startTime = [];
        this.event.endTime = [];
      }
      else {
        this.checkDuplicate();
        if (this.duplicate == false) {
          this.timeslotarr.push({ id: this.timeslotarr.length + 1, start: this.event.startTime, end: this.event.endTime });
          this.event.startTime = [];
          this.event.endTime = [];
        }
      }
    }
    else {
      this.timeslotarr.forEach(element => {
        if (element.id == this.timeDetail.id) {
          element.start = this.event.startTime;
          element.end = this.event.endTime;
        }
      })
      this.edit = false;
      this.event.startTime = [];
      this.event.endTime = [];
    }
  }
  addCal() {
    
    if (!this.editEvent) {
      if (this.calenderSlots.length == 0) {
        var startDate = this.selectDt + 'T' + this.start + ':00';
        var endDate = this.selectDt + 'T' + this.end + ':00';
        this.calenderSlots.push({ title: 'slot', id: this.calenderSlots.length + 1, start: startDate, end: endDate, backgroundColor: '#C1E1C1' });
        this.calendarOptions.events = this.calenderSlots;
        this.showModal = false;
      }
      else {
        this.checkDuplicateCal()
        var startDate = this.selectDt + 'T' + this.start + ':00';
        var endDate = this.selectDt + 'T' + this.end + ':00';
        this.calenderSlots.push({ title: 'slot', id: this.calenderSlots.length + 1, start: startDate, end: endDate, backgroundColor: '#C1E1C1' });
        this.calendarOptions.events = this.calenderSlots;
        this.showModal = false;
      }
    }
    else {
      var startDate = this.selectDt + 'T' + this.start + ':00';
      var endDate = this.selectDt + 'T' + this.end + ':00';
      this.calenderSlots.forEach(element => {
        if (element.id == this.id) {
          element.start = startDate;
          element.end = endDate;
        }
      });
      this.calendarOptions.events = this.calenderSlots;
      this.showModal = false;
    }

  }


  // get getUserRoleKC(): string {
  //   this.userId = this.context.authenticationService.getUserRoleKC();
  //   var access_token = this.userId.source.value;
  //   return access_token;
  // }
  checkDuplicate() {
    
    this.timeslotarr.forEach(element => {
      if (element.start == this.event.startTime && element.end == this.event.endTime) {
        this.duplicate = true;
        return;
      }
    })
  }
  checkDuplicateCal() {
    
    this.timeslotarr.forEach(element => {
      var startDate = this.selectDt + 'T' + this.start + ':00';
      var endDate = this.selectDt + 'T' + this.end + ':00';
      if (element.start == startDate && element.end == endDate) {
        this.duplicate = true;
        return;
      }
    })
  }
  send(f: NgForm) {
    
    if (f.invalid) {
      return;
    }
    //  this.checkdates();
    //   if(this.datevalidate == true){
    //     return;
    //   }
    this.slot = [];
    if (this.timeslotarr.length != 0) {
      this.timeslotarr.forEach(element => {
        if (element.itemId) {
          this.slot.push({
            CounsellorId: this.context.getUserId(),
            Id: element.itemId,
            Status: 1,
            SelectedDate: this.timeSlot.SelectedDate,
            StartTime: element.start,
            EndTime: element.end,
            TimeDuration: this.timeSlot.Duration,
            CreatedBy: this.context.getUserId().toString(),
            UpdatedBy: this.context.getUserId().toString(),
            IsActive: true
          })
        }
        else {
          this.slot.push({
            CounsellorId: this.context.getUserId(),
            Id: 0,
            Status: 1,
            SelectedDate: this.timeSlot.SelectedDate,
            StartTime: element.start,
            EndTime: element.end,
            TimeDuration: this.timeSlot.Duration,
            CreatedBy: this.context.getUserId().toString(),
            UpdatedBy: this.context.getUserId().toString(),
            IsActive: true
          })
        }

      })
    } else {
      this.notifyError("All fields are mandatory");
      return;
    }
    this.context.httpService.post(environment.counsellingUrl + this.timeUrl, this.slot).subscribe(
      (response) => {
        var successmsg = "Timeslot added successfully.";
        if (response.error != true) {
          this.notifySuccess(successmsg);
          this.clear();
          this.formdates = '';
        } else if (response.errorCode == ErrorCode.DateValidate) {
          this.notifyError("Select 5 days prior the session")
          this.formdates = '';
        } else {
          this.notifyError("Failed to Add Time slots")
          this.formdates = '';
        }
      });
  }
  // checkdates(){
  //   
  //   this.datevalidate = false;
  //   var date  = new Date();
  //   date.setDate(date.getDate() + 5);
  // if(date > this.dates){
  // this.datevalidate = true;
  // this.notifyError("Selected date should be 5 days prior to current date")
  // return;
  //     }
  // }
  checkTimeslots() {
    
    this.datevalidate = false;
    var startTime = moment(this.event.startTime, "HH:mm");
    var endTime = moment(this.event.endTime, "HH:mm");
    var duration = moment.duration(endTime.diff(startTime));
    var hours = duration.asHours();
    var minutes = duration.asMinutes();
    this.allTimeSlots.forEach(element => {
      var date = moment(element.selectedDate).format("YYYY/MM/DD");
      if (date == this.formdates && (element.startTime == this.event.startTime || element.endTime == this.event.endTime)) {
        this.datevalidate = true;
        this.notifyError("This slot alreday exists");
        return;
      }
    });
  }
  clear() {
    this.timeSlot.Duration = null;
    this.dataSet = [];
    this.datesDisabled = [];
    this.dateCustomClasses = [];
    this.timeadd = false;
  }
  removeTimeCal(id, e) {
    
    this.showModal = false;
    this.context.notificationService.confirmAlert((confirm) => {
      if (!confirm.dismiss) {
        this.context.httpService.put(environment.counsellingUrl + '/Counselling/inactive-FreeTime/' + e).subscribe(
          (response) => {
            const index: number = this.calenderSlots.indexOf(id);
            if (index !== -1) {
              this.calenderSlots.splice(index, 1);
            }
            this.notifySuccess("Deleted Successfully")
            if (this.calenderSlots.length == 0) {
              this.timeadd = false;
              this.edit = false;
            }
            else {
              this.timeadd = true;
              this.edit = false;
            }

          });
      }
    }, 'Delete?');
  }
}
