import { Component, OnInit, Output } from '@angular/core';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { AuthService } from '../../../../services/auth.service';
import { GraphService } from '../../../../services/graph.service';
import { newappointment } from '../modals/appointment';
import { User } from '../modals/user';
import { ActivatedRoute, Router } from "@angular/router";
import { environment } from 'environments/environment';
import { NgForm } from '@angular/forms';
import * as moment from 'moment';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Gender, GenderAr } from '@services/enumfiles';
import { LangChangeEvent } from '@ngx-translate/core';

@Component({
  selector: 'app-appointments',
  templateUrl: './appointments.component.html',
  styleUrls: ['./appointments.component.scss']
})
export class AppointmentsComponent extends BaseComponent implements OnInit {
  public enumgender = Gender;
  public enumgenderAr = GenderAr;

  meeting = {
    link: ''
  };
  appointmentId: string;
  appointment: any;
  form = {
    reason: '',
  }
  outLookLogin: boolean = false;
  buttondisabled: boolean = false;
  reasonrequired: boolean = false;
  userId: any;
  @Output() studentid: any;
  slang: string = 'en';

  get authenticated(): boolean {
    return this.authService.authenticated;
  }
  // The user
  get user(): User | undefined {
    return this.authService.user;
  }

  model = new newappointment();



// test data{

// }

  constructor(
    context: ContextContainer,
    private authService: AuthService,
    private graphService: GraphService,
    private route: ActivatedRoute,
    private router: Router,
    private modalservice: NgbModal
  ) {
    super(context)
  }

  ngOnInit(): void {
    this.appointmentId = this.route.snapshot.paramMap.get('id');
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang
    });
    this.getappointment();
  }
  getappointment() {
    this.context.httpService.get(environment.counsellingUrl + '/Counselling/VirtualAppointment/' + this.appointmentId).subscribe
      ((results) => {
        if (results.success == true) {
          this.appointment = results.data;
          this.studentid = results.data.studentId;
        }
      })
  }

  async signIn(): Promise<void> {
    await this.authService.signIn();
    this.submitform(1);
  }

  signOut(url: string): void {
    this.authService.signOut(url);
  }

  onSubmit(): void {
    const timeZone = this.authService.user?.timeZone ?? 'UTC';

    const graphEvent = this.model.getGraphEvent(timeZone);

    this.graphService.addEventToCalendar(graphEvent)
      .then((result: any) => {
        this.meeting = result;
        if (result.onlineMeetingProvider == "teamsForBusiness") {
          this.meeting.link = result.onlineMeeting.joinUrl;
        }
      }).catch(error => {
        throw error;
      });
  }
  submitform(value) {
    if (value == 1) {
      if (!this.authenticated) {
        this.signIn();
      } else {
        if(this.authService.user.email == null){
          this.notifyError('kindly login with your teams for Business Account')
          return this.signOut('/counselling/counsellors/dashboard')
        }
        const timeZone = this.authService.user?.timeZone ?? 'UTC';
        this.model.attendees = 'ashikaliasvkr@gmail.com';
        this.model.subject = this.appointment.subject;
        this.model.start = moment(this.appointment.selectedDate).toISOString();
        this.model.end = moment(this.appointment.selectedDate).toISOString();
        const graphEvent = this.model.getGraphEvent(timeZone);

        this.graphService.addEventToCalendar(graphEvent)
          .then((result: any) => {
            this.meeting = result;
            if (result.onlineMeetingProvider == "teamsForBusiness") {
              this.meeting.link = result.onlineMeeting.joinUrl;
              this.appointment.Link = this.meeting.link;
              let appointmentdata = {
                statusId: 0,
                Link: '',
                updatedBy: this.context.getUserId().toString(),
              }
              appointmentdata.statusId = 3;
              appointmentdata.Link = this.meeting.link;

              this.context.httpService.put(environment.counsellingUrl + '/Counselling/VirtualAppointment/' + this.appointmentId, appointmentdata).subscribe
                ((results) => {
                  if (results.success == true) {
                    this.notifySuccess('Appointment Confirmed Successfully');
                    this.router.navigate(['/counselling/counsellors/view-appointment']);
                    this.getappointment();
                    this.buttondisabled = true;
                  } else {
                    this.notifyError('Failed to confirm Appointment')
                  }
                })
            }else{
              this.notifyError('kindly login with your teams for Business Account')
            }
          }).catch(error => {
            throw error;
          });
      }
    }
    else {
      if (this.appointment.reasonReject == ('' || null)) {
        this.reasonrequired = true;
        return
      } else {
        this.context.notificationService.confirmAlert((confirm) => {
          if (!confirm.dismiss) {
            this.showCardProgress('grid-card');
            let appointmentdata = {
              statusId: 4,
              updatedBy: this.context.getUserId().toString(),
              ReasonReject: this.appointment.reasonReject
            }
            this.context.httpService.put(environment.counsellingUrl + '/Counselling/VirtualAppointment/' + this.appointmentId, appointmentdata).subscribe
              ((results) => {
                if (results.success == true) {
                  this.notifySuccess('Rejected Successfully');
                  this.router.navigate(['/counselling/counsellors/view-appointment']);
                  this.getappointment();
                } else {
                  this.notifyError('Failed to Reject');
                }
              })
          }
        }, 'Confirm Reject?')
      }
    }
  }
  showModal(studentprofile){
    this.modalservice.open(studentprofile, { ariaLabelledBy: 'modal-primary-title', size: 'xl' });
  }
  // get getUserId(): string {
  //   this.userId = this.context.authenticationService.getUserId();
  //   var access_token = this.userId.source.value;
  //   return access_token;
  // }
}
