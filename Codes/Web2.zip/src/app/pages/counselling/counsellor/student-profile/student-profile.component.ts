import { HttpParams } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { rating } from '@app/services/enumfiles';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { environment } from 'environments/environment';

@Component({
  selector: 'app-student-profile',
  templateUrl: './student-profile.component.html',
  styleUrls: ['./student-profile.component.scss']
})
export class StudentProfileComponent extends BaseComponent implements OnInit {
  public enumrating = rating
  d = "dismiss";
  @Input() studentid: any;
  personals: any;
  educationlist: any;
  courseslist: any;
  volunteeringlist: any;
  workexplist: any;
  skillslist: any;
  accomplishmentlist: any;
  // personals = {
  //   profilePic: '../../../../../assets/images/counselling/Prof01.jpg',
  //   name: 'Zaheer Usain ',
  //   gender: 'Male',
  //   dob: '11/08/2000',
  //   mobileNo: '3409875',
  //   phoneNumber: '3409875',
  //   emirateId: '192u3904',
  //   currentAddressLine1: 'Al-dehra street',
  //   currentAddressLine2: 'Muesuem road',
  //   currentCityName: 'Abu-dhabi',
  //   currentEmiratesName: 'Abu-dhabi',
  //   currentZipCode: '3456864',
  //   permanentAddressLine1: 'Al-dehra street',
  //   permanentAddressLine2: 'Muesuem road',
  //   permanentCityName: 'Abu-dhabi',
  //   permanentEmiratesName: 'Abu-dhabi',
  //   permanentZipCode: '3456864',
  //   email: 'zaheer221@gmail.com'
  // }
  // educationlist = [
  //   {
  //     majorName: 'Agriculture, Forestry, Fisheries & Veterinary',
  //     institute: 'Al Ain University',
  //     startDate: '03/20/2016',
  //     endDate: '',
  //     pursuing: 1
  //   },
  //   {
  //     majorName: 'Agriculture, Forestry, Fisheries & Veterinary',
  //     institute: 'Al Ain University',
  //     startDate: '03/20/2016',
  //     endDate: '',
  //     pursuing: 1
  //   },
  //   {
  //     majorName: 'Agriculture, Forestry, Fisheries & Veterinary',
  //     institute: 'Al Ain University',
  //     startDate: '03/20/2016',
  //     endDate: '',
  //     pursuing: 1
  //   },
  //   {
  //     majorName: 'Agriculture, Forestry, Fisheries & Veterinary',
  //     institute: 'Al Ain University',
  //     startDate: '03/20/2016',
  //     endDate: '',
  //     pursuing: 1
  //   },
  //   {
  //     majorName: 'Agriculture, Forestry, Fisheries & Veterinary',
  //     institute: 'Al Ain University',
  //     startDate: '03/20/2016',
  //     endDate: '',
  //     pursuing: 1
  //   },
  //   {
  //     majorName: 'Agriculture, Forestry, Fisheries & Veterinary',
  //     institute: 'Al Ain University',
  //     startDate: '03/20/2016',
  //     endDate: '',
  //     pursuing: 1
  //   },
  //   {
  //     majorName: 'Agriculture, Forestry, Fisheries & Veterinary',
  //     institute: 'Al Ain University',
  //     startDate: '03/20/2016',
  //     endDate: '',
  //     pursuing: 1
  //   },
  //   {
  //     majorName: 'Agriculture, Forestry, Fisheries & Veterinary',
  //     institute: 'Al Ain University',
  //     startDate: '03/20/2016',
  //     endDate: '',
  //     pursuing: 1
  //   },
  // ];
  // courseslist = [
  //   {
  //     certificatename: 'Master of C language',
  //     Institutename: 'University of Dubai',
  //     issuingauthority: 'Principal of UD',
  //     validtill: 'Sep 2024',
  //   },
  //   {
  //     certificatename: 'Master of C++ language',
  //     Institutename: 'University of Dubai',
  //     issuingauthority: 'Principal of UD',
  //     validtill: 'Sep 2025',
  //   },
  //   {
  //     certificatename: 'Ungraduate Degree of Computer Science',
  //     Institutename: 'University of Dubai',
  //     issuingauthority: 'Principal of UD',
  //     validtill: 'No Expiry',
  //   },
  //   {
  //     certificatename: 'Master of C language',
  //     Institutename: 'University of Dubai',
  //     issuingauthority: 'Principal of UD',
  //     validtill: 'Sep 2024',
  //   },
  //   {
  //     certificatename: 'Master of C language',
  //     Institutename: 'University of Dubai',
  //     issuingauthority: 'Principal of UD',
  //     validtill: 'Sep 2024',
  //   },
  //   {
  //     certificatename: 'Master of C language',
  //     Institutename: 'University of Dubai',
  //     issuingauthority: 'Principal of UD',
  //     validtill: 'Sep 2024',
  //   },
  //   {
  //     certificatename: 'Master of C language',
  //     Institutename: 'University of Dubai',
  //     issuingauthority: 'Principal of UD',
  //     validtill: 'Sep 2024',
  //   },
  //   {
  //     certificatename: 'Master of C language',
  //     Institutename: 'University of Dubai',
  //     issuingauthority: 'Principal of UD',
  //     validtill: 'Sep 2024',
  //   },
  // ];
  // volunteeringlist = [
  //   {
  //     eventname: 'Multilingual quiz',
  //     Organization: 'Arab social university',
  //     Date: '03/20/2016',
  //   },
  //   {
  //     eventname: 'Multilingual quiz',
  //     Organization: 'Arab social university',
  //     Date: '03/20/2016',
  //   },
  //   {
  //     eventname: 'Multilingual quiz',
  //     Organization: 'Arab social university',
  //     Date: '03/20/2016',
  //   },
  //   {
  //     eventname: 'Multilingual quiz',
  //     Organization: 'Arab social university',
  //     Date: '03/20/2016',
  //   },
  //   {
  //     eventname: 'Multilingual quiz',
  //     Organization: 'Arab social university',
  //     Date: '03/20/2016',
  //   },
  //   {
  //     eventname: 'Multilingual quiz',
  //     Organization: 'Arab social university',
  //     Date: '03/20/2016',
  //   },
  //   {
  //     eventname: 'Multilingual quiz',
  //     Organization: 'Arab social university',
  //     Date: '03/20/2016',
  //   },
  //   {
  //     eventname: 'Multilingual quiz',
  //     Organization: 'Arab social university',
  //     Date: '03/20/2016',
  //   },
  // ];
  // workexplist = [
  //   {
  //     organization: 'Sight Spectrum',
  //     worktype: 'Professional Exp',
  //     startDate: '01/04/2020',
  //     endDate: '',
  //     pursuing: 1
  //   },
  //   {
  //     organization: 'TCS',
  //     worktype: 'Work placement',
  //     startDate: '23/05/2018',
  //     endDate: '30/03/2020',
  //     pursuing: 1
  //   },
  //   {
  //     organization: 'Casp tech',
  //     worktype: 'Internship',
  //     startDate: '01/01/2017',
  //     endDate: '18/04/2018',
  //     pursuing: 1
  //   },
  //   {
  //     organization: 'Sight Spectrum',
  //     worktype: 'Professional Exp',
  //     startDate: '01/04/2020',
  //     endDate: '',
  //     pursuing: 1
  //   },
  //   {
  //     organization: 'Casp tech',
  //     worktype: 'Internship',
  //     startDate: '01/01/2017',
  //     endDate: '18/04/2018',
  //     pursuing: 1
  //   },
  //   {
  //     organization: 'Sight Spectrum',
  //     worktype: 'Professional Exp',
  //     startDate: '01/04/2020',
  //     endDate: '',
  //     pursuing: 1
  //   },
  //   {
  //     organization: 'Casp tech',
  //     worktype: 'Internship',
  //     startDate: '01/01/2017',
  //     endDate: '18/04/2018',
  //     pursuing: 1
  //   },
  //   {
  //     organization: 'Sight Spectrum',
  //     worktype: 'Professional Exp',
  //     startDate: '01/04/2020',
  //     endDate: '',
  //     pursuing: 1
  //   },
  // ];
  // skillslist = [
  //   {
  //     skilltitle: 'Computer skills',
  //     selfrate: '4',
  //     year: '3',
  //     month: '6'
  //   },
  //   {
  //     skilltitle: 'Communication skills',
  //     selfrate: '5',
  //     year: '2',
  //     month: '0'
  //   },
  //   {
  //     skilltitle: 'Collaboration talent',
  //     selfrate: '3',
  //     year: '1',
  //     month: '6'
  //   },
  //   {
  //     skilltitle: 'Computer skills',
  //     selfrate: '4',
  //     year: '3',
  //     month: '6'
  //   },
  //   {
  //     skilltitle: 'Collaboration talent',
  //     selfrate: '3',
  //     year: '1',
  //     month: '6'
  //   },
  //   {
  //     skilltitle: 'Computer skills',
  //     selfrate: '4',
  //     year: '3',
  //     month: '6'
  //   },
  //   {
  //     skilltitle: 'Collaboration talent',
  //     selfrate: '3',
  //     year: '1',
  //     month: '6'
  //   },
  //   {
  //     skilltitle: 'Computer skills',
  //     selfrate: '4',
  //     year: '3',
  //     month: '6'
  //   },
  // ];
  // accomplishmentlist = [
  //   {
  //     type: 'project',
  //     title: 'Mini-map retention creator',
  //     url: 'https://techdocs.broadcom.com/',
  //     startDate: '01/04/2020',
  //     endDate: '01/05/2021',
  //   },
  //   {
  //     type: 'publication',
  //     title: 'A wiser judgement',
  //     url: 'https://anurab.publication.com/',
  //     publisher: 'Dr. Anurab',
  //     startDate: '08/11/2019',
  //   },
  //   {
  //     type: 'testscore',
  //     title: 'Talent feast',
  //     score: '77.8 %',
  //     startDate: '08/11/2019',
  //   },
  //   {
  //     type: 'testscore',
  //     title: 'Talent feast',
  //     score: '77.8 %',
  //     startDate: '08/11/2019',
  //   },
  //   {
  //     type: 'competition',
  //     title: 'Abacus Quiz Competition',
  //     score: '88',
  //     startDate: '17/12/2016',
  //   },
  //   {
  //     type: 'awards',
  //     title: 'Master brains',
  //     award: 'Puzzle solve expert',
  //     startDate: '11/11/205',
  //   },
  //   {
  //     type: 'competition',
  //     title: 'Abacus Quiz Competition',
  //     score: '88',
  //     startDate: '17/12/2016',
  //   },
  //   {
  //     type: 'awards',
  //     title: 'Master brains',
  //     award: 'Puzzle solve expert',
  //     startDate: '11/11/205',
  //   },
  //   {
  //     type: 'competition',
  //     title: 'Abacus Quiz Competition',
  //     score: '88',
  //     startDate: '17/12/2016',
  //   },
  //   {
  //     type: 'awards',
  //     title: 'Master brains',
  //     award: 'Puzzle solve expert',
  //     startDate: '11/11/205',
  //   }
  // ]
  accomplishmenttype = 1;
  pvisible: boolean = true;
  evisible: boolean = false;
  cvisible: boolean = false;
  vvisible: boolean = false;
  wvisible: boolean = false;
  svisible: boolean = false;
  avisible: boolean = false;
  accomplish: any;

  constructor(context: ContextContainer,) {
    super(context)
  }

  ngOnInit(): void {
    this.getstudentdetails();
  }
  loadData(event) {
    if (event.target.value == 1) { this.pvisible = true; this.evisible = false; this.cvisible = false; this.vvisible = false; this.wvisible = false; this.svisible = false; this.avisible = false; }
    if (event.target.value == 2) { this.pvisible = false; this.evisible = true; this.cvisible = false; this.vvisible = false; this.wvisible = false; this.svisible = false; this.avisible = false; }
    if (event.target.value == 3) { this.pvisible = false; this.evisible = false; this.cvisible = true; this.vvisible = false; this.wvisible = false; this.svisible = false; this.avisible = false; }
    if (event.target.value == 4) { this.pvisible = false; this.evisible = false; this.cvisible = false; this.vvisible = true; this.wvisible = false; this.svisible = false; this.avisible = false; }
    if (event.target.value == 5) { this.pvisible = false; this.evisible = false; this.cvisible = false; this.vvisible = false; this.wvisible = true; this.svisible = false; this.avisible = false; }
    if (event.target.value == 6) { this.pvisible = false; this.evisible = false; this.cvisible = false; this.vvisible = false; this.wvisible = false; this.svisible = true; this.avisible = false; }
    if (event.target.value == 7) { this.pvisible = false; this.evisible = false; this.cvisible = false; this.vvisible = false; this.wvisible = false; this.svisible = false; this.avisible = true; }

  }
  
  getstudentdetails(){
    this.getpersonals();
    this.getDegreeDetail();
    this.getCertificationDetail();
    this.getVolunteering();
    this.getWorkExperience();
    this.getSkill();
    // this.getProject();
    // this.getPublication();
    // this.getTest();
    // this.getCompetition();
    // this.getAward();
    this.accomplishment();  
  }
  accomplistType(e){
var data = e.target.value;
this.accomplish = this.accomplishmentlist.filter(x => x.accomplishmentTypeId == data);
;  }
  accomplishment() {
    var param = new HttpParams().set("studentId", '129');
      this.showCardProgress('proj-grid-card')
      this.context.httpService.get(environment.academicsUrl + '/Accomplishment/LoadGrid', {params : param})
        .subscribe(results => {
          if(results.data){
          this.accomplishmentlist = results.data;
          this.accomplish = this.accomplishmentlist.filter(x => x.accomplishmentTypeId == 1);
          }
        });
      this.hideCardProgress('proj-grid-card')
  }
  // getStudentDetails() {
  //   this.showCardProgress("intern-grid-card");
  //   this.context.httpService.get(this.environment.internshipUrl + '/Internship/students-view/?StudentId=' + this.studentId )
  //     .subscribe(
  //       (Response) => {
  //         this.hideCardProgress("intern-grid-card");
  //         if (Response.success) {
  // this.studentDetails = Response.data || [];
  // this.answers = this.studentDetails.internshipQuestionnaireDetails;
  // if (this.studentDetails.internshipQuestionnaireDetails.length <= 0) {
  //   this.noquestion = false;
  //   this.questionVisible = false;
  // } else {
  //   this.noquestion = true;
  //   this.questionVisible = true;
  // }
  //     }
  //     else {
  //       this.notifyError('Failed to get data');
  //     }
  //   });
  // }
  getpersonals() {
    
    this.context.httpService.get(environment.academicsUrl + '/StudentProfile/PersonalDetails/' + this.studentid).subscribe
      ((results) => {
        this.personals = results.data;
      })
  }
  getDegreeDetail() {
    this.showCardProgress('education-grid-card');
    this.context.httpService.get(environment.academicsUrl + '/StudentProfile/DegreeDetails/' + this.studentid).subscribe(
      (results) => {
        this.educationlist = results.data;
      })
  }
  getCertificationDetail() {
    this.showCardProgress('course-grid-card');
    this.context.httpService.get(environment.academicsUrl + '/StudentProfile/CertificationDetail/' + this.studentid).subscribe(
      (results) => {
        this.courseslist = results.data;
      })

  }
  getVolunteering() {
    this.showCardProgress('volunteering-grid-card')
    this.context.httpService.get(environment.academicsUrl + '/StudentProfile/Volunteering/' + this.studentid).
      subscribe(
        (results) => {
          this.volunteeringlist = results.data;
        })
  }
  getSkill() {
    this.showCardProgress('skill-grid-card');
    this.context.httpService.get(environment.academicsUrl + '/StudentProfile/Skill/' + this.studentid).subscribe(
      (results) => { 
        this.skillslist = results.data;
      })
    }
    // getProject() {
    //   var param = new HttpParams().set("accomplishmentTypeId", '1').set("studentId", this.studentid);
    //   this.showCardProgress('proj-grid-card')
    //   this.context.httpService.get(environment.academicsUrl + '/Accomplishment/LoadGrid', {params : param})
    //     .subscribe(results => {
    //       console.log(results);
    //       this.accomplishmentlist.push(results.data);
    //     });
    //   this.hideCardProgress('proj-grid-card')
    // }
    // getPublication() {
    //   var param = new HttpParams().set("accomplishmentTypeId", '2').set("studentId", this.studentid);
    //   this.showCardProgress('pub-grid-card')
    //   this.context.httpService.get(environment.academicsUrl + '/Accomplishment/LoadGrid', {params : param})
    //     .subscribe(Response => {
    //       this.accomplishmentlist.push(Response.data);
    //     });
    //   this.hideCardProgress('pub-grid-card')
    // }
    // getTest() {
      
    //   var param = new HttpParams().set("accomplishmentTypeId", '3').set("studentId", this.studentid);
    //   this.showCardProgress('test-grid-card')
    //   this.context.httpService.get(environment.academicsUrl + '/Accomplishment/LoadGrid', {params : param})
    //     .subscribe(Response => {
    //       this.accomplishmentlist.push(Response.data);
    //     });
    //   this.hideCardProgress('test-grid-card')
    // }
    // getCompetition() {
    //   var param = new HttpParams().set("accomplishmentTypeId", '4').set("studentId", this.studentid);
    //   this.showCardProgress('comp-grid-card')
    //   this.context.httpService.get(environment.academicsUrl + '/Accomplishment/LoadGrid', {params : param})
    //     .subscribe(Response => {
    //       this.accomplishmentlist.push(Response.data);
    //     });
    //   this.hideCardProgress('comp-grid-card')
    // }
    // getAward() {
    //   var param = new HttpParams().set("accomplishmentTypeId", '5').set("studentId", this.studentid);
    //   this.showCardProgress('award-grid-card')
    //   this.context.httpService.get(environment.academicsUrl + '/Accomplishment/LoadGrid', {params : param})
    //     .subscribe(Response => {
    //       this.accomplishmentlist.push(Response.data);
    //     });
    //   this.hideCardProgress('award-grid-card')
    // }
  
    getWorkExperience() {
      this.showCardProgress('experience-grid-card')
      this.context.httpService.get(environment.academicsUrl + '/StudentProfile/WorkExperience/' + this.studentid).
        subscribe(
          (response) => {
           this.workexplist = response.data;
          })
    }
}
