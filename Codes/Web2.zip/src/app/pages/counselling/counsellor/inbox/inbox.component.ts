import { HttpParams } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { ConnectCounsellor } from '@app/models/connectcounsellor.model';
import { PostFaq } from '@app/models/postfaq.model';
import { Status } from '@app/models/status';
import { FileUploadControl } from '@iplab/ngx-file-upload';
import { DataTableDirective } from 'angular-datatables';
import { environment } from 'environments/environment';
import * as moment from 'moment';


@Component({
  selector: 'app-inbox',
  templateUrl: './inbox.component.html',
  styleUrls: ['./inbox.component.scss']
})
export class InboxComponent extends BaseComponent implements OnInit {
  @ViewChild(DataTableDirective) dtElement: DataTableDirective;

  activeTab = 'search';
  connectCounsellor: ConnectCounsellor =
  {
    Id: 0,
    StudentId:0,
    CounsellorId: 0,
    Status: false,
    Category: null,
    Service: null,
    Subject: '',
    AskQuestion:'',
    Purpose: '',
    Option: 0,
    PreferredLanguage: null,
    UploadFile: '',
    CreatedBy: '',
    UpdatedBy: '',
    Duration:null,
    SelectedDate: '',
    StartTime:'',
    EndTime:'',
    PostedDate: '',
    ReplayDate: '',
    Pinned: false,
    Answer: '',
    IsActive: true
  }
  readonly Status: typeof Status = Status;

  uploadFile: Array<File> = [];
  answerQues: '';
  ansValidation: boolean = false
  counsellingURL: string = '/Counselling/Inbox';
  filterURL: string = '/Counselling/FilterQandA';
  askUrl: string = '/Counselling/QandAResponse';
  markUrl: string ='/Counselling/QandAPin';
  public documentControl = new FileUploadControl(null);
  qaList=[];
  filterList=[];
  pagination: Pagination = new Pagination(1, 0, 10, [10,20,30,40]);
  serverPage: number = 1;
  clickCount: number =5;
  visibleRecentview: boolean = false;
  visibleRecent:boolean = false;
  visibleAnswerview:boolean = false;
  visibleAnswer:boolean = false;
  config: any;
  answerList=[];

  mark: boolean = false;
  answer:boolean = false;
  filterAnswerList=[];
  clickCountanswer: number = 5;
  pinnedList=[];
  isFormVisible: boolean;
  postFaq: PostFaq = {
    Id: 0,
    CounsellorId: 0,
    QuestionEn:'',
    AnswerEn:'',
    QuestionAr:'',
    AnswerAr:'',
    CategoryId:null,
    RejectReason:'',
    PostedDate:'',
    StatusId: 0,
    CreatedDate:'',
    UpdatedDate:'',
    CreatedBy: '',
    UpdatedBy: '',
    IsActive:true
  }
  dropURL: string = '/Dropdown/dropdowns';
  faqUrl: string = '/Counselling/FaqDetails';
  postfaqUrl: string ='/Counselling/FaqDetail';
  categoryList: any;
  faqList=[];
  userId: any;
  badgeStyle: { [id: string]: string; } = {};
  file: any;
  fieldsetDisabled: boolean= false;
  active: boolean = false;
  list: boolean = true;
  listSample: any;
  listId: any;
  searchText: string;
  postedDate: string;
  subject: any;
  markView: any;
  showModal: boolean =  false;
  category: any;
  service: any;
  question: any;
  id: any;

  constructor(context: ContextContainer) {
    super(context);
    this.config = {
      itemsPerPage: 10,
      currentPage: this.pagination.page,
      totalItems : 0
   };
  }

  ngOnInit(): void {
    this.getQuestionList();
    this.getdropdown();
    this.getFaq();
    this.initBadgeStyle();
  }
  ngAfterViewInit() {
    this.context.datatableService.init(this.dtElement);
  }
  onSelect(): void {
    this.list = false;
  }
  initBadgeStyle() {

    this.badgeStyle[Status.Draft] = 'badge badge-info';
    this.badgeStyle[Status.Pending] = 'badge badge-warning';
    this.badgeStyle[Status.Approved] = 'badge badge-success';
    this.badgeStyle[Status.Rejected] = 'badge badge-danger';
  }

  listClick(a,id){
    
this.list =  false;
this.subject = a.subject;
this.postedDate = moment(a.postedDate).format("ll");
let params = new HttpParams();
params = params.append('Id', id.toString());
this.context.httpService.get(environment.counsellingUrl + '/Counselling/QandAbyId',{params:params}).
  subscribe(
  (response) => {
    this.listId = response.data;
    this.listId.forEach(element => {
      if(element.postedDate){
        element.date = moment(a.postedDate).format("ll");
      }
    });
  });
}

markClick(a){
  this.showModal = true;
this.category = a.categoryEn;
this.service = a.servicesEn;
this.question= a.question;
this.answer =  a.answer;
this.id = a.id;
}

  fileChange(e){
    
 this.uploadFile = e.target.files;
  }

      getMarkedList(){
        let params = new HttpParams();
        params = params.append('counsellorId', this.context.getUserId().toString());
        params = params.append('page', this.serverPage.toString());
        params = params.append('pagesize', this.pagination.pageSize.toString());
        params = params.append('pinned', 'true');
        this.showCardProgress("grid-card");
        this.context.httpService.get(environment.counsellingUrl + '/Counselling/Inbox-pinned', { params: params }).
          subscribe(
          (response) => {
            if(response.data.items){
              this.hideCardProgress("grid-card");
              if(this.config.currentPage == 1){
            this.pinnedList = [];
            this.pinnedList = response.data.items;
              }
              else{
                var items =[];
                items = response.data.items;
                items.forEach((ele)=>{
                  if(ele.status == true && ele.pinned == true){
                  this.pinnedList.push(ele);
                  }
                })


              }
            }
          });
      }
      textWrap(word: string) {
        if (word)
          return word.length > 30 ? word.substring(0, 30) + "..." : word;
        else return "";
      }
  search(activeTab){
    this.visibleRecent = false;
    this.visibleAnswer = false;
    this.activeTab = activeTab;
    this.list = true;
    this.config = {
      itemsPerPage: 10,
      currentPage: this.pagination.page,
      totalItems : 0
   };
   this.getQuestionList();
  }
  back(){

    this.getQuestionList();
    this.list = true;
  }
  hide()
  {
    this.showModal = false;
  }
  markPin(id){
    
    this.listId.forEach(element => {
      if(element.id == id){
       element.pinned = true
      }
    });
    var pin =[];
    pin.push({id:id,pinned:true});
    var msg="Are you sure to mark question?"
    this.context.notificationService.confirmAlert((confirm) => {
      if (!confirm.dismiss) {
    this.context.httpService.put(environment.counsellingUrl + this.markUrl, pin).subscribe(
      (response) => {
        if (response.error != true) {
          this.notifySuccess("Question Marked successfully");
          this.getMarkedList();
        }
});
}},msg);
  }
  expand(){
    this.active = true;
  }
  download(item,name){
    
    //let document = this.createFile(item, name);
    //let file = new Blob([document], { type: document.type });
   // saveAs(item, name);
   this.context.fileUtility.download(item,name);
  }
  unmarkpinML(id){
    var pin =[];
    pin.push({id:id,pinned:false});
    this.showModal =  false;
    var msg="Are you sure to unmark question?"
    this.context.notificationService.confirmAlert((confirm) => {
      if (!confirm.dismiss) {
    this.context.httpService.put(environment.counsellingUrl + this.markUrl, pin).subscribe(
      (response) => {
        if (response.error != true) {
          this.notifySuccess("Question UnMarked successfully");
          this.getMarkedList();
        }
});
}},msg);
  }

  getQuestionList(){
  
  this.visibleRecentview = true;
  this.visibleAnswerview = true;
  this.visibleRecent = true;
  this.visibleAnswer = false;
  this.qaList = [];
  this.showCardProgress('grid-card');
  let params = new HttpParams();
    params = params.append('counsellorId', this.context.getUserId().toString());

    params = params.append('page', this.serverPage.toString());
    params = params.append('pagesize', this.pagination.pageSize.toString());
    this.context.httpService.get(environment.counsellingUrl + this.filterURL, { params: params }).
      subscribe(
      (response) => {
        if(response.data.items){
          this.hideCardProgress("grid-card");
          if(this.config.currentPage == 1){
        var list = response.data.items;
        this.qaList =[];
        list.forEach(element => {

          this.qaList.push(element);

        });
          }
          else{
            var items =[];
            items = response.data.items;
            items.forEach((ele)=>{
              this.qaList.push(ele);
            })
          }
        }
      });

}
onPageChangeRecent(e){
  
    this.config.currentPage = e;
    this.pagination.page = e;
    //this.getQuestionList(this.active);
    if(this.pagination.page == this.clickCount){
      this.serverPage = this.pagination.page + 1;
    this.getQuestionList();
    this.clickCount = this.clickCount + 5;
    }
}
onPageChangeAnswer(e){
  
    this.config.currentPage = e;
    this.pagination.page = e;
    //this.getQuestionList(this.active);
    if(this.pagination.page == this.clickCount){
      this.serverPage = this.pagination.page + 1;
    this.getMarkedList();
    this.clickCount = this.clickCount + 5;
    }
}
delete(id){
  var msg = 'Are you sure to delete?';
  this.context.notificationService.confirmAlert((confirm) => {
    if (!confirm.dismiss) {
  this.context.httpService.put(environment.counsellingUrl + '/Counselling/inactive-FAQ/'+id).subscribe(
    (response) => {
  var successmsg = "Deleted successfully";
      if (response.error != true) {
        this.notifySuccess(successmsg);
        this.getFaq();
        this.isFormVisible = false;
      }
    });
  }}, msg)
}
  result(activeTab){
    this.activeTab = activeTab;
    this.pinnedList =[];
    this.getMarkedList();
    this.config = {
      itemsPerPage: 10,
      currentPage: this.pagination.page,
      totalItems : 0
   };
  }
  results(e){
    this.activeTab = e;
  }
  send(e){
    
      if (this.answerQues == undefined ) {
        this.notifyError("Please send the response")
        return
      }
    
    e.status = 8;
    var data = this.uploadFile;
    var date =new Date();
    const formData = new FormData();
    var i = 0;
    if(data){
      formData.append('files[' + i + ']', data[i]);

  }
    formData.append('qandAdetail.id', e.id);
    formData.append('qandAdetail.studentId', e.studentId.toString());
    formData.append('qandAdetail.counsellorId', e.counsellorId.toString());
    formData.append('qandAdetail.status', e.status.toString());
    formData.append('qandAdetail.pinned', e.pinned.toString());
    formData.append('qandAdetail.replayDate', moment(date).format());
    formData.append('qandAdetail.answer', this.answerQues);
    formData.append('qandAdetail.updatedBy', e.counsellorId.toString());
    formData.append('qandAdetail.qandAListId', e.qandAListId);


    this.context.httpService.post(environment.counsellingUrl + this.askUrl, formData).subscribe(
      (response) => {
    var successmsg = "Response send successfully";
        if (response.error != true) {
          this.notifySuccess(successmsg);
          this.documentControl.clear();
          this.listClick(e,e.qandAListId);
        }
        });
  }

  getdropdown(){
    this.context.httpService.get(environment.counsellingUrl + this.dropURL).
      subscribe(
      (response) => {
        if(response.data.categoryMaster){
        this.categoryList = response.data.categoryMaster;
        }
      });
  }
  getFaq(){
    
    let params = new HttpParams();
        params = params.append('counsellorId', this.context.getUserId().toString());
    this.context.httpService.get(environment.counsellingUrl + this.faqUrl,{params:params}).
    subscribe(
    (response) => {
      if(response.data){
      this.faqList = response.data;
      this.context.datatableService.reRender('datatable');

      }

    });
  }
  bindQues(item){
    this.postFaq.CategoryId=item.categoryId;
    this.postFaq.QuestionEn = item.questionEn;
    this.postFaq.QuestionAr = item.questionAr;
    this.postFaq.AnswerEn = item.answerEn;
    this.postFaq.AnswerAr = item.answerAr;
  }
  cancel(f:NgForm){
    this.postFaq = {
      Id: 0,
      CounsellorId: 0,
      QuestionEn:'',
      AnswerEn:'',
      QuestionAr:'',
      AnswerAr:'',
      CategoryId:null,
      RejectReason:'',
      PostedDate:'',
      StatusId: 0,
      CreatedDate:'',
      UpdatedDate:'',
      CreatedBy: '',
      UpdatedBy: '',
      IsActive:true
    }
    f.resetForm();
    this.fieldsetDisabled = false;
  }
  public hideForm() {
    this.isFormVisible = false;
  }
  public showForm(form: NgForm) {
    this.fieldsetDisabled = false;
    this.cancel(form);
    this.isFormVisible = true;
  }
  editRow(e){
this.isFormVisible = true;
this.fieldsetDisabled =false;
this.postFaq.Id = e.id;
this.postFaq.CounsellorId = e.counsellorId;
this.postFaq.CategoryId = e.categoryId;
this.postFaq.QuestionEn = e.questionEn;
this.postFaq.AnswerEn = e.answerEn;
this.postFaq.QuestionAr = e.questionAr;
this.postFaq.AnswerAr = e.answerAr;
if(e.statusId == 3){
  this.fieldsetDisabled =true;
}
  }
  deleteRow(e){

  }

  post(f:NgForm){
    if (f.invalid){
      return;
     }
    var date =new Date();
    this.postFaq.StatusId = 2;
    this.postFaq.IsActive = true
    const formData = new FormData();
    formData.append('faqDetail.id', this.postFaq.Id.toString());
    formData.append('faqDetail.counsellorId', this.context.getUserId().toString());
    formData.append('faqDetail.categoryId', this.postFaq.CategoryId.toString());
    formData.append('faqDetail.questionEn', this.postFaq.QuestionEn.toString());
    formData.append('faqDetail.questionAr', this.postFaq.QuestionAr.toString());
    formData.append('faqDetail.answerEn', this.postFaq.AnswerEn.toString());
    formData.append('faqDetail.answerAr', this.postFaq.AnswerAr.toString());
    //formData.append('qandAdetail.createdDate', moment(date).format());
    formData.append('faqDetail.postedDate', moment(date).format());
    //formData.append('qandAdetail.updatedDate', moment(date).format());
    formData.append('faqDetail.createdBy', this.context.getUserId().toString());
    formData.append('faqDetail.updatedBy', this.context.getUserId().toString());
    formData.append('faqDetail.statusId', this.postFaq.StatusId.toString());
    formData.append('faqDetail.isActive', this.postFaq.IsActive.toString());
    this.context.httpService.post(environment.counsellingUrl + this.postfaqUrl, formData).subscribe(
      (response) => {
        if(this.postFaq.Id == 0){
    var successmsg = "FAQ posted successfully";
        }
        else{
          var successmsg = "FAQ updated successfully";
        }
        if (response.error != true) {
          this.notifySuccess(successmsg);
          this.cancel(f);
          this.getFaq();
          this.isFormVisible = false;
        }
      });
  }
}

export class PageResult<T>{
  Count: number;
  PageIndex: number;
  PageSize: number;
  Items: T[];
}
export class Pagination{
  page: number;
  count: number;
  pageSize: number;
  pageSizes: number[];
  constructor(page?: number, count?: number, pageSize?: number, pageSizes?: number[]){
this.page= page;
this.count =count;
this.pageSize =pageSize;
this.pageSizes =pageSizes;
  }
}
export class BadgeStyle {
  Pending: string;
  Approved: string;
  Rejected: string;
  OnHold: string;
}

