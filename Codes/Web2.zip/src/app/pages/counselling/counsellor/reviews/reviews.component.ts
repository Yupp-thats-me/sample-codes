import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { environment } from 'environments/environment';
import { rating } from '@app/services/enumfiles';
import { HttpParams } from '@angular/common/http';

@Component({
  selector: 'app-reviews',
  templateUrl: './reviews.component.html',
  styleUrls: ['./reviews.component.scss']
})
export class ReviewsComponent extends BaseComponent implements OnInit {
  public enumrating = rating
config:any;
  allreviews = [];
  counsellorid: string;
  userId: any;
  pagination: Pagination = new Pagination(1, 0, 9, [9, 18, 27, 36]);
  serverPage: number = 1;
  clickCount: number = 5

  constructor(context: ContextContainer,
    private route: ActivatedRoute) {
    super(context)
    this.config = {
      itemsPerPage: 9,
      currentPage: this.pagination.page,
      totalItems: 0
    };
     }

  ngOnInit(): void {
    this.counsellorid = this.route.snapshot.paramMap.get('id');
    this.getallreviews();
  }

  getallreviews(){
    let params = new HttpParams();
    params = params.append('page', this.serverPage.toString());
    params = params.append('pagesize', this.pagination.pageSize.toString());
    params = params.append('counsellorId', this.context.getUserId().toString());
    this.context.httpService.get(environment.counsellingUrl + '/Counselling/Reviews/',{ params: params }).subscribe(
      (results)=>{
        if(results.success == true){
          if (results.data.items) {
            if (this.config.currentPage == 1) {
              this.allreviews = results.data.items;
              //this.config.totalItems = response.count;
            }
            else {
              var items = [];
              items = results.data.items;
              items.forEach((ele) => {
                this.allreviews.push(ele);
              })
            }
            // this.visible = true;
          }
        }else{

        }
    })
  }
  onPageChange(e){
    this.config.currentPage = e;
    this.pagination.page = e;
    //this.getQuestionList(this.active);
    if (this.pagination.page == this.clickCount) {
      this.serverPage = this.pagination.page + 1;
      this.getallreviews();
      this.clickCount = this.clickCount + 5;
    }
  }

  SortByRate(event){
    let value = event.target.value;
    if(value == 'lowrating'){
      this.allreviews = this.allreviews.sort((a, b) => (a.rateGiven < b.rateGiven ? -1 : 1));

    }
    else if(value == 'highrating'){
      this.allreviews = this.allreviews.sort((a, b) => (a.rateGiven < b.rateGiven ? 1 : -1));

    }else{
      this.allreviews = this.allreviews;
    }
  }
}
  export class Pagination {
    page: number;
    count: number;
    pageSize: number;
    pageSizes: number[];
    constructor(page?: number, count?: number, pageSize?: number, pageSizes?: number[]) {
      this.page = page;
      this.count = count;
      this.pageSize = pageSize;
      this.pageSizes = pageSizes;
    }
  }

