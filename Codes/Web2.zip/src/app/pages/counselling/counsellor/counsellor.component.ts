import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-counsellor',
  templateUrl: './counsellor.component.html'
})
export class CounsellorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
