import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Authorize } from '@app/app-core/identity/auth.guard';
import { Role } from '@app/models/role.enum';
import { AppointmentsComponent } from './appointments/appointments.component';
import { CalenderComponent } from './calender/calender.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { InboxComponent } from './inbox/inbox.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { ReviewsComponent } from './reviews/reviews.component';
import { TimeslotComponent } from './timeslot/timeslot.component';
import { ViewAppointmentsComponent } from './view-appointments/view-appointments.component';
const routes: Routes = [
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [Authorize],
    data: { roles: [Role.Counsellor]}
  },
  {
    path: 'inbox',
    component: InboxComponent,
    canActivate: [Authorize],
    data: { roles: [Role.Counsellor]}
  },
  {
    path: 'timeslot',
    component: TimeslotComponent,
    canActivate: [Authorize],
    data: { roles: [Role.Counsellor]}
  },
  {
    path: 'calendar',
    component: CalenderComponent,
    canActivate: [Authorize],
    data: { roles: [Role.Counsellor]}
  },
  {
    path: 'appointments/:id',
    component: AppointmentsComponent,
    canActivate: [Authorize],
    data: { roles: [Role.Counsellor]}
  },
  {
    path: 'my-profile',
    component: MyProfileComponent,
    canActivate: [Authorize],
    data: { roles: [Role.Counsellor]}
  },
  {
    path: 'view-appointment',
    component: ViewAppointmentsComponent,
    canActivate: [Authorize],
    data: { roles: [Role.Counsellor]}
  },
  {
    path: 'reviews',
    component: ReviewsComponent,
    canActivate: [Authorize],
    data: { roles: [Role.Counsellor]}
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CounsellorRoutingModule { }
