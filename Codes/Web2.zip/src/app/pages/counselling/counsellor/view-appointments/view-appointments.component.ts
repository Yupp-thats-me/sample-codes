import { HttpParams } from '@angular/common/http';
import { Renderer2, Component, ElementRef, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { DataTableDirective } from 'angular-datatables';
import { environment } from 'environments/environment';
import { appointmentstatus } from '@app/models/status';
import { StudentSessionReportComponent } from '../../shared/student-session-report/student-session-report.component';
import { CounsellingService } from '@services/counselling.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-view-appointments',
  templateUrl: './view-appointments.component.html',
  styleUrls: ['./view-appointments.component.scss']
})
export class ViewAppointmentsComponent extends BaseComponent implements OnInit {

  @ViewChildren(DataTableDirective) dtElements: QueryList<DataTableDirective>;
  @ViewChild('scrollBottom') private scrollBottom: ElementRef;

  counsellorId: any;
  upcomingAppointments: any;
  Appointments: any;
  badgeStyle: { [id: string]: string; } = {};
   Status= appointmentstatus;
  Session: boolean = false;
  sessions: any;
  dialog: any;
  userId: any;
  constructor(
    context: ContextContainer,
    private route: ActivatedRoute,
    private router: Router,
    private counsellingService: CounsellingService,
    private modalservice:NgbModal
  ) {
    super(context);
    this.setDTTriggers(['newappointment', 'allappointment']);
  }

  ngOnInit(): void {
    //this.counsellorId = this.route.snapshot.paramMap.get('id');
    this.getvirtualappointment();
    this.initBadgeStyle();

  }

  getvirtualappointment() {
    let params = new HttpParams().set("counsellorId", this.context.getUserId().toString())
    this.context.httpService.get(environment.counsellingUrl + '/Counselling/VirtualAppointment', { params: params }).subscribe
      ((results) => {
        if (results.success == true) {
          this.upcomingAppointments = results.data.filter(x => x.statusId == 2);
          this.context.datatableService.reRender('newappointment');
          this.Appointments = results.data;
          this.context.datatableService.reRender('allappointment');
        }
      })
  }
  initBadgeStyle() {
    this.badgeStyle[appointmentstatus.Waiting] = 'badge badge-warning';
    this.badgeStyle[appointmentstatus.ScheduleConfirmed] = 'badge badge-success';
    this.badgeStyle[appointmentstatus.Declined] = 'badge badge-danger';
    this.badgeStyle[appointmentstatus.Completed] = 'badge badge-info';
  }
  ngAfterViewInit() {
    this.context.datatableService.init(this.dtElements);
  }
  viewHistory(appointment) {
debugger

    this.counsellingService.viewHistory(appointment);
    this.dialog = this.modalservice.open(StudentSessionReportComponent,  { ariaLabelledBy: 'modal-basic-title', size: 'xl' });
    (<StudentSessionReportComponent>this.dialog.componentInstance).data = 'hi';
    this.dialog.result.then((result) => {
      if (result) {

        //this.ngOnInit();

      }
    }, (reason) => {;
    });
  }
  editRow(appointment) {
    this.router.navigate(['/counselling/counsellors/appointments/' + appointment.id]);
  }
}
export class BadgeStyle {
  Waiting:string;
  ScheduleConfirmed:string;
  Declined:string;
  Completed: string;
}
