import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CounsellingRoutingModule } from './counselling-routing.module';
import { CounsellingComponent } from './counselling.component';
import {  StudentModule } from './student/student.module';
import { NgxPaginationModule } from 'ngx-pagination';
import { SharedModule } from '@app/shared/shared.module';
import { baseModule } from '@app/app-core/Common Modules/baseModule';
import { NgbAccordionModule, NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { CarouselModule } from 'ngx-bootstrap/carousel';
import { AutocompleteLibModule } from 'angular-ng-autocomplete';
import { SnotifyModule } from 'ng-snotify';
import { DataTablesModule } from 'angular-datatables';
import { InputTrimModule } from 'ng2-trim-directive';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { HttpClient } from '@angular/common/http';
import { NgxSummernoteModule } from 'ngx-summernote';
import { FileUploadModule } from '@iplab/ngx-file-upload';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { CounsellorModule } from './counsellor/counsellor.module';
import { LandingPageComponent } from './student/landing-page/landing-page.component';
import { ListComponent } from './student/list/list.component';
import { ViewComponent } from './student/view/view.component';
import { FaqListComponent } from './student/faq-list/faq-list.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { TreeviewModule } from 'ngx-treeview';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HomePageModule } from '../home-page/home-page.module';
import { CounsellorComponent } from './counsellor/counsellor.component';
// import { StudentSessionReportComponent } from './shared/student-session-report/student-session-report.component';

@NgModule({
  declarations: [CounsellingComponent,LandingPageComponent,ListComponent,ViewComponent,FaqListComponent,CounsellorComponent],
  imports: [
    NgxPaginationModule,
    CommonModule,
    CounsellingRoutingModule,
    SharedModule,
    baseModule,
    StudentModule,
    CounsellorModule,
    NgbAccordionModule,
    NgMultiSelectDropDownModule,
    ReactiveFormsModule,
    FormsModule,
    Ng2SearchPipeModule,
    CarouselModule.forRoot(),
    DataTablesModule,
    SnotifyModule,
    AutocompleteLibModule,
    TreeviewModule,
    FileUploadModule,
    InputTrimModule,
    HomePageModule,
    NgxSummernoteModule,
    NgbTooltipModule,
    BsDatepickerModule.forRoot(),
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: httpTranslateLoader,
        deps: [HttpClient]
      }
    }),
  ],
  exports:[]
})
export class CounsellingModule { }

export function httpTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http);
}
