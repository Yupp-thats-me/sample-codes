import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { formatDate } from '@angular/common';

import { Calendar, CalendarOptions, FullCalendarComponent } from '@fullcalendar/angular';
import { ContextContainer } from '@app/app-core/context-container';
import { BaseComponent } from '@app/app-core/base.component';
import { ThisReceiver } from '@angular/compiler';
import { EventModel } from '../../models/eventModel';


@Component({
  selector: 'app-event',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.scss'],

})
export class EventComponent extends BaseComponent {

  cxoId: any;
  calendarView: boolean = true;
  dateObj = new Date();
  events: any[] = [];
  yearMonth = this.dateObj.getUTCFullYear() + '-' + (this.dateObj.getUTCMonth() + 1);

  url: string;

  selectedEvent: EventModel={};

  calendarOptions: CalendarOptions = {};

  constructor(context: ContextContainer, private route: ActivatedRoute) {
    super(context);

    this.url = '/Event';

    
  }

  initCalendarOptions() {

    let t = this;

    this.calendarOptions = {
      initialView: 'dayGridMonth',
      themeSystem: 'bootstrap',
      height: 'auto',
      dateClick: function (arg) {
      },
      eventClick: function (model: any) {

        t.showEvent(model.event.id);
      },
      events: []
    };
  }



  ngOnInit(): void {

    this.route.params.subscribe(param => {
      this.cxoId = param['id'];
    });

    this.loadEvents();

    this.initCalendarOptions();
  }

  loadEvents() {


    this.context.httpService.get(this.environment.cxoUrl +'/Event?cxoId=' + this.cxoId).subscribe(

      (response) => {

        if (response.success) {
          this.calendarOptions.events = this.buildEvents(response.data || []);
        }
      }
    );
  }

  private loadEvent(id: number) {

    this.context.httpService.get(this.cxoId + this.url + '/Event?id=' + id).subscribe(

      (response) => {

        if (response.success) {
          this.showEvent(response.data || {});
        }
      }
    );
  }

  private showCalendar() {

    this.calendarView = true;

  }

  private hideCalendar() {

    this.calendarView = false;
  }

  showEvent(id: number) {

    this.context.httpService.get(this.environment.cxoUrl + this.url + '/Event?id=' + id).subscribe(

      (response) => {

        if (response.success) {

          let event = response.data;
          this.selectedEvent = new EventModel();

          this.selectedEvent.imageFile = event.imageFile;
          this.selectedEvent.eventTitle = event.title;
          this.selectedEvent.eventDate = event.eventDate;
          this.selectedEvent.eventurl = event.url;
          this.selectedEvent.description = event.description;
          this.selectedEvent.venue = event.venue;
        }
      }
    );

    // this.model = {
    //   event: {
    //     id: data.event.id,
    //     start: data.event.start,
    //     end: data.event.end,
    //     title: data.event.title,
    //     allDay: data.event.allDay
    //     // other params
    //   },
    //   duration: {}
    // }
  }

  private buildEvents(events: any[]) {
    return events.map(a => {
      return {

        title: a.title,
        start: formatDate(a.eventDate, 'yyyy-MM-dd', 'en-US'),
        end: formatDate(a.expiryDate, 'yyyy-MM-dd', 'en-US'),
        id: a.id
      };
    });
  }
}
