import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { PublicationModel } from '@app/pages/sj-admin/cxo/publication/publication.component';
import { LangService } from '@app/services/lang.service';
import { LangChangeEvent } from '@ngx-translate/core';
import { DatepickerDateCustomClasses } from 'ngx-bootstrap/datepicker';
import { ProfileModel } from '../models/profileModel';
import { PublicationType } from '../models/publication-type';

@Component({
  selector: 'app-viewprofile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent extends BaseComponent {

  @ViewChild('video') myVideo: ElementRef;

  privateCXOData: any = [];
  publicCXOData: any = [];
  isplay=false;
  public activeTabMedia: string;
  activeTab1: string = 'list';

  private route: ActivatedRoute

  private readonly privateCXOTypeId: number = 1;
  private readonly publicCXOTypeId: number = 2;

  model: ProfileModel = {};

  cxoId: any;

  profile: any = {};

  eventData: any[] = [];

  publicationData: any[] = [];

  publicationVideo: any;

  publicationModel: PublicationModel = {};

  linkData: boolean = true;

  seminarData: any[] = [];
  leadershipData: any[] = [];
  workshopData: any[] = [];
  summitData: any[] = [];
  slang: string = 'en'
  dataSet = [];
  datesDisabled: Date[];
  currentDate: any;
  targetDate: any;
  cDateMillisecs: any;
  tDateMillisecs: any;
  difference: any;
  seconds: any;
  minutes: any;
  hours: any;
  days: any;
  year: number = 2021;
  month: number = 11;
  months = ['Jan', 'Feb', 'Mar', 'April', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
  day: number = 31;
  edate: boolean;
  dateCustomClasses: DatepickerDateCustomClasses[];
  currentEventsArr: any = [];



  constructor(context: ContextContainer, route: ActivatedRoute,  private router: Router, private langService: LangService) {
    super(context)
    this.route = route;
  }

  ngOnInit(): void {

    this.slang = this.langService.currentlang(); 
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {     
       if (this.slang != event.lang) {
         this.slang = event.lang;
       }
     });
 
    this.route.params.subscribe(param => {
      this.cxoId = param['id'];
    });

    this.loadprofile();
    this.loadEvents();
    this.loadPublications();
    this.activeTabMedia = 'Videos';
  }
  textWrap(word: string) {
    if (word != null || '') {
      return word.length > 80 ? word.substring(0, 80) + "..." : word;
    }
  }

  
  playVideo(){
    if(this.isplay){
        this.myVideo.nativeElement.pause();
    }
    else{
        this.myVideo.nativeElement.play();
    }  
    this.isplay=!this.isplay
  }

  search1(activeTab: string) {
    this.activeTabMedia = activeTab;
    if (this.activeTabMedia == 'Videos') {
      this.loadprofile();
    } else if (this.activeTabMedia == 'Events') {
      this.search('list');
    } else if (this.activeTabMedia == 'Publications') {
      this.loadPublications();
    }
    else if (this.activeTabMedia == 'Seminars/Lectures') {
      this.loadPublications();
    }

  }
  search(activeTab1) {
    this.activeTabMedia = 'Events'
    this.activeTab1 = activeTab1
    if (activeTab1 === 'list') {
      this.loadEvents();
    }
  }

  protected loadprofile() {
    this.context.httpService.get(this.environment.cxoUrl + '/profile/' + this.cxoId).subscribe(
      (response) => {
        if (response.success) {
          this.bindProfile(response.data || []);
        }
        else {
          this.notifyError('Failed to get profile data')
        }
      }
    );
  }

  demo:any
  test:any
  protected loadEvents() {
    this.context.httpService.get(this.environment.cxoUrl + '/Event?cxoId=' + this.cxoId).subscribe(
      (response) => {
        if (response.success) {
          this.eventData = (response.data || []);
          this.demo = this.eventData[0];
          if(this.demo){
            this.test = true
          }
          localStorage.setItem('expiryDate1', this.eventData[0].expiryDate);
          // localStorage.setItem('expiryDate2', this.eventData[1].expiryDate);
          this.edate = true;    
           this.myTimer();

          }
             else {
              this.notifyError('Failed to get Event data')
            }
      });
  }

  // Event Date Time 
  myTimer() {
    if (this.eventData[0] || []) {
      this.currentDate = new Date();
      this.targetDate = new Date(localStorage.getItem('expiryDate'));
      this.cDateMillisecs = this.currentDate.getTime();
      this.tDateMillisecs = this.targetDate.getTime();
      this.difference = this.tDateMillisecs - this.cDateMillisecs;
      this.seconds = Math.floor(this.difference / 1000);
      this.minutes = Math.floor(this.seconds / 60);
      this.hours = Math.floor(this.minutes / 60);
      this.days = Math.floor(this.hours / 24);
      this.hours %= 24;
      this.minutes %= 60;
      this.seconds %= 60;
      this.hours = this.hours < 10 ? "0" + this.hours : this.hours;
      this.minutes = this.minutes < 10 ? "0" + this.minutes : this.minutes;
      this.seconds = this.seconds < 10 ? "0" + this.seconds : this.seconds;
      let url = window.location.pathname;
      if (url == "/cxouser/profile/198") {
        document.getElementById("days").innerText = this.days;
        document.getElementById("hours").innerHTML = this.hours;
        document.getElementById("mins").innerHTML = this.minutes;
        document.getElementById("seconds").innerHTML = this.seconds;
      }
    }
    setInterval(this.myTimer, 10);
  }

  loadPublications() {  
    this.context.httpService.get(this.environment.cxoUrl + '/Publication/cxo-publications/' + this.cxoId).subscribe(
      (response) => {
        if (response.success) {
          this.publicationData = (response.data.data || []);
            this.bindPublication(this.publicationData);
        }
        else {
          this.notifyError('failed to load publication data');
        }
      })
  }

  bindPublication(publicationData: any[]) {

    publicationData = publicationData || [];
    this.seminarData = publicationData.filter(a => a.publicationTypeId == PublicationType.Seminar);
    this.leadershipData = publicationData.filter(a => a.publicationTypeId == PublicationType.Leadership);
    this.workshopData = publicationData.filter(a => a.publicationTypeId == PublicationType.Workshop);
    this.summitData = publicationData.filter(a => a.publicationTypeId == PublicationType.Summit);

  }

  private bindProfile(data) {
    this.profile = data.profile;
    this.profile.designation = (data.elements || []).find(a => a.elementId == this.profile.designationId).elementValue;
    this.profile.company = (data.elements || []).find(a => a.elementId == this.profile.companyId).elementValue;
  }

}
