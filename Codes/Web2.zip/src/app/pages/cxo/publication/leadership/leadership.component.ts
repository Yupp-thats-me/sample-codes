import { Component, OnInit } from '@angular/core';
import { ContextContainer } from '@app/app-core/context-container';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { PublicationType } from '../../models/publication-type';
import { PublicationComponent } from '../publication.component';

@Component({
  selector: 'app-leadership',
  templateUrl: '../../publication/publication.component.html',
  styleUrls: ['./leadership.component.scss']
})
export class LeadershipComponent  extends PublicationComponent {

  constructor(context:ContextContainer,  modalService: NgbModal) { super(context, PublicationType.Leadership, modalService);
  
  }


}
