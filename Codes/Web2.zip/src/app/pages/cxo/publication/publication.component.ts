import { AfterViewInit, Component, ViewEncapsulation } from '@angular/core';
import { BaseComponent } from '@app/app-core/base.component';
import { FeedbackConfiguration } from '@app/app-core/components/feedback-form/feedback-form.component';
import { ContextContainer } from '@app/app-core/context-container';
import { PublicationModel } from '@app/pages/sj-admin/cxo/publication/publication.component';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { PublicationType } from '../models/publication-type';
import * as moment from 'moment';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Feedback } from '../../../models/feedback.model';
import { NgForm } from '@angular/forms';
import { LangChangeEvent } from '@ngx-translate/core';
import { LangService } from '../../../services/lang.service';
import { TreeviewConfig, TreeviewI18n, TreeviewItem } from 'ngx-treeview';
import { DropdownTreeviewI18n } from '@app/app-core/i18/dropdown-treeview-i18';



@Component({
  selector: 'app-publication',
  templateUrl: './publication.component.html',
  styleUrls: ['./publication.component.scss'],
  providers: [{ provide: TreeviewI18n, useClass: DropdownTreeviewI18n }]
})
export class PublicationComponent extends BaseComponent implements AfterViewInit {

  publicationTypeId: PublicationType;
  filter: ModelFilter;
  pdfFile: string;
  isDocument: boolean;
  pdfSrc: any;
  data: any = [];
  result: any[] = [];
  industryList: any[] = [];
  isEventVisible: boolean = false;
  isHideReceipt: boolean = false;
  model: PublicationModel = {};
  feedbackControl: FeedbackConfiguration = new FeedbackConfiguration();
  private url: string = '/Publication';
  saveFeedback = '/Publication/SaveFeedback/'
  bsConfig: Partial<BsDatepickerConfig>;
  slang: string = 'en';
  searchValue = "";
  industryListData: any = [];
  feedbackModel: Feedback = {
    Id: 0,
    PublicationtypeID: 0,
    UserId: 0,
    Content: 0,
    Design: 0,
    Functionality: 0,
    Personalization: 0,
    CreatedBy: ""
  }
  userid: any;
  hidefeedback: boolean = false;
  treeviewConfig = TreeviewConfig.create({
    hasAllCheckBox: true,
    hasFilter: true,
    hasCollapseExpand: true,
    decoupleChildFromParent: false,
    maxHeight: 400
  });

  startdDateFiter:any;
  endDateFiter:any;

  searchBox: string = "";

  constructor(public context: ContextContainer, publicationType: PublicationType, private modalService: NgbModal) {
    super(context);
    this.modalService = modalService;
    this.publicationTypeId = publicationType;
    this.filter = new ModelFilter([]);

  }

  ngOnInit(): void {

    let lan = this.context.translateService.currentLang;
    if (lan == 'ar') {
      this.slang = 'ar';
    }

    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang;
      this.bindIndustryList();
    });

    this.loadData();
    this.feedbackControl.noBTNValue = 'No';
    this.feedbackControl.yesBTNValue = 'Yes';
    this.getuserId();
  }

  getuserId() {
    this.userid = this.context.getUserId();
  }
  // data will be populated to view once this component is initialized by child component.
  // this.onView();
  ngAfterViewInit() {

  }
  openmodel(content) {
    this.modalService.open(content, { centered: true });
  }
  showEvent() {
    this.isEventVisible = true;
  }

  hideEvent() {
    this.isEventVisible = false;
  }


  private loadData() {


    this.showCardProgress('view-card');

    this.context.httpService.get(this.environment.cxoUrl + this.url + '/user-publications/' + this.publicationTypeId).subscribe(

      (response) => {

        this.hideCardProgress('view-card');

        if (response.success) {
          this.data = response.data || [];
          this.filter.data = response.data.data || [];
          this.filter.filteredData = response.data.data || [];
          this.filter.industryList = response.data.industryList || [];
          this.industryListData = response.data.industryList || [];
          this.pdfSrc = (response.data.data || []).filter(a => a.documentFiles);

          this.industryListData.map((x: any) => {
            {
              const data = {
                elementId: x.elementId,
                elementValue: x.elementValue,
                elementValueAr: x.elementValueAr,
                category: x.category,
                isActive: true,
              };
            }
          })

          this.bindIndustryList();

        }
        else {
          this.notifyError('Failed to get data')
        }
      },
      (err) => {
      }
    );
  }

  titletextWrap(word: string) {
    if (word != null || '') {
      return word.length > 75 ? word.substring(0, 75) + "..." : word;
    }
  }

  download(document: any, documentName: string) {
    let a = Object.keys(PublicationType);
    let docTitle = this.publicationTypeId as PublicationType;
    if (document != null) {
      const blob = document;
      //saveAs(blob, documentName);
      this.context.fileUtility.download(document, documentName);
    }
    else {
      this.notifyError('Document is not available');
    }
  }

  toggle() {
    this.isHideReceipt = !this.isHideReceipt;
    if (this.pdfFile == null) {
      this.isDocument = false;
    } else {
      this.isDocument = true;
    }
  }

  bindData(result) {
    this.model.titleEn = result.titleEn;
    this.model.abstractEn = result.abstractEn;
    this.model.imageFiles = result.imageFiles;
    this.model.publicationVideoList = (result.publicationVideoList || []);
    this.model.documentFiles = result.documentFiles;
    this.pdfFile = result.documentFiles;
    this.model.documentName = result.documentName;
    this.model.postedDate = result.postedDate;
    this.model.authorEn = result.authorEn
    this.model.expiryDate = result.expiryDate;

  }
  onSubmit(form: NgForm): boolean {
    this.feedbackModel.PublicationtypeID = this.publicationTypeId;
    this.feedbackModel.UserId = this.userid;

    if (form.status == 'INVALID') {
      // this.notifyError('Please enter all the mandatory fields');
      return false
    } else {
      this.context.httpService.post(this.environment.cxoUrl + this.saveFeedback, this.feedbackModel).subscribe(
        (results) => {
          if (results.success == true) {
            this.notifySuccess('Feedback saved successfully');
            this.hidefeedback = true;

          } else {
            this.notifyError('Failed to send feedback');
          }
        })
    }
    return true;
  }
  closefeedback() {
    this.hidefeedback = true;
  }

  public onView(id: number) {
    this.showCardProgress('view-card');
    this.context.httpService.get(this.environment.cxoUrl + this.url + "/" + id).subscribe(

      (response) => {
        this.hideCardProgress('view-card');
        if (response.success) {
          this.result = response.data || new PublicationModel();
          this.bindData(this.result);
        }
        else {
          this.notifyError('Failed to get data')
        }
      }
    );
  }

  bindIndustryList() {

    this.industryList = this.industryListData.map(value => {
      let text = this.slang == 'ar' ? value.elementValueAr : value.elementValue;
      return new TreeviewItem({ text: text, value: value.elementId, collapsed: true, checked: false });
    });

  }

  public reset(form:NgForm) {
    
    form.resetForm();
    this.bindIndustryList();
    this.filter.filteredData = this.filter.data;
    this.filter.authorValue = "";
    this.startdDateFiter = null;
    this.endDateFiter = null;

  }
}

export class ModelFilter {

  data: any[] = [];
  filteredData: any[] = [];
  industryList: any[] = [];
  industryData: any[] = [];

  startDate: Date;
  endDate: Date;
  authorValue: string;

  constructor(data: any) {

    this.data = data || [];
  }

  searchByAuthor(val: string) {

    this.authorValue = val || '';
    // this.filteredData = this.data.filter(a => a.authorEn.toLocaleLowerCase().startsWith(val) || a.authorEn.toLocaleLowerCase().includes(val));
    this.applyFilter();
  }


  updateIndustryFilter(data: any) {

    this.industryList = (data || []).map((data, i) => {
      return data.value;
    });
    this.applyFilter();
  }


  applyFilter() {
    let data = [];

    let startDate = null;
    let endDate = null;

    let authorValue = (this.authorValue || '').toLocaleLowerCase().trim();

    if (this.startDate && this.endDate) {
      startDate = moment(this.startDate).format('MM-DD-YYYY');
      endDate = moment(this.endDate).format('MM-DD-YYYY');

    }

    for (let item of this.data || []) {

      let postedDate = moment(item.postedDate).format('MM-DD-YYYY');

      if (
        (this.industryList.includes(item.industryId) || this.industryList.length == 0)
        && ((!authorValue) || item.authorEn.toLocaleLowerCase().startsWith(authorValue) || item.authorEn.toLocaleLowerCase().includes(authorValue))

        && (
          (!startDate && !endDate)
          || ((moment(postedDate).isSameOrAfter(moment(startDate)))
            && moment(postedDate).isSameOrBefore(moment(endDate)))
        )

      ) {
        data.push(item);
      }
    }
    this.filteredData = data;


  }

  filterDate() {

    this.applyFilter();
    // if (this.startDate && !this.endDate) {
    //   this.filteredData = this.data.filter(
    //     m => new Date(m.postedDate) >= new Date(this.startDate)
    //   );
    // } else if (this.startDate && this.endDate) {
    //   this.filteredData = this.data.filter(
    //     m => new Date(m.postedDate) >= new Date(this.startDate) && new Date(m.postedDate) <= new Date(this.endDate)
    //   );
    // }
  }

  updateStartDateFilter(value: any) {
    this.startDate = value;
    this.filterDate();
  }

  updateEndDateFilter(value: any) {
    this.endDate = value;
    this.filterDate();
  }
}
