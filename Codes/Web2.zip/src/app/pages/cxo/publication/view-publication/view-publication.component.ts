import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { PublicationModel } from '@app/pages/sj-admin/cxo/publication/publication.component';
import * as moment from 'moment';

@Component({
  selector: 'app-view-publication',
  templateUrl: './view-publication.component.html',
  styleUrls: ['./view-publication.component.scss']
})
export class ViewPublicationComponent extends BaseComponent {

  private url: string = '/Publication';
  cxoId:any;
  private route: ActivatedRoute;
  id:number;
  model: PublicationModel = {};


  constructor(context: ContextContainer,route: ActivatedRoute
  ) {
    super(context);
    
    this.route = route;

  }

  ngOnInit(): void {
    this.route.params.subscribe(param => {
      this.id = param['id'];
    });
    this.loadPublications();
  }



  loadPublications() {
    this.context.httpService.get(this.environment.cxoUrl + '/publication/'+this.id).subscribe(

      (response) => {
        if (response.success) {
          let data = response.data;
          this.bindEvent(data);
        }
        else{
          this.notifyError('Failed to get publication data')
        }
      }
    );
  }

  bindEvent(data){
    this.model.titleEn=data.titleEn;
    this.model.authorEn = data.authorEn;
    this.model.abstractEn = data.abstractEn;
    this.model.imageFiles=data.imageFiles;
    this.model.postedDate= moment(data.postedDate).format('DD/MM/YYYY');
    this.model.expiryDate= moment(data.expiryDate).format('DD/MM/YYYY');
    this.model.publicationVideoList=(data.publicationVideoList || []);
   
  }

}
