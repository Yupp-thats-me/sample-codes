import { Component, OnInit } from '@angular/core';
import { ContextContainer } from '@app/app-core/context-container';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { PublicationType } from '../../models/publication-type';
import { PublicationComponent } from '../publication.component';


@Component({
  selector: 'app-workshop',
  templateUrl: '../../publication/publication.component.html',
  styleUrls: ['./workshop.component.scss']
})
export class WorkshopComponent extends PublicationComponent {

  constructor(context:ContextContainer, modalService: NgbModal) { super(context, PublicationType.Workshop, modalService);
  
  }
}
