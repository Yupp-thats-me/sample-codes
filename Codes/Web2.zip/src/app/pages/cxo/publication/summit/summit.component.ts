import { Component, OnInit } from '@angular/core';
import { ContextContainer } from '@app/app-core/context-container';
import { PublicationModel } from '@app/pages/sj-admin/cxo/publication/publication.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { PublicationType } from '../../models/publication-type';
import { PublicationComponent } from '../publication.component';

@Component({
  selector: 'app-summit',
  templateUrl: '../../publication/publication.component.html',
  styleUrls: ['./summit.component.scss']
})

export class SummitComponent extends PublicationComponent {

  constructor(context:ContextContainer, modalService: NgbModal) { super(context, PublicationType.Summit, modalService);
  

    
  }

  bsConfig: Partial<BsDatepickerConfig>;
  model:PublicationModel

}
