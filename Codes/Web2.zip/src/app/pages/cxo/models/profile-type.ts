export enum ProfileType
{
    Public=1,
    Private=2
   
}