
export class ProfileModel {
  fname?: string=null;
  lname?: string=null;
  email?: string=null;
  dob?:Date =null;
  gender?:number=null;
  mobileno?:string=null;
  id?: number=null;
  bio?: string=null;
  industryId?: number=null;
  companyId?: number=null;
  designationId?: number=null;
  companyZoneId?: number=null;
  onlineProfile?: string=null;
  remarks?: string=null;
  videoTitle?: string=null;
  videoFiles?: string=null;
  imageFiles?: string=null;
  cxoId?: number=null;
  cxoTypeId?: number=null;
  temp?: number=null;
  createdDate?: Date=null;
  createdBy?:string=null;
  Reason?: string = null;
  Status?: number = null;
}