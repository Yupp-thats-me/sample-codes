
export class EventModel
{
  id?:number;
  eventTitle?:string;
  eventurl?:string;
  description?:string;
  venue?:string;
  videoTitle?:string;
  imageTitle?:string;
  tEventDate?:string;
  tExpiryDate?:string;
  eventDate?:Date;
  expiryDate?:Date;
  userId?:number;
  createdBy?:string;
  updatedBy?:string;
  remarks?:string;
  imageFile?:string;
  videoFile?:string;
  isActive?:boolean;
}
