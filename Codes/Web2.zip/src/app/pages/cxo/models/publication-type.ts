export enum PublicationType
{
    Summit = 1,
    Workshop = 2,
    Leadership = 3,
    Seminar = 5
}

export enum PostType
{
    Events=4,
    Seminars =5,
    Summit = 1,
    Workshop = 2,
    Leadership = 3,

}

export enum PostTypeAr
{
    'الأحداث ' = 1,
    ' ندوات' = 2,
    ' قمة' = 3,
    ' ورشة عمل' = 4,
    '  قيادة' = 5,
}