import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { EventModel } from '../models/eventModel';

@Component({
  selector: 'app-view-event',
  templateUrl: './view-event.component.html',
  styleUrls: ['./view-event.component.scss']
})
export class VieweventComponent extends BaseComponent {

  eventData: any = [];
  model: EventModel = {};
  url: string = '/';
  private route: ActivatedRoute;
  id: number
  constructor(context: ContextContainer, route: ActivatedRoute) {
    super(context);
    this.route = route;
  }

  ngOnInit(): void {
    this.route.params.subscribe(param => {
      this.id = param['id'];
    });

    this.loadEvents();
    this.updateView(this.id);
  }

  loadEvents() {
    this.context.httpService.get(this.environment.cxoUrl + '/Event/' + this.id).subscribe(
      (response) => {
        if (response.success) {
          let data = response.data || []
          this.bindEvent(data);
        }
        else {
          this.notifyError('Failed to get data')
        }
      }
    );
  }

  bindEvent(data) {
    this.model.eventTitle = data.title;
    this.model.eventurl = data.url;
    this.model.description = data.description;
    this.model.venue = data.venue;
    this.model.videoTitle = data.videoTitle || '';
    this.model.eventDate = new Date(data.eventDate);
    this.model.expiryDate = new Date(data.expiryDate);
    this.model.imageFile = data.imageFile;
    this.model.videoFile = data.videoFile;

  }
  updateView(id) {
    this.context.httpService.put(this.environment.cxoUrl + '/event/update-view/' + id).subscribe(
      (response) => {
        if (response.success) {

        }
        else {

        }
      }

    );
  }


}

