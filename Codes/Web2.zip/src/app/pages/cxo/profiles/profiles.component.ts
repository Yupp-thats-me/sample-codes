import { Component, ElementRef, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';
import { DropdownTreeviewI18n } from '@app/app-core/i18/dropdown-treeview-i18';
import { LangService } from '@app/services/lang.service';
import { LangChangeEvent } from '@ngx-translate/core';
import { TreeviewConfig, TreeviewI18n, TreeviewItem } from 'ngx-treeview';
import { ProfileType } from '../models/profile-type';

@Component({
  selector: 'app-profiles',
  templateUrl: './profiles.component.html',
  styleUrls: ['./profiles.component.scss'],
  providers: [{ provide: TreeviewI18n, useClass: DropdownTreeviewI18n }]
})
export class ProfilesComponent extends BaseComponent {
  slang: string = 'en';
  profiles: any[] = [];
  searchBox: any = "";
  cxoType: any = null;
  filter: FilterModel;
  industryList: any[] = [];
  designationList: any[] = [];
  companyList: any[] = [];

  dropdownData: any;
  elements: any[] = [];

  treeviewConfig = TreeviewConfig.create({
    hasAllCheckBox: true,
    hasFilter: true,
    hasCollapseExpand: true,
    decoupleChildFromParent: false,
    maxHeight: 400
  });

  constructor(context: ContextContainer, private langService: LangService) {
    super(context);
    this.filter = new FilterModel([]);
  }


  ngOnInit(): void {
    let lan = this.context.translateService.currentLang;
    if (lan == 'ar') {
      this.slang = 'ar';
    }
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang;
      this.initDropdowns();
    });
    this.loadElements();
    this.loadProfiles();
  }

  loadElements() {
    this.context.httpService.get(this.environment.cxoUrl + '/Profile/GetElements/').subscribe(
      (response) => {
        if (response.success) {
          //this.loadFormData(response.data);
          this.dropdownData = response.data || [];

          this.dropdownData.map((x: any) => {
            {
              const data = {
                elementId: x.elementId,
                elementValue: x.elementValue,
                elementValueAr: x.elementValueAr,
                category: x.category,
                isActive: true,
              };
            }
          })

          this.initDropdowns();

        }
        else {
          this.notifyError('Failed to get data')
        }
      }
    );
  }

  initDropdowns() {

    this.companyList = this.bindDropdowns(ELEMENT_TYPES.Company);
    this.designationList = this.bindDropdowns(ELEMENT_TYPES.Designation);
    this.industryList = this.bindDropdowns(ELEMENT_TYPES.Industry);
  }

  bindDropdowns(elementTypeId) {

    const data = this.dropdownData.filter(a => a.elementTypeId == elementTypeId).map(value => {

      const text = this.slang == 'ar' ? value.elementValueAr : value.elementValue;
      return new TreeviewItem({ text: text, value: value.elementId, collapsed: true, checked: false });

    });

    return data;
  }

  loadProfiles() {

    this.context.httpService.get(this.environment.cxoUrl + '/Profile/GetProfiles/').subscribe(

      (response) => {

        if (response.success) {
          this.profiles = response.data || [];

          let data = (response.data.profile || []).forEach(a => {
            let item = a;
            item.designation = response.data.elements.find(a => a.elementId == item.designationId).elementValue;
            item.company = response.data.elements.find(a => a.elementId == item.companyId).elementValue;

            return item;
          });

          this.filter.data = response.data.profile;

          this.filter.filteredData = response.data.profile;
        }
        else {
          this.notifyError('Failed to get data')
        }
      }
    );
  }

  public reset(form: NgForm) {
    form.resetForm();
    this.filter.filteredData = this.filter.data;
    this.initDropdowns();
    this.searchBox = "";
    this.cxoType = "null";
    this.filter.value = null;
  }

  // loadFormData(data: any[]) {

  //   this.industryList = data.filter(a => a.elementTypeId == ELEMENT_TYPES.Industry) || [];
  //   this.designationList = data.filter(a => a.elementTypeId == ELEMENT_TYPES.Designation) || [];
  //   this.companyList = data.filter(a => a.elementTypeId == ELEMENT_TYPES.Company) || [];
  // }
  value: any;

  changedProfileType(data) {
    this.value = data;
    this.filter.changed(data);
  }


}

export enum ELEMENT_TYPES {
  Industry = 1,
  Designation = 2,
  Company = 3
}

export class FilterModel {
  data: any[] = [];
  value: any;
  filteredData: any[] = [];
  industryList: any[] = [];
  designationList: any[] = [];
  companyList: any[] = [];

  constructor(data: any) {

    this.data = data || [];
  }

  updateFilter(column: string, data: any[]) {
    let result = [];

  }
  changed(data) {
    this.value = data;
    this.applyFilter();
  }

  searchByName(val: string) {

    this.filteredData = this.data.filter(a => a.firstName.toLocaleLowerCase().startsWith(val) || a.firstName.toLocaleLowerCase().includes(val));

  }



  updateIndustryFilter(data: any) {

    this.industryList = $.map(data, function (d, i) {
      return d.value;
    });
    this.applyFilter();

  }


  updateDesignationFilter(data: any) {

    this.designationList = $.map(data, function (d, i) {
      return d.value;
    });
    this.applyFilter();
  }


  updateCompanyFilter(data: any) {

    this.companyList = $.map(data, function (d, i) {
      return d.value;
    });
    this.applyFilter();
  }

  applyFilter() {

    let data = [];
    let datas = [];
    for (let item of this.data || []) {

      if ((this.industryList.includes(item.industryId) || this.industryList.length == 0)
        && (this.designationList.includes(item.designationId) || this.designationList.length == 0)
        && (this.companyList.includes(item.companyId) || this.companyList.length == 0)

      ) {
        if (this.value == 'A') {
          if (item.cxoTypeId == ProfileType.Public) {
            data.push(item);
          }
        }
        else if (this.value == 'B') {
          if (item.cxoTypeId == ProfileType.Private) {
            data.push(item);
          }
        }
        else if (!this.value) {
          data.push(item);
        }
        // data.push(item);
      }
    }
    this.filteredData = data;
  }
  resetForm() {

  }
}
