import { Component, OnInit } from '@angular/core';
import { ContextContainer } from '@app/app-core/context-container';
import { BaseComponent } from '@app/app-core/base.component';
import { ProfileType } from '../../models/profile-type';
import { LangService } from "@app/services/lang.service";
import { LangChangeEvent } from '@ngx-translate/core';

@Component({
  selector: 'app-profile-type',
  templateUrl: './profile-type.component.html',
  styleUrls: ['./profile-type.component.scss']
})
export class ProfileTypeComponent extends BaseComponent {

  profiles: any[] = []
  publicProfile: any[] = [];
  privateProfile: any[] = [];
  filter: any;
  top1: 0;
  top2: any;
  top3: any;
  top4: any;
  top5: any;
  top6: any;
  top7: any;
  top8: any;
  slang: string = 'en';
  mobileCarousel: boolean;

  constructor(context: ContextContainer, private LangService: LangService)
  {
    super(context);
    if (window.screen.width < 500) {
      this.mobileCarousel = true
    }
  }

  ngOnInit(): void {

    this.slang = this.LangService.currentlang();

    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {

      if (this.slang != event.lang) {
        this.slang = event.lang;
      }
    });
    this.loadProfiles();
  }

  loadProfiles() {

    this.context.httpService.get(this.environment.cxoUrl + '/Profile/GetProfiles/').subscribe(

      (response) => {

        if (response.success) {
          this.profiles = response.data.profile || [];
          this.publicProfile = this.profiles.filter(a => a.cxoTypeId == ProfileType.Public);
          this.privateProfile = this.profiles.filter(a => a.cxoTypeId == ProfileType.Private)
          this.filter = response.data.profile;
          for (var i = 0; i < this.profiles.length; i++) {
            if (i == 0) {
              this.top1 = this.profiles[0]
            }
            if (i == 1) {
              this.top2 = this.profiles[1]
            }
            if (i == 2) {
              this.top3 = this.profiles[2]
            }
            if (i == 3) {
              this.top4 = this.profiles[3]
            }
            if (i == 4) {
              this.top5 = this.profiles[4]
            }
            if (i == 5) {
              this.top6 = this.profiles[5]
            }
            if (i == 6) {
              this.top7 = this.profiles[6]
            }
            if (i == 7) {
              this.top8 = this.profiles[7]
            }
            
          }

          // this.filter.filteredData = response.data.profile;
        }
        else {
          this.notifyError('Failed to load profile data')
        }
      }
    );
  }

}
