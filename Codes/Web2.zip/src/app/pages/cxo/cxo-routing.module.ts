import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProfilesComponent } from './profiles/profiles.component';
import { ProfileComponent } from './profile/profile.component';
import { PublicationComponent } from './publication/publication.component';
import { SummitComponent } from './publication/summit/summit.component';
import { WorkshopComponent } from './publication/workshop/workshop.component';
import { LeadershipComponent } from './publication/leadership/leadership.component';
import { TrainingComponent } from './publication/training/training.component';
import { EventComponent } from './profile/event/event.component';
import { ViewPublicationComponent } from './publication/view-publication/view-publication.component';
import { ProfileTypeComponent } from './profiles/profile-type/profile-type.component';
import { VieweventComponent } from './view-event/view-event.component';
import { Authorize } from '@app/app-core/identity/auth.guard';
import { Role } from '@app/models/role.enum';

const routes: Routes = [
 
  {
    path:'profiles',
    component:ProfilesComponent
  },
  {
    path:'profile/event/:id',
    component:EventComponent,
    canActivate: [Authorize],
    data: { roles: [Role.Student, Role.General] }
  },
  {
    path:'publication',
    component:PublicationComponent
  },
  {
    path:'profile/:id',
    component:ProfileComponent,
    canActivate: [Authorize],
    data: { roles: [Role.Student, Role.General] }
  },
  {
    path:'viewevent/:id',
    component:VieweventComponent,
    canActivate: [Authorize],
    data: { roles: [Role.Student, Role.General] }
  },
  {
    path:'viewpublication/:id',
    component:ViewPublicationComponent,
    canActivate: [Authorize],
    data: { roles: [Role.Student, Role.General] }
  },
  {
    path:'summit',
    component:SummitComponent
  },
  {
    path:'workshop',
    component:WorkshopComponent
  },
  {
    path:'leadership',
    component:LeadershipComponent
  },
  {
    path:'training',
    component:TrainingComponent
  },
  {
    path:'profile-type',
    component:ProfileTypeComponent
  }
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CxoRoutingModule { }
