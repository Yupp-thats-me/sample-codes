import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CxoRoutingModule } from './cxo-routing.module';
import { SharedModule } from '@app/shared/shared.module';
import { AutocompleteLibModule } from 'angular-ng-autocomplete';
import { NgbCarouselModule, NgbDatepickerModule, NgbPaginationModule } from '@ng-bootstrap/ng-bootstrap';
import { TreeviewModule } from 'ngx-treeview';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { ProfilesComponent } from './profiles/profiles.component';
import { ProfileComponent } from './profile/profile.component';
import { PublicationComponent } from './publication/publication.component';
import { SummitComponent } from './publication/summit/summit.component';
import { LeadershipComponent } from './publication/leadership/leadership.component';
import { TrainingComponent } from './publication/training/training.component';
import { WorkshopComponent } from './publication/workshop/workshop.component';
import { baseModule } from '@app/app-core/Common Modules/baseModule';
import { EventComponent } from './profile/event/event.component';
import { FullCalendarModule } from '@fullcalendar/angular';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';
import { ViewPublicationComponent } from './publication/view-publication/view-publication.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { ProfileTypeComponent } from './profiles/profile-type/profile-type.component';
import { VieweventComponent } from './view-event/view-event.component';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { HttpClient } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { CarouselModule } from 'ngx-bootstrap/carousel';

FullCalendarModule.registerPlugins([ // register FullCalendar plugins added by Karthik M.
  dayGridPlugin,
  interactionPlugin
]);



@NgModule({
  declarations: [ProfilesComponent, ProfileComponent, SummitComponent, VieweventComponent,
                 WorkshopComponent, TrainingComponent, LeadershipComponent,
                PublicationComponent, EventComponent, ViewPublicationComponent, ProfileTypeComponent],
  imports: [
    CommonModule,
    CxoRoutingModule,
    SharedModule,
    AutocompleteLibModule,
    NgbPaginationModule,
    NgbCarouselModule,
    NgbDatepickerModule,
    TreeviewModule.forRoot(),
    Ng2SearchPipeModule,
    PdfViewerModule,
    baseModule,
    BsDatepickerModule.forRoot(),
    FullCalendarModule,
    CarouselModule.forRoot(),
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: httpTranslateLoader,
        deps: [HttpClient]
      }
    }),
  ]
})
export class CxoModule { }

export function httpTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http);
}

