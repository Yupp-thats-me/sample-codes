import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';

@Component({
  selector: 'app-sliding-menu',
  templateUrl: './sliding-menu.component.html',
  styleUrls: ['./sliding-menu.component.scss']
})
export class SlidingMenuComponent extends BaseComponent implements OnInit {
  url: any;
  roles: any;

  constructor(context: ContextContainer,private router: Router) {
    super(context);
  var url = this.router.url.split("/");
  this.url = url[1];
 }

ngOnInit(): void {
 var roles = this.context.getRoles();
 this.roles = roles[0];
}
}
