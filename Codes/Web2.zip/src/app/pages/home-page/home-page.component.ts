import { Component, OnInit } from '@angular/core';
import { LangChangeEvent, TranslateService } from '@ngx-translate/core';
import { LangService } from '@services/lang.service';
import { AuthenticationService } from '@services/authentication.service';
import { BaseComponent } from '@app-core/base.component';
import { ContextContainer } from '@app-core/context-container';
import { environment } from 'environments/environment';
import * as moment from 'moment';
import { TreeviewItem } from 'ngx-treeview';
import { MediaType } from '@app/models/mediacenter.model';
import { Status } from '@app/models/status';
import { Router } from '@angular/router';
import { bannerListDetail } from './helper/mock-banner-data.helper';
import { servicesListDetail } from './helper/mock-service-data.helper';
import { LayoutService } from '../../services/layout.service';
import { forkJoin, Observable } from 'rxjs';


@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss']
})
export class HomePageComponent extends BaseComponent implements OnInit {

  public hoverShow: boolean = false;
  scholarshipURL = '/Scholarship/GetUserScholarshipDetailsList';
  majordropDownUrl = '/InternshipDropdown/InternshipMajor';
  dropDownUrl = '/InternshipDropdown/InternshipDropdown';
  internList: any = [];
  dropdowndetails: any = [];
  higherEducationlist: TreeviewItem[];
  scholarshipValue: boolean;
  scholarshipDetails: any = [];
  scholarshipDetail: any = [];
  internshipValue: boolean = false;
  isupdatebarhidden: boolean = false;
  announcementsList: any = [];
  eventList: any = [];
  newsList: any[] = [];
  recentAnnouncementEn: any;
  recentAnnouncementAr: any;
  recentAnnouncementId: any;
  recentNews: any;
  recentEvent: any;
  currentDate = Date.now();
  top1: 0;
  top2: any;
  isEn: boolean = true;
  //services
  servicesList: any;
  servicesListLeft: any = [];
  servicesListRight: any = [];
  servicesListMiddle: any = [];
  //hero
  bannerListDetail: any;
  bannerActive: boolean = true;
  proceedSlide: number = 1;
  behindSlide: number = 0;
  slang: string = 'en';

  constructor(context: ContextContainer, private layoutservice: LayoutService, protected router: Router, private langservice: LangService, private translate: TranslateService
  ) {
    super(context);
    this.bannerList();
    this.bannerDataList();
  }

  ngOnInit() {
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang
      this.getMajorTree();
      this.Getdropdowndetails();
    });
    this.getAllDetails();
    this.getMajorTree();
    this.Getdropdowndetails();
  }
 

  onButtonGroupClick($event) {
    let clickedElement = $event.target || $event.srcElement;
    if (clickedElement.nodeName === "BUTTON") {
      let isCertainButtonAlreadyActive = clickedElement.parentElement.querySelector(".active");
      // if a Button already has Class: .active
      if (isCertainButtonAlreadyActive) {
        isCertainButtonAlreadyActive.classList.remove("active");
      }
      clickedElement.className += " active";
    }
  }

  setSchoolIntern() {
    this.internshipValue = true;
  }

  setUniversityIntern() {
    this.internshipValue = false;
  }

  userHoverEnter() {
    this.hoverShow = true;
  }

  userHoverLeave() {
    this.hoverShow = false;
  }

  getMajorTree() {
    this.context.httpService.get(this.environment.internshipUrl + this.majordropDownUrl)
      .subscribe(
        (response) => {
          if (this.slang === 'ar') { 
            this.internList = response.map(value => {
              return new TreeviewItem({
                text: value.textAr, value: value.value, collapsed: true,
                checked: value.checked, children: value.children
              });
            });
          } else {
            this.internList = response.map(value => {
              return new TreeviewItem({
                text: value.text, value: value.value, collapsed: true,
                checked: value.checked, children: value.children
              });
            });
          } 
        });
  }
 
  Getdropdowndetails() {
    this.context.httpService.get(this.environment.internshipUrl + this.dropDownUrl)
      .subscribe(
        (Response) => {
          this.dropdowndetails = Response.data;
          this.higherEducationlist = this.binddropdown('GeneralEducationLevel');
        }
      );
  }

  binddropdown(categorystr) {
    let dropdown = this.dropdowndetails.filter(x => x.category == categorystr).
      map(value => {
        return new TreeviewItem({
          text: this.slang == 'ar' ? value.dropdownValueAr : value.dropdownValueEn,
          value: value.dropdownId, collapsed: true, checked: false
        });
      });
    return dropdown;
  }
 
  //fork-join
  getAllDetails() {
    let checkExpiry: boolean = true;
    let queryParamsA = 'checkExpiry=' + checkExpiry + '&mediaType=' + MediaType.Announcement + '&Status=' + Status.Approved;
    let queryParamsN = 'checkExpiry=' + checkExpiry + '&mediaType=' + MediaType.News + '&Status=' + Status.Approved
    let queryParamsE = 'checkExpiry=' + checkExpiry + '&mediaType=' + MediaType.Event + '&Status=' + Status.Approved
    const annoucement = this.context.httpService.get(environment.mediaCenterUrl + "/MediaCenter/media-detail-thumbnail?" + queryParamsA)
    const news = this.context.httpService.get(environment.mediaCenterUrl + "/MediaCenter/media-detail-thumbnail?" + queryParamsN)
    const event = this.context.httpService.get(environment.mediaCenterUrl + "/MediaCenter/media-detail-thumbnail?" + queryParamsE)
    const scholar = this.context.httpService.get(environment.scholarshipUrl + this.scholarshipURL)

    forkJoin([annoucement, news, event, scholar]).subscribe(response => {

      this.announcementsList = response[0].data;
      let announcement = this.announcementsList.slice(0, 1)
      this.recentAnnouncementEn = announcement.map(a => a.titleEn);
      this.recentAnnouncementAr = announcement.map(a => a.titleAr);
      this.recentAnnouncementId = announcement.map(a => a.id);

      this.eventList = response[1].data;
      let event = this.eventList.filter(a => moment(a.expiryDate) > moment(new Date()));
      this.recentEvent = event.slice(0, 3);

      this.newsList = response[2].data;
      for (var i = 0; i < this.newsList.length; i++) {
        if (i == 0) {
          this.top1 = this.newsList[0]
        }
        if (i == 1) {
          this.top2 = this.newsList[1]
        }
      }

      this.scholarshipDetails = response[3].data;
      if (this.scholarshipDetails.length != 0) {
        this.scholarshipValue = true;
        this.scholarshipDetail = this.scholarshipDetails.slice(0, 2);
      }
    })        
  }
 
  navigate(data) {
    this.router.navigate(['/scholarship/view'], { queryParams: { id: data } });
    window.scrollTo(0, 100);
  }

  onclickNews() {
    this.router.navigate(['/mediacenter']);
    window.scrollTo(0, 100);
  }

  onclickIntern() {
    this.router.navigate(['/internship/home']);
    window.scrollTo(0, 100);
  }

  onclickScholar() {
    this.router.navigate(['/scholarship/home']);
    window.scrollTo(0, 100);
  }

  textWrap(word: string) {
    return word.length > 110 ? word.substring(0, 110) + "..." : word;
  }

  public bannerList(): void {
    this.bannerListDetail = bannerListDetail;
    setInterval(() => {
      if (bannerListDetail.length > this.proceedSlide) {
        this.bannerActive = true;
        this.behindSlide = this.behindSlide + 1;
        this.proceedSlide = this.proceedSlide + 1;
      }
      else {
        this.bannerActive = true;
        this.behindSlide = this.behindSlide - 1;
        this.proceedSlide = this.proceedSlide - 1;
      }
    }, 10000);
  }

  public preClick(id): void {
    if (id > 1) {
      this.bannerActive = true;
      this.proceedSlide = id - 1;
      this.behindSlide = id - 2;
    }
  }

  public nextClick(id): void {
    if (bannerListDetail.length > id) {
      this.bannerActive = true;
      this.proceedSlide = id + 1;
      this.behindSlide = id;
    }
  }

  public bannerDataList(): void {
    this.servicesList = servicesListDetail;
    for (let i = 0; i < this.servicesList.length; i++) {
      if (this.servicesList[i].Placement == 'Left') {
        this.servicesListLeft.push({ "Id": this.servicesList[i].Id, "TitleEn": this.servicesList[i].TitleEn, "TitleAr": this.servicesList[i].TitleAr, "SvgImageDefault": this.servicesList[i].SvgImageDefault, "SvgImageActive": this.servicesList[i].SvgImageActive });
      }
      else if (this.servicesList[i].Placement == 'right') {
        this.servicesListRight.push({ "Id": this.servicesList[i].Id, "TitleEn": this.servicesList[i].TitleEn,"TitleAr": this.servicesList[i].TitleAr,"SvgImageDefault": this.servicesList[i].SvgImageDefault, "SvgImageActive": this.servicesList[i].SvgImageActive });
      }
      else {
        this.servicesListMiddle.push({ "Id": this.servicesList[i].Id, "TitleEn": this.servicesList[i].TitleEn, "TitleAr": this.servicesList[i].TitleAr, "SvgImageDefault": this.servicesList[i].SvgImageDefault, "SvgImageActive": this.servicesList[i].SvgImageActive });
      }
    }
  }

  public moveClick(id, moveSide): void {
    if (moveSide == 'left' && id >= 2) {
      for (let i = 0; i < this.servicesList.length; i++) {
        if (this.servicesList[i].Id == id) {
          this.servicesListMiddle = [];
          this.servicesListLeft.pop();
          this.servicesListRight.unshift({ "Id": this.servicesList[i].Id, "TitleEn": this.servicesList[i].TitleEn, "TitleAr": this.servicesList[i].TitleAr,"SvgImageDefault": this.servicesList[i].SvgImageDefault, "SvgImageActive": this.servicesList[i].SvgImageActive });
          this.servicesListMiddle.push({ "Id": this.servicesList[i - 1].Id, "TitleEn": this.servicesList[i - 1].TitleEn, "TitleAr": this.servicesList[i - 1].TitleAr, "SvgImageDefault": this.servicesList[i - 1].SvgImageDefault, "SvgImageActive": this.servicesList[i - 1].SvgImageActive });
        }
      }
    }
    else if (moveSide == 'right' && id <= 5) {
      for (let i = 0; i < this.servicesList.length; i++) {
        if (this.servicesList[i].Id == id) {
          this.servicesListMiddle = [];
          this.servicesListRight.shift();
          this.servicesListLeft.push({ "Id": this.servicesList[i].Id, "TitleEn": this.servicesList[i].TitleEn, "TitleAr": this.servicesList[i].TitleAr,"SvgImageDefault": this.servicesList[i].SvgImageDefault, "SvgImageActive": this.servicesList[i].SvgImageActive });
          this.servicesListMiddle.push({ "Id": this.servicesList[i + 1].Id, "TitleEn": this.servicesList[i + 1].TitleEn, "TitleAr": this.servicesList[i + 1].TitleAr, "SvgImageDefault": this.servicesList[i + 1].SvgImageDefault, "SvgImageActive": this.servicesList[i + 1].SvgImageActive });
        }
      }
    }
  }

  imageAnimation() {
    this.layoutservice.languageimgchangeObserver.subscribe(navbarImage => {
      if (navbarImage) {
        this.isEn = true;
      }
      else {
        this.isEn = false;
      }
    });
  }

  //twitter
  makecall() {
    var headers = new Headers();
    headers.append('Content-Type', 'application/X-www-form-urlencoded');
    this.context.httpService.post('http://localhost:3000/authorize', { headers: headers }).subscribe(
      (res) => {
      }
    )
  }
  hideupdatenotify(){
    this.isupdatebarhidden = true;
  }

}
