import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomePageRoutingModule } from './home-page-routing.module';
import { HomePageComponent } from './home-page.component';
import { SharedModule } from '../../shared/shared.module';
import { NgbCarouselModule } from '@ng-bootstrap/ng-bootstrap';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient } from '@angular/common/http';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { AsideNavComponent } from './aside-nav/aside-nav.component';
import { MaintenComingSoonComponent } from './mainten-coming-soon/mainten-coming-soon.component';
import { CircularMenuComponent } from './circular-menu/circular-menu.component';
import { SlidingMenuComponent } from './sliding-menu/sliding-menu.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactComponent } from './contact/contact.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
    declarations: [HomePageComponent, AsideNavComponent, MaintenComingSoonComponent, CircularMenuComponent, SlidingMenuComponent, AboutUsComponent, ContactComponent],
  imports: [
    CommonModule,
    HomePageRoutingModule,
    NgbCarouselModule,
    SharedModule,
    ReactiveFormsModule,
    FormsModule,
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: httpTranslateLoader,
        deps: [HttpClient]
      }
    })
  ],
  exports: [AsideNavComponent, MaintenComingSoonComponent, CircularMenuComponent, SlidingMenuComponent, ContactComponent]
})
export class HomePageModule { }

export function httpTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http);
}
