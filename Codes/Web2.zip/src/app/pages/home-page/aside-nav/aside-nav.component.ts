import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BaseComponent } from '@app/app-core/base.component';
import { ContextContainer } from '@app/app-core/context-container';

@Component({
  selector: 'app-aside-nav',
  templateUrl: './aside-nav.component.html',
  styleUrls: ['./aside-nav.component.scss']
})
export class AsideNavComponent extends BaseComponent implements OnInit {
  roles: any;
  url: string;

  constructor(context: ContextContainer,private router: Router) {
    super(context);
    var url = this.router.url.split("/");
    this.url = url[1];
   }

  ngOnInit(): void {
   var roles = this.context.getRoles();
   this.roles = roles[0];
  }

  public navigateToSection(section: string) {
    window.location.hash = '';
    window.location.hash = section;
}

}
