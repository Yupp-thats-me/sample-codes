export const bannerListDetail = [
    {
        Id: 1,
        TitleEn: "Scholarships",
        DescriptionEn: "Pursuing passion made simple with scholarships",
        TitleAr: "المنح الدراسية",
        DescriptionAr: "أصبح السعي وراء الشغف أمرًا بسيطًا مع المنح الدراسية",
        Button: true,
        ButtonTxt: "Know more",
        ButtonLink: "www.google.com",
        Target: "_parent",
        SvgImage: ""
    },
    {
        Id: 2,
        TitleEn: "Internship",
        DescriptionEn: "Handpicked Internships for your offcampus hunt",
        TitleAr: "التدريب الداخلي",
        DescriptionAr: "دورات تدريبية منتقاة بعناية للبحث خارج الحرم الجامعي",
        Button: true,
        ButtonTxt: "Know more",
        ButtonLink: "www.google.com",
        Target: "_parent",
        SvgImage: ""
    }
]
