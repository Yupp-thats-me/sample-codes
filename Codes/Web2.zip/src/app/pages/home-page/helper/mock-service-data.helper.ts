export const servicesListDetail = [
    {
        Id: 1,
        TitleEn: "Assessment",
        TitleAr: "تقدير",
        Placement: "Left",
        SvgImageDefault: "../../../../assets/img/home/banner/slide/circle-slider/assessment.svg",
        SvgImageActive: "../../../../assets/img/home/banner/slide/circle-slider/active/assessment.svg"
    },
    {
        Id: 2,
        TitleEn: "Counselling",
        TitleAr: "تقديم المشورة",
        Placement: "Left",
        SvgImageDefault: "../../../../assets/img/home/banner/slide/circle-slider/counselling.svg",
        SvgImageActive: "../../../../assets/img/home/banner/slide/circle-slider/active/counselling.svg"
    },
    {
        Id: 3,
        TitleEn: "Scholarships",
        TitleAr: "المنح الدراسية",
        Placement: "middle",
        SvgImageDefault: "../../../../assets/img/home/banner/slide/circle-slider/scholarships.svg",
        SvgImageActive: "../../../../assets/img/home/banner/slide/circle-slider/active/scholarships.svg"
    },
    {
        Id: 4,
        TitleEn: "Credit Transfer",
        TitleAr: "تحويل الرصيد",
        Placement: "right",
        SvgImageDefault: "../../../../assets/img/home/banner/slide/circle-slider/credit-transfer.svg",
        SvgImageActive: "../../../../assets/img/home/banner/slide/circle-slider/active/credit-transfer.svg"
    },
    {
        Id: 5,
        TitleEn: "Internship",
        TitleAr: "التدريب الداخلي",
        Placement: "right",
        SvgImageDefault: "../../../../assets/img/home/banner/slide/circle-slider/internship.svg",
        SvgImageActive: "../../../../assets/img/home/banner/slide/circle-slider/active/internship.svg"
    },
    {
        Id: 6,
        TitleEn: "CXO",
        TitleAr: "جxس",
        Placement: "right",
        SvgImageDefault: "../../../../assets/img/home/banner/slide/circle-slider/cxo.svg",
        SvgImageActive: "../../../../assets/img/home/banner/slide/circle-slider/active/cxo.svg"
    }
]
