import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LangChangeEvent } from '@ngx-translate/core';
import { environment } from 'environments/environment';
import { BaseComponent } from '@app-core/base.component';
import { ContextContainer } from '@app-core/context-container';
import { mediaCenter } from '@models/mediacenter.model';
import * as moment from 'moment';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { LangService } from '@app/services/lang.service';


@Component({
  selector: 'app-eventsdetails',
  templateUrl: './eventsdetails.component.html',
  styleUrls: ['./eventsdetails.component.scss']
})
export class EventsdetailsComponent extends BaseComponent implements OnInit {
  context: ContextContainer;
  newsId: any = 0;
  slang: string = 'en';
  public isMediaType: string;
  Edate: string;
  isReadMore: boolean;
  Adate: string;
  existingcount: any = 0;
  totalcount: any = 0;
  existingloggedincount: any = 0;
  totalloggedincount: any = 0;
  studentId: any;

  eventsDetail: mediaCenter = {
    id: 0,
    titleEn: null,
    titleAr: null,
    descriptionEn: null,
    descriptionAr: null,
    pagelink: null,
    imagelink: null,
    sourceEn: null,
    sourceAr: null,
    placeEn: null,
    placeAr: null,
    dateAnnounced: null,
    expiryDate: null,
    theme: null,
    industry: 0,
    mediaType: 2,
    status: 0,
    isActive: false,
    thumbNailPath: '',
    speakersEn: null,
    speakersAr: null,
    startDate: null,
    endDate: null,
    startTime: null,
    endTime: null,
    totalViews: 0,
    loggedinViews: 0
  };
  
  

  constructor(context: ContextContainer, private router: Router,private modalService: NgbModal, private route: ActivatedRoute,private langService: LangService) {
    super(context);
    this.isMediaType = 'about';
  }

  ngOnInit(): void {
    this.slang = this.langService.currentlang();
 
this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {     
      if (this.slang != event.lang) {
        this.slang = event.lang;
      }
    });

    this.newsId = this.route.snapshot.paramMap.get('id');
    this.geteventsDetail(this.newsId);
  }
  geteventsDetail(id) {
    this.context.httpService.get(environment.mediaCenterUrl + "/MediaCenter/media-detail/" + id)
      .subscribe(
        (response) => {
          if (response != null) {
            this.eventsDetail = response.data;
            this.Edate = moment.utc(this.eventsDetail.expiryDate).format('MM-DD-YYYY');
            this.Adate = moment.utc(this.eventsDetail.dateAnnounced).format('MM-DD-YYYY');
            this.studentId = ''
            this.studentId = this.context.getUserId();
            if (this.studentId == null) {
              this.existingcount = this.eventsDetail.totalViews;
              this.totalcount = this.existingcount + 1;
              this.totalloggedincount = this.eventsDetail.loggedinViews;
            }
            else {
              this.existingloggedincount = this.eventsDetail.loggedinViews;
              this.totalloggedincount = this.existingloggedincount + 1;
              this.totalcount = this.eventsDetail.totalViews;
            }
          }
          else {
            this.notifyError("Events data not available, please try again");
            this.router.navigate(['/']);
          }
          this.updatetotalviews();
        });

  }

  showText() {
    this.isReadMore = !this.isReadMore
 }

 goBack() {
   this.router.navigate(['/mediacenter/events']);
   window.scrollTo(0, 100);
  }

  updatetotalviews() {
    this.eventsDetail.id = this.eventsDetail.id;
    this.eventsDetail.totalViews = this.totalcount;
    this.eventsDetail.loggedinViews = this.totalloggedincount;
    let MediacenterDto = {
      id: this.eventsDetail.id,
      totalViews: this.eventsDetail.totalViews,
      loggedinViews: this.eventsDetail.loggedinViews
    };
    this.context.httpService.put(environment.mediaCenterUrl + '/MediaCenter/update/' + MediacenterDto.id, MediacenterDto).subscribe(
      (Response) => {
        if (Response.success) {
        }

      });

  }
  
}
