// Common Module
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { baseModule } from '@app-core/Common Modules/baseModule';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { TreeviewModule } from 'ngx-treeview';
// Project Module
import { MediacenterRoutingModule } from './mediacenter-routing.module';
import { MediacenterComponent } from './mediacenter.component';
import { NewsComponent } from './news/news.component';
import { EventsComponent } from './events/events.component';
import { AnnouncementsComponent } from './announcements/announcements.component';
import { NewsdetailsComponent } from './newsdetails/newsdetails.component';
import { EventsdetailsComponent } from './eventsdetails/eventsdetails.component';
import { AnnouncementsdetailsComponent } from './announcementsdetails/announcementsdetails.component';
import { FullCalendarModule } from '@fullcalendar/angular';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';
import { CarouselModule } from 'ngx-bootstrap/carousel';



FullCalendarModule.registerPlugins([ // register FullCalendar plugins added by Karthik M.
  dayGridPlugin,
  interactionPlugin
]);

@NgModule({
  declarations: [MediacenterComponent, NewsComponent, AnnouncementsComponent, NewsdetailsComponent, EventsComponent, EventsdetailsComponent, AnnouncementsdetailsComponent],
  imports: [
    CommonModule,
    MediacenterRoutingModule,
    HttpClientModule,
    baseModule,
    BsDatepickerModule.forRoot(),
    DatepickerModule.forRoot(),
    TreeviewModule.forRoot(),
    FullCalendarModule,
    CarouselModule.forRoot(),
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: httpTranslateLoader,
        deps: [HttpClient]
      }
    })
  ]
})
export class MediacenterModule { }

export function httpTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http);
}
