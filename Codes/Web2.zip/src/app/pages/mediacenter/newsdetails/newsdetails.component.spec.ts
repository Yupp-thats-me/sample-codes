﻿/// <reference path="../../../../../../node_modules/@types/jasmine/index.d.ts" />
import { TestBed, async, ComponentFixture, ComponentFixtureAutoDetect } from '@angular/core/testing';
import { BrowserModule, By } from "@angular/platform-browser";
import { NewsdetailsComponent } from './newsdetails.component';

let component: NewsdetailsComponent;
let fixture: ComponentFixture<NewsdetailsComponent>;

describe('newsdetails component', () => {
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ NewsdetailsComponent ],
            imports: [ BrowserModule ],
            providers: [
                { provide: ComponentFixtureAutoDetect, useValue: true }
            ]
        });
        fixture = TestBed.createComponent(NewsdetailsComponent);
        component = fixture.componentInstance;
    }));

    it('should do something', async(() => {
        expect(true).toEqual(true);
    }));
});