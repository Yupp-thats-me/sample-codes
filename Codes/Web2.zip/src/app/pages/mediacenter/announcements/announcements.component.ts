import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { BaseComponent } from '@app-core/base.component';
import { ContextContainer } from '@app-core/context-container';
import { environment } from 'environments/environment';
import { TreeviewItem, TreeviewConfig, DropdownTreeviewComponent, TreeviewI18n } from 'ngx-treeview';
import {  mediaStatus, MediaType } from '@models/mediacenter.model';
import { LangChangeEvent } from '@ngx-translate/core';
import * as moment from 'moment';
import { Status } from '@models/status';
import { DropdownTreeviewI18n } from '@app/app-core/i18/dropdown-treeview-i18';
import { Router } from '@angular/router';
import { LangService } from '@app/services/lang.service';


@Component({
    selector: 'app-announcements',
    templateUrl: './announcements.component.html',
    styleUrls: ['./announcements.component.scss'],
    providers: [{ provide: TreeviewI18n, useClass: DropdownTreeviewI18n }]
})
/** announcements component*/
export class AnnouncementsComponent extends BaseComponent implements OnInit {
  context: ContextContainer;
  announcementsList: any;
  page = 1;
  pageSize = 3;
  collectionSize = 0;
  noOfMatches = 0;
  language: string = 'en';
  slang: string = 'en';
  @ViewChild(DropdownTreeviewComponent, { static: false }) dropdownTreeviewComponent: DropdownTreeviewComponent;

  treeviewConfig = TreeviewConfig.create({
    hasAllCheckBox: true,
    hasFilter: true,
    hasCollapseExpand: true,
    decoupleChildFromParent: false,
    maxHeight: 400
  });
  treeViewItems: TreeviewItem[];
  buttonClass = "btn-outline-primary";
  selectedThemes: '';

  fromDate: any;
  toDate: any;
  searchValue: any;
  sourceValue: any;
  bsValue: Date[];

  filteredAnnouncements: any[] = [];



  mediaStatus = mediaStatus;

  constructor(context: ContextContainer,private router:Router,private langService: LangService) {
    super(context);

  }

  ngOnInit(): void {
    // let lan =  this.context.translateService.currentLang;
    // if(lan=='ar'){
    //   this.language = 'ar';
    // }
    
    this.slang = this.langService.currentlang();
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang;
      this.getThemeTree();
    });
    this.getThemeTree();
    this.getNewsDetails();
  }

  //Get only the approved News details to be shown for the user
  getNewsDetails() {
    let checkExpiry: boolean = true;
    let queryParams = 'checkExpiry=' + checkExpiry + '&mediaType=' + MediaType.Announcement + '&Status=' + Status.Approved
    this.context.httpService.get(environment.mediaCenterUrl + "/MediaCenter/media-detail-thumbnail?" + queryParams)
      .subscribe(
        (response) => {
          this.announcementsList = response.data;
          this.filteredAnnouncements = response.data;
          this.collectionSize = this.announcementsList.length;
        });
  }

  // getThemeTree() {
  //   this.context.httpService.get(environment.mediaCenterUrl + "/MediaCenter/theme-tree/")
  //     .subscribe(
  //       (response) => {
  //         this.treeViewItems = response.map(value => {
  //           return new TreeviewItem({ text: value.text, value: value.id, collapsed: true, checked: true, children: value.children });
  //         });

  //       });
  // }
  getThemeTree() {
    this.context.httpService.get(environment.mediaCenterUrl + "/MediaCenter/theme-tree")
      .subscribe(
        (response) => {

          if (this.slang === 'ar') {
            let temp: any = [];
            this.treeviewPreparation(response, temp)
            this.treeViewItems = []
            this.treeViewItems = temp.map(value => {
              return new TreeviewItem({
                text: value.text, value: value.value, collapsed: true,
                checked: true, children: value.children
              });
             });
          } else {
            this.treeViewItems = response.map(value => {
              return new TreeviewItem({
                text: value.text, value: value.id, collapsed: true,
                checked: true, children: value.children
              });
            });
          }
          // if (this.themeArray !== undefined) {
          //   this.bindArray(this.themeArray);
          // }
        });
  }
  titletextWrap(word: string) {
    if (word != null || '') {
      return word.length > 100? word.substring(0, 100) + "..." : word;
    }
  }


  treeviewPreparation(data, temp) {
    data.map((dt, i) => {
      let obj = {
        text: dt.textAr,
        value: dt.id,
        children: [],
        collapsed: true,
        checked: dt.checked,
      };
      temp.push(obj);
      if (dt.hasOwnProperty('children') && dt.children.length > 0) {
        this.treeviewPreparation(dt.children, temp[i].children);
      }
    });
  }

  updateSearchValue(value) {
    this.searchValue = value;
    this.onFilter();
  }
  updateSourceValue(value) {
    this.sourceValue = value;
    this.onFilter();
  }

  
  goBack(){
    this.router.navigate(['/mediacenter']);
    window.scrollTo(0, 100);
  }

  onSelectedChange(form, values): void {
    this.selectedThemes = values;

    this.onFilter();
  }

  public getByDate(form, event) {
    if (event) {
      this.fromDate = event[0];
      this.toDate = event[1];
      this.onFilter();
    }
  }

  dateValid(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if ((charCode > 46 && charCode < 58) || charCode == 46) {
      return true;
    }
    return false;
  }

  treeViewReset() {
    let allChecked = this.dropdownTreeviewComponent.treeviewComponent.allItem.checked;
    if (allChecked) {
      this.dropdownTreeviewComponent.treeviewComponent.allItem.checked = false;

    }
    if(this.slang  == "ar"){
      this.dropdownTreeviewComponent.buttonLabel = 'اشر على الخيارات'
    }else{
      this.dropdownTreeviewComponent.buttonLabel = 'Select Options'
    }
    this.treeViewItems.forEach(element => {
      element.checked = false;
      element.children.forEach(elem => {
        elem.checked = false;
        if (elem.children != null && elem.children.length > 0)
          elem.children.forEach(elem => {
            elem.checked = false;
          });
      });
    });
  }

  resetForm(form: NgForm) {
    form.resetForm();
    this.fromDate = null;
    this.toDate = null;
    this.bsValue = null;
    this.selectedThemes = '';
    this.treeViewReset();
    this.filteredAnnouncements = this.announcementsList;
    this.collectionSize = this.filteredAnnouncements.length;
    this.noOfMatches = 0;
  }

  textWrap(word: string) {
    return word.length > 110 ? word.substring(0, 110) + "..." : word;
  }

  onFilter() {
    let fromDate = null;
    let toDate = null;

    if (this.fromDate != undefined && this.toDate != undefined) {
      let fromDateFormatted =moment(this.fromDate).format('MM/DD/YYYY');
      fromDate = new Date(fromDateFormatted);
      let toDateFormatted =moment(this.toDate).format('MM/DD/YYYY');
      toDate = new Date(toDateFormatted);
    }

    let searchValue = this.searchValue || '';
    searchValue = searchValue.toLocaleLowerCase();
    let themes = this.selectedThemes || [];
    let source = this.sourceValue || '';
    source = source.toLocaleLowerCase();
    


    let data = [];

    (this.announcementsList || []).forEach(records => {

      let dateAnnouncedFormatted = moment(records.dateAnnounced).format('MM/DD/YYYY');
      let dateAnnounced = new Date(dateAnnouncedFormatted);

      if(
        (!fromDate || ((moment(dateAnnounced).isSameOrAfter(moment(fromDate))) && (moment(dateAnnounced).isSameOrBefore(moment(toDate)))))
        &&
      (!searchValue || (records.titleEn.toLocaleLowerCase().startsWith(searchValue) || records.titleEn.toLocaleLowerCase().endsWith(searchValue) || records.titleEn.toLocaleLowerCase().includes(searchValue) ||
        records.titleEn.toLocaleUpperCase().startsWith(searchValue) || records.titleEn.toLocaleUpperCase().endsWith(searchValue) || records.titleEn.toLocaleUpperCase().includes(searchValue)||
        records.titleEn.toLocaleString().startsWith(searchValue) || records.titleEn.toLocaleString().endsWith(searchValue) || records.titleEn.toLocaleString().includes(searchValue)))
      &&
     
      (themes.length == 0 || ((records.theme || '').split(',') || []).some(item => themes.includes(parseInt(item))))
      &&
      (!source || (records.sourceEn.toLocaleLowerCase().startsWith(source) || records.sourceEn.toLocaleLowerCase().endsWith(source) || records.sourceEn.toLocaleLowerCase().includes(source) ||
        records.sourceEn.toLocaleUpperCase().startsWith(source) || records.sourceEn.toLocaleUpperCase().endsWith(source) || records.sourceEn.toLocaleUpperCase().includes(source) ||
        records.sourceEn.toLocaleString().startsWith(source) || records.sourceEn.toLocaleString().endsWith(source) || records.sourceEn.toLocaleString().includes(source)))
 
      )
        
        {
                  data.push(records);
                }

                this.filteredAnnouncements = data;

                    });


                    this.collectionSize = this.filteredAnnouncements.length;
                    this.noOfMatches = this.filteredAnnouncements.length;
                  }

                }

            
