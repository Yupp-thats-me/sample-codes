﻿/// <reference path="../../../../../../node_modules/@types/jasmine/index.d.ts" />
import { TestBed, async, ComponentFixture, ComponentFixtureAutoDetect } from '@angular/core/testing';
import { BrowserModule, By } from "@angular/platform-browser";
import { AnnouncementsComponent } from './announcements.component';

let component: AnnouncementsComponent;
let fixture: ComponentFixture<AnnouncementsComponent>;

describe('announcements component', () => {
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ AnnouncementsComponent ],
            imports: [ BrowserModule ],
            providers: [
                { provide: ComponentFixtureAutoDetect, useValue: true }
            ]
        });
        fixture = TestBed.createComponent(AnnouncementsComponent);
        component = fixture.componentInstance;
    }));

    it('should do something', async(() => {
        expect(true).toEqual(true);
    }));
});