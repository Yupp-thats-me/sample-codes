import { AfterViewInit, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { mediaCenter, MediaType } from '@models/mediacenter.model';
import { ContextContainer } from '../../app-core/context-container';
import { BaseComponent } from '../../app-core/base.component';
import { LangChangeEvent } from '@ngx-translate/core';
import { environment } from '../../../environments/environment';
import { CalendarOptions } from '@fullcalendar/core';
import { formatDate } from '@angular/common';
import { BsDatepickerConfig, BsDatepickerInlineConfig, DatepickerDateCustomClasses } from 'ngx-bootstrap/datepicker';
import * as moment from 'moment';
import { LangService } from '@app/services/lang.service';


@Component({
  selector: 'app-mediacenter',
  templateUrl: './mediacenter.component.html',
  styleUrls: ['./mediacenter.component.scss']
})

export class MediacenterComponent extends BaseComponent implements OnInit, AfterViewInit {
  data: Map<MediaType, MediaDataModel> = new Map<MediaType, MediaDataModel>();
  currentAnnoucements: any[] = [];
  currentNews: any[] = [];
  currentEvents: any[] = [];
  currentAnnoucementsIndex: number = 0;
  totalAnnouncement: number;
  currentEventsIndex: number = 0;
  totalEvents: number;
  currentNewsIndex: number = 0;
  totalNews: number;
  MediaType = MediaType;
  announcementsDetails: any;
  announcementsArray: any = [];
  mediaURL = '/MediaCenter/GetMediaDetailsForUser/'
  mediaURLById = '/MediaCenter?/'
  slang: string = 'en'
  calendarOptions: CalendarOptions = {}
  selectedEvent: mediaCenter = {}
  calendarView: boolean = true;
  dateObj = new Date();
  events: any[] = [];
  mobileCarouselMedia: boolean = false;
  edate1: any;
  public activeTabMedia: string;
  datesDisabled: Date[];
  dateCustomClasses: DatepickerDateCustomClasses[];
  bsConfig: Partial<BsDatepickerConfig>;
  dataSet = [];
  mediaModel: mediaCenter = {
    id: 0,
    titleEn: null,
    titleAr: null,
    descriptionEn: null,
    descriptionAr: null,
    pagelink: null,
    imagelink: null,
    sourceEn: null,
    sourceAr: null,
    placeEn: null,
    placeAr: null,
    dateAnnounced: null,
    expiryDate: null,
    theme: null,
    industry: null,
    mediaType: 2,
    status: 0,
    isActive: false,
    thumbNailPath: '',
    speakersEn: null,
    speakersAr: null,
    startDate: null,
    endDate: null,
    startTime: null,
    endTime: null
  };
  activeTab1: string = 'list';
  Etop1: any;
  Etop2: any;
  Etop3: any;
  Etop4: any;
  eventCalendar: boolean;
  calenderDate: any;

  //date and time
  currentDate: any;
  targetDate: any;
  cDateMillisecs: any;
  tDateMillisecs: any;
  difference: any;
  seconds: any;
  minutes: any;
  hours: any;
  days: any;
  year: number = 2021;
  month: number = 11;
  months = ['Jan', 'Feb', 'Mar', 'April', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
  day: number = 31;
  currentEventsArr: any = [];

  constructor(context: ContextContainer, private router: Router,private langService: LangService) {
    super(context);
    if (window.screen.width < 500) {
      this.mobileCarouselMedia = true
    }
  }

  ngOnInit(): void {
   this.slang = this.langService.currentlang(); 
   this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {     
      if (this.slang != event.lang) {
        this.slang = event.lang;
      }
    });

    this.getAnnouncementDetails();
    this.getNewsDetails();
    this.getEventsDetails();

    this.activeTabMedia = 'News';
    this.bsConfig = Object.assign({}, {
      showWeekNumbers: false
    });

  }
  ngAfterViewInit() {
    // this.myTimer();
  }
 
  top1annouce: any;
  top2annouce: any;
  top3annouce: any;
  getAnnouncementDetails() {

    this.context.httpService.get(environment.mediaCenterUrl + this.mediaURL + MediaType.Announcement).
      subscribe(
        (response) => {
          let model: MediaDataModel = { data: response };
          this.data.set(MediaType.Announcement, model);
          this.currentAnnoucements = (response || []);
          for (var i = 0; i < this.currentAnnoucements.length; i++) {
            if (i == 0) {
              this.top1annouce = this.currentAnnoucements[0]
            }
            if (i == 1) {
              this.top2annouce = this.currentAnnoucements[1]
            }
            if (i == 2) {
              this.top3annouce = this.currentAnnoucements[2]
            }
          }
        })
  }

  top1: 0;
  top2: any;
  top3: any;
  getNewsDetails() {

    this.context.httpService.get(environment.mediaCenterUrl + this.mediaURL + MediaType.News).
      subscribe(
        (response) => {
          let model: MediaDataModel = { data: response };
          this.data.set(MediaType.News, model);
          this.currentNews = (response || []);
          for (var i = 0; i < this.currentNews.length; i++) {
            if (i == 0) {
              this.top1 = this.currentNews[0]
            }
            if (i == 1) {
              this.top2 = this.currentNews[1]
            }
            if (i == 2) {
              this.top3 = this.currentNews[2]
            }
          }
        })
  }

  getEventsDetails() {
    this.currentEvents = [];
    this.currentEventsArr = [];
    this.dataSet = [];
    this.dateCustomClasses = [];
    this.context.httpService.get(environment.mediaCenterUrl + this.mediaURL + MediaType.Event).
      subscribe(
        (response) => {
          let model: MediaDataModel = { data: response };
          this.data.set(MediaType.Event, model);
          this.currentEvents = (response || []);
          for (var i = 0; i < this.currentEvents.length; i++) {
            if (i == 0) {
              this.Etop1 = this.currentEvents[0]
              localStorage.setItem('startDate', this.Etop1.startDate);
              this.edate1 = true;
            }
            if (i == 1) {
              this.Etop2 = this.currentEvents[1]
              localStorage.setItem('startDate1', this.Etop2.startDate);
              this.edate1 = false;
            }
            if (i == 2) {
              this.Etop3 = this.currentEvents[2]
            }
          }
          this.currentEvents = (response || []);
          this.currentEvents.forEach(data => {
            var exdate = moment(data.startDate).format("MM/DD/YYYY").toString();

            this.dataSet.push({ 'date': exdate, 'isAvailable': true });
          });
          let dateArray = [];
          this.dataSet.forEach((data) => {
            if (data.isAvailable == false) {
              dateArray.push(new Date(data.date))
            }
          });
          this.datesDisabled = dateArray;
          this.dateCustomClasses = this.dataSet.map((data) => {
            return { date: new Date(data.date), classes: [data.isAvailable ? 'bg-success text-white' : 'bg-danger text-white'] }
          });
          this.currentEvents.forEach(res => {
            if (res.startDate) {
              const startDateMonth = new Date(res.startDate);
              const today = new Date();
              if (startDateMonth.getMonth() === today.getMonth()) {
                this.currentEventsArr.push(res)
              }
            }
          });
        })
    this.myTimer();
  }

  getEventCalander() {

  }
  //date and time

  myTimer() {
    if (this.Etop1 || []) {
      this.currentDate = new Date();
      this.targetDate = new Date(localStorage.getItem('startDate'));
      this.cDateMillisecs = this.currentDate.getTime();
      this.tDateMillisecs = this.targetDate.getTime();
      this.difference = this.tDateMillisecs - this.cDateMillisecs;
      this.seconds = Math.floor(this.difference / 1000);
      this.minutes = Math.floor(this.seconds / 60);
      this.hours = Math.floor(this.minutes / 60);
      this.days = Math.floor(this.hours / 24);
      this.hours %= 24;
      this.minutes %= 60;
      this.seconds %= 60;
      this.hours = this.hours < 10 ? "0" + this.hours : this.hours;
      this.minutes = this.minutes < 10 ? "0" + this.minutes : this.minutes;
      this.seconds = this.seconds < 10 ? "0" + this.seconds : this.seconds;
      let url = window.location.pathname;
      if (url == "/mediacenter") {
        document.getElementById("days").innerText = this.days;
        document.getElementById("hours").innerText = this.hours;
        document.getElementById("mins").innerText = this.minutes;
        document.getElementById("seconds").innerText = this.seconds;
      }
    }
    if (this.Etop2 || []) {
      this.currentDate = new Date();
      this.targetDate = new Date(localStorage.getItem('startDate1'));
      this.cDateMillisecs = this.currentDate.getTime();
      this.tDateMillisecs = this.targetDate.getTime();
      this.difference = this.tDateMillisecs - this.cDateMillisecs;
      this.seconds = Math.floor(this.difference / 1000);
      this.minutes = Math.floor(this.seconds / 60);
      this.hours = Math.floor(this.minutes / 60);
      this.days = Math.floor(this.hours / 24);

      this.hours %= 24;
      this.minutes %= 60;
      this.seconds %= 60;
      this.hours = this.hours < 10 ? "0" + this.hours : this.hours;
      this.minutes = this.minutes < 10 ? "0" + this.minutes : this.minutes;
      this.seconds = this.seconds < 10 ? "0" + this.seconds : this.seconds;
      let url = window.location.pathname;
      if (url == "/mediacenter") {
        document.getElementById("day").innerText = this.days;
        document.getElementById("hour").innerText = this.hours;
        document.getElementById("min").innerText = this.minutes;
        document.getElementById("second").innerText = this.seconds;
      }
    }

    setInterval(this.myTimer, 10);
  }


  updateMyDate(event) {
    let checkExpiry: boolean = false;
    let startDate = moment(event).format("YYYY-MM-DD").toString();
    let queryParams = 'checkExpiry=' + checkExpiry + '&mediaType=' + MediaType.Event + '&statusid=' + 3 + '&startDate=' + startDate


    this.context.httpService.get(environment.mediaCenterUrl + this.mediaURLById + queryParams).subscribe(
      (response) => {
        if (response) {
          this.currentEventsArr = response.data;
          this.eventCalendar = true
        }
      }
    );
  }

  setTab(tabname: string) {
    if (tabname == 'News') {
      this.router.navigate(['/mediacenter/news']);
      window.scrollTo(0, 100)
    }
    else if (tabname == 'Events') {
      this.router.navigate(['/mediacenter/events']);
      window.scrollTo(0, 100)
    }
    else if (tabname == 'Announcements') {
      this.router.navigate(['/mediacenter/announcement']);
      window.scrollTo(0, 100)
    }
  }

  search1(activeTab: string) {
    this.activeTabMedia = activeTab;
    if (this.activeTabMedia == 'News') {
      this.getEvent()
    } else if (this.activeTabMedia == 'Events') {
      this.search('list')
    } else if (this.activeTabMedia == 'Announcements') {
      this.getEvent()
    } 
  }
  textWrap(word: string) {
    return word.length > 125 ? word.substring(0, 125) + "..." : word;
  }
  search(activeTab1) {
    this.activeTabMedia = 'Events'
    this.activeTab1 = activeTab1
    if (activeTab1 === 'list') {
      this.getEvent()

    }
  }
  getEvent() {
    this.currentEvents = [];
    this.dataSet = [];
    this.dateCustomClasses = [];
    this.getEventsDetails();
  }
}


export class MediaDataModel {
  data: any[];
}
