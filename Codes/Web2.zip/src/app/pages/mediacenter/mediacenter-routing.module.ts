import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MediacenterComponent } from './mediacenter.component';
import { NewsComponent } from './news/news.component';
import { EventsComponent } from './events/events.component';
import { AnnouncementsComponent } from './announcements/announcements.component';
import { NewsdetailsComponent } from './newsdetails/newsdetails.component';
import { EventsdetailsComponent } from './eventsdetails/eventsdetails.component';
import { AnnouncementsdetailsComponent } from './announcementsdetails/announcementsdetails.component';
import { Authorize } from '@app/app-core/identity/auth.guard';
import { Role } from '../../models/role.enum';


const routes: Routes = [
  {
    path: '',
    component: MediacenterComponent,
    
  },
  {
    path: 'news',
    component: NewsComponent
  },
  {
    path: 'newsdetails/:id',
    component: NewsdetailsComponent
  },
  {
    path: 'events',
    component: EventsComponent
  },
  
  {
    path: 'announcement',
    component: AnnouncementsComponent
  },
  {
    path: 'eventsdetails/:id',
    component: EventsdetailsComponent
  },
  {
    path: 'announcementsdetails/:id',
    component: AnnouncementsdetailsComponent
  }
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MediacenterRoutingModule { }
