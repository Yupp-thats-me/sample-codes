import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LangChangeEvent } from '@ngx-translate/core';
import { environment } from 'environments/environment';
import { BaseComponent } from '@app-core/base.component';
import { ContextContainer } from '@app-core/context-container';
import { mediaCenter } from '@models/mediacenter.model';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import { LangService } from '@app/services/lang.service';

@Component({
  selector: 'app-announcementsdetails',
  templateUrl: './announcementsdetails.component.html',
  styleUrls: ['./announcementsdetails.component.scss']
})
export class AnnouncementsdetailsComponent extends BaseComponent implements OnInit {
  context: ContextContainer;
  newsId: any = 0;  
  public isMediaType: string;
  Edate: string;
  Adate: string;
  isReadMore: any;
  slang: string = 'en'
  existingcount: any = 0;
  totalcount: any = 0;
  existingloggedincount: any = 0;
  totalloggedincount: any = 0; 
  studentId: any;

  announcementsDetail: mediaCenter = {
    id: 0,
    titleEn: null,
    titleAr: null,
    descriptionEn: null,
    descriptionAr: null,
    pagelink: null,
    imagelink: null,
    sourceEn: null,
    sourceAr: null,
    placeEn: null,
    placeAr: null,
    dateAnnounced: null,
    expiryDate: null,
    theme: null,
    industry: 0,
    mediaType: 2,
    status: 0 ,
    isActive: false,
    thumbNailPath: '',
    speakersEn: null,
    speakersAr: null,
    startDate: null,
    endDate: null,
    startTime: null,
    endTime: null,
    totalViews: 0,
    loggedinViews :0
  };
  additionalTabHeads: any[];
  
  

  constructor(context: ContextContainer, private router: Router,private modalService: NgbModal, private route: ActivatedRoute,private langService: LangService) {
    super(context);
    this.isMediaType = 'about';
  }

  ngOnInit(): void {
    this.additionalTabHeads = [];
    // let lan =  this.context.translateService.currentLang;
    // if(lan=='ar'){
    //   this.language = 'ar';
    // }
    this.slang = this.langService.currentlang();
 
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {     
       if (this.slang != event.lang) {
         this.slang = event.lang;
       }
     });
    this.newsId = this.route.snapshot.paramMap.get('id');
    this.getannouncementsDetail(this.newsId);
    //this.existingcount = this.announcementsDetail.totalViews;
    //this.totalcount = this.existingcount + 1;
    /*this.updatetotalviews();*/

  }

  goBack() {
    this.router.navigate(['/mediacenter/announcement']);
    window.scrollTo(0, 100);
  }

  getannouncementsDetail(id) {
    this.context.httpService.get(environment.mediaCenterUrl + "/MediaCenter/media-detail/" + id)
      .subscribe(
        (response) => {
          if (response != null) {
            this.announcementsDetail = response.data;
            this.Edate = moment.utc(this.announcementsDetail.expiryDate).format('MM-DD-YYYY');
            this.Adate = moment.utc(this.announcementsDetail.dateAnnounced).format('MM-DD-YYYY');
            this.studentId = ''
            this.studentId = this.context.getUserId();
            if (this.studentId == null) {
              this.existingcount = this.announcementsDetail.totalViews;
              this.totalcount = this.existingcount + 1;
              this.totalloggedincount = this.announcementsDetail.loggedinViews;
            }
            else {
              this.existingloggedincount = this.announcementsDetail.loggedinViews;
              this.totalloggedincount = this.existingloggedincount + 1;
              this.totalcount = this.announcementsDetail.totalViews;
            }
          }
          else {
            this.notifyError("Announcement data not available, please try again");
            this.router.navigate(['/']);
          }
          this.updatetotalviews();
        });

  }

  
  showText() {
    this.isReadMore = !this.isReadMore
 }

  updatetotalviews() {
    this.announcementsDetail.id = this.announcementsDetail.id;
    this.announcementsDetail.totalViews = this.totalcount;
    this.announcementsDetail.loggedinViews = this.totalloggedincount;
    let MediacenterDto = {
      id: this.announcementsDetail.id,
      totalViews: this.announcementsDetail.totalViews,
      loggedinViews: this.announcementsDetail.loggedinViews
    };
     this.context.httpService.put(environment.mediaCenterUrl + '/MediaCenter/update/' + MediacenterDto.id, MediacenterDto).subscribe(
          (Response) => {
         if (Response.success) {   
         }
 
     }    );
 
  }

}
