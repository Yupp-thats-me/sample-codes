import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnnouncementsdetailsComponent } from './announcementsdetails.component';

describe('AnnouncementsdetailsComponent', () => {
  let component: AnnouncementsdetailsComponent;
  let fixture: ComponentFixture<AnnouncementsdetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AnnouncementsdetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AnnouncementsdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
