import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { NgbModal, } from '@ng-bootstrap/ng-bootstrap';
import { PersonalDetail } from '@models/personalDetail';
import { FormControl, NgForm } from '@angular/forms';
import { LangService } from '@services/lang.service';
import { BaseComponent } from '@app-core/base.component';
import { ContextContainer } from '@app-core/context-container';
import { LangChangeEvent } from '@ngx-translate/core';
import { environment } from 'environments/environment';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { Router } from '@angular/router';
import { MyprofileService } from '@services/myprofile.service';
import * as moment from 'moment';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { DomSanitizer } from '@angular/platform-browser';
import { LayoutService } from '../../../../services/layout.service';
import { ErrorCode } from '../../../../app-core/constants/constants';

@Component({
  selector: 'app-dialog-popup',
  templateUrl: './dialog-popup.component.html',
  styleUrls: ['./dialog-popup.component.scss']
})

export class DialogPopupComponent extends BaseComponent implements OnInit {
  persdet: any;
  emirates = [];
  model: any = {};
  form: NgForm
  LanguageKnown = [];
  studentId: any;
  slang: string = "en"
  dateInputFormat: string;
  saveInProgress: boolean;
  urlLink: any;
  files: any[] = [];
  myImage: string;
  thumbnail: any;
  private httpClient: HttpClient;
  public tab: string;
  profilePicPath: string
  userId: any
  dropDownUrl: string = '/DropdownDetails/Acadropdowns';
  personalDetailUrl: string = '/StudentProfile/PersonalDetails/';
  bsConfig: Partial<BsDatepickerConfig>;
  futureDate: boolean = false

  personals: PersonalDetail = {
    Id: 0,
    FirstName: '',
    MiddleName: '',
    LastName: '',
    DOB: '',
    Gender: null,
    MobileNo: null,
    MobileCode: '',
    Email: '',
    EmirateId: '',
    AlternateEmail: '',
    PhoneNumber: '',
    FileName: '',
    OnlineProfile: '',
    LanguageKnown: '',
    CurrentAddressLine1: '',
    CurrentAddressLine2: '',
    CurrentZipCode: '',
    CurrentCityName: null,
    IsCurrentAddress: false,
    PermanentAddressLine1: '',
    PermanentAddressLine2: '',
    PermanentZipCode: '',
    PermanentCityName: null,
    UpdatedBy: ''
  }
  perdet = {
    LanguageKnown: [],
    DateOfBirth:''
  }
  public profile: boolean = false;
  public maskMobileNo = [0,/\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/];
  public maskTelNo = [/\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/];
  public maskEmirate = [/\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/, '-', /\d/];
  maxDate: Date;
  public data: any;
  ProfilePicUrl: string = '/StudentProfile/postProfilepic/';
  emailValidate: boolean = false;
  emirateValidate: boolean = false;
  duplicateEmirate: boolean = false;
  phoneValidate: boolean = false;
  placement: 'bottom-left';
  keyPress: number;
  @ViewChild('fileInput') fileInput;
  //public validators = [this.must_be_email];

  //public errorMessages = {
  //  //  'must_be_email': 'Your items need to start with Captial letter',

  //};
  fileValidate: boolean;
  constructor(private modalService: NgbModal, httpClient: HttpClient, private activeModal: NgbActiveModal, private myprofileService: MyprofileService,
    private langservice: LangService, private domSanitizer: DomSanitizer,contextContainer: ContextContainer, private router: Router,
    private layoutService: LayoutService) {
    super(contextContainer);
    this.httpClient = httpClient;
  }

  ngOnInit(): void {
    this.getPersonals();
    this.getEmirates();
    this.saveInProgress = false;
    this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {
      this.slang = event.lang
    });
    this.bsConfig = Object.assign({}, {

      dateInputFormat: 'MM/DD/YYYY'

    });
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate());
  }
  //private must_be_email(control: FormControl) {
  //  var EMAIL_REGEXP = /^[A-Z].*$/;
  //  if (!EMAIL_REGEXP.test(control.value)) {
  //      return { "must_be_email": true };
  //  }
//}
  getPersonals() {
    this.context.httpService.get(environment.academicsUrl + this.personalDetailUrl + this.getStudentId).subscribe(
      (response) => {
        this.persdet = response.data || [];

        this.personals.FirstName = this.persdet.firstName
        this.personals.MiddleName = this.persdet.middleName
        this.personals.LastName = this.persdet.lastName
        this.personals.Email = this.persdet.email
      }
    );
  }

  get getStudentId(): Number {
    this.studentId = this.context.authenticationService.getStudentId();
    var access_token = this.studentId.source.value;
    return access_token;
    //return 2;
  }

  //close(){
  //  // this.dialogRef.close();
  //  this.activeModal.close('success');
  //}
  onSubmit(form: NgForm) {
    this.emirateValidate = this.personals.EmirateId.indexOf('_') > -1;
    this.phoneValidate = this.personals.PhoneNumber.indexOf('_') > -1;
    this.fileValidate=this.fileInput.nativeElement.value.length > 0
    if(!this.fileValidate){
      return this.notifyError('Please update your profile picture');
    }

    if (form.invalid || this.emirateValidate || this.phoneValidate|| !this.fileValidate) {
      return this.notifyError('Please enter all the mandatory fields');
    }

    this.changesInPersonal(form)
  }

  changesInPersonal(form: NgForm) {
    let lang_arr = [];
    this.perdet.LanguageKnown.forEach(lang => {
      lang_arr.push(lang.value)
    });

    this.personals.LanguageKnown = lang_arr.toLocaleString();
    var DOB = this.perdet.DateOfBirth;
    this.personals.DOB = moment(DOB).format("YYYY-MM-DD").toString();
    // this.personals.MobileCode = form.value.mobileCode.replace('C','');
    //var edate = new Date(DOB);

    var id = this.getStudentId;
    this.personals.MobileNo = +form.value.MobileNo
    if (this.personals.Email == this.personals.AlternateEmail) {
      this.emailValidate = true;
    }
    else {
      this.emailValidate = false;
    }
    if (this.emailValidate != true) {
      this.saveInProgress = true;
      this.context.httpService.put(environment.academicsUrl + this.personalDetailUrl + id,
        this.personals).subscribe(
          (response) => {
            if (response.success) {
              this.saveInProgress = false;
              this.activeModal.close(true);
              this.notifySuccess('Saved Succesfully')
              this.myprofileService.profEmit(true);
            }

            else if (response.errorCode == ErrorCode.Duplicate) {
              this.notifyError("Emirate Id already exists");
              this.duplicateEmirate = true;
              this.saveInProgress = false;
            }

            else {
              this.saveInProgress = false;
              this.notifyError('Failed to save data')
            }
          }, (error) => {
            this.saveInProgress = false;
          });
    }
  }

  //dateValid(event): boolean {
  //  const charCode = (event.which) ? event.which : event.keyCode;
  //  if ((charCode > 46 && charCode < 58) || charCode == 46) {
  //    return true;
  //  }
  //  return false;
  //}
  selectFile(event) {
    if (event.target.files && event.target.files.length > 0) {
      var reader = new FileReader()
      reader.readAsDataURL(event.target.files[0])
      reader.onload = (event: any) => {
        this.urlLink = event.target.result
      };
      var size = event.target.files[0].size
      if (size > 1048576) {
        this.context.notificationService.error('Upload the image less than 1 MB')
        return;
      }
      const formData = new FormData();

      formData.append('files[0]', event.target.files[0]);
      formData.append('profilePicDetails.studentId', this.getStudentId.toString());

      formData.append('profilePicDetails.updatedBy', this.getUserId.toString());

      let file = event.target.files[0];

      let url = window.URL.createObjectURL(file);

      let tokenKeycloakInfo = localStorage.getItem('keycloakSession');

      const httpOptions = {
        headers: new HttpHeaders({
          "Authorization": "Bearer " + tokenKeycloakInfo
        })
      };

      this.httpClient.post(environment.academicsUrl + this.ProfilePicUrl, formData, httpOptions).subscribe(
        (response: any) => {

          if (response.success) {
            this.profilePicPath = response.data.fileName;
            //this.context.notificationService.success('Image Uploded Sucessfully')
            this.getProfilePic(response.data.profilePic, response.data.fileName);
          }
        },
        // (error) => { },
        // () => { this.getProfilePic(file.name);}

      );
    }
  }

  getProfilePic(data, fileName) {

    if (data) {

      let file = this.createFile(data, fileName);

      let url = window.URL.createObjectURL(file);

      this.thumbnail = this.domSanitizer.bypassSecurityTrustUrl(url);
    }
  }
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  get getUserId(): string {
    this.userId = this.context.authenticationService.getUserId();
    var access_token = this.userId.source.value;
    return access_token;
  }
  getEmirates() {
    this.context.httpService.get(environment.academicsUrl + this.dropDownUrl).subscribe(
      (response) => {
        this.emirates = response.data.emirates || [];
      }
    );
  }
  fileSelect(event) {
    var src = this.thumbnail;
    if (src) {
      window.open(src.changingThisBreaksApplicationSecurity, '_blank')

    }

  }
  trackById(index: number, emirates: any): number {
    return emirates.emiratesId;
  }

  copyaddress(event, f) {

    if (event.target.checked) {
      this.personals.PermanentAddressLine1 = this.personals.CurrentAddressLine1
      this.personals.PermanentAddressLine2 = this.personals.CurrentAddressLine2
      this.personals.PermanentCityName = this.personals.CurrentCityName
      this.personals.PermanentZipCode = this.personals.CurrentZipCode
    } else {
      this.personals.PermanentAddressLine1 = ''
      this.personals.PermanentAddressLine2 = ''
      this.personals.PermanentCityName = null
      this.personals.PermanentZipCode = ''
    }

  }

  addressChange() {
    if (this.personals.IsCurrentAddress == true) {
      this.personals.PermanentAddressLine1 = this.personals.CurrentAddressLine1
      this.personals.PermanentAddressLine2 = this.personals.CurrentAddressLine2
      this.personals.PermanentCityName = this.personals.CurrentCityName
      this.personals.PermanentZipCode = this.personals.CurrentZipCode
    }
  }

  clrEmail() {
    this.emailValidate = false;
  }

  clr() {
    if (moment(this.personals.DOB).isAfter(new Date())) {
      this.futureDate = true
      this.personals.DOB = '';
    }
    else {
      this.futureDate = false
    }
  }

  clremirate() {
    this.emirateValidate = false;
  }
  clrPhonNo() {
    this.phoneValidate = false;
  }
  checkLang(event) {
    var charCode;
    charCode = event.charCode;
    return ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123));
  }

  getImageHTML(url) {
    return '<img src = "' + url + '" />';
  }

  sanitize(url) {
    return this.domSanitizer.bypassSecurityTrustUrl(url);
  }

  langaugeChange(event){
    if (event.target.value === 'en') {
      this.setLtrLayout();
    }else{
      this.setRtlLayout();
    }
  }
  setRtlLayout() {
    const flag = true;
    this.changeRtlLayout(flag);
  }

  setLtrLayout() {
    const flage = false;
    this.changeLtrLayout(flage);
  }

  changeRtlLayout(flag: boolean) {
    if (flag) {
      document.querySelector('body').classList.add('able-pro-rtl');
    } else {
      document.querySelector('body').classList.remove('able-pro-rtl');
    }
    this.langservice.enableArab();
    this.layoutService.enableRTL();
  }

  changeLtrLayout(flage: boolean) {
    if (flage) {
      document.querySelector('body').classList.add('able-pro-rtl');
    } else {
      document.querySelector('body').classList.remove('able-pro-rtl');
    }
    this.langservice.enableEnglish();
    this.layoutService.disableRTL();
  }
}
