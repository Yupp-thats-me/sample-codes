import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { APP_INITIALIZER, ErrorHandler, NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from './shared/shared.module';
import { AppComponent } from './app.component';
import { AdminComponent } from './layout/admin/admin.component';
import { AuthComponent } from './layout/auth/auth.component';
import { ToggleFullScreenDirective } from './shared/full-screen/toggle-full-screen';

/ Menu Items /
import { NgbAccordionModule, NgbButtonsModule, NgbCarouselModule, NgbDropdownModule, NgbTabsetModule, NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { httpInterceptor } from '@interceptor/httpInterceptor';
import { ErrorInterceptor } from '@interceptor/errorInterceptor';
import { AuthenticationService } from '@services/authentication.service'
import { OAuthModule } from 'angular-oauth2-oidc';
import { SnotifyModule, SnotifyService, ToastDefaults } from 'ng-snotify';
import { ContextContainer } from '@app-core/context-container';
import { ConfigurationComponent } from './layout/shared/configuration/configuration.component';
import { FooterComponent } from 'app/layout/shared/footer/footer.component';;
import { NavBarComponent } from 'app/layout/shared/nav-bar/nav-bar.component';
import { NavLeftComponent } from 'app/layout/shared/nav-bar/nav-left/nav-left.component';
import { NavRightComponent } from 'app/layout/shared/nav-bar/nav-right/nav-right.component';
import { NavSearchComponent } from 'app/layout/shared/nav-bar/nav-left/nav-search/nav-search.component';
import { NavigationComponent } from 'app/layout/shared/navigation/navigation.component';
import { NavContentComponent } from 'app/layout/shared/navigation/nav-content/nav-content.component';
import { NavGroupComponent } from 'app/layout/shared/navigation/nav-content/nav-group/nav-group.component';
import { NavCollapseComponent } from 'app/layout/shared/navigation/nav-content/nav-collapse/nav-collapse.component';
import { NavItemComponent } from 'app/layout/shared/navigation/nav-content/nav-item/nav-item.component';
import { NavigationItem } from 'app/layout/shared/navigation/navigation';

//admin
import { AdminlayoutComponent } from './layout/sj-admin/adminlayout/adminlayout.component';
import { AdminComponentUser } from './layout/sj-admin/admin.component'
import { CommonModule, DatePipe } from '@angular/common';
import { GlobalErrorHandler } from './app-core/handlers/global-error-handler';
import { FormsModule } from '@angular/forms';
import { KeycloakAngularModule, KeycloakService } from 'keycloak-angular';
import { AutofocusDirective } from './app-core/customDirectives/autofocus.directive';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
// import { initializer } from '../app-init';
import { NavTextComponent } from 'app/layout/shared/navigation/nav-content/nav-text/nav-text.component';
import { AppSettings, APP_CONFIG, APP_DI_SETTINGS } from './app-core/config/app-settings';
import { NgxPaginationModule } from 'ngx-pagination';
import { Authorize } from './app-core/identity/auth.guard';
import { AccountService } from './services/account.service';
import { SharedemailModule } from './pages/sharedemail/sharedemail.module';
import { SocialLoginModule, SocialAuthServiceConfig } from '@abacritt/angularx-social-login';
import {
  GoogleLoginProvider,
  FacebookLoginProvider
} from '@abacritt/angularx-social-login';

import {
  IPublicClientApplication,
  PublicClientApplication,
  BrowserCacheLocation
} from '@azure/msal-browser';
import { OAuthSettings } from '../app/services/oauth';
import {
  MsalModule,
  MsalService,
  MSAL_INSTANCE
} from '@azure/msal-angular';
import { JwtModule } from '@auth0/angular-jwt';


let msalInstance: IPublicClientApplication | undefined = undefined;



export function MSALInstanceFactory(): IPublicClientApplication {
  msalInstance = msalInstance ?? new PublicClientApplication({
    auth: {
      clientId: OAuthSettings.appId,
      redirectUri: OAuthSettings.redirectUri,
      postLogoutRedirectUri: OAuthSettings.redirectUri
    },
    cache: {
      cacheLocation: BrowserCacheLocation.LocalStorage,
    }
  });

  return msalInstance;
}


export function tokenGetter() {
  return localStorage.getItem("userToken");
}



//function initializeKeycloak(keycloak: KeycloakService) {

//  return () =>
//    keycloak.init({
//      config: {
//        url: environment.keycloakUrl,
//        realm: 'master',
//        clientId: 'sjp',
//      },
//      initOptions: {
//        //onLoad: '',
//        redirectUri:
//          window.location.origin + '/',
//      },
//    });
//}


@NgModule({
  declarations: [
    AppComponent,
    AdminComponent,
    AuthComponent,
    NavigationComponent,
    NavContentComponent,
    NavGroupComponent,
    NavCollapseComponent,
    NavItemComponent,
    NavTextComponent,
    NavBarComponent,
    NavLeftComponent,
    NavSearchComponent,
    NavRightComponent,
    ConfigurationComponent,
    ToggleFullScreenDirective,
    FooterComponent,
    AdminlayoutComponent,
    AdminComponentUser,
    AutofocusDirective
  ],
  imports: [
    NgxPaginationModule,
    CommonModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    SharedModule,
    SharedemailModule,
    NgbDropdownModule,
    NgbTooltipModule,
    NgbModule,
    NgbAccordionModule,
    NgbButtonsModule,
    HttpClientModule,
    NgbCarouselModule,
    SnotifyModule,
    FormsModule,
    OAuthModule.forRoot({
      resourceServer: {
        allowedUrls: ['http://localhost:5000/api', 'https://localhost:44304/', 'https://localhost:44362/'],
        sendAccessToken: true
      }
    }),
    JwtModule.forRoot({
      config: {
        tokenGetter: tokenGetter
      }
    }),
    KeycloakAngularModule,
    MsalModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: httpTranslateLoader,
        deps: [HttpClient]
      }
    }),
  ],


  providers: [NavigationItem,
    { provide: HTTP_INTERCEPTORS, useClass: httpInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    //authorizationcheck,
    Authorize,
    AccountService,
    AuthenticationService,
    ContextContainer,
    DatePipe,
    { provide: ErrorHandler, useClass: GlobalErrorHandler },
    { provide: 'SnotifyToastConfig', useValue: ToastDefaults },
    {
      provide: 'SocialAuthServiceConfig',
      useValue: {
        autoLogin: false,
        providers: [
          {
            id: GoogleLoginProvider.PROVIDER_ID,
            provider: new GoogleLoginProvider(
              '461777353190-7v94265p5c4r2239jd20cfrf7hpdar5f.apps.googleusercontent.com'
            )
          },
          {
            id: FacebookLoginProvider.PROVIDER_ID,
            provider: new FacebookLoginProvider('clientId')
          }
        ],
        onError: (err) => {
          console.error(err);
        }
      } as SocialAuthServiceConfig,
    },
    {
      provide: APP_CONFIG,
      useValue: APP_DI_SETTINGS
    },
    SnotifyService,
    {
      provide: MSAL_INSTANCE,
      useFactory: MSALInstanceFactory
    },
    MsalService
  ],
  bootstrap: [AppComponent]
})  

export class AppModule {

}

export function httpTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http);
}
