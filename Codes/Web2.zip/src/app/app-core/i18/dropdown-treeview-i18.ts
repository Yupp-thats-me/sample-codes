import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { TreeviewI18n, TreeviewSelection } from 'ngx-treeview';

@Injectable()
export class DropdownTreeviewI18n extends TreeviewI18n {

    constructor(private translateService: TranslateService) {
        super();

    }

    getText(selection: TreeviewSelection): string {
        if (selection.uncheckedItems.length === 0) {
            if (selection.checkedItems.length > 0) {
                return this.getAllCheckboxText();
            } else {
                return '';
            }
        }
        switch (selection.checkedItems.length) {
            case 0:
                return this.translate('SelectOptions');
            case 1:
                return selection.checkedItems[0].text;
            default:
                return this.translate('SelectedOptions').replace('{0}',selection.checkedItems.length.toString());
        }
    }

    getAllCheckboxText(): string {
        return this.translate('All');
    }

    getFilterPlaceholder(): string {
        return this.translate('Filter');
    }

    getFilterNoItemsFoundText(): string {
        return this.translate('NoItemsFound');
    }

    getTooltipCollapseExpandText(isCollapse: boolean): string {
        return isCollapse ? this.translate('Expand') : this.translate('Collapse');
    }

    private translate(msg) {

        let translatedMsg = '';

        this.translateService.get(msg).subscribe(msg => { translatedMsg = (msg || '').toString(); });

        return translatedMsg;
    }
}