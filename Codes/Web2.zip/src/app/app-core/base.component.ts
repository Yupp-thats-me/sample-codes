import { ElementRef, Injectable, OnInit, QueryList, OnChanges, ViewChildren, SimpleChanges, Input, OnDestroy } from '@angular/core';
import { Subject, Subscription } from 'rxjs';
import { ContextContainer } from 'app/app-core/context-container';
import { environment } from 'environments/environment'; // used by derived components. Please do not remove.
import { NgForm } from '@angular/forms';
import { DataTableDirective } from 'angular-datatables';
import { FileResponseCode } from './models/file-lib';
import { FileUploadControl } from '@iplab/ngx-file-upload';
import { FileUtility } from './utilities/file-utility';
import * as moment from 'moment';
import { LangChangeEvent } from '@ngx-translate/core';
import { DoCheck, KeyValueDiffers, KeyValueDiffer } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export abstract class BaseComponent implements OnInit, DoCheck,OnDestroy {
  differ: KeyValueDiffer<string, any>;
  @ViewChildren(DataTableDirective) private dtDirectives: QueryList<DataTableDirective>;
  @Input('fileUpload') myContent: string;
  dtTriggers: Map<string, Subject<any>> = new Map<string, Subject<any>>();
  context: ContextContainer;
  protected isAnyChange: boolean = false;

  studentId: number;

  baseURL: string;

  private removeBTN = $('.remove-btn');

  environment = environment;
  el: ElementRef;
  private isAlive$ = new Subject<any>();

  saveInProgress: boolean;
  datatableElement: any;

  private invalidFiles: Set<string>;

  get hasInvalidFiles(): boolean {
    return (this.invalidFiles && this.invalidFiles.size > 0);
  };

  //below config is used for Summernote control
  config = {
    //placeholder: '',
    hidden: true,
    tabsize: 2,
    height: '250px',
    //uploadImagePath: '/api/upload',
    toolbar: [
      ['view', ['codeview', 'undo', 'redo', 'fullscreen']],
      ['style', ['bold', 'italic', 'underline']],
      ['font', ['strikethrough', 'superscript', 'subscript', 'clear']],
      ['fontsize', ['fontname', 'fontsize', 'color']],
      ['para', ['style', 'ul', 'ol', 'paragraph', 'height']],
      ['insert', ['ltr', 'rtl']],
      ['insert', ['table', 'picture', 'link', 'video', 'hr']]
    ],
    fontNames: ['Helvetica', 'Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 'Roboto', 'Times']
  }

  dtOptions: DataTables.Settings = {};
  translateObservable: Subscription;
  lang: string = "en";

  constructor(context: ContextContainer, el?: ElementRef) {

    this.context = context;
    this.saveInProgress = false;
    this.el = el;
    this.initDefaultDTTrigger();
    // this.loggedIn();
    this.invalidFiles = new Set<string>();

    this.translateObservable = this.context.translateService.onLangChange.subscribe((event: LangChangeEvent) => {

      if (this.lang != event.lang) {
        this.lang = event.lang;
        this.updateDropzoneLang();
      }
    });

  //  alert('value updated');
  }

  ngDoCheck() {

    this.updateFileUploadRemoveButton();
    this.updateInputTagLang();
  }

  abstract ngOnInit();

  baseInit() {

  }
  loginValue
  loggedIn() {
    var body = document.getElementById('breadcrumb');
    this.loginValue = this.context.accountService.getUserRole();
    if (this.loginValue.source.value !== " ") {
      body.classList.remove('login');
    }
    else {
      body.classList.add('login');
    }
  }

  private initDefaultDTTrigger() {

    this.dtTriggers.set('datatable', new Subject<any>());
  }

  protected setDTTriggers(datatablesIds: string[]) {
    for (let id of datatablesIds) {
      this.dtTriggers.set(id, new Subject<any>());
    }
  }

  getDTTrigger(datatableId?: string) {

    if (!this.dtTriggers.has(datatableId || ''))
      return this.dtTriggers[0];
    else
      return this.dtTriggers.get(datatableId);
  }

  protected notifySuccess(msg: string, title?: string) {
    let translatedMsg = this.context.notificationService.translate(msg);
    this.context.notificationService.success(translatedMsg, '');
  }

  protected notifyError(msg: string, title?: string) {
    let translatedMsg = this.context.notificationService.translate(msg);
    this.context.notificationService.error(translatedMsg, '');
  }

  ngOnDestroy() {
    // this.isAlive$.next();
    // this.isAlive$.complete();

    this.context.datatableService.destroyDatatables();

  }

  protected validateForm(form: NgForm): boolean {

    if (this.el) {
      for (const key of Object.keys(form.controls)) {
        if (form.controls[key].invalid) {
          const invalidControl = this.el.nativeElement.querySelector('[name="' + key + '"]');
          invalidControl.focus();
          break;
        }
      }
    }
    else {
      console.warn('el:ElementRef is not initialized by ' + this.constructor.name);
    }
    if (form.invalid) {
      return false;
    }
    else return true;
  }

  protected createFile(baseString, filename): File {

    if (baseString && filename) {
      var arr = baseString.split(','),
        mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]),
        n = bstr.length,
        u8arr = new Uint8Array(n);

      while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
      }
      return new File([u8arr], filename, { type: mime });
    }
    else {
      return null;
    }
  }

  protected showCardProgress(cardId: string) {
    $('#' + cardId).addClass('card-load');

    $('#' + cardId).append('<div class="card-loader ng-tns-c94-0 ng-star-inserted"><i _ngcontent-eci-c94="" class="pct-loader1 anim-rotate ng-tns-c94-0"></i></div>');
  }

  protected hideCardProgress(cardId: string) {
    $('#' + cardId).removeClass('card-load');
    let progressDiv = $('#' + cardId).find('.card-loader');
    $(progressDiv).remove();
  }

  protected setFormReadonly(formId: string, isReadOnly: boolean) {

    if (isReadOnly) {
      $('#' + formId).wrap('<fieldset disabled></fieldset>');
    }
    else {
      $('#' + formId).unwrap('<fieldset></fieldset>');
    }
  }

  protected validateFile(files: any, allowedFiles: string): string {

    let msg = '';

    if (files && files.length > 0) {

      files.forEach((file: Blob) => {
        let response = this.context.fileUtility.validateFile(file, allowedFiles);
        let allowedSize = this.context.fileUtility.getAllowedSize(file.type);

        if (response == FileResponseCode.LimitExceeded) {
          if (file.size > 0 && allowedSize > 0) {

            let allowedSizeInMB = allowedSize / 1000000 + 'MB';
            msg = this.context.notificationService.translate('FileLimitExceeded').replace('{0}', allowedSizeInMB.toString());

          }
        }
        else if (response == FileResponseCode.NotAllowed) {

          //let fileType = this.context.fileUtility.getFileType(file.type);

          // if(fileType != 'doc')
          // {
          //   allowedFiles = this.context.fileUtility.getAllowedTypes(file.type);
          // }  

          msg = this.context.notificationService.translate('FileTypeNotAllowed').replace('{0}', allowedFiles);

        }
        else if (response == FileResponseCode.Unknown) {
          // need to handle.
        }
        if (msg) {
          if (!this.invalidFiles.has(allowedFiles))
            this.invalidFiles.add(allowedFiles);
        }
      });
    }

    if (allowedFiles && (!files || files.length == 0)) {
      this.invalidFiles.delete(allowedFiles);
    }

    return msg;
  }

  public getDate(date: any) {

    if (date) {
      return moment(date).format('DD/MM/YYYY');
    }

    return '';
  }

  public updateDropzoneLang() {

    let dragDropText = this.context.notificationService.translate("Drag and drop");
    let filesText = this.context.notificationService.translate("files");
    let clickHereText = this.context.notificationService.translate("ClickHere");

    var html = '<b _ngcontent-fgp-c187="" class="drag-drop-container">' + dragDropText + '</b> ' + filesText;

    html += '<br>' + clickHereText;

    $('.upload-text').html(html);

    let removeText = this.context.notificationService.translate("remove");
    $('.remove-btn').text(removeText);

  }


  updateFileUploadRemoveButton() {

    if ($('.remove-btn').length > 0) {

      const t = this;

      const removeText = this.context.notificationService.translate("remove");

      $('.remove-btn').each(function (i, item) {

        const btnText = $(item).text();

        if (btnText != removeText) {
          $(item).text(removeText);
        }
      });
    }
  }



  updateInputTagLang() {

    if ($('tag-input-form input').length > 0) {

      const placeholderText = this.context.notificationService.translate("tagPlaceholder");

      $('tag-input-form input').each(function(i, item){

          let placeholder = $(item).attr('placeholder');

        if(placeholder != placeholderText)
        {
            $(item).attr('placeholder', placeholderText);
        }
      })
    }
  }


}
