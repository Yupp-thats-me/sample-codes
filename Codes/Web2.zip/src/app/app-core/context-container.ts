import { Injectable } from "@angular/core";
import { HttpService } from "./http/http.service";
import { NotificationService } from "./notification/notification.service";
import { TranslateService } from '@ngx-translate/core';
import { AuthenticationService } from "@services/authentication.service";
import { DatePipe } from "@angular/common";

import { DatatableService } from "@app/services/datatable.service";

import { AppConfiguration } from "read-appsettings-json";
import { FileUtility } from "./utilities/file-utility";
import { AccountService } from "@app/services/account.service";
import { UserModel } from "./models/user-model";




@Injectable({
    providedIn: 'root'
  })

export class ContextContainer
{
  httpService:HttpService;
  notificationService: NotificationService;
  translateService: TranslateService;
  currentComponent:string;
  authenticationService:AuthenticationService;
  datePipe:DatePipe;
  datatableService:DatatableService;
  appSettings:any;
  fileUtility:FileUtility;
  accountService:AccountService;

  public externalToken:any;

  constructor(httpService: HttpService, notificationService: NotificationService, translateService: TranslateService,
     authenticationService:AuthenticationService,datatableService:DatatableService,fileUtility:FileUtility, accountService:AccountService
  ){

      this.httpService = httpService;
      this.notificationService = notificationService;
      this.translateService = translateService;
      this.authenticationService = authenticationService;
      this.datatableService = datatableService;
      this.appSettings = AppConfiguration.Setting();
      this.fileUtility = fileUtility;
      this.accountService = accountService;
    
     //this.accountService.init(this.httpService);
    }

    getUserDetails(){

      let data:any = this.accountService.getCurrentUser();
      var access_token = data.source.value;
      return access_token;

    }

    getProfilePic(){
      let data:any = this.accountService.getProfilePic();
      var access_token = data.source.value;
      return access_token;
    }

    getUserId(): number {
      let id:any = this.accountService.getUserId();
      var access_token = id.source.value;
      let userId = access_token;

      return userId;
    }

    getRoles()
    {
      let id:any = this.accountService.getUserRole();
      var access_token = id.source.value;
      let role = access_token;
      return role;
    } 

    getUserToken()
    {
      let id:any = this.accountService.getUserToken();
      var access_token = id.source.value;
      let token = access_token;
      return token;
    }

}
