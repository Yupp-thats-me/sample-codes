import { ErrorHandler, Injectable, NgZone } from "@angular/core";
import { LogService } from "@app-core/services/log.service";

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
  logService:LogService;
  zone:NgZone;

  constructor(logService:LogService, zone:NgZone) {
      this.logService = logService;
      this.zone = zone;
  }

  handleError(error: Error) {

    this.zone.run(() =>
    this.logService.log(error));
    console.log(error);
  }
}
