import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from "@angular/router";
import { Role } from "@app/models/role.enum";
import { AccountService } from "@app/services/account.service";

import { ContextContainer } from '../context-container';

@Injectable({ providedIn: 'root' })
export class Authorize implements CanActivate {
  constructor(
    private router: Router,
    private accountService: AccountService
  ) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    const currentUser = this.accountService.currentUserValue;
    if (currentUser) {

      if(currentUser.roles[0] == Role.External)
      {
        this.router.navigate(['admin/manage-users/register/external']);
      }

      let currentuserrole = currentUser.roles[0];

      // check if route is restricted by role
      if ((route.data.roles || []).length == 0 || this.arrayCompare(route.data.roles, currentUser.roles)) {
       
        return true;  
      }
      else if (currentuserrole == Role.ContentApprover || currentuserrole == Role.SuperAdmin || currentuserrole == Role.CXO || currentuserrole == Role.InternshipCounsellor || currentuserrole == Role.HEI || currentuserrole == Role.GEI || currentuserrole == Role.Employer) {
        // Navigate admin users to admin screen unauthorized page
        this.router.navigate(['admin/manage-users/unauthorized-screen']);
        return false;
      } else {
        // role not authorised so redirect to home page

        if (this.router.url.includes('login?returnUrl')) {
          if (currentuserrole == null || currentuserrole == Role.Student || currentuserrole == Role.General || currentuserrole == Role.Counsellor) {
            this.router.navigate(['/home-page']);
          } else {
            this.router.navigate(['/admin']);
          }
          return true;
        }
        else {
          this.router.navigate(['user/unauthorized']);
          return false;
        }

      }
      // this.router.navigate(['/']);
      //     return false;

      // authorised so return true

    }

    // not logged in so redirect to login page with the return url
    this.router.navigate(['user/login'], { queryParams: { returnUrl: state.url } });
    return false;
  }

  arrayCompare(_arr1, _arr2) {

    let matched = false;
    _arr1.forEach(element => {

      _arr2.forEach(element2 => {

        if (element == element2) {
          matched = true;
          return;
        }
      });
    });

    return matched;

  }
}
