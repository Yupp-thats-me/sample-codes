export class Constants
{
   public static defaultProfilePic:string= "";

}

export enum DateFormat
{
   Date='MM-DD-YYYY',
}

export enum ErrorCode
{
   Duplicate = 50001,
   DateValidate = 50002
}
