import { HttpClient, HttpErrorResponse, HttpHandler, HttpHeaders, HttpParams, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { NotificationService } from '../notification/notification.service';
import { saveAs } from 'file-saver';
import { catchError, takeUntil } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  notification:NotificationService;

  baseURL:string;

  errorCodes:Map<number,string>;

  constructor(private http: HttpClient, notification:NotificationService)
  {
      this.notification = notification;
      this.defineErrorCodes();
  }

  get(url: string, options?: {}): Observable<any> {


    
    return this.http.get(url, options).pipe(
      catchError(error => {
        //this.handleError(error)
        return throwError(error);
      })
    );
  }

  put(url: string, body: Object = {}, options?: {}): Observable<any> {
    return this.http.put(url,
      JSON.stringify(body), options
    ).pipe(
      catchError(error => {
        //this.handleError(error)
        return throwError(error);
      })
    );
  }

  post<T>(url: string, body: Object = {}, options?: {}): Observable<any> {

     let dataType = body != null ? body.constructor.name : '';

    if(dataType != 'FormData')
    {
      body = JSON.stringify(body)
    }

    return this.http.post<any>(url,
      body,options
    ).pipe(
      catchError(error => {
        //this.handleError(error)
        return throwError(error);
      })
    );
  }

  postFile<T>(data:FormData) {

     

  }

  downloadFile(fileName: string, url: string,  options?:{}) {

    this.http.get(url, { ...options, responseType: 'blob' }).subscribe(
      (response:any)=>{ 
        let file = new Blob([response], { type: response.type });
        saveAs(file, fileName);
      },
      //(error)=>{//this.handleError(error)},
      ()=>{}
    );
  }
  downloadFiles(fileName: string, url: string,  options?:{}) {

    return this.http.get(url, { ...options, responseType: 'blob' }).pipe(
      catchError(error => {
       // //this.handleError(error)
        return throwError(error);
      })
    );
  }
  getFile(fileName: string, url: string, options?:{}){

    return this.http.get(url, { ...options, responseType: 'blob' }).pipe(
      catchError(error => {
       // //this.handleError(error)
        return throwError(error);
      })
    );
  }
  
  public delete(url: string, options?: any): Observable<any>    
  {
      if(options)
      {
        if(!options.params)
          options.params = new HttpParams();
        
        options.params = options.params.set('handleResponse', options.handleResponse);
        return this.http.delete(url, options).pipe(
          catchError(error => {
           // //this.handleError(error)
            return throwError(error);
          }),
          
        );;
      }

    return this.http.delete(url).pipe(
        catchError(error => {
         // //this.handleError(error)
          return throwError(error);
        })
      );;
  }

  public deleteDoc(url: string, options?: {}): Observable<any>    
  {
    return this.http.delete(url,options).pipe(
        catchError(error => {
          ////this.handleError(error)
          return throwError(error);
        })
      );;
  }
  //CURRENTLY IN TESTING.
  // private handleError(error: any) 
  // {
  //   if (error instanceof HttpErrorResponse) {
  //     if (error.error instanceof ErrorEvent) {
  //       this.notification.error(error.message,'');
  //     } else {
  //         let errorType = this.errorCodes.get(error.status);
  //         this.notification.error(error.message,''); 
  //     } 
  //   }

  //   return false;
  // }

  defineErrorCodes(){
    // 401 is already handled in HttpErrorInterceptor
    this.errorCodes = new Map<number, string>();
    this.errorCodes.set(400,'Bad Request');
    this.errorCodes.set(402,'Payment required');
    this.errorCodes.set(403,'Un Authorized');
    this.errorCodes.set(404,'Not found');
    this.errorCodes.set(415,'Unsupported media type');
  }
}
