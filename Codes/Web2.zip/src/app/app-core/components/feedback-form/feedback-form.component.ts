import { Template } from '@angular/compiler/src/render3/r3_ast';
import { Component, ElementRef, EventEmitter, Input, OnInit, Output, TemplateRef, ViewChild } from '@angular/core';
import { NgForm, NgModelGroup } from '@angular/forms';
import { DialogPopupComponent } from '@app/pages/common-reg/component/dialog-popup/dialog-popup.component';
import { NgbModal, NgbModalConfig, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-feedback-form',
  templateUrl: './feedback-form.component.html',
  styleUrls: ['./feedback-form.component.scss']
})
export class FeedbackFormComponent implements OnInit {

  @Input()
  config:FeedbackConfiguration;

  @Input()
  feedbackQuery:string;

  queryResult:boolean=false;


  @Output() submitModal = new EventEmitter<any>();

  translateService:TranslateService;

  constructor(translateService:TranslateService, private modal: NgbModal) {
    
    this.translateService = translateService;
   }

  ngOnInit(): void {

    this.initConfig();
  }

  onSubmit(form:NgForm){

    form.setValue({'queryResult': true});
    this.submitModal.emit(form);
    this.modal.dismissAll();
   
  }

  private translate(msg){
    
    let translatedMsg = '';

    this.translateService.get(msg).subscribe(msg => { translatedMsg = (msg || '').toString(); });

    return translatedMsg;
  }

  private initConfig(){

    if(!this.config) 
      this.config = new FeedbackConfiguration();
    
    this.feedbackQuery = this.feedbackQuery || this.translate('feedback_defaultQuery');
    this.config.yesBTNValue = this.config.yesBTNValue || this.translate('feedback_yesBTNValue');
    this.config.noBTNValue = this.config.noBTNValue || this.translate('feedback_noBTNValue');
  }
  
  onYes(content:string, ngForm:NgForm) {

    ngForm.setValue({'queryResult': true});

    if(this.config.showModal)
    {
      this.modal.open(content);
    }
    else{ 
      this.onSubmit(ngForm);
    }
  }

  onNo(ngForm:NgForm){

    ngForm.setValue({'queryResult': false});
    
    this.onSubmit(ngForm);
  }
  
  onDestroy(){

  }
}

export class FeedbackConfiguration
{
  yesBTNValue?:string;
  noBTNValue?:string;
  showModal?:boolean;
  feedbackSuccess?:boolean = false;
}