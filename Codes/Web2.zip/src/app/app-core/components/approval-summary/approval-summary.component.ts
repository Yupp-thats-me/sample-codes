import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-approval-summary',
  templateUrl: './approval-summary.component.html',
  styleUrls: ['./approval-summary.component.scss']
})
export class ApprovalSummaryComponent implements OnInit {

  @Input()
  totalRecords:number=0;

  @Input()
  totalPending:number=0;

  @Input()
  totalApproved:number=0;

  @Input()
  totalRejected:number=0;

  constructor() { }

  ngOnInit(): void {
  }
}
