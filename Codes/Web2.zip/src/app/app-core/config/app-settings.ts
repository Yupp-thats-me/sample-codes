import { InjectionToken } from "@angular/core";
import { FilesLimitValidator } from "@iplab/ngx-file-upload";
import { FileSizeType, FileType } from "../models/file-lib";


export let APP_CONFIG = new InjectionToken<AppSettings>('app.config');

export class AppSettings {

    layout: string; // vertical, horizontal
    subLayout: string; // horizontal-2
    collapseMenu: boolean;
    layoutType: string; // menu-dark, menu-light, dark
    headerBackColor: string; // background-blue, background-red, background-purple, background-info, background-dark
    rtlLayout: boolean;
    navFixedLayout: boolean;
    headerFixedLayout: boolean;
    boxLayout: boolean;

    // THIS WILL BE REMOVED LATER.
    fileLimit: FileSizeType = {
        DOC: 1000000,
        File: 1000000,
        Image: 1000,
        PDF: 1000000,
        Thumbnail: 30000
    };
    //THIS IS THE REPLACEMENT OF ABOVE CODE
    fileSizeLimit: Map<FileType, number> = null;
}

export const APP_DI_SETTINGS: AppSettings = {

    fileLimit: {
        DOC: 1000000,
        File: 1000000,
        Image: 1000,
        PDF: 1000000,
        Thumbnail: 30000
    },

    fileSizeLimit: new Map<FileType, number>().set(FileType.Image, 100000)
        .set(FileType.Image, 1000000)
        .set(FileType.Video, 5000000)
        .set(FileType.Doc, 1000000)
        .set(FileType.PDF, 1000000)
        .set(FileType.Thumbnail, 30000),

    layout: 'horizontal',
    subLayout: '',
    collapseMenu: false,
    layoutType: 'menu-color2',
    headerBackColor: 'background-blue',
    rtlLayout: false,
    navFixedLayout: false,
    headerFixedLayout: false,
    boxLayout: false,
};