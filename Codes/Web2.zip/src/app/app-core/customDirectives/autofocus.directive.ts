import { Directive, ElementRef, Input } from '@angular/core';

@Directive({
  selector: '[appAutofocus]'
})
export class AutofocusDirective {


  @Input()
  public set datoAutoFocus(value) {
    if (!!value) {
      this.host.nativeElement.focus();
    }
  }

  constructor(private host: ElementRef,) { }

}
