import { NgModule } from '@angular/core';
import { NgbCarouselModule, NgbDatepickerModule, NgbDropdownModule, NgbModule, NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { LightboxModule } from 'ngx-lightbox';
import { TextMaskModule } from 'angular2-text-mask';
import { NgNumberFormatterModule } from 'ng-number-formatter';
import {  HttpClient, HttpClientModule } from '@angular/common/http';
import { FileUploadModule } from '@iplab/ngx-file-upload';
import { SharedModule } from '@app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DataTablesModule } from 'angular-datatables';
import { HomePageModule } from '@app/pages/home-page/home-page.module';
import { SnotifyModule } from 'ng-snotify';
import { TagInputModule } from 'ngx-chips';
import { AutocompleteLibModule } from 'angular-ng-autocomplete';
import { InputTrimModule } from 'ng2-trim-directive';
import { NouisliderModule } from 'ng2-nouislider';
import { BarRatingModule } from 'ngx-bar-rating';
import { DatatableComponent } from '../datatable/datatable.component';
import { Feedback } from '@app/models/feedback.model';
import { FeedbackFormComponent } from '../components/feedback-form/feedback-form.component';
import { TabComponent } from '../components/tabs/tab/tab.component';
import { TabsComponent } from '../components/tabs/tabs.component';
import { ApprovalSummaryComponent } from '../components/approval-summary/approval-summary.component';
import { ArchwizardModule } from 'angular-archwizard';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';




@NgModule({
  declarations: [DatatableComponent, FeedbackFormComponent, TabComponent, TabsComponent, ApprovalSummaryComponent],
  imports: [
    NgbDropdownModule,
    NgbTooltipModule,
    NgbCarouselModule,
    LightboxModule,
    TextMaskModule,
    NgNumberFormatterModule,
    NgbDatepickerModule,
    HttpClientModule,
    FileUploadModule,
    SharedModule,
    ReactiveFormsModule,
    FormsModule,
    DataTablesModule,
    HomePageModule,
    SnotifyModule,
    TagInputModule,
    AutocompleteLibModule,
    InputTrimModule,
    NouisliderModule,
    BarRatingModule,
    NgbModule,
    ArchwizardModule,
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: httpTranslateLoader,
        deps: [HttpClient]
      }
    })

  ],
  exports: [
    NgbDropdownModule,
    NgbTooltipModule,
    NgbCarouselModule,
    LightboxModule,
    TextMaskModule,
    NgNumberFormatterModule,
    NgbDatepickerModule,
    HttpClientModule,
    FileUploadModule,
    SharedModule,
    ReactiveFormsModule,
    FormsModule,
    DataTablesModule,
    HomePageModule,
    SnotifyModule,
    TagInputModule,
    AutocompleteLibModule,
    InputTrimModule,
    NouisliderModule,
    BarRatingModule,
    DatatableComponent,
    NgbModule,
    FeedbackFormComponent,
    TabsComponent,
    TabComponent,
    ApprovalSummaryComponent,
    ArchwizardModule
    

  ]

})
export class baseModule { }
export function httpTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http);
}