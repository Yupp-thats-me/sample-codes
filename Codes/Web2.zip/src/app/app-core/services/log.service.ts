
import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NotificationService } from 'app/app-core/notification/notification.service';

@Injectable({
  providedIn: 'root'
})
export class LogService {
  notification:NotificationService;

  constructor(notification:NotificationService) {
    this.notification = notification;
   }

  log(error)
  {
    if(error instanceof HttpErrorResponse)
    {
     // this.notification.error(this.notification.translate('FailedToCallAPIMethod'), 'Http Error');
     this.notification.error('', 'Http Error');
    }
    else
    {
      if (error instanceof TypeError) {
        // this.notification.error(error.message, 'Type Error');
    } else if (error instanceof Error) {
        this.notification.error(error.message, 'General Error');
    } else if(error instanceof SyntaxError){
        this.notification.error(error.message, 'Syntax Error');
    } else if(error instanceof RangeError){
        this.notification.error(error.message, 'Range Error');
    } else if(error instanceof URIError){
        this.notification.error(error.message, 'URI Error');
    } else {
        this.notification.error(error.message, 'Global Error');
    }
    //console.error('==>Global Error<==\n', error);
    }
  }
}
