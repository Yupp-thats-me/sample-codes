import { InjectionToken, Injector } from "@angular/core";
import { TranslateService } from "@ngx-translate/core";

module AppLib
{
    function set(){

    }
}

let _injector: Injector;

// export const appInjector = (injectorRef?: Injector):Injector => {
// 	if (injectorRef) {
//         injector = injectorRef;
// 	}

// 	return injectorRef;
// };

export function T(msg:string):string{

   return "";

}