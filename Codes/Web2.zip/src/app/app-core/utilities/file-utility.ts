import { Injectable } from "@angular/core";
import { AppConfiguration } from "read-appsettings-json";
import { AppSettings } from "../config/app-settings";
import { FileResponseCode, FileSizeType, FileType } from "../models/file-lib";
import { plainToClass, serialize } from 'class-transformer';
import { EventModel } from "@app/pages/cxo/models/eventModel";
import * as FileSaver from "file-saver";

@Injectable({
    providedIn: 'root'
})

export class FileUtility {
    fileDict: Map<string, string>;
    _fileSizeSetting: FileSizeType;

    static readonly DOC: string = 'application/doc';

    get fileSizeSetting(): FileSizeType {
        if (this._fileSizeSetting == null) {
            this._fileSizeSetting = this.getFileLimit();
        }
        return this._fileSizeSetting;
    };

    appSettings: any;

    constructor() {
        this.appSettings = AppConfiguration.Setting();
    }

    init() {
        // this function need to be initialized during app/module initialization. STILL IN DEVELOPMENT BY KARTHIK M.
    }

    private initFileDict() {

        this.fileDict = new Map<string, string>();
        this.fileDict.set('image/png', 'image');
        this.fileDict.set('image/jpeg', 'image');
        this.fileDict.set('video/webm', 'video');
        this.fileDict.set('video/mp4', 'video');
        this.fileDict.set('application/pdf', 'pdf');
        this.fileDict.set(FileUtility.DOC, 'doc');
    }

  download(base64String: string, fileName?: string) {

    FileSaver(base64String, fileName || 'file');
    return;
  }


    disable() {
        // this.control.disable();
    }

    validateFile(file: Blob, allowedTypes: string): FileResponseCode {

        let response = FileResponseCode.Unknown;

        if (!this.fileDict) {
            this.initFileDict();
        }

        let fileType = this.getFileType(file.type);

        if (!fileType || (allowedTypes && (!allowedTypes.includes(file.type))))  // this validation to prevent other than custom files.
            return FileResponseCode.NotAllowed;

        let allowedSize = this.fileSizeSetting[fileType];

        if (file.size > allowedSize) {
            response = FileResponseCode.LimitExceeded;
        }
        else if (file.size == 0) {
            response = FileResponseCode.NotAllowed;
        }

        return response;
    }

    getAllowedSize(type: string): number {
        if (type) {
            if (this.fileDict.has(type)) {
                let fileType = this.fileDict.get(type);
                return this.fileSizeSetting[fileType];
            }
        }
        else
            return null;
    }

    getFileType(type: string) {

        let fileType = null;
        if (type.includes('document')) {
            fileType = this.fileDict.get(FileUtility.DOC);
        }
        else if (this.fileDict.has(type))
            fileType = this.fileDict.get(type);

        return fileType;
    }

    getAllowedTypes(fileType: string) {

        let allowedTypes = '';

        if (fileType.includes('video'))
            allowedTypes = 'video/webm';
        else if (fileType.includes('image'))
            allowedTypes = 'image/png';
        else if (fileType.includes('doc'))
            allowedTypes = 'application/dox';
        else if (fileType.includes('pdf'))
            allowedTypes = 'document/pdf';

        return allowedTypes;
    }

    getFileLimit(): FileSizeType {

        return plainToClass(FileSizeType, this.appSettings.fileLimit);

    }
}
