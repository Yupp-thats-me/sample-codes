import { Injectable } from '@angular/core';
import { SnotifyPosition, SnotifyService, SnotifyToastConfig } from 'ng-snotify';
import 'sweetalert2/src/sweetalert2.scss';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import { Observable } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  timeout = 2000;
  position: SnotifyPosition = SnotifyPosition.centerTop;
  progressBar = false;
  closeClick = true;
  newTop = true;
  filterDuplicates = true;
  backdrop = -1;
  dockMax = 8;
  blockMax = 6;
  pauseHover = true;
  bodyMaxLength = 200;
  titleMaxLength = 100;

  translateService: TranslateService;

  constructor(private snotifyService: SnotifyService, translateService: TranslateService) {

    this.translateService = translateService;
  }

  getConfig(): SnotifyToastConfig {
    this.snotifyService.setDefaults({
      global: {
        newOnTop: this.newTop,
        maxAtPosition: this.blockMax,
        maxOnScreen: this.dockMax,
        filterDuplicates: this.filterDuplicates
      }
    });

    return {
      bodyMaxLength: this.bodyMaxLength,
      titleMaxLength: this.titleMaxLength,
      backdrop: this.backdrop,
      position: this.position,
      timeout: this.timeout,
      showProgressBar: this.progressBar,
      closeOnClick: this.closeClick,
      pauseOnHover: this.pauseHover
    };
  }


  success(message: string, title?: string) {
    this.snotifyService.success(message, title || '', this.getConfig());
  }
  error(message: string, title?: string) {
    this.snotifyService.error(message, title || '', this.getConfig());
  }


  confirmAlert(callback: Function, text?:string) {
    Swal.fire({
      title: this.translate('PleaseConfirm'),
      text: this.translate(text),
      type: 'warning',
      showCloseButton: true,
      showCancelButton: true,
      confirmButtonText: this.translate("Yes"),
      cancelButtonText: this.translate("No")
    }).
      then((confirm) => {
        callback(confirm);
      });
  }



  editDeleteALert(callback: Function,alText?:string) {
    Swal.fire({
      title: this.translate('PleaseConfirm'),
      text: this.translate(alText || 'Unsaved changes are detected Do you want to save the changes') + '?',
      type: 'warning',
      showCloseButton: true,
      showCancelButton: true,
      confirmButtonText: this.translate("Yes"),
      cancelButtonText: this.translate("No")
    }).
      then((confirm) => {
        callback(confirm);
      });
  }

  ApproveALert(callback: Function) {
    Swal.fire({
      title: this.translate('PleaseConfirm'),
      text: this.translate('Are you sure to approve') + '?',
      type: 'warning',
      showCloseButton: true,
      showCancelButton: true,
      confirmButtonText: this.translate("Approve"),
      cancelButtonText: this.translate("No")
    }).
      then((confirm) => {
        callback(confirm);
      });
  }
  RejectALert(callback: Function) {
    Swal.fire({
      title: this.translate('PleaseConfirm'),
      text: this.translate('Are you sure to reject') + '?',
      type: 'warning',
      showCloseButton: true,
      showCancelButton: true,
      confirmButtonText: this.translate("Reject"),
      cancelButtonText: this.translate("No")
    }).
      then((confirm) => {
        callback(confirm);
      });
  }
  translate(msg) {

    let translatedMsg = '';

    this.translateService.get(msg).subscribe(msg => { translatedMsg = (msg || '').toString(); });

    return translatedMsg;
  }
}
