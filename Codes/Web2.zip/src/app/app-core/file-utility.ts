//import { base64StringToBlob } from 'blob-util';

export class FileUtility
{
    constructor(){

    }

    // createBLOB(base64String:string):Blob{
    //     const contentType = 'image/png';
    //     const blob = base64StringToBlob(base64String, contentType);

    //     return blob;
    // }
}