import { Component, Input, OnInit } from '@angular/core';
import { DatatableService } from '@app/services/datatable.service';



@Component({
  selector: 'app-datatable',
  templateUrl: './datatable.component.html',
  styleUrls: ['./datatable.component.scss']
})

export class DatatableComponent implements OnInit {

  @Input() datasource: any=[];

  @Input() columns?: string[];
  @Input() advancedColumns?:DataTables.ColumnSettings[];

  @Input() tableId: string;
  @Input() order:[];
  @Input() test:string;

  dtOptions:DataTables.Settings;
  
  constructor(private apiService: DatatableService) {}

  ngOnInit() {


    if((this.columns || []).length>0 && (this.advancedColumns || []).length >0)
    throw new Error('Datatable: Either columns or advancedColumns can be used at a time');

      this.inItDtOptions();

      $(this.tableId).DataTable();
  }

  inItDtOptions() {
    this.dtOptions = {
      pagingType: 'numbers',
      pageLength: 5,
      lengthMenu: [5, 10, 15, 20, 25],
      //order: [[5, "desc"]],
      "ordering": false,
      "language": {
        "search": "",
        searchPlaceholder: '🔍',
        "info": "",
        "lengthMenu": "_MENU_",
      }
    };
  }

}

export enum ColumnType
{
  data=1,
  action=2
}
