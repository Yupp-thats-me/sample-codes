// Author : Karthik M

export enum FileType {
    Image = 1,
    Video = 2,
    Doc = 3,
    PDF = 4,
    Thumbnail = 5
}

export class FileSizeType
{
    DOC?:number;
    File?:number;
    Image?: number;
    PDF?: number
    Thumbnail?: number;
}

export enum FileResponseCode
{
    NotAllowed=1,
    LimitExceeded=2,
    OK = 10,
    Unknown = -1
}