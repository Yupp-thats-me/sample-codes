export class TagInputModel
{
    display:string;
    value:string;
}