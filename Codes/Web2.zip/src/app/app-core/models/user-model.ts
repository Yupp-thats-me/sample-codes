import { Observable } from "rxjs";

export class UserModel
{
    id:string;
    emailId:string;
    name:string;
}