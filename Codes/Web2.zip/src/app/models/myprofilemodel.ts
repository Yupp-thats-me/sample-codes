export class Myprofile {
  StudentId: number
  Mobile: number
  EmailId: string
  EmirateId: number
  Qualification: string
  Skills: string
  OnlineProfileURL: string
  CertificationName: string
  IssuingAuthority: string
  CompletedDate: string
  NameOfEvent: string
  Organization: string
  Title: string
  IsWorkingOn: string
  Publisher: string
  PublicationURL: string
}
