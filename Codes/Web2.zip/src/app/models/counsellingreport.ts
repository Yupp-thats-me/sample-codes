export class Counselling{
  
    selectDaterange:string;
    educationcategory?:any =0;
     educationcategoryId?:any =0;
     educationlevel:any =0;
    category?:any = 0;
    // CategoryId:any = null;
    // ServiceId:any = null;
    Service?:any = 0;
    gender:any=0;
    emirate:any=0;
    startTime?: string;
    endTime?: string;
    totalFaqMoeAdmin?:number;
    totalFaqPostsPosted?:number;
    totalFaqPostsRejected?:number;
    mostFaqOnCategory?:string;
    mostFaq?:string;
    mostRejected?:string;
}