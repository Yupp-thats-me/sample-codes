export class FilterDetails {
  uploadImage: string;
  internshipRoleNameEn: string;
  internshipRoleNameAr: string;
  eligibilityEn: string;
  eligibilityAr: string;
  countryId: string;
  emirateId: string;
  roleId: string;
  educationId: string;
  higherEducationId: string;
  orgId: number; 
  companyNameEn: string;
  companyNameAr: string;
  joiningDate: Date;
  applicationDeadline: Date;
  ageId: number;
  duration: number;
  postedDays: number;
  internshipTitleEn: string;
  internshipTitleAr: string;
}
