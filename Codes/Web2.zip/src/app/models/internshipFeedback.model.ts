export class InternshipFeedback {

  Id?: number;
  StudentId?: number;
  InternshipId?: number;
  ScientificLiteracy?: number;
  TechLiteracy?: number;
  FinancialLiteracy?: number;
  CriticalThinking?: number;
  Creativity?: number;
  Communication?: number;
  Collaboration?: number;
  Adaptability?: number;
  Leadership?: number;
  SocialAwarness?: number;
  Empathy?: number;
  GrowthMindset?: number;
  OverallSatisfaction?: number;
  ShortDescription?: string;
  Strength?: string;
  DevelopmentAreas?: string;
  Comments?: string;
  Term?: number;
  SupervisorName?: string;
  SupervisorDesignation?: string;
  SupervisorEmailId?: string;
  Rating?: number;
  IsApplicable?: number;
  joiningDate?: string;
  expiryDate?: string;
  Fall?: number;
  Spring?: number;
  Summer?: number;
  NewDate?: string;
  id?: number;
  UserId?: number;
  employerId:number;
  employerName?: string;
  location?: string;
  accountTYpe?: string;
  minimumHoursRequiredId?: number;
  duration?: number;
  internshipId?: number;
  studentId?: number;
  createdDate?: string;
  studentName?: string;
  email?: string;
  mobileNo?: number;
  studentLocation?: string;
  institute?: string;
  degreeName?: string;
  majorName?: string;
  status?: number;
  updatedBy?: number;
  internshipRoleNameEn?: string;
  monthlySalaryRangeId?: string
  AdminFeedbackRatingModel? : any[];
  createdBy?: string;
  anyFeedback?: string;
  StudentFeedbackRatingModel?: any[];
  feedbackAdmin?:string;
  department?:string;
  FeedbackId?:number;
}
// export interface AdminFeedbackRatingModel {
  
// id: number;
// feedbackId: number;
// parameterId: number;
// rating?: number;
// isApplicable?: boolean;
// createdBy: string;
      
// }
