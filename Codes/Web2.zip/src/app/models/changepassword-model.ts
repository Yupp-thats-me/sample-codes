export class ChangePassword {

  Id: number;
  CurrentPassword: string;
  NewPassword: string;
  ConfirmPassword: string;
  
}

