export class Volunteering {

  Id: number;
  StudentId: number;
  ReferenceId: number;
  Organization: string;
  DateOfEvent: string;
  NameOfEvent: string;
  Description: string;
  Hours: number;
  CreatedBy: string;
  UpdatedBy: string;
  //CreatedDate: Date;
  //UpdatedDate: Date;
}
