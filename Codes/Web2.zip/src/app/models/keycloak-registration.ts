export class KeycloakRegistration {

  token: string;
  userInfo: {
    userName: string,
    firstName: string,
    lastName: string,
    accountType:string,
    emailId: string,
    ResponseStatus: string,
    userId: number,
    studentId:number
  };

}
