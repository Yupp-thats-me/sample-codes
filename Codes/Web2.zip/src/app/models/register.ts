export class Register {
    Id: any;

    AccountType: string;

    UserName: string;

    Email: string;

    Password: string;

    FirstName: string;

    MiddleName: string;

    LastName: string;

    Gender: string;

    AddressL1: string;

    AddressL2: string;

    //EmirateCountry: string;

    //Address: string;

    MobileNo: number;

    PhoneNo: string;

    PhoneCode: string;

    POBoxNumber: string;

    Emirate: string;

    Residency: string;

    EmirateId: string;

    CountryId: string;

    PassportNo: string;

    DocumentNo: string;

    SecurityQuestionId: string;

  SecurityQuestionAnswer: string;

  InstituteName: string;
  EducationalZone: string;
  LicenseNumber: string;
  LicenseExpDate: Date;
  EducationalActivities: string;

  CXOcompanyName: string;
  CXOEmployerCatgory: string;
  CXOEmployeeId: string;
  CXOEmployerZone: string;
  CXOLicenseNumber: string;
  CXOLicenseExpiryDate: Date;

  EmployerName: string;
  EmployerEmpId: string;
  EmployerCatgory: string;
  EmployerZone: string;
  EmpLicenseNumber: string;
  EmpLicenseExpiryDate: Date;
}
