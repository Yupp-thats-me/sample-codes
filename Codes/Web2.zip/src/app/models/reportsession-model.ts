
export class Reportsession{
  Id: number;
  StudentId: number;
  CounsellorId: number;
  AppointmentId: number;
  Title: string;
  SessionDate: string;
  StartTime:string;
  EndTime:string;
  Description:string;
  StudentAttandance:boolean;
  Remarks:string;
  CreatedBy: string;
  UpdatedBy: string;
  IsActive: boolean;
}

export class Virtual{
    Id:number;
    StudentId :number;
    StudentName ? :string;
    StudentQualification :string
    CounsellorId :number
    CounsellorName ?:string;
    CategoryEn?:string;
    Category :number;
    Service :number;
    Languages :string;
    Subject :string;
    Purpose :string;
    Documents?:string;
    Duration :string;
    SelectedDate :string;
    StartTime :string;
    EndTime:string;
    StatusId:number;
    VirtualLink :string;
    CreatedBy: string;
    UpdatedBy: string;
    IsActive: boolean;
}
