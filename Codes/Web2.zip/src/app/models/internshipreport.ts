export class Internship {

    selectDaterange: string;
    educationCategory: any;
    educationLevel?: any;
    companyname: 0;
    internshipFor:number;
    instituteName:number;

}

export class ApplicationSummary{
selectRng: string;
educationCategory: number;
educationLevel?: number;
recruitmentStatus: number;
companyName?: number;
companyNameEn?:string;
companyNameAr?:number;
industry: number;
internshipFor:number;
totalCompaniesHigherEducationSatisfactory?: number;
totalCompaniesHigherEducationNotSatisfactory?: number;
totalCompaniesGeneralEducationSatisfactory?: number;
totalCompaniesGeneralEducationNotSatisfactory?: number;
industryName?: number;
CompanyName?: any = null

}
