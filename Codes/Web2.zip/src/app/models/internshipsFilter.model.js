"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FilterDetails = void 0;
var FilterDetails = /** @class */ (function () {
    function FilterDetails() {
    }
    return FilterDetails;
}());
exports.FilterDetails = FilterDetails;
//# sourceMappingURL=internshipsFilter.model.js.map