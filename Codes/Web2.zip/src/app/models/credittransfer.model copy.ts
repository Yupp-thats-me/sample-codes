export class CreditTransfer {

  JoiningDate: string;
  expiryDate: string;
  Postedby: string;
  
}



