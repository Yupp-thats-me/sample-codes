"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnswerDetails = exports.Feedback = void 0;
var Feedback = /** @class */ (function () {
    function Feedback() {
    }
    return Feedback;
}());
exports.Feedback = Feedback;
var AnswerDetails = /** @class */ (function () {
    function AnswerDetails() {
    }
    return AnswerDetails;
}());
exports.AnswerDetails = AnswerDetails;
//# sourceMappingURL=feedback.model.js.map