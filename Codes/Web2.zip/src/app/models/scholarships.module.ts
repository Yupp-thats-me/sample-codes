export class Scholarships {
  Id: number;
  //ReferenceId: number;
  TitleEn: string;
  TitleAr: string;
  DescriptionEn: string;
  DescriptionAr: string;
  BenefitsEn: string;
  BenefitsAr: string;
  NationalityID: number;
  HigherEducationId: string;
  MajorId: string;
  YearId: string;
  EligibilityEn: string;
  EligibilityAr: string;
  HowToApplyEn: string;
  HowToApplyAr: string;
  ApplicationUrl: string;
  ContactEmail: string;
  ExpiryDate: string;
  FileUpload: string;
  StatusID: number;
  OnBehalfOf: number;
  Active: boolean;
  CreatedBy: string;
  UpdatedBy: string;
  scholarshiptype: number;
  scholarshipfeature: number;
  UploadImage: '';
  TotalViews?: number;
  TotalScholarshipInPortal?: number;
  TotalScholarshipBachelor?: number;
  TotalScholarshipMaster?: number;
  TotalStudentsLoggedIn?: number;
  AdminName?: string;
  Nationality?: string;
  CreatedDate?: string;
  educationCategoryId?: number;
  educationLevelId?: number;
  totalScholarshipPosted?: number;
  totalScholarshipPending?: number;
  totalScholarshipApproved?: number;
  totalScholarshipRejected?: number;
  employerAdmin?: number;
  heiAdmin?: number;
  generalAdmin?: number;
  moeAdmin?: number;
  selectRng?: string;
  requestedRole?:number
}

export class ReportModuleFeedback {
  satisfiedContent: number;
  notContent: number;
  satisfiedPersonalization: number;
  notPersonalization: number;
  satisfiedDesign: number;
  notDesign: number;
  satisfiedFunctionality: number;
  notFunctionality: number;
 selectRng?: string;
 requestedRole?:number;
}
