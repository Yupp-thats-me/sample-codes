export class Credittransfer {
  Id: number;
  //ReferenceId: number;
  AcademicYear: number;
  FromHEI: number;
  ToHEI: number;
  DepartmentTo: string;
  DepartmentFrom: string;
  ArDepartmentTo: string;
  ArDepartmentFrom: string;
  MajorTo: string;
  MajorFrom: string;
  ArMajorTo: string;
  ArMajorFrom: string;
  Courses: any[];
  ExpiryDate: string;
  UploadFile: string;
  UploadId: number;
  StatusID: number;
  OnBehalfOf: number;
  Active: boolean;
  CreatedBy: string;
  UpdatedBy: string;
  Reason: string;
  DepartmentToId: number;
  DepartmentFromId: number;
  ArDepartmentToId: number;
  ArDepartmentFromId: number;
  MajorToId: number;
  MajorFromId: number;
  ArMajorToId: number;
  ArMajorFromId: number;
}

export interface Course {
  id: number;
  courseFromEn: string;
  courseToEn: string;
  courseFromAr: string;
  courseToAr: string;
}

