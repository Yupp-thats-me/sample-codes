"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MediaCenterReport = exports.mediaApproval = exports.lookUp = exports.MediaType = exports.mediaStatus = exports.mediaCenter = void 0;
var mediaCenter = /** @class */ (function () {
    function mediaCenter() {
    }
    return mediaCenter;
}());
exports.mediaCenter = mediaCenter;
var mediaStatus;
(function (mediaStatus) {
    mediaStatus[mediaStatus["Draft"] = 1] = "Draft";
    mediaStatus[mediaStatus["Pending"] = 2] = "Pending";
    mediaStatus[mediaStatus["Approved"] = 3] = "Approved";
    mediaStatus[mediaStatus["Rejected"] = 4] = "Rejected";
})(mediaStatus = exports.mediaStatus || (exports.mediaStatus = {}));
var MediaType;
(function (MediaType) {
    MediaType[MediaType["Announcement"] = 1] = "Announcement";
    MediaType[MediaType["Event"] = 2] = "Event";
    MediaType[MediaType["News"] = 3] = "News";
})(MediaType = exports.MediaType || (exports.MediaType = {}));
var lookUp = /** @class */ (function () {
    function lookUp() {
    }
    return lookUp;
}());
exports.lookUp = lookUp;
var mediaApproval = /** @class */ (function () {
    function mediaApproval() {
    }
    return mediaApproval;
}());
exports.mediaApproval = mediaApproval;
var MediaCenterReport = /** @class */ (function () {
    function MediaCenterReport() {
    }
    return MediaCenterReport;
}());
exports.MediaCenterReport = MediaCenterReport;
//# sourceMappingURL=mediacenter.model.js.map