export class CreditTransfer {

    JoiningDate: string;
    expiryDate: string;
    Postedby: number;
    selectDaterange: string;
    totalMoePosted?: number;
    totalHEIPosted?: number;
    totalHEIApproved?: number;
    totalHEIRejected?: number;
  }
export class Credit{
    
    selectDaterange?:string;
    Postedby?:any = 0;
    Academicyear?:any = 0;
    fromHei?:any = 0;
    ToHei?:any = 0;
  TotalHighestViews?:number;
  TotalLeastViews?: number;
  totalCreditViews?: number;
  


}