export class CertificationDetails {
  Id: number;
  StudentId: number;
  CertificationName: string;
  CompletedYear: string;
  IssuingAuthority: string;
  Institute: string;
  NotExpire: boolean;
  CreatedBy: string;
  UpdatedBy: string;
}
