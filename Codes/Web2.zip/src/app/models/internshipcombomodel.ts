export class internshipcombomodel {
  internshipRoleId: number;

  internshipRoleNameEn: string;

  internshipRoleNameAr: string;
 
}
