export class mediaCenter {
  id?:number
  titleEn?: string;
  titleAr?: string;
  descriptionEn?: string;
  descriptionAr?: string;
  pagelink?: string;
  imagelink?: string;
  sourceEn?: string;
  sourceAr?: string;
  placeEn?: string;
  placeAr?: string;
  dateAnnounced?: string;
  expiryDate?: string;
  theme?: string;
  industry?: number;
  mediaType?: number;
  status?: number;
  isActive?: boolean;
  thumbNailPath?: string;
  speakersEn?: string;
  speakersAr?: string;
  startDate?: string;
  endDate?: string;
  startTime?: string;
  endTime?: string;
  updatedBy?: string;
  createdBy?: string;
  totalViews?: number;
  loggedinViews?: number;
}


export enum mediaStatus {
  Draft = 1,
  Pending = 2,
  Approved = 3,
  Rejected = 4
}

export enum MediaType {
  Announcement = 1,
  Event = 2,
  News = 3
}

export class lookUp {
  UDID: string;
  UDCategoryID: string;
  UDDescriptionEn: string;
  UDDescriptionAr: string;
  UDCode: string;
  SortOrder: string;
}

export class mediaApproval {
  Id: number;
  Status: number;
  UpdatedBy: number;
  RejectReason: string;
}

export class MediaCenterReport {
  [x: string]: any;
  datePublished?: string;
  dateExpiry?: string;
  createdBy?: number;
  theme?: string;
  industry?: number;
  mostViewedNewsEn?: string;
  mostViewedNewsAr?: string;
  leastViewedNewsEn?: string;
  leastViewedNewsAr?: string;
  heiAdmin?: number;
  moeAdmin?: number;
  mostViewedEventsEn?: string;
  mostViewedEventsAr?: string;
  leastViewedEventsEn?: string;
  leastViewedEventsAr?: string;
  mostViewedAnnounceEn?: string;
  mostViewedAnnounceAr?: string;
  leastViewedAnnounceEn?: string;
  leastViewedAnnounceAr?: string;
  mostViewEn?: string;
  mostViewAr?: string;
  leastViewEn?: string;
  leastViewAr?: string;
  selectRng?: string;
  OnBehalfOf?: number;
  totalNewsSummary?:number;
  totalEventSummary?:number;
  totalAnnouncementSummary?:number;
  totalAnnouncementsListingStatistics?:number;
  totalNewsListingStatistics?:number;
  totalEventsListingStatistics?:number; 
  requestedRole?:number;
  mediaType?:number;
}
