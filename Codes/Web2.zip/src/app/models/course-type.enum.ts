export enum CourseType
{
    FullTime = 1,
    PartTime = 2
}