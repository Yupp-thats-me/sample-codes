export class CxoReport {

    JoiningDate: string;
    expiryDate: string;
    OrgType: number;
    Emirates: number;
    CompanyTypeId: string;
    selectDaterange: string;
    TotalCXO?:number;
    TotalCXOPublic?: number;
    TotalCXOPrivate?: number;
    TotalCXOPosted?:number;
    TotalCXOPending?:number;
    TotalCXOApproved?:number;
    TotalCXORejected?:number
    
}
export class Cxo {

    PostType?:number;
    CompanyTypeId: number;
    selectDaterange: string;
    educationCategory?:any = null;
    educationLevel?:any = null;
 

    

//     postTitle: number;
//     totalevent: number;
//    totalseminar: number;
//   totalpublication: number;
  
   
  }  