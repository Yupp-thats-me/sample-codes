"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AnswerDetails = exports.InternsApplications = void 0;
var InternsApplications = /** @class */ (function () {
    function InternsApplications() {
    }
    return InternsApplications;
}());
exports.InternsApplications = InternsApplications;
var AnswerDetails = /** @class */ (function () {
    function AnswerDetails() {
    }
    return AnswerDetails;
}());
exports.AnswerDetails = AnswerDetails;
//# sourceMappingURL=internApplications.model.js.map