export class AccomplishmentModel
{
    studentId:number;
    id:number;
    accomplishmentTypeId:number;
    title:string;
    description:string;
    startDate:string;
    endDate:string;
    urlLink:string;
    isWorkingOn:boolean;
    publisher:string;
    testScore:string;
    createdBy: string;
    updatedBy: string;
    recordVersion: number;
    
    
}
