export class SkillComboModel {
  SkillName: string;
}
