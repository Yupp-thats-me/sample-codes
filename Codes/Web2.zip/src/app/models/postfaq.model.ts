export class PostFaq {
  Id: number;
  CounsellorId: number;
  QuestionEn: string;
  AnswerEn: string;
  QuestionAr: string;
  AnswerAr: string;
  PostedDate: string;
  CategoryId: number;
  StatusId: number;
  RejectReason: string;
  CreatedDate: string;
  UpdatedDate: string;
  CreatedBy: string;
  UpdatedBy: string;
  IsActive: boolean;
}
