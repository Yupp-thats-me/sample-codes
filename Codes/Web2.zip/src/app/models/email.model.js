"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Email = void 0;
var Email = /** @class */ (function () {
    function Email() {
    }
    return Email;
}());
exports.Email = Email;
//# sourceMappingURL=email.model.js.map