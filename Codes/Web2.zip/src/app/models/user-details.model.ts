import { Gender } from "@app/services/enumfiles";

export class UserDetails
{
    firstName?:string;
    lastName?:string;
    middleName?:string;
    dob?:Date;
    gender?:Gender;
    language?:string;
    phone?:number;
    emailId?:string;
    userId?:string;
  profilePicFileName?: string;
  profilePicURL?:string;
  studentCategory?: string;
} 
