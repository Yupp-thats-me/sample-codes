export class Feedback {
  Id?: number;
  ScholarshipId?: number;
  StudentId?: number;
  FeedbackId?: number;
  InternshipId?: number;
  Content?: number;
  Design?: number;
  Personalization?: number;
  Functionality?: number;
  UploadDocument?: string;
  DocumentTitle?: string;
  KeySkills?: string;
  ProbableJoiningDate?: string;
  IsStudentProfile?: boolean;
  CreatedBy?: string;
  CreatedDate?: Date;
  UpdatedBy?: string;
  UpdatedDate?: Date;
  AnswerDetails?: AnswerDetails[];
  PublicationtypeID? : number;
  UserId?: number;
  StatusId?: number;
  totalViews?: number;
  loggedinViews? :number;

}

export class AnswerDetails {
  QuestionnaireId?: number;
  Answers?: string;
  StudentId?: number;
  CreatedBy?: string;
}
