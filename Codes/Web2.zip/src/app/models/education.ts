export class DegreeDetails {
  Id: number;
  StudentId: number;
  DegreeId: number;
  MajorId: number;
  SpecializationId: number;
  CompletionYear: string;
  CourseTypeId: number;
  CourseNameEn:string;
  CourseNameAr: string;
  Institute: string;
  GPA: string;
  Percentage: string;
  IsGpaSelected: boolean;
  CreatedBy: string;
  UpdatedBy: string;
}
