export class InternsApplications {

  id: number;
  internshipId: number;
  studentId: number;
  createdDate: Date;
  studentName: string;
  email: string;
  mobileNo: number;
  permanentAddressLine1?: string;
  emirate?: string;
  filename: string;
  institute: string;
  degreeName: string;
  majorName: string;
  specializationName: string;
  organization: string;
  startDate: string;
  endDate: string;
  questions: string;
  answers: string;
  resume: string;
  status: number;
  updatedBy: string;
  AnswerDetails?: AnswerDetails[];
  IsDisagreed: boolean;
  DisagreedReason: string;
  internshipRoleNameEn?: string;
  ResumeId?: number;
  CutoffDate?: Date;
  CutOffReturn?: string;
  }

export class AnswerDetails {
  Questions?: number;
  Answers?: string;
}
