export class ConnectCounsellor {
  Id: number;
  StudentId: number;
  CounsellorId: number;
  Option: number;
  Category: number;
  AskQuestion: string;
  Service: number;
  PreferredLanguage: number;
  SelectedDate: string;
  StartTime: string;
  EndTime: string;
  Duration: number;
  Subject: string;
  Purpose: string;
  UploadFile: string;
  CreatedBy: string;
  UpdatedBy: string;
  PostedDate: string;
  ReplayDate: string;
  Pinned: boolean;
  Answer: string;
  Status: boolean;
  IsActive:boolean;
}
