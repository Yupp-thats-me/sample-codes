export enum Status {
  Draft = 1,
  Pending = 2,
  Approved = 3,
  Rejected = 4,
  UnRegistered = 5
}
export enum appointmentstatus {
  Waiting = 2,
  ScheduleConfirmed = 3,
  Declined = 4,
  Completed = 6,
}

