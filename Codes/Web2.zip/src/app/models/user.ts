export class userDetails {
  token: string;
  userInfo: {
    userName: string,
    password: string,
    emailAddress: string,
    responseMessage: string
  };
}
