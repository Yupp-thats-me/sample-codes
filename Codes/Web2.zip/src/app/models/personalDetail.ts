export class PersonalDetail {
  Id: number;
  FirstName: string;
  MiddleName: string;
  LastName: string;
  DOB: string;
  Gender: string;
  MobileNo: number;
  MobileCode: string;
  PhoneNumber: string;
  EmirateId: string;
  Email: string;
  AlternateEmail: string;
  FileName: string;
  OnlineProfile: string;
  LanguageKnown: string;
  CurrentAddressLine1: string;
  CurrentAddressLine2: string;
  CurrentZipCode: string;
  CurrentCityName: string;
  IsCurrentAddress: boolean;
  PermanentAddressLine1: string;
  PermanentAddressLine2: string;
  PermanentZipCode: string;
  PermanentCityName: string;
  UpdatedBy: string;
}
