export class TimeSlot {
  Id: number;
  CounsellorId: number;
  SelectedDate: string;
  StartTime: string;
  EndTime: string;
  Duration: number;
  CreatedBy: string;
  UpdatedBy: string;
  Status: number;
  IsActive: boolean;
}
