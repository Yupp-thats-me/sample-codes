export enum ErrorCode {
    Duplicate = 50001,
    DateValidate = 50002,
    EmailNotConfirmed = 10,
    Userexists = 900,
    DoesNotExists = 901,
    NotApproved = 902,
    EmailNotVerified = 903,
    Deactivated = 904,
    Failed = 905,
    InvalidPassword = 906,
    EmailExists = 907,
    EmirateIdExists = 908,
    PhoneNumberExists = 909,
    
}