export class Scholarship {
  Id: number;
  ScholarshipId: number;
  ReferenceId: number;
  SpecializationId: number;
  MajorId: number;
  DegreeId: number;
  NationalityId: number;
  Year: number;
  Title: string;
  Benefits: string;
  ExpiryDate: string;
  Description: string;
  QualificationDescription: string;
  CreatedBy: string;
  UpdatedBy: string;  
}
