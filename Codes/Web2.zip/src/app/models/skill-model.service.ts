export class Skill {

  Id: number;
  StudentId: number;
  ReferenceId: number;
  SkillName: string;
  Experience: string;
  SelfRating: number;
  ExpInYears: number;
  ExpInMonths: number;
  Created_By: string;
  Updated_By: string;
}
