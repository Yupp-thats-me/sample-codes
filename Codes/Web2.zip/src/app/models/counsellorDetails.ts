export class ExperienceDetails {
  id: number;
  counsellorId: number;
  title: string;
  organizationName: string;
  descriptions: string;
  emirateId: number;
  startDate: string;
  pursuing:  boolean;
  endDate:  string;
  createdBy: string;
  updatedBy:  string;
  isActive: true
};

