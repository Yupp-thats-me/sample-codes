export class Email {
  Id?: number;
  StudentId?: number;
  InternshipId?: number;
  FromEmail?: string;
  ToEmail?: string;
  CcEmail?: string;
  Subject?: string;
  EmailContent?: string;
  Attachment?: string;
  Status?: number;
  CreatedBy?: string;
  CreatedDate?: Date;
  Reason?: string;
}
