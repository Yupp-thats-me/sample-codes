export class Student{
    
    newsDateRng?:string;
    eduCategory?: number;
    eduLevel?:number;
    Nationality?:number;
    emirate?:number;
   
    
}