export enum Role {

  SuperAdmin = 'SuperAdmin',
  HEI = 'HEI',
  GEI = "GEI",
  Student = "Student",
  Employer = "Employer",
  CXO = "CXO",
  Counsellor = "Counsellor",
  InternshipCounsellor = "Internship Counsellor",
  General = "General",
  ContentCreator = "ContentCreator",
  ContentApprover = "ContentApprover",
  External = "External",
  creditTransfer = "creditTransfer",
  CreditTransfer = "CreditTransfer",
  CreditTransfe = "CreditTransfe"
}

export enum RoleValue {
  SuperAdmin = 1000,

  ContentCreator = 2000,
  ContentApprover = 2001,

  Student = 1,
  HEI = 2,
  GEI = 3,
  Employer = 4,
  CXO = 5,
  Counsellor = 6,
  InternshipCounsellor = 7,
  General = 8,

  None = 0,
  Internal = -1
}