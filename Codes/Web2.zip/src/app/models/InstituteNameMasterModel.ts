export class InstituteNameMasterModel {
  Institute: string;
}
