export class Internship {

  Id: number;
  StudentId: number;
  ReferenceId: number;
  WorkTypeId: number;
  Organization: string;
  StartDate: string;
  EndDate: string;
  JobDescription: string;
  CreatedBy: string;
  UpdatedBy: string;
  CurrentWork: boolean;
  //CreatedDate: Date;
  //UpdatedDate: Date;
}
