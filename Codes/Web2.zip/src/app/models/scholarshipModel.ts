export class ScholarshipModel {
  //Id: number;
  TitleEn: string;
  TitleAr: string;
  DescriptionEn: string;
  DescriptionAr: string;
  BenefitsEn?: string;
  BenefitsAr?: string;
  NationalityID?: number;
  HigherEducationId?: number;
  MajorId?: number;
  YearId?: number;
  EligibilityEn?: string;
  EligibilityAr?: string;
  HowToApplyEn?: string;
  HowToApplyAr?: string;
  ApplicationUrl?: string;
  ContactEmail?: string;
  ExpiryDate?: number;
  UploadImage?: string;
  //StatusID: number;
  //OnBehalfOf: number;
  //Active: boolean;
  //CreatedBy: string;
  //UpdatedBy: string;
}
