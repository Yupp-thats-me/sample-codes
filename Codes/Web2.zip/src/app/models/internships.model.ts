export class Internships {
  id: number;
  uploadImage?: string;
  internshipTypeId?: number;
  internshipTitleEn?: string;
  internshipTitleAr?: string;
  descriptionEn?: string;
  descriptionAr?: string;
  eligibilityEn?: string;
  eligibilityAr?: string;
  countryId?: string;
  emirateId?: string;
  higherEducationId?: string;
  genderId?: number;
  ageId?: number;
  majorId?: string;
  stream? : string;
  joiningDate?: string;
  duration?: string;
  numberOfPositionsId?: number;
  minimumHoursRequiredId?: number;
  organizationLink?: string;
  industryName?: string;
  internshipRoleNameEn?: string;
  internshipRoleNameAr?: string;
  monthlySalaryRangeId?: number;
  fieldofTraining?: number;
  howToApplyEn?: string;
  howToApplyAr?: string;
  contactEmail?: string;
  expiryDate?: string;
  statusId?: number;
  onBehalfOf?: number;
  isActive?: boolean;
  createdBy?: string;
  updatedBy?: string;
  status?: string;
  internshipQuestionnaireDetails?: InternshipQuestionnaireDetails[];
  reason?: string;
  isProbable?: boolean;
  lastJoiningDate?: string;
  internshipFor?: number;
  userId?: number;
  applicationDeadline?: string;
  companyNameEn?: string;
  companyNameAr?: string
  type?: any;
  userinternshipId?: number;
  studentId?: number;
  requestedRole?: string
 
  
}

export class InternshipQuestionnaireDetails {
  QuestionnaireId?: number;
  questions?: string;
  options1?: string;
  options2?: string;
  options3?: string;
  options4?: string;
  type?: number;
  answers?: string;
}


export class internshipReport {

  selectRng?: string;
  startDate:string;
  endDate:string;
  AdminName: string;
  internshipRoleEn:string;
  internshipRoleAr:string;
  InternRole:string;
  totalInternshipPosted?:number;
  totalFullTimePosted?:number;
  mostInternshipByCompany?:number;
  totalGeneralPosted?:number;
  totalHigherPosted?:number;
  OnBehalfOf?: number;
  internshipType?:number;
  educationCategory?:number;
  companyNameEn?:string;

}

export class InternshipReport {

  selectDaterange:string;
  StartDate:string;
  EndDate:string;
  createdBy?: number;
  educationCategory:any=0;
  educationLevel:any=0;
  admin?:any=0
}

