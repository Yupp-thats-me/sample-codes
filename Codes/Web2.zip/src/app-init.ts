// import { KeycloakService, KeycloakOptions } from 'keycloak-angular';
// import { environment } from 'environments/environment';

// export function initializer(keycloak: KeycloakService): () => Promise<any> {
//   const options: KeycloakOptions = {
//     config: environment.keycloakConfig,
//     initOptions: {
//       //onLoad: '',
//       redirectUri:
//         window.location.origin + '/',
//     },
//   };
//   return (): Promise<any> => keycloak.init(options);
// }
