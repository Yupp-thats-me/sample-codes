using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Ocelot.Middleware;
using Ocelot.DependencyInjection;
using Serilog;
using Serilog.Events;
using Ocelot.ApiGateway.Middlewares;
using Microsoft.AspNetCore.Builder;
using System.IO;
using Microsoft.Extensions.Logging;

namespace Ocelot.ApiGateway
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder
                       .ConfigureAppConfiguration((hostingContext, config) =>
                       {
                           config
                               .SetBasePath(hostingContext.HostingEnvironment.ContentRootPath)
                               .AddJsonFile("ocelot.json")
                               .AddEnvironmentVariables();

                           config.AddOcelot("OcelotConfigs", hostingContext.HostingEnvironment);
                       });
                    
                    webBuilder.UseStartup<Startup>();
                });

    }
}
