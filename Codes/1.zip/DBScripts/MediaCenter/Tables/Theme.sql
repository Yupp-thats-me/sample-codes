USE [SJMediaCenter]
GO

/****** Object:  Table [dbo].[Theme]    Script Date: 1/4/2022 5:19:35 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Theme](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[En_theme] [nvarchar](50) NULL,
	[Ar_theme] [nvarchar](100) NULL,
	[miscellaneous] [nvarchar](max) NULL,
	[CreatedBy] [nvarchar](25) NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[UpdatedBy] [nvarchar](25) NULL,
	[UpdatedDate] [datetime] NULL,
	[ParentID] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


