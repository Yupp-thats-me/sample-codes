USE [SJMediaCenter]
GO

/****** Object:  Table [dbo].[MediaTypeMaster]    Script Date: 1/4/2022 5:10:02 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[MediaTypeMaster](
	[MediaTypeId] [int] NOT NULL,
	[MediaTypeEn] [nvarchar](100) NULL,
	[MediaTypeAr] [nvarchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[MediaTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


