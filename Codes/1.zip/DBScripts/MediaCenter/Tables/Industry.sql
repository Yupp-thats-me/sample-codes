USE [SJMediaCenter]
GO

/****** Object:  Table [dbo].[Industry]    Script Date: 1/4/2022 4:58:31 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Industry](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[En_industry] [nvarchar](50) NULL,
	[Ar_industry] [nvarchar](100) NULL,
	[miscellaneous] [nvarchar](max) NULL,
	[CreatedBy] [nvarchar](25) NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[UpdatedBy] [nvarchar](25) NULL,
	[UpdatedDate] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


