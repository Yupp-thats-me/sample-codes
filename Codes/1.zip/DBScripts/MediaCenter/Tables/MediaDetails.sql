USE [SJMediaCenter]
GO

/****** Object:  Table [dbo].[MediaDetails]    Script Date: 08-02-2022 04:56:28 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[MediaDetails](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[TitleEn] [nvarchar](250) NULL,
	[DescriptionEn] [nvarchar](max) NULL,
	[TitleAr] [nvarchar](250) NULL,
	[DescriptionAr] [nvarchar](max) NULL,
	[PageLink] [nvarchar](500) NULL,
	[ImageLink] [nvarchar](150) NULL,
	[SourceEn] [nvarchar](250) NULL,
	[PlaceEn] [nvarchar](100) NULL,
	[SourceAr] [nvarchar](250) NULL,
	[PlaceAr] [nvarchar](100) NULL,
	[DateAnnounced] [datetime] NOT NULL,
	[ExpiryDate] [datetime] NULL,
	[StatusID] [int] NOT NULL,
	[Theme] [nvarchar](250) NULL,
	[Industry] [int] NULL,
	[MediaType] [int] NULL,
	[CreatedBy] [int] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[UpdatedBy] [int] NULL,
	[UpdatedDate] [datetime] NULL,
	[ThumbNailPath] [nvarchar](1000) NULL,
	[IsActive] [bit] NOT NULL,
	[RejectReason] [nvarchar](1000) NULL,
	[SpeakersEn] [nvarchar](100) NULL,
	[SpeakersAr] [nvarchar](100) NULL,
	[StartDate] [datetime] NULL,
	[EndDate] [datetime] NULL,
	[StartTime] [nvarchar](50) NULL,
	[EndTime] [nvarchar](50) NULL,
	[TotalViews] [bigint] NULL,
 CONSTRAINT [PK_Id] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[MediaDetails] ADD  CONSTRAINT [DF_MediaDetails_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [dbo].[MediaDetails]  WITH CHECK ADD FOREIGN KEY([MediaType])
REFERENCES [dbo].[MediaTypeMaster] ([MediaTypeId])
GO

ALTER TABLE [dbo].[MediaDetails]  WITH CHECK ADD  CONSTRAINT [FK_MediaDetails_MediaStatus] FOREIGN KEY([StatusID])
REFERENCES [dbo].[MediaStatus] ([ID])
GO

ALTER TABLE [dbo].[MediaDetails] CHECK CONSTRAINT [FK_MediaDetails_MediaStatus]
GO


