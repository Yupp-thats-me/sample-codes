USE [SJMediaCenter]
GO

/****** Object:  Table [dbo].[s_UserDefinedCategories]    Script Date: 1/4/2022 5:13:02 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[s_UserDefinedCategories](
	[UDCategoryID] [int] IDENTITY(1,1) NOT NULL,
	[UDCategory] [nvarchar](1000) NULL,
PRIMARY KEY CLUSTERED 
(
	[UDCategoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


