﻿USE [SJMediaCenter]
GO

INSERT INTO [dbo].[Theme]
           ([En_theme]
           ,[Ar_theme]
           ,[miscellaneous]
           ,[CreatedBy]
           ,[CreatedDate]
           ,[UpdatedBy]
           ,[UpdatedDate]
           ,[ParentID])

     VALUES
           ('Government Agencies',N' الجهات الحكومية',NULL,'1','2021-02-23 15:19:16.107','1','2021-02-23 15:19:16.107',NULL),
		   ('Universities',N'الجامعات',NULL,'SightSpectrum','2021-02-23 15:19:16.107','SightSpectrum','2021-02-23 15:19:16.107',NULL),
		   ('Careers',N' الوظائف',NULL,'SightSpectrum','2021-02-23 15:19:16.110','SightSpectrum','2021-02-23 15:19:16.110',NULL),
		   ('Employment',N' التوظيف',NULL,'SightSpectrum','2021-02-23 15:19:16.110','SightSpectrum','2021-02-23 15:19:16.110',NULL),
		   ('Education Agencies',N'وكالات التعليم',NULL,'SightSpectrum','2021-05-05 08:57:26.070',NULL,NULL,1),
		   ('Ministry of Education',N'وزارة التربية والتعليم',NULL,'SightSpectrum','2021-05-05 08:57:26.070',NULL,NULL,1),
		   ('Non-Education Agencies',N'وكالات غير تعليمية',NULL,'SightSpectrum','2021-05-05 08:57:26.070',NULL,NULL,1),
		   ('Academic Performance',N'أداء أكاديمي',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,2),
		   ('Applications',N'التطبيقات',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,2),
		   ('Fees and Funding',N'الرسوم والتمويل',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,2),
		   ('International Universities',N'جامعات عالمية',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,2),
		   ('Investment',N'خدمات الطالب',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,2),
		   ('Leadership & Faculty',N'القيادة والكلية',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,2),
			('Programs/Courses',N'البرامج / الدورات',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,2),
			('Rankings',N'الترتيب',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,2),
			('Student Services',N'وكالات غير تعليمية',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,2),
			('Study options (Credit Transfer)',N'(تحويل رصيد)خيارات الدراسة',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,2),
			('Technology',N'تقنية',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,2),
			('Career Services',N'الخدمات المهنية',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,3),
			('Employers/Recruiters',N'أرباب العمل / المجندون',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,3),
			('Labour Market (Graduate)',N'(خريج) سوق العمل',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,3),
			('Economy',N'اقتصاد',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,21),
			('Industries',N'الصناعات',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,21),
			('Occupation',N'الاحتلال',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,21),
			('Salaries',N'الرواتب',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,21),
			('Enternships/Work Experience',N'فترات التدريب / الخبرة في العمل',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,3),
			('Entrepreneurship',N'ريادة الأعمال',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,3),
			('International Trends',N'الاتجاهات الدولية',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,3),
			('Studies/Future of Work',N'دراسات / مستقبل العمل',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,3),

			('Volunteering',N'التطوع',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,3),
			('Advice and Support',N'المشورة والدعم',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,27),
			('Funding and Investment',N'التمويل والاستثمار',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,27),
			('Incubators and Accelerators',N'الحاضنات والمسرعات',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,27),
			('International Trends',N'الاتجاهات الدولية',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,27),
			('Decision Making',N'اتخاذ القرار',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,3),
			('Assessment Tools',N'ادوات التقييم',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,35),
			('Career Events',N'الأحداث المهنية',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,35),
			('Websites',N'مواقع الويب',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,35),
			('International Job Sites',N'مواقع العمل الدولية',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,4),
			('Job Sites (All)',N'(الكل)مواقع العمل',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,4),
			('Job Sites (National)',N'(وطنية)مواقع العمل ',NULL,'SightSpectrum','2021-05-05 08:57:26.073',NULL,NULL,4)


GO


