USE [SJMediaCenter]
GO

INSERT INTO [dbo].[s_UserDefinedCategories]
           ([UDCategory])
     VALUES
           ('MediaIndustry'),
		   ('MediaTheme')
GO


