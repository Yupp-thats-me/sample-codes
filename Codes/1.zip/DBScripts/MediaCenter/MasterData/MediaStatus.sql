USE [SJMediaCenter]
GO

INSERT INTO [dbo].[MediaStatus]
           ([Status])
     VALUES
           ('Draft'),
		   ('Pending Approval'),
		   ('Approved'),
		   ('Rejected')
GO


