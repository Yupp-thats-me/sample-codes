﻿USE [SJMediaCenter]
GO

Insert into MediaTypeMaster 
    (MediaTypeId,
	MediaTypeEn,
	MediaTypeAr)
                 
values
   (1,'Announcements',N'الإعلانات'),
   (2,'Events',N'الأحداث'),
   (3,'News',N'أخبار')
GO

