﻿USE [SJMediaCenter]
GO

INSERT INTO [dbo].[s_UserDefinedOptions]
           ([UDCategoryID]
           ,[UDDescriptionEng]
           ,[UDDescriptionAr]
           ,[UDCode]
           ,[SortOrder]
           ,[IsActive])
     VALUES
           (1,'Accounting & Conulting',N'المحاسبة والاستشارات',1,NULL,1),
		   (1,'Agriculture',N' الزراعة',2,NULL,1),
			(1,'Airlines & Aerospace',N' شركات الطيران والفضاء',3,NULL,1),
			(1,'Automotive Manufacture & Retail',N'صناعة السيارات والتجزئة',4,NULL,1),
			(1,'Banking & Finance',N'الخدمات المصرفية والمالية',5,NULL,1),
			(1,'Chemicals & Manufacture',N' المواد الكيميائية وتصنيع',6,NULL,1),
			(1,'Clothing Manufacture & Retail',N'. الملابس تصنيع وتجارة التجزئة',7,NULL,1),
			(1,'Construction',N' - التشييد',8,NULL,1),
			(1,'Consumer Electronics Manufacture & Retail',N'. تصنيع الالكترونيات الاستهلاكية والتجزئة',9,NULL,1),
			(1,'Creative Arts',N'. الفنون الإبداعية',10,NULL,1),
			(1,'Defence & Police',N'- الدفاع والشرطة',11,NULL,1),
			(1,'Education',N'- التعليم',12,NULL,1),
			(1,'Electrical, Household & Consumer Goods',N'. الكهربائية والمنزلية والسلع الاستهلاكية',13,NULL,1),
			(1,'Facilities Management',N'- إدارة المرافق',14,NULL,1),
			(1,'Food Manufacturing & Retail',N' تصنيع الأغذية وتجارة التجزئة',15,NULL,1),
			(1,'Health & Social Care',N'الرعاية الصحية والاجتماعية',16,NULL,1),
			(1,'Hospitality & Leisure',N'الضيافة والترفيه',17,NULL,1),
			(1,'ICT and Telecommunications',N'تكنولوجيا المعلومات والاتصالات والاتصالات السلكية واللاسلكية',18,NULL,1),
			(1,'Insurance',N'التأمين',19,NULL,1),
			(1,'Information Technology',N'تكنولوجيا المعلومات',20,NULL,1),
			(1,'Legal',N'القانونية',21,NULL,1),
			(1,'Marine Transport',N'النقل البحري',22,NULL,1),
			(1,'Metals Manufacturing',N'تصنيع المعادن',23,NULL,1),
			(1,'Mining',N'التعدين',24,NULL,1),
			(1,'Oil & Gas',N'النفط والغاز',25,NULL,1),
			(1,'Pharmaceuticals Manufacturing',N'صناعة المستحضرات الصيدلانية',26,NULL,1),
			(1,'Power Generation & Distribution',N'توليد الطاقة والتوزيع',27,NULL,1),
			(1,'Printing, Paper & Packaging',N'الطباعة، ورق والتغليف',28,NULL,1),
			(1,'Public Administration',N'الإدارة العامة',29,NULL,1),
			(1,'Rail or Road Transport',N'النقل بالسكك الحديدية أو النقل البري',30,NULL,1),
			(1,'Real Estate',N'العقارات',31,NULL,1),
			(1,'Rental, Leasing & Agencies',N'التأجير والإجارة والوكالات',32,NULL,1),
			(1,'Sports',N'الرياضة',33,NULL,1),
			(1,'TV, Film, Music and Photography',N'التلفزيون والسينما والموسيقى والتصوير الفوتوغرافي',34,NULL,1),
			(1,'Water & Waste',N'المياه والنفايات',35,NULL,1),
			(2,'Government Agencies',N'',1,1,1),
			(2,'Universities',N'?',2,2,1),
			(2,'Careers',N'',3,3,1),
			(2,'Employment',N'',4,4,1)

GO


