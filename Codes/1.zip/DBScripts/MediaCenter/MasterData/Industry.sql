﻿USE [SJMediaCenter]
GO

INSERT INTO [dbo].[Industry]
           ([En_industry]
           ,[Ar_industry]
           ,[miscellaneous]
           ,[CreatedBy]
           ,[CreatedDate]
           ,[UpdatedBy]
           ,[UpdatedDate])
     VALUES
			('Accounting & Conulting',N'المحاسبة والاستشارات',NULL,'1',GETDATE(),'',''),
			('Agriculture',N' الزراعة',NULL,'1',GETDATE(),'',''),
			('Airlines & Aerospace',N' شركات الطيران والفضاء',NULL,'1',GETDATE(),'',''),
			('Automotive Manufacture & Retail',N'صناعة السيارات والتجزئة',NULL,'1',GETDATE(),'',''),
			('Banking & Finance',N'الخدمات المصرفية والمالية',NULL,'1',GETDATE(),'',''),
			('Chemicals & Manufacture',N' المواد الكيميائية وتصنيع',NULL,'1',GETDATE(),'',''),
			('Clothing Manufacture & Retail',N'. الملابس تصنيع وتجارة التجزئة',NULL,'1',GETDATE(),'',''),
			('Construction',N' - التشييد',NULL,'1',GETDATE(),'',''),
			('Consumer Electronics Manufacture & Retail',N'. تصنيع الالكترونيات الاستهلاكية والتجزئة',NULL,'1',GETDATE(),'',''),
			('Creative Arts',N'. الفنون الإبداعية',NULL,'1',GETDATE(),'',''),
			('Defence & Police',N'- الدفاع والشرطة',NULL,'1',GETDATE(),'',''),
			('Education',N'- التعليم',NULL,'1',GETDATE(),'',''),
			('Electrical, Household & Consumer Goods',N'. الكهربائية والمنزلية والسلع الاستهلاكية',NULL,'1',GETDATE(),'',''),
			('Facilities Management',N'- إدارة المرافق',NULL,'1',GETDATE(),'',''),
			('Food Manufacturing & Retail',N' تصنيع الأغذية وتجارة التجزئة',NULL,'1',GETDATE(),'',''),
			('Health & Social Care',N'الرعاية الصحية والاجتماعية',NULL,'1',GETDATE(),'',''),
			('Hospitality & Leisure',N'الضيافة والترفيه',NULL,'1',GETDATE(),'',''),
			('ICT and Telecommunications',N'تكنولوجيا المعلومات والاتصالات والاتصالات السلكية واللاسلكية',NULL,'1',GETDATE(),'',''),
			('Insurance',N'التأمين',NULL,'1',GETDATE(),'',''),
			('Information Technology',N'تكنولوجيا المعلومات',NULL,'1',GETDATE(),'',''),
			('Legal',N'القانونية',NULL,'1',GETDATE(),'',''),
			('Marine Transport',N'النقل البحري',NULL,'1',GETDATE(),'',''),
			('Metals Manufacturing',N'تصنيع المعادن',NULL,'1',GETDATE(),'',''),
			('Mining',N'التعدين',NULL,'1',GETDATE(),'',''),
			('Oil & Gas',N'النفط والغاز',NULL,'1',GETDATE(),'',''),
			('Pharmaceuticals Manufacturing',N'صناعة المستحضرات الصيدلانية',NULL,'1',GETDATE(),'',''),
			('Power Generation & Distribution',N'توليد الطاقة والتوزيع',NULL,'1',GETDATE(),'',''),
			('Printing, Paper & Packaging',N'الطباعة، ورق والتغليف',NULL,'1',GETDATE(),'',''),
			('Public Administration',N'الإدارة العامة',NULL,'1',GETDATE(),'',''),
			('Rail or Road Transport',N'النقل بالسكك الحديدية أو النقل البري',NULL,'1',GETDATE(),'',''),
			('Real Estate',N'العقارات',NULL,'1',GETDATE(),'',''),
			('Rental, Leasing & Agencies',N'التأجير والإجارة والوكالات',NULL,'1',GETDATE(),'',''),
			('Sports',N'الرياضة',NULL,'1',GETDATE(),'',''),
			('TV, Film, Music and Photography',N'التلفزيون والسينما والموسيقى والتصوير الفوتوغرافي',NULL,'1',GETDATE(),'',''),
			('Water & Waste',N'المياه والنفايات',NULL,'1',GETDATE(),'','')

GO


