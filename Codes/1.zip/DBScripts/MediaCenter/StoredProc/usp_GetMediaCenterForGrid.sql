USE [SJMediaCenter]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetMediaCenterForGrid]    Script Date: 1/3/2022 10:30:57 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE OR ALTER PROCEDURE [dbo].[usp_GetMediaCenterForGrid]
	@MediaType INT = NULL,
	@StatusID CHAR(1) = Null
AS
BEGIN
 
 
	SET NOCOUNT ON;
	
	SELECT	MD.[Id],[TitleEn]
      ,[TitleAr]
	  ,SourceEn
	  ,SourceAr
	  ,[DateAnnounced]
	  ,[ExpiryDate]
	  ,ms.status as Status
	FROM MediaDetails md  WITH(NOLOCK)
	INNER JOIN mediastatus ms ON md.StatusID = ms.ID
	WHERE 
		[MediaType] in (@MediaType) 
		and md.StatusID = ISNULL(@StatusID, md.StatusID)
		and IsActive = 1
	ORDER BY CreatedDate DESC, UpdatedDate DESC
	
END

--exec [usp_GetMediaCenterForGrid] 'News', 2
GO


