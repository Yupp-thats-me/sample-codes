USE [SJMediaCenter]
GO

/****** Object:  StoredProcedure [dbo].[usp_InsertMedia]    Script Date: 1/3/2022 10:43:13 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[usp_InsertMedia] 
(  
   
	@Id BIGINT NULL
	,@TitleEn NVARCHAR(250) = NULL
	,@DescriptionEn NVARCHAR(max) = NULL
	,@TitleAr NVARCHAR(250) = NULL
	,@DescriptionAr NVARCHAR(max) = NULL
	,@PageLink NVARCHAR(150) = NULL
	,@ImageLink NVARCHAR(150) = NULL
	,@SourceEn NVARCHAR(250) = NULL
	,@PlaceEn NVARCHAR(100) = NULL
	,@SourceAr NVARCHAR(250) = NULL
	,@PlaceAr NVARCHAR(100) = NULL
	,@DateAnnounced DATETIME = NULL
	,@ExpiryDate DATETIME = NULL
	,@StatusID INT = NULL
	,@Theme NVARCHAR(250) = NULL
	,@Industry INT = NULL
	,@MediaType INT = NULL
	,@CreatedBy INT = NULL
	,@UpdatedBy INT = NULL
	,@ThumbNailPath NVARCHAR(1000) = NULL
	,@IsActive BIT=0
	,@SpeakersEn NVARCHAR(100)=NULL
	,@SpeakersAr NVARCHAR(100)=NULL
	,@StartDate DATETIME =NULL
	,@EndDate DATETIME =NULL
	,@StartTime NVARCHAR(50)=NULL
	,@EndTime Nvarchar(50)=NULL
	,@Duplicate bit = 0,
	@TotalViews BIGINT=0,
    @LoggedinViews BIGINT = 0
)
AS
BEGIN
	SET NOCOUNT ON;

	BEGIN TRY
		BEGIN TRANSACTION;

		
		----Announcements
			IF  EXISTS (

					SELECT 1
					FROM MediaDetails
					WHERE TitleEn = @TitleEn AND TitleAr= @TitleAr
						AND CONVERT(Date, DateAnnounced) =CONVERT(DATE,@DateAnnounced)
						AND MediaType=@MediaType  AND IsActive = 1
						AND ID!= @Id
           --events
					OR EXISTS
					(
						SELECT 1
					FROM MediaDetails
					WHERE TitleEn = @TitleEn AND TitleAr=@TitleAr
						AND CONVERT(Date, DateAnnounced) = CONVERT(DATE,@DateAnnounced) AND 
						PlaceEn=@PlaceEn AND MediaType=@MediaType AND IsActive = 1
						AND ID!=@Id
					)
			--news
					OR EXISTS
					(
						SELECT 1
					FROM MediaDetails
					WHERE TitleEn = @TitleEn AND TitleAr=@TitleAr
						 AND SourceEn=@SourceEn AND CONVERT(DATE, ExpiryDate) = CONVERT (DATE, @ExpiryDate)
						 AND MediaType=@MediaType
						 AND ID!=@Id AND IsActive = 1
					)
					)

   THROW 50001,'Duplicate is found.',1;


		--END

		IF ISNULL(@Id, 0) = 0
		   BEGIN
				INSERT INTO [dbo].[MediaDetails] (
					[TitleEn]
					,[DescriptionEn]
					,[TitleAR]
					,[DescriptionAr]
					,[PageLink]
					,[ImageLink]
					,[SourceEn]
					,[PlaceEn]
					,[SourceAr]
					,[PlaceAr]
					,[DateAnnounced]
					,[ExpiryDate]
					,[StatusID]
					,[Theme]
					,[Industry]
					,[MediaType]
					,[CreatedBy]
					,[CreatedDate]
					,[UpdatedBy]
					,[UpdatedDate]
					,[ThumbNailPath]
					,IsActive
					,SpeakersEn
					,SpeakersAr
					,StartDate
					,EndDate
					,StartTime
					,EndTime 
					,TotalViews  
                    ,LoggedinViews 
					)
				VALUES (
					@TitleEn
					,@DescriptionEn
					,@TitleAr
					,@DescriptionAr
					,@PageLink
					,@ImageLink
					,@SourceEn
					,@PlaceEn
					,@SourceAr
					,@PlaceAr
					,@DateAnnounced
					,CASE WHEN @ExpiryDate='1900-01-01' THEN NULL
		             ELSE @ExpiryDate END
					,@StatusID
					,@Theme
					,@Industry
					,@MediaType
					,@CreatedBy
					,GETDATE()
					,@UpdatedBy
					,GETDATE()
					,@ThumbNailPath
					,@IsActive
					,@SpeakersEn
					,@SpeakersAr
					,@StartDate
					,@EndDate
					,@StartTime
					,@EndTime
					, 0  
                    , 0  
					)


			SELECT @Id= SCOPE_IDENTITY()

			SELECT @Id 	


			END		
			
			
			
		
		ELSE

		BEGIN
			UPDATE [dbo].[MediaDetails] 
			SET 
					[TitleEn] =@TitleEn
					,[DescriptionEn] =@DescriptionEn
					,[TitleAR] =@TitleAr
					,[DescriptionAr]=@DescriptionAr
					,[PageLink] =@PageLink
					,[ImageLink] =@ImageLink
					,[SourceEn] =@SourceEn
					,[PlaceEn] =@PlaceEn
					,[SourceAr] =@SourceAr
					,[PlaceAr] =@PlaceAr
					,[DateAnnounced] =@DateAnnounced
					,[ExpiryDate] =@ExpiryDate
					,[StatusID] =@StatusID
					,[Theme] =@Theme
					,[Industry] =@Industry
					,[MediaType] =@MediaType
					,[CreatedBy] =@CreatedBy
					,[CreatedDate] =GETDATE()
					,[UpdatedBy] =@UpdatedBy
					,[UpdatedDate] =GETDATE()
					,[ThumbNailPath] = ISNULL(@ThumbNailPath, ThumbNailPath) -- update in case of new image else keep the same
					,IsActive =@IsActive
					,SpeakersEn=@SpeakersEn
					,SpeakersAr=@SpeakersAr
					,StartDate=@StartDate
					,EndDate=@EndDate
					,StartTime=@StartTime
					,EndTime=@EndTime
					,TotalViews=0  
                    ,LoggedinViews=0  
			WHERE Id =@Id
			
		END


		SELECT @Id


		COMMIT TRANSACTION;

		
	END TRY

	BEGIN CATCH

	IF(ERROR_NUMBER() = 50001)
		throw 50001,'Duplicate is found.',1;
	ELSE
		BEGIN
			ROLLBACK TRANSACTION;
		END

		
	END CATCH

		BEGIN
					INSERT INTO  AuditMediaCenterDetails(
			          MediacenterId,
			          UpdatedBy,
			          UpdatedOn,
			          statusid,
			          Reason)
			Values(
			         @Id,
					 @UpdatedBy ,
					 GETDATE(),
					 @StatusId,
					 null)

		END
END

--EXEC [usp_GetMediaDetails] @MediaType,'1'
GO


