USE [SJMediaCenter]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetThemeTreeView]    Script Date: 1/3/2022 10:40:26 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[usp_GetThemeTreeView]  

AS  
BEGIN  
  
 SET NOCOUNT ON;  
 select Id, En_theme,Ar_theme, isnull(ParentID, 0) 'ParentID'  from Theme   
  
END  
GO


