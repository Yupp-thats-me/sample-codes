USE [SJMediaCenter]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetLookUp]    Script Date: 29-07-2021 15:59:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--usp_GetLookUp 'MediaTheme'
CREATE OR ALTER PROCEDURE [dbo].[usp_GetLookUp]
(
	@UDCategoryName NVARCHAR(1000) = NULL
)
AS
BEGIN
	SELECT 
	udo.UDID
	, udo.UDCategoryID
	, udo.UDDescriptionEng
	, udo.UDDescriptionAr
	, udo.UDCode
	, udo.SortOrder
	FROM s_UserDefinedOptions udo
	INNER JOIN s_UserDefinedCategories udc on udc.UDCategoryID = udo.UDCategoryID
	WHERE udc.UDCategory = @UDCategoryName AND isnull(IsActive,0) =1
END

--EXEC [usp_GetLookUp] 1
GO


