CREATE OR ALTER PROC [dbo].[UpdateTotalViews]
 
@Id	BIGINT NULL,
@TotalViews BIGINT=NULL,
@LoggedinViews BIGINT = NULL

AS

BEGIN
 
	SET NOCOUNT ON;
 
			UPDATE 
			dbo.MediaDetails
			SET
			TotalViews = @TotalViews ,			
			LoggedinViews = @LoggedinViews
			WHERE Id=@Id

 
END