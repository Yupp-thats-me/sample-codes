CREATE OR ALTER  PROC [dbo].[GetMediaReportCountDetails]    
     
AS  
  
BEGIN    
    
SELECT 
(DATENAME(MONTH, DATEADD(MONTH, 0 , CreatedDate)) + ' ' + CAST(Year(CreatedDate) AS NVARCHAR)) AS PostedDate ,   
SUM(CASE WHEN MediaType= 1 THEN 1 ELSE 0 END) AS TotalAnnouncementsPosted,
SUM(CASE WHEN MediaType= 2 THEN 1 ELSE 0 END) AS TotalEventsPosted,
SUM(CASE WHEN MediaType= 3 THEN 1 ELSE 0 END) AS TotalNewsPosted,
SUM(CASE WHEN MediaType= 1 THEN TotalViews ELSE 0 END) AS TotalAnnouncementsViews,
SUM(CASE WHEN MediaType= 2 THEN TotalViews ELSE 0 END) AS TotalEventsViews,
SUM(CASE WHEN MediaType= 3 THEN TotalViews ELSE 0 END) AS TotalNewsViews

FROM mediadetails
GROUP BY (DATENAME(MONTH, DATEADD(MONTH, 0, CreatedDate)) + ' ' + CAST(Year(CreatedDate) AS NVARCHAR))
 
  
END


