CREATE OR ALTER PROCEDURE [dbo].[GetReportListStatistics]

(
@DatePublished Datetime=NULL,
@DateExpiry Datetime=NULL,
@CreatedBy int=0,
@MediaType int
)

AS
BEGIN
DECLARE @Type1 BIGINT, @Type2 BIGINT, @Type3 BIGINT , @Type4 BIGINT , @Type5 INT , @Type6 INT,
@Type7 NVARCHAR(50), @Type8 NVARCHAR(50), @Type9 NVARCHAR(50), @Type10 NVARCHAR(50),@Type11 INT

SET @Type1=(SELECT COUNT(Id) FROM MediaDetails)
SET @Type2=(SELECT COUNT(Id) FROM MediaDetails WHERE StatusID = 2)
SET @Type3=(SELECT COUNT(Id) FROM MediaDetails WHERE StatusID = 3)
SET @Type4=(SELECT COUNT(Id) FROM MediaDetails WHERE StatusID = 4)
SET @Type5=(SELECT COUNT(RequestedRole) From SJIdentity..[User] US 
    JOIN MediaDetails MD WITH(NOLOCK) 
    ON MD.CreatedBy=US.ID
	where MediaType=2 and (@CreatedBy=0 or (US.RequestedRole=@CreatedBy)))
SET @Type6=(SELECT count(RequestedRole) From SJIdentity..[User] US 
    JOIN MediaDetails MD WITH(NOLOCK) 
    ON MD.CreatedBy=US.ID
	where MediaType=3 )
	--and (@CreatedBy=0 or (US.RequestedRole=@CreatedBy)))
SET @Type7=(SELECT TOP 1 TitleEn FROM MediaDetails  MD
JOIN SJIdentity..[User] US WITH(NOLOCK) 
ON MD.CreatedBy=US.ID
where RequestedRole=2 AND MD.IsActive=1 and (@CreatedBy=0 or (US.RequestedRole=@CreatedBy)) ORDER BY TotalViews DESC )
SET @Type8=(SELECT TOP 1 TitleAr FROM MediaDetails  MD
JOIN SJIdentity..[User] US WITH(NOLOCK) 
ON MD.CreatedBy=US.ID
where RequestedRole=2 AND MD.IsActive=1 ORDER BY TotalViews DESC )
SET @Type9=(SELECT TOP 1 TitleEn FROM MediaDetails  MD
JOIN SJIdentity..[User] US WITH(NOLOCK) 
ON MD.CreatedBy=US.ID
where RequestedRole=2 AND MD.IsActive=1 ORDER BY TotalViews ASC)
SET @Type10=(SELECT TOP 1 TitleAr FROM MediaDetails  MD
JOIN SJIdentity..[User] US WITH(NOLOCK) 
ON MD.CreatedBy=US.ID
where RequestedRole=2 AND MD.IsActive=1 ORDER BY TotalViews ASC)
SET @Type11=(SELECT count(RequestedRole) From SJIdentity..[User] US 
    JOIN MediaDetails MD WITH(NOLOCK) 
    ON MD.CreatedBy=US.ID
	WHERE MediaType=1 and (@CreatedBy=0 or (US.RequestedRole=@CreatedBy)))

SET NOCOUNT ON;
SELECT  DISTINCT 
--MD.Id,
CONCAT(US.FirstName,' ',US.LastName) AS CreatedBy,
@Type1 AS TotalPosted ,
@Type2 AS TotalPending,
@Type3 AS TotalApproved,
@Type4 AS TotalRejected,
@Type5 AS TotalEventsListingStatistics,
@Type6 AS TotalNewsListingStatistics,
@Type7 AS MostViewEn,
@Type8 AS MostViewAr,
@Type9 AS LeastViewEn,
@Type10 AS LeastViewAr,
@Type11 AS TotalAnnouncementsListingStatistics,
U.RequestedRole,

MD.MediaType

FROM MediaDetails MD
JOIN [SJIdentity].[dbo].[User] US WITH(NOLOCK) 
ON US.ID=MD.CreatedBy
INNER join [SJIdentity]..[User] U 
on MD.CreatedBy  = U.Id


WHERE MD.IsActive=1 And    
  MD.CreatedDate Between @DatePublished AND @DateExpiry
  and MD.MediaType = @MediaType
--AND (@DatePublished is null or Convert(date ,DateAnnounced ) = Convert(date,@DatePublished))
--AND (@DateExpiry is null or Convert(date ,ExpiryDate ) = Convert(date,@DateExpiry))
  AND (@CreatedBy = 0 or U.RequestedRole = @CreatedBy )

END



--Exec GetReportListStatistics  '2021-02-12 07:00:48.790','2022-02-20',2000,3


--SELECT * FROM MediaDetails
--UPDATE MediaDetails
--SET CreatedBy = 16
--WHERE Id = 351
--select * from SJIdentity..[User] where RequestedRole=2