USE [SJMediaCenter]
GO

/****** Object:  StoredProcedure [dbo].[usp_InActiveMediaById]    Script Date: 08-06-2021 14:07:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE OR ALTER PROCEDURE [dbo].[usp_InActiveMediaById]
	@Id int
AS
BEGIN
 
	SET NOCOUNT ON;
	
	UPDATE MediaDetails SET IsActive = 0
	WHERE Id = @Id
	
END
--exec [usp_DeleteMediaDetailById] 11

GO


