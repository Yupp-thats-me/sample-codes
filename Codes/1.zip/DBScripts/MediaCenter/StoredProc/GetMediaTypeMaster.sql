USE [SJMediaCenter]
GO

/****** Object:  StoredProcedure [dbo].[GetMediaTypeMaster]    Script Date: 1/3/2022 10:17:04 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetMediaTypeMaster]
as
begin
   SELECT 

   MediaTypeId,
   MediaTypeEn,
   MediaTypeAr
   
   FROM MediaTypeMaster with(nolock)
END
GO


