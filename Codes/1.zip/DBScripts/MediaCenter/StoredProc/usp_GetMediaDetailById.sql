USE [SJMediaCenter]
GO

/****** Object:  StoredProcedure [dbo].[usp_GetMediaDetailById]    Script Date: 1/3/2022 10:34:12 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

  
  
  
  
CREATE OR ALTER PROCEDURE [dbo].[usp_GetMediaDetailById]  
 @Id int  
AS  
BEGIN  
   
   
 SET NOCOUNT ON;  
   
 SELECT MD.[Id],[TitleEn]  
      ,[DescriptionEn]  
      ,[TitleAr]  
      ,[DescriptionAr]  
   ,PageLink  
   ,ImageLink  
   ,SourceEn   
   ,PlaceEn  
   ,SourceAr  
   ,PlaceAr  
   ,Theme  
   ,Industry  
   ,[MediaType]  
   ,DateAnnounced  
   ,[ExpiryDate]  
   ,StatusID
   ,[IsActive]  
   ,ThumbNailPath
   ,RejectReason
   ,SpeakersEn
   ,SpeakersAr
   ,MD.StartDate
   ,MD.EndDate
   ,MD.StartTime
   ,MD.EndTime
   ,MD.TotalViews
   ,MD.LoggedinViews

 FROM MediaDetails MD WITH(NOLOCK)   
 		
 WHERE MD.Id = @Id  
   
END  
GO


