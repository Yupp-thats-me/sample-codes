﻿USE [SJCounselling]
GO

Insert Into  [SlotMaster] 
                 ([SlotEn],
	              [SlotAr])
VALUES
    ('30 Minutes',N'30 دقيقة'),
    ('60 Minutes',N'60 دقيقة')
GO