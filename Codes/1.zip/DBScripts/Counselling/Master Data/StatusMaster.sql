﻿USE SJCounselling
GO

Insert Into  [StatusMaster] 
                 ([StatusEn],
	              [StatusAr])
values
              ('Draft',N'مشروع'),
				('Pending Approval',N'ما زال يحتاج بتصدير'),
				('Approved',N'وافق'),
				('Rejected',N'مرفوض')



GO