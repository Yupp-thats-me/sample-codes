﻿USE SJCounselling
GO

Insert Into  [AccountTypeMaster] 
                 ([AccountTypeEn],
	              [AccountTypeAr])
values 
          ('Higher Education Student',N' طالب التعليم العالي'),
          (' Higher Education Institute',N'معهد التعليم العالي'),
			('CXO',N'CXO'),
			('Employer',N' صاحب العمل'),
			('General User',N' المستخدم العام'),
			('Counsellor',N' مستشار')




GO