﻿USE SJCounselling
GO

Insert Into  EmirateMaster 
                 (EmirateEn,
	              EmirateAr)
values

     (' Abu Dhabi',N' أبوظبي'),
('Ajman',N' عجمان'),
('Al Ain',N' العين'),
(' Al Dhafra',N' الظفرة'),
('Dubai',N' دبي'),
('Fujairah',N' الفجيرة'),
 ('Ras Al Khaimah',N'رأس الخيمة'),
('Sharjah',N' الشارقة'),
('Umm Al Quwain',N' أم القيوين')

             


GO