﻿USE [SJCounselling]
GO

Insert Into  [GenderMaster] 
                 ([GenderEn],
	              [GenderAr])
values
              ('Male',N' ذكر.'),
('Female',N' انثى'),
('Others',N' الاخرين')


GO