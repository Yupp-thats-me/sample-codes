﻿USE SJCounselling
GO

Insert Into  [CategoryMaster] 
                 ([CategoryEn],
	              [CategoryAr])
values 
           ('Academic UAE/Overseas',N'أكاديمي في الإمارات العربية المتحدة / في الخارج'),
           ('Wellbeing',N'لرفاهية'),
           ('Career',N'المهنة')



GO