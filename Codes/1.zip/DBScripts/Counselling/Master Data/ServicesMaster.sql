﻿USE [SJCounselling]
GO
SET IDENTITY_INSERT [dbo].[ServicesMaster] ON 

INSERT [dbo].[ServicesMaster] ([ServicesId], [ServicesEn], [ServicesAr], [CategoryId]) VALUES (1, N'Choose institution or university to study at', N'اختر مؤسسة أو جامعة للدراسة في', 1)
INSERT [dbo].[ServicesMaster] ([ServicesId], [ServicesEn], [ServicesAr], [CategoryId]) VALUES (2, N'Choose major to study', N'اختر تخصصا للدراسة', 1)
INSERT [dbo].[ServicesMaster] ([ServicesId], [ServicesEn], [ServicesAr], [CategoryId]) VALUES (3, N'University or scholarship application process', N'عملية طلب الجامعة أو المنح الدراسية', 1)
INSERT [dbo].[ServicesMaster] ([ServicesId], [ServicesEn], [ServicesAr], [CategoryId]) VALUES (4, N'Credit transfer', N'تحويل الائتمان', 1)
INSERT [dbo].[ServicesMaster] ([ServicesId], [ServicesEn], [ServicesAr], [CategoryId]) VALUES (5, N'Dealing with negative thoughts and emotions (depression, anxiety, anger and so on)', N'التعامل مع الأفكار والعواطف السلبية (الاكتئاب والقلق والغضب وهلم جرا)', 1)
INSERT [dbo].[ServicesMaster] ([ServicesId], [ServicesEn], [ServicesAr], [CategoryId]) VALUES (6, N'Time Management', N'إدارة الوقت', 1)
INSERT [dbo].[ServicesMaster] ([ServicesId], [ServicesEn], [ServicesAr], [CategoryId]) VALUES (7, N'Managing stress during exam', N'إدارة الإجهاد أثناء الامتحان', 2)
INSERT [dbo].[ServicesMaster] ([ServicesId], [ServicesEn], [ServicesAr], [CategoryId]) VALUES (8, N'Dealing with problems and crises (death of a family member, accident, family problems and so on) ', N'التعامل مع المشاكل والأزمات (وفاة أحد أفراد الأسرة، حادث، مشاكل عائلية وما إلى ذلك)', 2)
INSERT [dbo].[ServicesMaster] ([ServicesId], [ServicesEn], [ServicesAr], [CategoryId]) VALUES (9, N'Discovering your hobbies.', N'اكتشاف هواياتك', 2)
INSERT [dbo].[ServicesMaster] ([ServicesId], [ServicesEn], [ServicesAr], [CategoryId]) VALUES (10, N'Decision making skills', N'مهارات صنع القرار', 2)
INSERT [dbo].[ServicesMaster] ([ServicesId], [ServicesEn], [ServicesAr], [CategoryId]) VALUES (11, N'The UAE graduate job market', N'سوق عمل الخريجين في دولة الإمارات العربية المتحدة', 3)
INSERT [dbo].[ServicesMaster] ([ServicesId], [ServicesEn], [ServicesAr], [CategoryId]) VALUES (12, N'Choose internships or work placements', N'اختيار التدريب الداخلي أو مواضع العم', 3)
INSERT [dbo].[ServicesMaster] ([ServicesId], [ServicesEn], [ServicesAr], [CategoryId]) VALUES (13, N'Choose career or occupation (eg, doctor, airline pilot, accountant, software engineer, business analyst and so on)', N'اختيار التدريب الداخلي أو مواضع العمل', 3)
INSERT [dbo].[ServicesMaster] ([ServicesId], [ServicesEn], [ServicesAr], [CategoryId]) VALUES (14, N'Choose industry (eg, healthcare, financial services, construction, retail, defense, government, education)', N'اختيار الصناعة (على سبيل المثال، الرعاية الصحية، الخدمات المالية، البناء، البيع بالتجزئة، الدفاع، الحكومة، التعليم)', 3)
INSERT [dbo].[ServicesMaster] ([ServicesId], [ServicesEn], [ServicesAr], [CategoryId]) VALUES (15, N'Job searching strategies (websites, careers fairs, networking)', N'استراتيجيات البحث عن وظيفة (المواقع، والمعارض المهنية، والشبكات)', 3)
INSERT [dbo].[ServicesMaster] ([ServicesId], [ServicesEn], [ServicesAr], [CategoryId]) VALUES (16, N'Job application skills (CV writing, interview skills, networking skills, writing cover letters and so on)', N'مهارات طلب الوظيفة (كتابة السيرة الذاتية ومهارات المقابلة ومهارات التواصل وكتابة رسائل التغطية وما إلى ذلك)', 3)
SET IDENTITY_INSERT [dbo].[ServicesMaster] OFF
GO