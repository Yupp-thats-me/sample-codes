﻿USE [SJCounselling]
GO

Insert Into  [TitleNameTypeMaster] 
                 ([TitleEn],
	              [TitleAr])
values
             ('Mr',N'السيد'),
			('Ms',N'السيدة'),
			('Mrs',N'سيدة'),
			('Dr',N'د')




GO