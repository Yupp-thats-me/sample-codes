﻿USE SJCounselling
GO

Insert Into  [HigherEducationMaster] 
                 ([HigherEducationEn],
	              [HigherEducationAr])
values
              ('PhD',N'الدكتوراه'),
              ('Master''s',N'ماجستير'),
              ('Bachelor''s',N'بكالوريوس')


GO