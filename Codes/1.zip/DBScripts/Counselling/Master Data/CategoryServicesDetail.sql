﻿USE [SJCounselling]
GO
INSERT [dbo].[CategoryServicesDetail] ([CategoryId], [ServicesId]) VALUES (1, 1)
INSERT [dbo].[CategoryServicesDetail] ([CategoryId], [ServicesId]) VALUES (1, 2)
INSERT [dbo].[CategoryServicesDetail] ([CategoryId], [ServicesId]) VALUES (1, 3)
INSERT [dbo].[CategoryServicesDetail] ([CategoryId], [ServicesId]) VALUES (1, 4)
INSERT [dbo].[CategoryServicesDetail] ([CategoryId], [ServicesId]) VALUES (1, 5)
INSERT [dbo].[CategoryServicesDetail] ([CategoryId], [ServicesId]) VALUES (1, 6)
INSERT [dbo].[CategoryServicesDetail] ([CategoryId], [ServicesId]) VALUES (2, 7)
INSERT [dbo].[CategoryServicesDetail] ([CategoryId], [ServicesId]) VALUES (2, 8)
INSERT [dbo].[CategoryServicesDetail] ([CategoryId], [ServicesId]) VALUES (2, 9)
INSERT [dbo].[CategoryServicesDetail] ([CategoryId], [ServicesId]) VALUES (2, 10)
INSERT [dbo].[CategoryServicesDetail] ([CategoryId], [ServicesId]) VALUES (3, 11)
INSERT [dbo].[CategoryServicesDetail] ([CategoryId], [ServicesId]) VALUES (3, 12)
INSERT [dbo].[CategoryServicesDetail] ([CategoryId], [ServicesId]) VALUES (3, 13)
INSERT [dbo].[CategoryServicesDetail] ([CategoryId], [ServicesId]) VALUES (3, 14)
INSERT [dbo].[CategoryServicesDetail] ([CategoryId], [ServicesId]) VALUES (3, 15)
INSERT [dbo].[CategoryServicesDetail] ([CategoryId], [ServicesId]) VALUES (3, 16)
GO
