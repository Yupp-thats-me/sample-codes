USE [SJCounselling]
GO

/****** Object:  Table [dbo].[Review]    Script Date: 11/9/2021 10:27:04 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Review](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[AppointmentId] [int] NOT NULL,
	[ReviewedBy] [bigint] NOT NULL,
	[ReviewedFor] [bigint] NOT NULL,
	[RateGiven] [int] NOT NULL,
	[CounsellorAttendSession] [bit] NOT NULL,
	[Reviewcontent] [nvarchar](1000) NULL,
	[CreatedBy] [nvarchar](20) NULL,
	[CreatedDate] [datetime] NOT NULL,
	[UpdatedBy] [nvarchar](20) NULL,
	[UpdatedDate] [datetime] NULL,
	[IsActive] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


