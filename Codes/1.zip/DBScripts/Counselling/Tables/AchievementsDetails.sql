USE [SJCounselling]
GO

/****** Object:  Table [dbo].[AchievementsDetails]    Script Date: 11/8/2021 4:42:33 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AchievementsDetails](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[CounsellorId] [bigint] NOT NULL,
	[Title] [nvarchar](250) NULL,
	[IssuingAuthority] [nvarchar](250) NULL,
	[CreatedBy] [nvarchar](100) NULL,
	[CreatedDate] [datetime] NULL,
	[UpdatedBy] [nvarchar](100) NULL,
	[UpdatedDate] [datetime] NULL,
	[IsActive] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[AchievementsDetails]  WITH CHECK ADD FOREIGN KEY([CounsellorId])
REFERENCES [dbo].[CounsellorPersonalDetails] ([Id])
GO


