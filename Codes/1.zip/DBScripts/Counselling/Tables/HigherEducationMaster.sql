USE [SJCounselling]
GO

/****** Object:  Table [dbo].[HigherEducationMaster]    Script Date: 11/9/2021 10:12:49 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[HigherEducationMaster](
	[HigherEducationId] [int] IDENTITY(1,1) NOT NULL,
	[HigherEducationEn] [nvarchar](36) NULL,
	[HigherEducationAr] [nvarchar](36) NULL,
PRIMARY KEY CLUSTERED 
(
	[HigherEducationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


