USE [SJCounselling]
GO

/****** Object:  Table [dbo].[FaqDetails]    Script Date: 11/9/2021 10:08:30 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[FaqDetails](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[CounsellorId] [bigint] NOT NULL,
	[QuestionEn] [nvarchar](500) NOT NULL,
	[AnswerEn] [nvarchar](500) NOT NULL,
	[QuestionAr] [nvarchar](500) NOT NULL,
	[AnswerAr] [nvarchar](500) NOT NULL,
	[CategoryId] [int] NOT NULL,
	[PostedDate] [datetime] NOT NULL,
	[StatusId] [int] NULL,
	[RejectReason] [nvarchar](500) NULL,
	[CreatedBy] [nvarchar](20) NULL,
	[CreatedDate] [datetime] NOT NULL,
	[UpdatedBy] [nvarchar](20) NULL,
	[UpdatedDate] [datetime] NULL,
	[IsActive] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[FaqDetails]  WITH CHECK ADD  CONSTRAINT [FK_Category] FOREIGN KEY([CategoryId])
REFERENCES [dbo].[CategoryMaster] ([CategoryId])
GO

ALTER TABLE [dbo].[FaqDetails] CHECK CONSTRAINT [FK_Category]
GO


