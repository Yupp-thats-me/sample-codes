USE [SJCounselling]
GO

/****** Object:  Table [dbo].[CategoryServicesDetail]    Script Date: 11/9/2021 9:45:06 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CategoryServicesDetail](
	[CategoryId] [int] NULL,
	[ServicesId] [int] NULL
) ON [PRIMARY]
GO


