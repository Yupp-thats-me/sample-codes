USE [SJCounselling]
GO

/****** Object:  Table [dbo].[AppointmentReports]    Script Date: 11/9/2021 9:38:16 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AppointmentReports](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[AppointmentId] [bigint] NOT NULL,
	[CounsellorId] [bigint] NOT NULL,
	[StudentId] [bigint] NOT NULL,
	[Title] [nvarchar](500) NOT NULL,
	[Description] [nvarchar](2000) NOT NULL,
	[SessionDate] [datetime] NOT NULL,
	[StartTime] [nvarchar](20) NOT NULL,
	[EndTime] [nvarchar](20) NOT NULL,
	[IsActive] [bit] NULL,
	[CreatedBy] [nvarchar](20) NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[UpdatedBy] [nvarchar](20) NULL,
	[UpdatedDate] [datetime] NULL
) ON [PRIMARY]
GO


