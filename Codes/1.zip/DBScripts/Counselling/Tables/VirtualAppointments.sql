USE [SJCounselling]
GO

/****** Object:  Table [dbo].[VirtualAppointments]    Script Date: 11/9/2021 10:40:49 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[VirtualAppointments](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[StudentId] [bigint] NOT NULL,
	[CounsellorId] [bigint] NOT NULL,
	[Category] [int] NOT NULL,
	[Service] [int] NOT NULL,
	[Languages] [nvarchar](500) NULL,
	[Subject] [nvarchar](250) NULL,
	[Purpose] [nvarchar](1000) NULL,
	[Documents] [nvarchar](100) NULL,
	[Duration] [int] NOT NULL,
	[SelectedDate] [datetime] NOT NULL,
	[StartTime] [nvarchar](50) NOT NULL,
	[EndTime] [nvarchar](50) NOT NULL,
	[StatusId] [int] NULL,
	[ReasonReject] [nvarchar](500) NULL,
	[VirtualLink] [nvarchar](500) NULL,
	[StudentAttandance] [bit] NULL,
	[CouncellorAttandance] [bit] NULL,
	[CreatedBy] [nvarchar](20) NULL,
	[CreatedDate] [datetime] NOT NULL,
	[UpdatedBy] [nvarchar](20) NULL,
	[UpdatedDate] [datetime] NULL,
	[Title] [nvarchar](500) NULL,
	[Descriptions] [nvarchar](2000) NULL,
	[IsActive] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[VirtualAppointments]  WITH CHECK ADD FOREIGN KEY([CounsellorId])
REFERENCES [dbo].[CounsellorPersonalDetails] ([Id])
GO

ALTER TABLE [dbo].[VirtualAppointments]  WITH CHECK ADD FOREIGN KEY([Service])
REFERENCES [dbo].[ServicesMaster] ([ServicesId])
GO

ALTER TABLE [dbo].[VirtualAppointments]  WITH CHECK ADD  CONSTRAINT [FK_Categ] FOREIGN KEY([Category])
REFERENCES [dbo].[CategoryMaster] ([CategoryId])
GO

ALTER TABLE [dbo].[VirtualAppointments] CHECK CONSTRAINT [FK_Categ]
GO


