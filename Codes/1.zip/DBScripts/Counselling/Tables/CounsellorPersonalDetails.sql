USE [SJCounselling]
GO

/****** Object:  Table [dbo].[CounsellorPersonalDetails]    Script Date: 11/9/2021 9:57:52 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CounsellorPersonalDetails](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[FirstName] [nvarchar](100) NULL,
	[MiddleName] [nvarchar](100) NULL,
	[LastName] [nvarchar](100) NULL,
	[Gender] [nvarchar](10) NULL,
	[DOB] [datetime] NULL,
	[LanguageKnown] [nvarchar](500) NULL,
	[Email] [nvarchar](100) NULL,
	[PhoneNumber] [nvarchar](50) NULL,
	[AddressLine1] [nvarchar](100) NULL,
	[AddressLine2] [nvarchar](100) NULL,
	[ZipCode] [nvarchar](100) NULL,
	[EmiratesCityId] [int] NULL,
	[EmirateId] [nvarchar](20) NULL,
	[UserId] [bigint] NULL,
	[MobileCode] [int] NULL,
	[AlternateEmail] [nvarchar](100) NULL,
	[Bio] [nvarchar](1000) NULL,
	[CategoryId] [nvarchar](100) NULL,
	[StatusId] [int] NULL,
	[RejectReason] [nvarchar](500) NULL,
	[CreatedBy] [nvarchar](100) NULL,
	[CreatedDate] [datetime] NULL,
	[UpdatedBy] [nvarchar](100) NULL,
	[UpdatedDate] [datetime] NULL,
	[MobileNo] [nvarchar](20) NULL,
	[EntryVia] [int] NULL,
	[ProfilePic] [nvarchar](100) NULL,
	[ServicesId] [nvarchar](100) NULL,
	[IsActive] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[CounsellorPersonalDetails]  WITH CHECK ADD FOREIGN KEY([EmiratesCityId])
REFERENCES [dbo].[EmirateMaster] ([EmirateId])
GO


