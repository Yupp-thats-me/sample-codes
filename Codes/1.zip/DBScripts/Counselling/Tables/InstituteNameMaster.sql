USE [SJCounselling]
GO

/****** Object:  Table [dbo].[InstituteNameMaster]    Script Date: 11/9/2021 10:20:21 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[InstituteNameMaster](
	[InstituteId] [int] IDENTITY(1,1) NOT NULL,
	[Institute] [nvarchar](250) NULL,
PRIMARY KEY CLUSTERED 
(
	[InstituteId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


