USE [SJCounselling]
GO

/****** Object:  Table [dbo].[CounsellorFreeTimings]    Script Date: 11/9/2021 9:55:14 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CounsellorFreeTimings](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[CounsellorId] [bigint] NOT NULL,
	[SelectedDate] [datetime] NOT NULL,
	[StartTime] [nvarchar](50) NOT NULL,
	[EndTime] [nvarchar](50) NOT NULL,
	[TimeDuration] [int] NULL,
	[CreatedBy] [nvarchar](20) NULL,
	[CreatedDate] [datetime] NOT NULL,
	[UpdatedBy] [nvarchar](20) NULL,
	[UpdatedDate] [datetime] NULL,
	[Status] [int] NOT NULL,
	[IsActive] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[CounsellorFreeTimings]  WITH CHECK ADD FOREIGN KEY([CounsellorId])
REFERENCES [dbo].[CounsellorPersonalDetails] ([Id])
GO


