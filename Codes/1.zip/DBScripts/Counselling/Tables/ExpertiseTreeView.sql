USE [SJCounselling]
GO

/****** Object:  Table [dbo].[ExpertiseTreeView]    Script Date: 11/9/2021 10:06:24 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ExpertiseTreeView](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[En_Expertise] [nvarchar](250) NULL,
	[Ar_Expertise] [nvarchar](250) NULL,
	[ParentId] [int] NULL
) ON [PRIMARY]
GO


