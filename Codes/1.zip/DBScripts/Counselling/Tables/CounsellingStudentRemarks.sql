USE [SJCounselling]
GO

/****** Object:  Table [dbo].[CounsellingStudentRemarks]    Script Date: 11/9/2021 9:52:48 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CounsellingStudentRemarks](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[AppointmentId] [bigint] NOT NULL,
	[StudentId] [bigint] NOT NULL,
	[CounsellorId] [bigint] NOT NULL,
	[Remarks] [nvarchar](2000) NOT NULL,
	[StudentAttandance] [bit] NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedBy] [nvarchar](20) NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[UpdatedBy] [nvarchar](20) NULL,
	[UpdatedDate] [datetime] NULL
) ON [PRIMARY]
GO


