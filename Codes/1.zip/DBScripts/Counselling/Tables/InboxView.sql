USE [SJCounselling]
GO

/****** Object:  Table [dbo].[InboxView]    Script Date: 11/9/2021 10:18:15 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[InboxView](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[QandAListId] [bigint] NOT NULL,
	[Question] [nvarchar](500) NOT NULL,
	[Answer] [nvarchar](500) NULL,
	[PostedDate] [datetime] NOT NULL,
	[ReplayDate] [datetime] NULL,
	[Pinned] [bit] NULL,
	[Document] [nvarchar](500) NULL,
	[StudentDocument] [nvarchar](500) NULL,
	[CreatedBy] [nvarchar](20) NOT NULL,
	[CreatedDate] [datetime] NULL,
	[UpdatedBy] [nvarchar](20) NULL,
	[UpdatedDate] [datetime] NULL,
	[IsActive] [bit] NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[InboxView]  WITH CHECK ADD  CONSTRAINT [FK_QandAId] FOREIGN KEY([QandAListId])
REFERENCES [dbo].[InboxList] ([Id])
GO

ALTER TABLE [dbo].[InboxView] CHECK CONSTRAINT [FK_QandAId]
GO


