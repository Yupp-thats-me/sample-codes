USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetInboxList]    Script Date: 13-01-2022 11:54:58 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetInboxList]
@CounsellorId BIGINT  = null,
@StudentId BIGINT = null
AS
BEGIN 
Declare @table Table(
Id BIGINT Identity not null,
QandAListId BIGINT NOt null, 
CounsellorName NVARCHAR(200),
StudentName  NVARCHAR(200),
CategoryEn NVARCHAR(100), 
CategoryAr NVARCHAR(100),
ServicesEn NVARCHAR(150),
ServicesAr NVARCHAR(150),
Language NVARCHAR(100),
Subject NVARCHAR(500),
PostedDate DateTime,
ReplayDate DateTime)

Insert into @table (QandAListId,StudentName,CounsellorName,CategoryEn,CategoryAr,ServicesEn,ServicesAr,
Language,Subject)
Select 
QandAListId,
    CONCAT(SPD.FirstName,' ',SPD.MiddleName,' ',SPD.LastName) AS StudentName,
	CONCAT(CPD.FirstName,' ',CPD.MiddleName,' ',CPD.LastName) AS CounsellorName,
CM.CategoryEn, CM.CategoryAr,
SM.ServicesEn, SM.ServicesAr,
Language,
Subject
 from QandADetails QAD
   join CategoryMaster CM
      ON QAD.CategoryId = CM.CategoryId

      join ServicesMaster SM
     ON QAD.ServiceId = SM.ServicesId
	 join CounsellorPersonalDetails CPD
	 ON QAD.CounsellorId = CPD.Id
      left Join  [SJAcademics]..StudentPersonalDetails SPD
	 on QAD.StudentId = SPD.Id
	where((@CounsellorId is null or @CounsellorId = 0 or CounsellorId=@CounsellorId) and
	(@StudentId is null or @StudentId =0 or StudentId = @StudentId))
     group By QandAListId, CONCAT(SPD.FirstName,' ',SPD.MiddleName,' ',SPD.LastName),
        CONCAT(CPD.FirstName,' ',CPD.MiddleName,' ',CPD.LastName),
        CM.CategoryEn,  CM.CategoryAr,
        SM.ServicesEn,  SM.ServicesAr,
       Language,
        Subject
 
 Declare @startCount int = 1, 
         @endCount int
 Select @endCount = Count(1) from @table
 
 while (@startCount <= @endCount)
 BEGIN
 Declare @PostDate DateTime,
         @ReplayDate DateTime

Select top 1 @PostDate= QAD2.PostedDate ,@ReplayDate = QAD2.ReplayDate from QandADetails QAD2
    join @table jt
	on QAD2.QandAListId = jt.QandAListId
	where Jt.Id = @startCount
	Order By QAD2.PostedDate desc

	update @table 
	set PostedDate = @PostDate,
	ReplayDate = @ReplayDate where Id = @startCount

	Set @startCount = @startCount+1
 END
Select * from @table
END
GO


