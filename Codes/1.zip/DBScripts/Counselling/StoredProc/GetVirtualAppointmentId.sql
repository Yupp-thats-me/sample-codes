USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetVirtualAppointmentId]    Script Date: 13-01-2022 12:30:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER   PROCEDURE [dbo].[GetVirtualAppointmentId]
@Id bigInt = null

AS 
BEGIN

 SELECT 	
    Va.Id,
	VA.StudentId as StudentId,
    CONCAT(SPD.FirstName,' ',SPD.LastName) AS StudentName,
	SPD.Email as StudentEmail,
	SPD.Gender as StudentGender,
	SPD.PhoneNumber as StudentPhoneNumber,
	CounsellorId,
	VA.Category as Category,
	CM.CategoryAr as CategoryAr,
    CM.CategoryEn as CategoryEn,
	VA.Service as Service,
	SM.ServicesAr as ServicesAr,
	SM.ServicesEn as ServicesEn,
	Languages,
	Subject,
	Purpose,
	Documents,
	Duration,
	SelectedDate,
	StartTime,
	EndTime,
	VA.StatusId,
	ReasonReject,
	VirtualLink,
	StudentAttandance,
	CouncellorAttandance,
	VA.CreatedBy,
	VA.CreatedDate,
	VA.UpdatedBy,
	Va.UpdatedDate,
	VA.IsActive,
	VA.StatusId as StatusId,
	VA.ReasonReject as ReasonReject,
	VirtualLink
	CouncellorAttandance,
	StudentAttandance,
	CONCAT(CPD.FirstName,' ',CPD.LastName) AS CounsellorName,
	CPD.Email,
	CPD.Gender

	FROM	[VirtualAppointments]VA WITH(NOLOCK) 
	left join CategoryMaster CM
      ON VA.Category = CM.CategoryId

     left join SJIdentity .. [User] CPD
	 on VA.CounsellorId = CPD.Id

      left join ServicesMaster SM
     ON VA.Service = SM.ServicesId

	 left join SJIdentity .. [User] SPD
	 on VA.StudentId = SPD.Id

	where VA.Id = @Id
	 AND VA.IsActive=1
    ORDER BY (CASE 
          WHEN VA.UpdatedDate IS NULL 
          THEN VA.CreatedDate ELSE VA.UpdatedDate 
          END) 
    DESC
END
GO


