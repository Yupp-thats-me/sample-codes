USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[InActiveQandAById]    Script Date: 13-01-2022 12:43:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[InActiveQandAById]
	@Id BigInt
AS
BEGIN
 
	SET NOCOUNT ON;
	
	UPDATE InboxView SET IsActive = 0
	WHERE Id = @Id
	
END
GO


