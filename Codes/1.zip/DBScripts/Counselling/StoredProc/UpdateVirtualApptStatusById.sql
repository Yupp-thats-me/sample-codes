USE SJCounselling
GO

/****** Object:  StoredProcedure [dbo].[UpdateVirtualApptStatusById]    Script Date: 11/9/2021 12:45:36 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER   PROCEDURE [dbo].[UpdateVirtualApptStatusById] 
(
	 @Id BIGINT
	,@StatusId varchar
	,@UpdatedBy NVARCHAR(20)= null
	,@ReasonReject NVARCHAR(1000) = NULL
	,@VirtualLink nvarchar(500)=NULL	
	,@AvailableTimeId Int=0
)
AS
  BEGIN

       IF (@StatusId=3)--approved
	   BEGIN
	    UPDATE CounsellorFreeTimings SET Status = 3 WHERE Id= @AvailableTimeId
		END
		
		IF (@StatusId=4)--Rejected
		BEGIN
		 UPDATE CounsellorFreeTimings SET Status = 1 WHERE ID= @AvailableTimeId
		END
		
		UPDATE VirtualAppointments
		 SET
		   
			  StatusId= @StatusId,--update
			  ReasonReject=@ReasonReject,---Update
			  VirtualLink=@VirtualLink,	
			  UpdatedBy=@UpdatedBy,
			  UpdatedDate=GETDATE()
				WHERE Id =@Id

	END



GO


