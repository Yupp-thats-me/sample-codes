USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetAchievementDetailId]    Script Date: 12-01-2022 15:44:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetAchievementDetailId]
@Id BIGINT
AS
BEGIN
 SELECT Id,
	CounsellorId,
	Title,
	IssuingAuthority,
	CreatedBy,
	CreatedDate,
	UpdatedBy,
	UpdatedDate,
	IsActive
  FROM [AchievementsDetails]
  where CounsellorId = @Id
  AND IsActive=1
  ORDER BY (CASE 
           WHEN UpdatedDate IS NULL 
		   THEN CreatedDate ELSE UpdatedDate 
		   END
				) DESC


END
GO


