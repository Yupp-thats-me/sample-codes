USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[SaveFaQDetails]    Script Date: 13-01-2022 13:02:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[SaveFaQDetails]
(

    @Id bigint=0,
	@CounsellorId bigint=0,
	@QuestionEn nvarchar(500)=NULL,
	@AnswerEn nvarchar(500)=NULL,
	@QuestionAr nvarchar(500)=NULL,
	@AnswerAr nvarchar(500)=NULL,
	@CategoryId int=0,
	@PostedDate datetime,
	@StatusId int=0,
	@RejectReason nvarchar(500)=NULL,
	@CreatedBy nvarchar(20)=NULL,
	@UpdatedBy nvarchar(20)=NULL,
	@IsActive bit=0
	
)
AS
BEGIN
IF ISNULL(@Id, 0) = 0
 BEGIN
  INSERT INTO FaqDetails(
  CounsellorId,  
  QuestionEn,
  AnswerEn ,
  QuestionAr,
  AnswerAr,
  CategoryId,
  PostedDate,
  StatusId,
  RejectReason, 
  CreatedBy,
  CreatedDate,
  IsActive
  
  
  )
  values
  (
    @CounsellorId ,
	@QuestionEn,
	@AnswerEn,
	@QuestionAr,
	@AnswerAr,
	@CategoryId,
	@PostedDate,
	@StatusId,
	@RejectReason,
	@CreatedBy,
	GETDATE(),
	@IsActive
	
	
	)
   SELECT @Id= SCOPE_IDENTITY()

			SELECT @Id 
END
ELSE
  BEGIN
		 UPDATE FaqDetails
		 SET
		      CounsellorId=@CounsellorId,  
			  QuestionEn=@QuestionEn,
			  AnswerEn=@AnswerEn,
			  QuestionAr=@QuestionAr,
			  AnswerAr=@AnswerAr,
			  CategoryId=CategoryId,
			  PostedDate=@PostedDate,
			  StatusId=@StatusId,
			  RejectReason=@RejectReason,			 
			  UpdatedBy=@UpdatedBy,
			  UpdatedDate=GETDATE(),
			  IsActive=@IsActive	
				WHERE Id =@Id

	END

	SELECT @Id
END
GO


