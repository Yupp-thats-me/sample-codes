USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[SaveAcheivementsDetails]    Script Date: 13-01-2022 12:48:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[SaveAcheivementsDetails]
(
@Id bigint=0,
@CounsellorId bigint=0,
@Title nvarchar(250)=NULL,
@IssuingAuthority nvarchar(250)=NULL,
@CreatedBy nvarchar(100)=NULL,
@UpdatedBy nvarchar(100)=NULL,
@IsActive bit=0
)
AS
BEGIN
IF ISNULL(@Id, 0) = 0
 BEGIN
  INSERT INTO AchievementsDetails(
  CounsellorId,
  Title,
  IssuingAuthority,
  CreatedBy,
  CreatedDate,
  IsActive
 
  )
  values
  (
    @CounsellorId,
	@Title,
	@IssuingAuthority,
	@CreatedBy,
	GETDATE(),
	@IsActive
	
   )
   SELECT @Id= SCOPE_IDENTITY()

			SELECT @Id 
END
ELSE
  BEGIN
     UPDATE AchievementsDetails
	 SET
	  CounsellorId=@CounsellorId,
	  Title=@Title,
	  IssuingAuthority=@IssuingAuthority,
	  UpdatedBy=@UpdatedBy,
	  UpdatedDate=GETDATE(),
	  IsActive=@IsActive
	WHERE Id =@Id

	END

	SELECT @Id
END













GO


