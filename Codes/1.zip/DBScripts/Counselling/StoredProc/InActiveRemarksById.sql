USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[InActiveRemarksById]    Script Date: 13-01-2022 12:47:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[InActiveRemarksById]
	@Id bigint
AS
BEGIN
 
	SET NOCOUNT ON;
	
	UPDATE  CounsellingStudentRemarks set IsActive = 0
	WHERE Id = @Id
	
END
GO


