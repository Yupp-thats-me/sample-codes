USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetCounsellorPersonalDetails]    Script Date: 12-01-2022 17:00:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetCounsellorPersonalDetails]
AS
BEGIN
 SELECT 	
	Id,
	EntryVia,
	FirstName,
	MiddleName,
	LastName,
	Gender,
	DOB,
	LanguageKnown,
	Email,
	PhoneNumber,
	AddressLine1,
	AddressLine2,
	ZipCode,
	CPD.EmiratesCityId as EmiratesCityId,
	EM.EmirateEn as EmirateEn,
	EM.EmirateAr as EmirateAr,
	CPD.EmirateId as EmirateId,
	UserId,
	MobileCode,
	AlternateEmail,
	Bio,
	CategoryId,
	ServicesId,
	StatusId,
	RejectReason,
	CreatedBy,
	CreatedDate,
	UpdatedBy,
	UpdatedDate,
	MobileNo,
	ProfilePic

	FROM [CounsellorPersonalDetails]CPD WITH(NOLOCK)
	
	join EmirateMaster EM
	On CPD.EmiratesCityId = EM.EmirateId
	AND IsActive=1
    ORDER BY (CASE 
          WHEN UpdatedDate IS NULL 
          THEN CreatedDate ELSE UpdatedDate 
          END) 
    DESC
END
GO


