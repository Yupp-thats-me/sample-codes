USE SJCounselling
GO

/****** Object:  StoredProcedure [dbo].[GetStatusMaster]    Script Date: 11/9/2021 12:23:47 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetStatusMaster]
AS
BEGIN
SELECT [StatusId]
      ,[StatusEn]
      ,[StatusAr]
  FROM StatusMaster with (nolock)
END
GO


