USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[SaveStudentRemarksDetail]    Script Date: 13-01-2022 13:08:11 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[SaveStudentRemarksDetail]
(
    @Id BigInt=0,
	@AppointmentId BigInt=0,
	@CounsellorId BigInt=0,
	@StudentId BigInt=0,
	@Remarks int=0,
	@StudentAttandance bit=false,
	@IsActive bit = false,
	@CreatedBy nvarchar(20)=NULL,	
	@UpdatedBy nvarchar(20)=NULL
	
)
AS
BEGIN
IF ISNULL(@Id, 0) = 0
BEGIN
  INSERT INTO CounsellingStudentRemarks(
	AppointmentId,
	CounsellorId,
	StudentId,
	Remarks,
	StudentAttandance,
	IsActive,
	CreatedBy,
	CreatedDate
	)
VALUES(
	@AppointmentId,
	@CounsellorId,
	@StudentId,
	@Remarks,
	@StudentAttandance,
	@IsActive,
	@CreatedBy,
	GETDATE()
	
)
update VirtualAppointments set StudentAttandance = @StudentAttandance where Id= @AppointmentId

   SELECT @Id= SCOPE_IDENTITY()

			SELECT @Id 
END

ELSE
  BEGIN
		 UPDATE CounsellingStudentRemarks
		 SET
	AppointmentId = @AppointmentId,
	CounsellorId = @CounsellorId,
	StudentId = @StudentId,
	Remarks = @Remarks,
	StudentAttandance = @StudentAttandance,
	IsActive = @IsActive,	
	UpdatedBy = @UpdatedBy,
	UpdatedDate = GETDATE()
	WHERE Id =@Id
	update VirtualAppointments set StudentAttandance = @StudentAttandance where Id= @AppointmentId
	END
	SELECT @Id
END
GO


