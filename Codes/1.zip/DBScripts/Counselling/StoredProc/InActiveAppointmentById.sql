USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[InActiveAppointmentById]    Script Date: 13-01-2022 12:33:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[InActiveAppointmentById]
	@Id bigint
AS
BEGIN
 
	SET NOCOUNT ON;
	
	UPDATE  VirtualAppointments set IsActive = 0
	WHERE Id = @Id
	
END
GO


