USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[SaveEducationDetails]    Script Date: 13-01-2022 12:58:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[SaveEducationDetails]
(
 @Id int=0,
@CounsellorId bigint=0,
@HigherEducationId int=0,
@MajorId int =0,
@InstituteId int =0,
@StartDate datetime,
@Pursuing bit,
@EndDate datetime,
@CreatedBy nvarchar(100)=NULL,
@UpdatedBy nvarchar(100)=NULL,
@IsActive bit=0
)
AS
BEGIN
IF ISNULL(@Id, 0) = 0
 BEGIN
  INSERT INTO EducationDetails(
  CounsellorId,
  HigherEducationId,
  MajorId,
  InstituteId,
  StartDate,
  Pursuing,
  EndDate,
  CreatedBy,
  CreatedDate,
  IsActive
  
  )
  values
  (
    @CounsellorId,
	@HigherEducationId,
	@MajorId,
	@InstituteId,
	@StartDate,
	@Pursuing,
	CASE WHEN @EndDate='1900-01-01' or @EndDate is null
	THEN NULL
	ELSE @EndDate END,
	@CreatedBy,
	GETDATE(),
	@IsActive
	
   )
   SELECT @Id= SCOPE_IDENTITY()

			SELECT @Id 
END
ELSE
  BEGIN
     UPDATE EducationDetails
	 SET
	  CounsellorId=@CounsellorId,
	  HigherEducationId=@HigherEducationId,
	  MajorId=@MajorId,
	  InstituteId=@InstituteId,
	  StartDate=@StartDate,
	  Pursuing=@Pursuing,
	  EndDate=CASE WHEN @EndDate='1900-01-01' or @EndDate is null
	  THEN NULL
	  ELSE @EndDate END,	  
	  UpdatedBy=@UpdatedBy,
	  UpdatedDate=GETDATE(),
	  IsActive=@IsActive
	WHERE Id =@Id

	END

	SELECT @Id
END
GO


