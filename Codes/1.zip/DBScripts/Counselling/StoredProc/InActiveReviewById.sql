USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[InActiveReviewById]    Script Date: 13-01-2022 12:48:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[InActiveReviewById]
	@Id bigint
AS
BEGIN
 
	SET NOCOUNT ON;
	
	UPDATE  Review set IsActive = 0
	WHERE Id = @Id
	
END
GO


