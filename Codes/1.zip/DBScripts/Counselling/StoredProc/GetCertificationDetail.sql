USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetCertificationDetail]    Script Date: 12-01-2022 15:52:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetCertificationDetail]
@CounsellorId BIGINT null
AS
BEGIN
 SELECT Id,
	CounsellorId,
	Title,
	IssuingAuthority,
	StartDate,
	Pursuing,
	EndDate,
	CreatedBy,
	CreatedDate,
	UpdatedBy,
	UpdatedDate
	FROM	[CertificationDetails] WITH(NOLOCK)
	where (@CounsellorId is null or CounsellorId = @CounsellorId)
	AND IsActive=1
    ORDER BY (CASE 
          WHEN UpdatedDate IS NULL 
          THEN CreatedDate ELSE UpdatedDate 
          END) 
    DESC
END
GO


