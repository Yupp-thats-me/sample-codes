USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetCounsellorDetailsList]    Script Date: 12-01-2022 15:54:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetCounsellorDetailsList]
AS
BEGIN
SELECT 
CP.Id, 
CP.profilepic,
CP.FirstName,
CP.MiddleName,
CP.LastName,
CONCAT(FirstName,' ',MiddleName,' ',LastName) AS Name ,
AVG(RV.RateGiven) AS AverageRating,
Count(RV.RateGiven) AS TotalRating,
CP.Bio,
CP.CategoryId,
CP.ServicesId
FROM CounsellorPersonalDetails CP WITH (NOLOCK)
left join Review RV 
ON RV.ReviewedFor=CP.Id 
GROUP BY CP.Id,CP.FirstName,
CP.MiddleName,
CP.LastName,CONCAT(FirstName,'',MiddleName,'',LastName),
CP.profilepic,
CP.Bio,
CP.CategoryId,
CP.ServicesId

END

GO


