USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetCategoryMaster]    Script Date: 12-01-2022 15:50:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetCategoryMaster]
AS
BEGIN
 SELECT [CategoryId]
      ,[CategoryEn]
      ,[CategoryAr]
  FROM [CategoryMaster] WITH (NOLOCK)
END
GO


