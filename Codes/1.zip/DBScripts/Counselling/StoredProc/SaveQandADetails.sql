USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[SaveQandADetails]    Script Date: 13-01-2022 13:05:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[SaveQandADetails]
(
    @ReferenceId BIGINT NULL OUTPUT,
    @Id bigint=0,
	@CounsellorId bigint=0,
	@StudentId bigint=0,
	@CategoryId int=0,
	@ServiceId int=0,
	@Language nvarchar(500)=NULL,
	@Subject nvarchar(250)=NULL,
	@Question nvarchar(500)=NULL,
	@Answer nvarchar(500)=NULL,
	@Document nvarchar(100) = null,
	@pinned bit = NULL,
	@PostedDate datetime =NULL,
	@ReplayDate datetime =NULL,
	@CreatedBy nvarchar(20)=NULL,	
	@UpdatedBy nvarchar(20)=NULL,
    @IsActive bit=0,
	@QandAListId bigInt=0
	

)
AS
BEGIN
IF ISNULL(@QandAListId, 0) = 0
 BEGIN
  INSERT INTO InboxList(
  CounsellorId,  
  StudentId,
  CategoryId,
  ServiceId,
  Language,
  Subject,
  Question,
  PostedDate,
  ReplayDate,
  Status,
  CreatedBy,
  CreatedDate)
  values
  (
    @CounsellorId,
	@StudentId,
	@CategoryId,
	@ServiceId,
	@Language,
	@Subject,
	@Question,
	@PostedDate,
	@PostedDate,
	0,
	@CreatedBy,
	GETDATE()
	)
   
    SET @ReferenceId = SCOPE_IDENTITY();

			SELECT @Id 
Insert into InboxView(
QandAListId,
Question,
PostedDate,
Pinned,
Document,
CreatedBy,
CreatedDate,
IsActive
)Values(
@ReferenceId,
@Question,
@PostedDate,
@Pinned,
@Document,
@CreatedBy,
GETDATE(),
@IsActive
)
 SET @ReferenceId = SCOPE_IDENTITY();
END
ELSE
  BEGIN
		 UPDATE InboxList
		 SET
			  Question=@Question,
			  Answer = @Answer,
			  PostedDate=@PostedDate,
			  ReplayDate = @PostedDate,
			  UpdatedBy=@UpdatedBy,
			  UpdatedDate=GETDATE()
				WHERE Id = @QandAListId
  Insert into InboxView(
QandAListId,
Question,
Answer,
PostedDate,
ReplayDate,
Pinned,
Document,
CreatedBy,
CreatedDate,
IsActive
)Values(
@QandAListId,
@Question,
@Answer,
@PostedDate,
@ReplayDate,
@Pinned,
@Document,
@CreatedBy,
GETDATE(),
@IsActive
)

				SET @ReferenceId=SCOPE_IDENTITY()
	END

	SELECT @Id
END
GO


