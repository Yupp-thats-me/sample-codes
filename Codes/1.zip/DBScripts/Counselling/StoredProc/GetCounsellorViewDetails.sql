USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetCounsellorViewDetails]    Script Date: 12-01-2022 17:01:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER   PROCEDURE [dbo].[GetCounsellorViewDetails]

as
begin
SELECT 
ReviewedFor, 
AVG(RateGiven) AS AverageRating,
Count(RateGiven) AS TotalRating


FROM  Review 

GROUP BY ReviewedFor

END

--exec GetCounsellorViewDetails
GO


