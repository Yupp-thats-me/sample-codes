USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[InActiveCertificationsById]    Script Date: 13-01-2022 12:34:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[InActiveCertificationsById]
	@Id bigint
AS
BEGIN
 
	SET NOCOUNT ON;
	
	UPDATE CertificationDetails SET IsActive = 0
	WHERE Id = @Id
	
END
GO


