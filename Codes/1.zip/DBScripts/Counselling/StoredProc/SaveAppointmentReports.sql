USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[SaveAppointmentReports]    Script Date: 13-01-2022 12:49:37 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[SaveAppointmentReports]
(
    @Id BigInt=0,
	@AppointmentId BigInt=0,
	@CounsellorId BigInt=0,
	@StudentId BigInt=0,
	@Remarks nvarchar(2000) = NULL,
	@StudentAttandance bit=false,
	@IsActive bit = false,
	@Title nvarchar(250) =NULL,
	@Description nvarchar(2000) = NULL,
	@SessionDate DateTime = null,
	@StartTime nvarchar(20) = NULL,
	@EndTime nvarchar(20) = NULL,
	@CreatedBy nvarchar(20)=NULL,	
	@UpdatedBy nvarchar(20)=NULL
	
)
AS
BEGIN
IF ISNULL(@Id, 0) = 0
BEGIN
  INSERT INTO CounsellingStudentRemarks(
	AppointmentId,
	CounsellorId,
	StudentId,
	Remarks,
	StudentAttandance,
	IsActive,
	CreatedBy,
	CreatedDate
	)
VALUES(
	@AppointmentId,
	@CounsellorId,
	@StudentId,
	@Remarks,
	@StudentAttandance,
	@IsActive,
	@CreatedBy,
	GETDATE()
	
)
INSERT INTO AppointmentReports(
	AppointmentId,
	CounsellorId,
	StudentId,
	Title,
	Description,
	SessionDate,
	StartTime,
	EndTime,
	IsActive,
	CreatedBy,
	CreatedDate
	)
VALUES(
	@AppointmentId,
	@CounsellorId,
	@StudentId,
	@Title,
	@Description,
	@SessionDate,
	@StartTime,
	@EndTime,
	@IsActive,
	@CreatedBy,
	GETDATE()
	
)
update VirtualAppointments set StudentAttandance = @StudentAttandance , StatusId = 6 where Id= @AppointmentId

   SELECT @Id= SCOPE_IDENTITY()

			SELECT @Id 
END

ELSE
  BEGIN
		 UPDATE CounsellingStudentRemarks
		 SET
	AppointmentId = @AppointmentId,
	CounsellorId = @CounsellorId,
	StudentId = @StudentId,
	Remarks = @Remarks,
	StudentAttandance = @StudentAttandance,
	IsActive = @IsActive,	
	UpdatedBy = @UpdatedBy,
	UpdatedDate = GETDATE()
	WHERE Id =@Id
	update VirtualAppointments set StudentAttandance = @StudentAttandance where Id= @AppointmentId
	END
	SELECT @Id
END
GO


