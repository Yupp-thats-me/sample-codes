USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetCertificationDetailId]    Script Date: 12-01-2022 15:53:35 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetCertificationDetailId]
@Id BIGINT
AS
BEGIN
 SELECT Id,
	CounsellorId,
	Title,
	IssuingAuthority,
	StartDate,
	Pursuing,
	EndDate,
	CreatedBy,
	CreatedDate,
	UpdatedBy,
	UpdatedDate,
	IsActive
	FROM	[CertificationDetails] WITH(NOLOCK)
	where CounsellorId = @Id
	AND IsActive=1
    ORDER BY (CASE 
          WHEN UpdatedDate IS NULL 
          THEN CreatedDate ELSE UpdatedDate 
          END) 
    DESC
END
GO


