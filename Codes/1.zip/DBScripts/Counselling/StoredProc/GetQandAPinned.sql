USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetQandAPinned]    Script Date: 13-01-2022 11:58:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER   PROCEDURE [dbo].[GetQandAPinned]
@PInned BigInt
AS
BEGIN
 SELECT 	
    IV.Id, 
	QandAListId,
	IL.CategoryId,
	CM.CategoryAr,
	CM.CategoryEn,
	IL.ServiceId,
	SM.ServicesAr,
	SM.ServicesEn,
	IV.Question,
	IV.Answer,
	Pinned,
	IV.PostedDate,
	IV.ReplayDate
	

	FROM	[InboxView]IV WITH(NOLOCK)
	  join InboxList IL
	  on IV.QandAListId = IL.Id

	 left join EmployeeDB .. [User] CPD
	 ON IL.CounsellorId = CPD.Id

     left join EmployeeDB .. [User] SPD
	 on IL.StudentId = SPD.Id

	 join CategoryMaster CM
	 on IL.CategoryId = CM.CategoryId

	  join ServicesMaster SM
	 on IL.ServiceId = SM.ServicesId

	where Pinned  = @Pinned and IV.Isactive=1
	
   ORDER BY (ReplayDate) 
    Asc
END


GO


