USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[SaveCounsellorPersonalDetails]    Script Date: 13-01-2022 12:58:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[SaveCounsellorPersonalDetails]
(
@ID BIGINT=0 ,
@ReferenceId bigint=0 OUT,
@EntryVia int=0,
@FirstName nvarchar(100)=NULL,
@MiddleName nvarchar(100)=NULL,
@LastName nvarchar(100)=NULL,
@Gender nvarchar(10)=NULL,
@DOB datetime=NULL,
@LanguageKnown nvarchar(500)=NULL,
@Email nvarchar(100)=NULL,
@PhoneNumber nvarchar(50)=NULL,
@AddressLine1 nvarchar(100)=NULL,
@AddressLine2 nvarchar(100)=NULL,
@ZipCode nvarchar(100)=NULL,
@EmiratesCityId int=0,
@EmirateId Nvarchar(50)=null,
@UserId bigint=0,
@MobileCode int=0,
@AlternateEmail nvarchar(100)=null,
@Bio nvarchar(1000)=NULL,
@CategoryId nvarchar(100)=null,
@ServicesId nvarchar(100)=null,
@RejectReason nvarchar(500)=NULL,
@CreatedBy nvarchar(100)=NULL,
@UpdatedBy nvarchar(100)=NULL,
@MobileNo nvarchar(20)=NULL,
@StatusId int =0,
@ProfilePic Nvarchar(100)=NULL,
@IsActive bit=0

)
				AS
				BEGIN
				IF ISNULL(@Id, 0) = 0
				BEGIN
				  INSERT INTO CounsellorPersonalDetails(
					
					 FirstName,
					 MiddleName,
					 LastName,
					 Gender,
					 DOB,
					 LanguageKnown,
					 Email,
					 PhoneNumber,
					 AddressLine1,
					 AddressLine2,
					 ZipCode,
					 EmiratesCityId,
					 MobileCode,
					 AlternateEmail,
					 Bio,
					 CategoryId,
					 ServicesId,
					 RejectReason,
					 CreatedBy,
					 CreatedDate,
					 MobileNo,
					 EntryVia,
					 ProfilePic,
					 IsActive
				)
				VALUES
				   (
						
						@FirstName ,
						@MiddleName ,
						@LastName ,
						@Gender ,
						@DOB ,
						@LanguageKnown ,
						@Email ,
						@PhoneNumber,
						@AddressLine1 ,
						@AddressLine2 ,
						@ZipCode,
						@EmiratesCityId ,
						@MobileCode ,
						@AlternateEmail ,
						@Bio ,
						@CategoryId,
						@ServicesId ,
						@RejectReason ,
						@CreatedBy ,
						GETDATE(),
						@MobileNo ,
						@EntryVia,
						@ProfilePic ,
						@IsActive
					)
						 SELECT @ReferenceId= SCOPE_IDENTITY()

							SELECT @Id 
					END		
				BEGIN
			UPDATE [dbo].CounsellorPersonalDetails 
			SET 
					
					FirstName =@FirstName
					,MiddleName =@MiddleName
					,LastName=@LastName
					,Gender =@Gender
					,DOB =@DOB
					,LanguageKnown =@LanguageKnown
					,Email =@Email
					,Bio=@Bio
					,PhoneNumber =@PhoneNumber
					,AddressLine1 =@AddressLine1
					,AddressLine2 =@AddressLine2
					,ZipCode =@ZipCode
					,EmirateId = @EmirateId
					,RejectReason =@RejectReason
					,CategoryId=@CategoryId
					,ServicesId=@ServicesId
					,EmiratesCityId=@EmiratesCityId
					,MobileCode = @MobileCode
					,[UpdatedBy] =@UpdatedBy
					,[UpdatedDate] =GETDATE()
					,MobileNo =@MobileNo
					,EntryVia=@EntryVia
					,ProfilePic= ISNULL(@ProfilePic, ProfilePic),
					IsActive=@IsActive
					
			WHERE Id =@Id
			
		END

			SELECT @Id

	END

		

	



		
GO


