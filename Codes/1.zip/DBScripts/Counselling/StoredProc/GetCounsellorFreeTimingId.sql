USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetCounsellorFreeTimingId]    Script Date: 12-01-2022 15:55:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetCounsellorFreeTimingId]
@Id BigInt = null

AS
BEGIN
 SELECT Id,
	CounsellorId,
	SelectedDate,
	StartTime,
	EndTime,
	TimeDuration,
	Status,
	CreatedBy,
	CreatedDate,
	UpdatedBy,
	UpdatedDate
	FROM [CounsellorFreeTimings] WITH(NOLOCK)
	where (Id = @Id) 
	AND IsActive=1
    ORDER BY (CASE 
          WHEN UpdatedDate IS NULL 
          THEN CreatedDate ELSE UpdatedDate 
          END) 
    DESC
END
GO


