USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetRemarkDetails]    Script Date: 13-01-2022 12:11:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetRemarkDetails]
    @Id BigInt=0,
	@StudentId BigInt=0,
	@CounsellorId BigInt=0
	
AS
BEGIN
 SELECT 	
    Id,
	AppointmentId,
	CounsellorId,
	StudentId,
	Remarks,
	StudentAttandance,
	IsActive,
	CreatedBy,
	CreatedDate,
	UpdatedBy,
	UpdatedDate

	 FROM	[CounsellingStudentRemarks] WITH(NOLOCK)
	
	where (@StudentId is null or  @StudentId= 0 or StudentId = @StudentId ) and 
	(@CounsellorId is null or @CounsellorId = 0 or CounsellorId =@CounsellorId ) and 
	(@Id is null or @Id = 0 or Id = @Id)


END
GO


