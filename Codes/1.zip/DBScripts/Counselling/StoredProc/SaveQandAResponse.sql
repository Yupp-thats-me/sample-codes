USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[SaveQandAResponse]    Script Date: 13-01-2022 13:05:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[SaveQandAResponse]
(
    @ReferenceId BIGINT NULL OUTPUT,
    @Id bigint=0,
	@QandAListId bigint=0,
	@Answer nvarchar(500)=NULL,
	@Pinned bit = Null,
	@StudentDocument nvarchar(100) = null,
	@ReplayDate datetime = NULL,
	@UpdatedBy NVARCHAR(20)
)
AS
BEGIN 
  BEGIN
		 UPDATE InboxList
		 SET
			  Answer=@Answer,
			  ReplayDate=@ReplayDate,			
			  UpdatedBy = @UpdatedBy,
			  UpdatedDate=GETDATE(),
			  Status = 0
	    WHERE Id =@QandAListId

	   UPDATE InboxView
		 SET
			  Answer=@Answer,
			  ReplayDate=@ReplayDate,
			  StudentDocument = @StudentDocument,
			   Pinned = @Pinned,
			   UpdatedBy = @UpdatedBy,
			  UpdatedDate=GETDATE()
		 WHERE Id =@Id
		 set @ReferenceId = @Id
	END
	SELECT @Id
END

GO


