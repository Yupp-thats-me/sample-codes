USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetCounsellorFreeTimings]    Script Date: 12-01-2022 15:57:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetCounsellorFreeTimings]

@CounsellorId BigInt = null,
@SelectedDate DateTime = null,
@TimeDuration int = 0,
@status int = 0

AS
BEGIN
 SELECT 	
    Id,
	CounsellorId,
	SelectedDate,
	StartTime,
	EndTime,
	TimeDuration,
	Status,
	CreatedBy,
	CreatedDate,
	UpdatedBy,
	UpdatedDate,
	IsActive
	FROM	[CounsellorFreeTimings] WITH(NOLOCK)
	where  ((@CounsellorId is null or CounsellorId = @CounsellorId) 
     and (@SelectedDate is null or Convert(date ,SelectedDate ) = Convert(date,@SelectedDate))
     and (@TimeDuration is null or @TimeDuration = 0 or TimeDuration = @TimeDuration) 
     and (@status = 0 or  @status IS NULL or [Status]=@Status )
	 AND IsActive=1)
    ORDER BY (CASE 
          WHEN UpdatedDate IS NULL 
          THEN CreatedDate ELSE UpdatedDate 
          END) 
    DESC
	
END

--exec GetCounsellorFreeTimings 
GO


