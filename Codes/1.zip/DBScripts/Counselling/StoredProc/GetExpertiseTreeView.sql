USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetExpertiseTreeView]    Script Date: 12-01-2022 17:13:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetExpertiseTreeView]  

AS  
BEGIN  
  
 SET NOCOUNT ON;  
 select Id, En_Expertise,Ar_Expertise, isnull(ParentID, 0) 'ParentID'  from ExpertiseTreeView   
  
END  
GO


