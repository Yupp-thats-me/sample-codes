USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetCategoryServicesMaster]    Script Date: 12-01-2022 15:51:43 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetCategoryServicesMaster]
AS
BEGIN
 SELECT CSD.CategoryId as CategoryId,         
        CM.CategoryAr as CategoryAr,
		CM.CategoryEn as CategoryEn,
		CSD.ServicesId as ServicesId,
		SM.ServicesAr as ServicesAr,
	    SM.ServicesEn as ServicesEn
	


   FROM [CategoryServicesDetail] CSD WITH (NOLOCK)
  join CategoryMaster CM WITH (NOLOCK)
 ON CSD.CategoryId = CM.CategoryId

 join ServicesMaster SM WITH (NOLOCK)
 ON CSD.ServicesId = SM.ServicesId

 


END
GO


