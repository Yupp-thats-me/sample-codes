USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[UpdateFaqStatusById]    Script Date: 13-01-2022 13:10:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER   PROCEDURE [dbo].[UpdateFaqStatusById] 
(
	 @Id BIGINT
	,@StatusId INT
	,@UpdatedBy NVARCHAR(20)= null
	,@RejectReason NVARCHAR(1000) = NULL
)
AS
  BEGIN

       
		
		UPDATE FaqDetails
		 SET
		   
			  StatusId= @StatusId,--update
			  RejectReason=@RejectReason,---Update	
			  UpdatedBy=@UpdatedBy,
			  UpdatedDate=GETDATE()
				WHERE Id =@Id

	END



GO


