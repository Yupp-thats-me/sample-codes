USE SJCounselling
GO

/****** Object:  StoredProcedure [dbo].[GetLanguages]    Script Date: 11/9/2021 12:11:04 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetLanguages]

@Id BigInt 
AS
BEGIN
SELECT  [Id],
        [Language] as LanguageKnown,
		CONCAT(FirstName,' ',LastName) AS Name
  FROM [EmployeeDB].[dbo].[User]
  Where Id = @Id
END
GO


