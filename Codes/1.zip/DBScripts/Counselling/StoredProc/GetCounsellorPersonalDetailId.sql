USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetCounsellorPersonalDetailId]    Script Date: 12-01-2022 16:59:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetCounsellorPersonalDetailId]
@Id bigInt
AS
BEGIN
 SELECT 	
	Id,
	EntryVia,
	FirstName,
	MiddleName,
	LastName,
	CONCAT(FirstName,' ',MiddleName,' ',LastName) AS Name,
	Gender,
	DOB,
	LanguageKnown,
	Email,
	PhoneNumber,
	AddressLine1,
	AddressLine2,
	ZipCode,
	CP.EmiratesCityId as EmiratesCityId,
	EM.EmirateEn as EmirateEn,
	EM.EmirateAr as EmirateAr,
	CP.EmirateId as EmirateId,
	UserId,
	MobileCode,
	AlternateEmail,
	Bio,
	CategoryId,
	 ServicesId,
	StatusId,
	RejectReason,
	CreatedBy,
	CreatedDate,
	UpdatedBy,
	UpdatedDate,
	MobileNo,
	ProfilePic,
	IsActive

	FROM [CounsellorPersonalDetails] CP WITH(NOLOCK)
	

	left join EmirateMaster EM WITH(NOLOCK)
	On CP.EmiratesCityId = EM.EmirateId
	Where Id= @Id
	AND IsActive=1

    ORDER BY (CASE 
          WHEN UpdatedDate IS NULL 
          THEN CreatedDate ELSE UpdatedDate 
          END) 
    DESC
	
END

--exec GetCounsellorPersonalDetailId 10081
GO


