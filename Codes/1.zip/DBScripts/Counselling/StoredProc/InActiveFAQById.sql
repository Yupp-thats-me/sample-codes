USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[InActiveFAQById]    Script Date: 13-01-2022 12:40:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[InActiveFAQById]
	@Id bigint
AS
BEGIN
 
	SET NOCOUNT ON;
	
	UPDATE FaqDetails SET IsActive = 0
	WHERE Id = @Id
	
END
GO


