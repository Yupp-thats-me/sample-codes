USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetMajorMaster]    Script Date: 13-01-2022 11:58:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetMajorMaster]
AS
BEGIN
SELECT  [MajorId]
      ,[MajorName]
      ,[ArMajorName]
  FROM [MajorMaster]
END
GO


