USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[SaveVirtualAppointmentsDetails]    Script Date: 13-01-2022 13:08:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[SaveVirtualAppointmentsDetails]
(
    @ReferenceId BIGINT NULL OUTPUT,
    @Id bigint=0,
	@CounsellorId bigint=0,
	@StudentId bigint=0,
	@Category int=0,
	@Service int=0,
	@Languages nvarchar(500)=NULL,
	@Subject nvarchar(250)=NULL,
	@Purpose nvarchar(1000)=null,
	@Documents nvarchar(100)=NULL,
	@Duration Int,
	@SelectedDate datetime,
	@StartTime nvarchar(50)=NULL,
	@EndTime nvarchar(50)=NULL,
	@StatusId int=0,
	@CreatedBy Nvarchar (20)=null,	
	@UpdatedBy Nvarchar (20) = NULL,
	@AvailableTimeId bigInt=0,
    @IsActive bit= 0,
	@VirtualLink NVARCHAR (500) = null
)
AS
BEGIN

  IF EXISTS
   (SELECT 1 From VirtualAppointments
   where StatusId = 2 
   and Category=@Category 
   and Service=@Service
   and StudentId=@StudentId)
   
   THROW 50001,'Duplicate is found.',1;

   IF (@SelectedDate<(DATEADD(DAY, 5, GETDATE())))
   
   THROW 50002,'Invalid Date',2;

IF ISNULL(@Id, 0) = 0

 BEGIN

    IF (@StatusId=2)--pending
	 BEGIN
	     UPDATE CounsellorFreeTimings SET Status=2 WHERE Id=@AvailableTimeId
	 END 
    IF (@StatusId=3)--approved
	   BEGIN
	    UPDATE CounsellorFreeTimings SET Status=3 WHERE Id=@AvailableTimeId
	 END
	 
	    
  INSERT INTO VirtualAppointments (
  CounsellorId,  
  StudentId,
  Category,
  Service,
  Languages,
  Subject,
  purpose,
  Documents,
  Duration,
  SelectedDate,
  StartTime,
  EndTime,
  StatusId,
  CreatedBy,
  CreatedDate,
  IsActive,
  VirtualLink
  )
  values
  (
    @CounsellorId ,
	@StudentId,
	@Category,
	@Service,
	@Languages,
	@Subject,
	@Purpose,
	@Documents,
	@Duration,
	@SelectedDate,
	@StartTime,
	@EndTime,
	@StatusId,
	@CreatedBy,
	GETDATE(),
	@IsActive,
	@VirtualLink
	)
    SET @ReferenceId = SCOPE_IDENTITY();
 
END
ELSE
  BEGIN

       IF (@StatusId=3)--approved
	   BEGIN
	    UPDATE CounsellorFreeTimings SET Status=3 WHERE Id=@AvailableTimeId
		END
		
		IF (@StatusId=4)--Rejected
		BEGIN
		 UPDATE CounsellorFreeTimings SET Status=1 WHERE ID=@AvailableTimeId
		END
		
		UPDATE VirtualAppointments
		 SET
		      CounsellorId=@CounsellorId,  
			  StudentId=@StudentId,
			  Category=@Category,
			  Service=@Service,
			  Languages=@Languages,
			  Subject=@Subject,
			  Purpose=@Purpose,
			  Documents=@Documents,
			  Duration=@Duration,
			  SelectedDate=@SelectedDate,
			  StartTime=@StartTime,
			  EndTime=@EndTime,
			  StatusId= @StatusId,--update
			  UpdatedBy=@UpdatedBy,
			  UpdatedDate=GETDATE(),
			  IsActive =@IsActive,
			  VirtualLink = @VirtualLink
				WHERE Id =@Id
				SET @ReferenceId=@Id
	END

	SELECT @Id

END

Select * from VirtualAppointments
GO


