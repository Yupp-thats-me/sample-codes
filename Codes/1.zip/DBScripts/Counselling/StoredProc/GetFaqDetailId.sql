USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetFaqDetailId]    Script Date: 12-01-2022 17:24:08 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetFaqDetailId]
@Id BigInt = null
AS
BEGIN
 SELECT 	
	Id,
	CounsellorId,
	QuestionEn,
	AnswerEn,
	QuestionAr,
	AnswerAr,
	FD.CategoryId as CategoryId,
	CM.CategoryEn as CategoryEn,
	CM.CategoryAr as CategoryAr,
	PostedDate,
	StatusId,
	RejectReason,
	CreatedBy,
	CreatedDate,
	UpdatedBy,
	UpdatedDate,
	IsActive

	FROM	[FaqDetails] FD WITH(NOLOCK)
	join  CategoryMaster CM
	on FD.CategoryId=CM.CategoryId 
	where CounsellorId = @Id
	AND IsActive=1
    ORDER BY (CASE 
          WHEN UpdatedDate IS NULL 
          THEN CreatedDate ELSE UpdatedDate 
          END) 
    DESC

END
GO


