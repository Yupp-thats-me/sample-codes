USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetHigherEducationMaster]    Script Date: 13-01-2022 11:53:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetHigherEducationMaster]
AS
BEGIN
SELECT TOP (1000) [HigherEducationId]
      ,[HigherEducationEn]
      ,[HigherEducationAr]
  FROM [HigherEducationMaster]
END
GO


