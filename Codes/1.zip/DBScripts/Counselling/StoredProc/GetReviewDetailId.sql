USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetReviewDetailId]    Script Date: 13-01-2022 12:17:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER   PROCEDURE [dbo].[GetReviewDetailId]
@Id int
AS
BEGIN
 SELECT 	
    R.Id,
	R.AppointmentId,
	R.ReviewedBy,
	R.ReviewedFor,
	R.RateGiven,
	R.CounsellorAttendSession,
	R.Reviewcontent,
	R.CreatedBy,
	R.CreatedDate,
	R.UpdatedBy,
	R.UpdatedDate,
	SPD.FirstName,
	SPD.LastName,
	concat(FirstName,' ',LastName)AS Name,
	R.IsActive

	FROM	[Review] R WITH(NOLOCK)
	
	

	left join SJIdentity .. [User] SPD
	 on R.ReviewedBy = SPD.Id

	where reviewedfor=@ID
	AND R.IsActive=1
    ORDER BY (CASE 
          WHEN R.UpdatedDate IS NULL 
          THEN R.CreatedDate ELSE R.UpdatedDate 
          END) 
    DESC
END
GO


