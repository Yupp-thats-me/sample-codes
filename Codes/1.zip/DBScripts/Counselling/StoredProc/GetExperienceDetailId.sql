USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetExperienceDetailId]    Script Date: 12-01-2022 17:09:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetExperienceDetailId]
@Id Bigint
AS
BEGIN
 SELECT 	
	Id,
	CounsellorId,
	Title,
	OrganizationName,
	Descriptions,
	EmirateId,
	StartDate,
	Pursuing,
	EndDate,
	CreatedBy,
	CreatedDate,
	UpdatedBy,
	UpdatedDate,
	IsActive

	FROM [ExperienceDetails] WITH(NOLOCK)
	Where CounsellorId =@Id
	AND IsActive=1
    ORDER BY (CASE 
          WHEN UpdatedDate IS NULL 
          THEN CreatedDate ELSE UpdatedDate 
          END) 
    DESC
	
END
GO


