USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[InActiveEducationById]    Script Date: 13-01-2022 12:37:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[InActiveEducationById]
	@Id bigint
AS
BEGIN
 
	SET NOCOUNT ON;
	
	UPDATE EducationDetails SET IsActive = 0
	WHERE Id = @Id
	
END
GO


