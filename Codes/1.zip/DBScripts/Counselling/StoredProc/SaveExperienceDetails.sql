USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[SaveExperienceDetails]    Script Date: 13-01-2022 13:00:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[SaveExperienceDetails]
(
    @Id bigint=0,
	@CounsellorId bigint=0,
	@Title nvarchar(250)=NULL,
	@OrganizationName nvarchar(250)=NULL,
	@EmirateId INT=0,
	@StartDate datetime=NULL,
	@Pursuing bit=FALSE,
	@EndDate datetime=NULL,
	@CreatedBy nvarchar(100)=NULL,	
	@UpdatedBy nvarchar(100)=NULL,	
	@Description nvarchar(1000)=NULL,
	@IsActive bit=0

)
AS
BEGIN
IF ISNULL(@Id, 0) = 0
 BEGIN
  INSERT INTO ExperienceDetails(
  CounsellorId,
  Title,
  OrganizationName,
  EmirateId,
  StartDate,
  Pursuing,
  EndDate,
  CreatedBy,
  CreatedDate ,
  Descriptions,
  IsActive
  )
  values
  (
    @CounsellorId,
	@Title,
	@OrganizationName,
	@EmirateId,
	@StartDate,
	@Pursuing,
	@EndDate,
	@CreatedBy,
	GETDATE(),	
	@Description,
	@IsActive
	)
   SELECT @Id= SCOPE_IDENTITY()

			SELECT @Id 
END
ELSE
  BEGIN
     UPDATE ExperienceDetails
	 SET
	  CounsellorId=@CounsellorId,
	  Title=@Title,
	  OrganizationName=@OrganizationName,
	  EmirateId=@EmirateId,
	  StartDate=@StartDate,
	  Pursuing=@Pursuing,
	  EndDate=@EndDate,	  
	  UpdatedBy=@UpdatedBy,
	  UpdatedDate=GETDATE(),
	  Descriptions=@Description,
	  IsActive=@IsActive	
	WHERE Id =@Id

	END

	SELECT @Id
END
GO


