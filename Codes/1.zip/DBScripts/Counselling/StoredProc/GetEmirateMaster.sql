USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetEmirateMaster]    Script Date: 12-01-2022 17:07:45 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetEmirateMaster]
AS
BEGIN
 SELECT [EmirateId]
      ,[EmirateEn]
      ,[EmirateAr]
  FROM [EmirateMaster]
END
GO


