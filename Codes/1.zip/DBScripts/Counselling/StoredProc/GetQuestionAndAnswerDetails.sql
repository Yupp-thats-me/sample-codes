USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetQuestionAndAnswerDetails]    Script Date: 13-01-2022 12:05:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER   PROCEDURE [dbo].[GetQuestionAndAnswerDetails]
@CounsellorId bigint= null, 
@StudentId bigint= null

AS
BEGIN
 SELECT 	
    QAD.Id,             
	QAD.CounsellorId as CounsellorId,
	QAD.StudentId as StudentId,
    CONCAT(SPD.FirstName,' ',SPD.LastName) AS StudentName,
	CONCAT(CPD.FirstName,' ',CPD.LastName) AS CounsellorName,
	QAD.CategoryId as CategoryId,
	CM.CategoryAr as CategoryAr,
    CM.CategoryEn as CategoryEn,
	QAD.ServiceId as ServiceId,
	SM.ServicesAr as ServicesAr,
	SM.ServicesEn as ServicesEn,
	Subject,
	Question,
	Answer,
	PostedDate,
	ReplayDate,
	Status,
	QAD.CreatedBy as CreatedBy,
	QAD.CreatedDate as CreatedDate,
	QAD.UpdatedBy as UpdatedBy,    
	QAD.UpdatedDate as UpdatedDate

	FROM	[InboxList] QAD WITH(NOLOCK)
	  join CategoryMaster CM
      ON QAD.CategoryId = CM.CategoryId

      join ServicesMaster SM
     ON QAD.ServiceId = SM.ServicesId
	 left join SJIdentity .. [User] CPD
	 ON QAD.CounsellorId = CPD.Id
      left join SJIdentity .. [User] SPD
	 on QAD.StudentId = SPD.Id

	where((@CounsellorId is null or @CounsellorId = 0 or CounsellorId=@CounsellorId) and
	(@StudentId is null or @StudentId =0 or StudentId = @StudentId)) 
	  
		ORDER BY (
				CASE WHEN @StudentId IS NULL or @StudentId = 0 THEN PostedDate ELSE ReplayDate END
			) DESC
	
END

--EXEC [GetQuestionAndAnswerDetails] 198

--SELECT * FROM InboxList



GO


