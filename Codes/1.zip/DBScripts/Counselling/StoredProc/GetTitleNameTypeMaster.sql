USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetTitleNameTypeMaster]    Script Date: 13-01-2022 12:19:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetTitleNameTypeMaster]
AS
BEGIN
SELECT  [TitleId]
      ,[TitleEn]
      ,[TitleAr]
  FROM [TitleNameTypeMaster]
END
GO


