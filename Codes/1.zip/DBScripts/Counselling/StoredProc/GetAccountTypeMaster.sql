USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetAccountTypeMaster]    Script Date: 12-01-2022 15:43:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetAccountTypeMaster]

AS  
  
BEGIN 
  SELECT  [AccountTypeId]
      ,[AccountTypeEn]
      ,[AccountTypeAr]
  FROM [AccountTypeMaster]
  

END

GO


