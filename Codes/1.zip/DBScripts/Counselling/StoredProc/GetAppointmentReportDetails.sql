USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetAppointmentReportDetails]    Script Date: 12-01-2022 15:48:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetAppointmentReportDetails]
    @Id BigInt=0,
	@StudentId BigInt=0,
	@CounsellorId BigInt=0,
	@AppointmentId Bigint =0 
AS
BEGIN
 SELECT 	
    AR.Id as Id,
	AR.AppointmentId as AppointmentId,
	AR.CounsellorId as CounsellorId,
	AR.StudentId as StudentId,
	CSR.Remarks as Remarks,
	CSR.StudentAttandance as StudentAttandance,
	Title,
	Description,
	SessionDate,
	StartTime,
	EndTime,
	AR.IsActive as IsActive,
	AR.CreatedBy as CreatedBy,
	AR.CreatedDate as CreatedDate,
	AR.UpdatedBy as UpdatedBy,
	AR.UpdatedDate as UpdatedDate

	 FROM [AppointmentReports]AR WITH(NOLOCK)
	 join  CounsellingStudentRemarks CSR
	on CSR.AppointmentId = AR.AppointmentId 

	where (@StudentId is null or  @StudentId= 0 or AR.StudentId = @StudentId ) and 
	(@CounsellorId is null or @CounsellorId = 0 or AR.CounsellorId =@CounsellorId ) and 
	(@AppointmentId is null or @AppointmentId = 0 or AR.AppointmentId =@AppointmentId ) and
	(@Id is null or @Id = 0 or AR.Id = @Id)


END
GO


