USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetReviewDetails]    Script Date: 13-01-2022 12:17:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER   PROCEDURE [dbo].[GetReviewDetails]
@AppointmentId BIGINT = null,
@ReviewedBy BIGINT = null,
@ReviewedFor BIGINT = null,
@RateGiven INT = 0,
@Id BIGINT = 0
AS
BEGIN
 SELECT 	
    R.Id,
	R.AppointmentId,
	R.ReviewedBy,
	R.ReviewedFor,
	R.RateGiven,
	R.CounsellorAttendSession,
	R.Reviewcontent,
	R.CreatedBy,
	R.CreatedDate,
	R.UpdatedBy,
	R.UpdatedDate,
	R.IsActive,
	concat(FirstName,' ',LastName)AS Name

	 FROM	[Review] R WITH(NOLOCK)
	

	left join SJIdentity .. [User] SPD
	 on R.ReviewedBy = SPD.Id
	where (@AppointmentId is null or AppointmentId = @AppointmentId ) and 
	(@ReviewedBy is null or ReviewedBy =@ReviewedBy ) and
	(@ReviewedFor is null or ReviewedFor = @ReviewedFor) and
	(@RateGiven is null or @RateGiven = 0 or RateGiven = @RateGiven) and 
	(@Id is null or @Id = 0 or R.Id = @Id)
	AND R.IsActive=1
    ORDER BY (CASE 
          WHEN R.UpdatedDate IS NULL 
          THEN R.CreatedDate ELSE R.UpdatedDate 
          END) 
    DESC


END
GO


