USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[InActiveAchievementById]    Script Date: 13-01-2022 12:32:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[InActiveAchievementById]
	@Id bigint
AS
BEGIN
 
	SET NOCOUNT ON;
	
	UPDATE  AchievementsDetails set IsActive = 0
	WHERE Id = @Id
	
END
GO


