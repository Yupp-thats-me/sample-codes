USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[SaveCertificationDetails]    Script Date: 13-01-2022 12:50:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[SaveCertificationDetails]
(
@Id bigint=0,
@CounsellorId bigint=0,
@Title nvarchar(250)=NULL,
@IssuingAuthority nvarchar(250)=NULL,
@StartDate datetime,
@Pursuing bit,
@EndDate datetime,
@CreatedBy nvarchar(100)=NULL,
@UpdatedBy nvarchar(100)=NULL,
@IsActive bit=0

)
AS
BEGIN
IF ISNULL(@Id, 0) = 0
 BEGIN
  INSERT INTO CertificationDetails(
  CounsellorId,
  Title,
  IssuingAuthority,
  StartDate,
  Pursuing,
  EndDate,
  CreatedBy,
  CreatedDate,
  IsActive 
  
  )
  values
  (
    @CounsellorId,
	@Title,
	@IssuingAuthority,
	@StartDate,
	@Pursuing,
	CASE WHEN @EndDate='1900-01-01' THEN NULL
	ELSE @EndDate END,
	@CreatedBy,
	GETDATE(),
	@IsActive 

   )
   SELECT @Id= SCOPE_IDENTITY()

			SELECT @Id 
END
ELSE
  BEGIN
     UPDATE CertificationDetails
	 SET
	  CounsellorId=@CounsellorId,
	  Title=@Title,
	  IssuingAuthority=@IssuingAuthority,
	  StartDate=@StartDate,
	  Pursuing=@Pursuing,
	  EndDate=CASE WHEN @EndDate='1900-01-01' THEN NULL
	  ELSE @EndDate END,
	  UpdatedBy=@UpdatedBy,
	  UpdatedDate=GETDATE(),
	  IsActive=@IsActive	
	WHERE Id =@Id

	END

	SELECT @Id
END

GO


