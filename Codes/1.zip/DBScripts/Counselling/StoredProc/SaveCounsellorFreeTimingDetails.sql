USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[SaveCounsellorFreeTimingDetails]    Script Date: 13-01-2022 12:56:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[SaveCounsellorFreeTimingDetails]
(
    @Id bigint=0,
	@CounsellorId bigint=0,
	@SelectedDate datetime,
	@StartTime nvarchar(50)=NULL,
	@EndTime nvarchar(50)=NULL,
    @TimeDuration nvarchar(50)=null,
	@Status int =0,
	@CreatedBy Nvarchar(20)=null,	
	@UpdatedBy nvarchar(20)=NULL,
	@IsActive bit=0

	

)
AS
BEGIN
  IF (@SelectedDate<(DATEADD(DAY, 5, GETDATE())))
   
   THROW 50002,'Invalid Date',2;

IF ISNULL(@Id, 0) = 0
 BEGIN
  INSERT INTO CounsellorFreeTimings
  (
  CounsellorId,  
  SelectedDate,
  StartTime,
  EndTime,
  TimeDuration,
  Status,
  CreatedBy,
  CreatedDate ,
  IsActive
  )
  values
  (
    @CounsellorId ,
	@SelectedDate,
	@StartTime,
	@EndTime,
	@TimeDuration,
	@Status,
	@CreatedBy,
	GETDATE(),
	@IsActive
	)
   SELECT @Id= SCOPE_IDENTITY()

			SELECT @Id 
END
ELSE
  BEGIN
		 UPDATE CounsellorFreeTimings
		 SET
		      CounsellorId=@CounsellorId,  
			  SelectedDate=@SelectedDate,
			  StartTime=@StartTime,
			  EndTime=@EndTime,
			  TimeDuration=@TimeDuration,
			  Status=@Status,
			  UpdatedBy=@UpdatedBy,
			  UpdatedDate=GETDATE(),
			  IsActive=@IsActive	
				WHERE Id =@Id

	END

	SELECT @Id
END
GO


