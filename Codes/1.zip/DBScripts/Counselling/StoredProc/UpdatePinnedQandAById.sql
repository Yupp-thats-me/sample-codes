USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[UpdatePinnedQandAById]    Script Date: 13-01-2022 13:10:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[UpdatePinnedQandAById] 
(
	 @Id BIGINT
	,@Pinned bit 
	,@UpdatedBy NVARCHAR(20)= null	
)
AS
  BEGIN
		UPDATE InboxView
		 SET	   
			  pinned = @Pinned,
			  UpdatedBy=@UpdatedBy
			WHERE Id =@Id
	END



GO


