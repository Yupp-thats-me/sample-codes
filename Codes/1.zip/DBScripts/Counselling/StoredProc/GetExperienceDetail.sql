USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetExperienceDetail]    Script Date: 12-01-2022 17:08:52 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetExperienceDetail]
@CounsellorId BIGINT =null
AS

BEGIN
 SELECT 	
	Id,
	CounsellorId,
	Title,
	OrganizationName,
	Descriptions,
	EmirateId,
	StartDate,
	Pursuing,
	EndDate,
	CreatedBy,
	CreatedDate,
	UpdatedBy,
	UpdatedDate

	FROM [ExperienceDetails] WITH(NOLOCK)
	where (@CounsellorId is null or CounsellorId = @CounsellorId)
	AND IsActive=1
    ORDER BY (CASE 
          WHEN UpdatedDate IS NULL 
          THEN CreatedDate ELSE UpdatedDate 
          END) 
    DESC
END
GO


