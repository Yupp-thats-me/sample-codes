USE SJCounselling
GO

/****** Object:  StoredProcedure [dbo].[GetSlotMaster]    Script Date: 11/9/2021 12:20:12 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetSlotMaster]
AS
BEGIN
SELECT  [SlotId]
      ,[SlotEn]
      ,[SlotAr]
  FROM SlotMaster with (nolock)
END
GO


