USE SJCounselling
GO

/****** Object:  StoredProcedure [dbo].[GetQandATransaction]    Script Date: 11/9/2021 12:14:57 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetQandATransaction]
(
@QuestionareId int=0
)
AS
BEGIN
SELECT
  QT.StudentId,
  CONCAT(SPD.FirstName,' ',SPD.LastName) AS StudentName,
  QA.Question,
  QA.Status,
  CPD.CounsellorName,
  CPD.CategoryId,
  CPD.ServicesId



FROM QandADetails QA WITH (NOLOCK)
JOIN QandATransation QT 
ON QT.Id=QA.QuestionareId
left join EmployeeDB .. [User] SPD
ON SPD.Id=QT.StudentId
left join EmployeeDB .. [User] CPD
ON CPD.Id=QT.CounsellorId
WHERE QuestionareId=@QuestionareId

END




GO


