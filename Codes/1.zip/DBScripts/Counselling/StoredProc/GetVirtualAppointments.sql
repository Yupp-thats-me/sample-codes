USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetVirtualAppointments]    Script Date: 13-01-2022 12:31:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER   PROCEDURE [dbo].[GetVirtualAppointments]
@StatusId int = 0 ,
@StudentId bigint = null,
@CounsellorId bigint =  null,
@SelectedDate DateTime = null,
@CheckExpiry bit = NULL,
@MultipleStatus bit = null,
@IsActive bit = 0

AS
BEGIN

	DECLARE @Date date=getdate()
 SELECT 	
    VA.Id as Id,
	CSR.Remarks as Remarks,
	VA.StudentId as StudentId,
    CONCAT(SPD.FirstName,' ',SPD.LastName) AS StudentName,
	VA.CounsellorId as CounsellorId,
	CONCAT(CPD.FirstName,' ',CPD.LastName) AS CounsellorName,
	VA.Category as Category,
	CM.CategoryAr as CategoryAr,
    CM.CategoryEn as CategoryEn,
	VA.Service as Service,
	SM.ServicesAr as ServicesAr,
	SM.ServicesEn as ServicesEn,
	Languages,
	Subject,
	Purpose,
	Documents,
	Duration,
	SelectedDate,
	StartTime,
	EndTime,
	VA.StudentAttandance as StudentAttandance,
	CouncellorAttandance,
	VA.CreatedBy,
	VA.CreatedDate,
	VA.UpdatedBy,
	VA.UpdatedDate,
	VA.IsActive as IsActive,
	VA.StatusId as StatusId,
	VA.ReasonReject as ReasonReject,	
	VirtualLink,
	CouncellorAttandance,
	CSR.StudentAttandance as StudentAttandance,
	(SELECT COUNT(*) FROM [VirtualAppointments] WHERE STATUSID=6) AS VirtualCount,
	(SELECT COUNT(*) FROM InboxList) AS InboxCount


	FROM [VirtualAppointments]VA WITH(NOLOCK) 
	join CategoryMaster CM
    ON VA.Category = CM.CategoryId

    join ServicesMaster SM
    ON VA.Service = SM.ServicesId

	left join CounsellingStudentRemarks CSR
	on VA.ID = CSR.AppointmentId

	left join SJIdentity .. [User] CPD
	 on VA.CounsellorId = CPD.Id

	
	 left join SJIdentity .. [User] SPD
	 on VA.StudentId = SPD.Id

	
	where	(@StudentId is null or @StudentId=0 or VA.StudentId= @StudentId)
	and		(@CounsellorId is null or @CounsellorId=0 or VA.CounsellorId = @CounsellorId) 
	and		(@SelectedDate is null or Convert(date ,SelectedDate ) = Convert(date,@SelectedDate)) 
	and		(@StatusId is null or @StatusId = 0 or VA.StatusId =@StatusId) and (VA.IsActive = 1)
	AND		(Convert(date ,SelectedDate )  >= @Date or @CheckExpiry=0 or @CheckExpiry is null) 
	and		((VA.StatusId = 3 or VA.StatusId = 6 )or @MultipleStatus is null or @MultipleStatus = 0)
	
    ORDER BY (CASE 
          WHEN VA.UpdatedDate IS NULL 
          THEN VA.CreatedDate ELSE VA.UpdatedDate 
          END) 
    DESC

END

-- exec GetVirtualAppointments @CounsellorId= 10081, @MultipleStatus = 1,  @CheckExpiry = 1
GO


