USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[CounsellorAvailableDates]    Script Date: 12-01-2022 15:40:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[CounsellorAvailableDates]

@CounsellorId BigInt,
@TimeDuration int 

AS
BEGIN
select  
	CounsellorId,
	Convert(date ,SelectedDate) as SelectedDate,
	COUNT (Convert(date ,SelectedDate)) as DateCount,
    count(case when Status = 3 then 'x' else null end) as ApprovedCount
	FROM [CounsellorFreeTimings] WITH(NOLOCK)
	Where (@CounsellorId is null or CounsellorId = @CounsellorId) 
     and (@TimeDuration is null or @TimeDuration = 0 or TimeDuration = @TimeDuration) 
	 and IsActive = 1
	GROUP BY CounsellorId, Convert(date ,SelectedDate)
END
GO


