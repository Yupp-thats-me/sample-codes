USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetAchievementDetails]    Script Date: 12-01-2022 15:47:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetAchievementDetails]
@CounsellorId BIGINT = null
AS
BEGIN
 SELECT Id,
	CounsellorId,
	Title,
	IssuingAuthority,
	CreatedBy,
	CreatedDate,
	UpdatedBy,
	UpdatedDate
  FROM [AchievementsDetails]
  where (@CounsellorId is null or CounsellorId = @CounsellorId)
  AND IsActive=1
  ORDER BY (CASE 
          WHEN UpdatedDate IS NULL 
          THEN CreatedDate ELSE UpdatedDate 
          END) 
DESC
END
GO


