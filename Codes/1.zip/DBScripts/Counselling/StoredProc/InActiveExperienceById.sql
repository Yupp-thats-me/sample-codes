USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[InActiveExperienceById]    Script Date: 13-01-2022 12:39:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[InActiveExperienceById]
	@Id bigint
AS
BEGIN
 
	SET NOCOUNT ON;
	
	UPDATE ExperienceDetails SET IsActive = 0
	WHERE Id = @Id
	
END
GO


