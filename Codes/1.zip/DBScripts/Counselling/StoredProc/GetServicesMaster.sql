USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetServicesMaster]    Script Date: 13-01-2022 12:18:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetServicesMaster]
AS
BEGIN
 SELECT [ServicesId]
      ,[ServicesEn]
      ,[ServicesAr]
	  
	 
  FROM  [ServicesMaster]
  
END
GO


