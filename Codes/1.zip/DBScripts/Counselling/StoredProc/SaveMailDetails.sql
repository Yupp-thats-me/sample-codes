USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[SaveMailDetails]    Script Date: 13-01-2022 13:04:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[SaveMailDetails]
(
    @Id bigint=0,
	@StudentId bigint=0,
	@CounsellorId bigint=0,
	@FromEmail nvarchar(500)=NULL,
	@ToEmail nvarchar(500)=NULL,
	@EmailContent nvarchar(500)=NULL,
	@Status nvarchar(500)=NULL,
	@CreatedBy nvarchar(20)=NULL	
)
AS
BEGIN
IF ISNULL(@Id, 0) = 0
 BEGIN
  INSERT INTO MailTracking(
  StudentId,
  CounsellorId, 
  FromEmail,
  ToEmail,
  EmailContent,
  Status,
  CreatedBy,
  CreatedDate
 )
  values
  (
    @StudentId,
    @CounsellorId ,
	@FromEmail,
    @ToEmail,
    @EmailContent,
    @Status,
    @CreatedBy,
	GETDATE()
	)
	   SELECT @Id= SCOPE_IDENTITY()
			SELECT @Id 
END
END
GO


