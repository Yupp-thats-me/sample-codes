USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetFaqDetails]    Script Date: 13-01-2022 11:51:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetFaqDetails]
@Id BigInt = null,
@CounsellorId BigInt = null,
@CategoryId int = 0,
@StatusId int = 0
AS
BEGIN
 SELECT 	
	Id,
	CounsellorId,
	QuestionEn,
	AnswerEn,
	QuestionAr,
	AnswerAr,
	FD.CategoryId as CategoryId,
	CM.CategoryEn as CategoryEn,
	CM.CategoryAr as CategoryAr,
	PostedDate,
	StatusId,
	RejectReason,
	CreatedBy,
	CreatedDate,
	UpdatedBy,
	UpdatedDate,
	IsActive

	FROM	[FaqDetails]FD WITH(NOLOCK)
	join  CategoryMaster CM
	on FD.CategoryId=CM.CategoryId 
	where (@CounsellorId IS NULL OR CounsellorId  = @CounsellorId )and 
	(FD.CategoryId=@CategoryId or @CategoryId = 0 OR @CategoryId IS NULL) and
	(StatusId=@StatusId or @StatusId = 0 OR @StatusId IS NULL) and (Id=@Id or @Id = 0 OR @Id IS NULL)
	AND IsActive=1
    ORDER BY (CASE 
          WHEN UpdatedDate IS NULL 
          THEN CreatedDate ELSE UpdatedDate 
          END) 
    DESC
	
END
GO


