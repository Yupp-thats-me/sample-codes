USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetQuestionAndAnswerDetailsId]    Script Date: 13-01-2022 12:07:45 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER   PROCEDURE [dbo].[GetQuestionAndAnswerDetailsId]
@Id BigInt =0,
@StudentId BIGINT = 0

AS
BEGIN
 SELECT 	
    IV.Id, 
	QandAListId,
	IL.CounsellorId,
	IL.StudentId,
    CONCAT(SPD.FirstName,' ',SPD.LastName) AS StudentName,
	SPD.ProfilePicFileName as StudentProfilePic,
	CONCAT(CPD.FirstName,' ',CPD.LastName) AS CounsellorName,
	CPD.ProfilePicFileName as CounsellorProfilePic,
	CM.CategoryAr,
	CM.CategoryEn,
	SM.ServicesAr,
	SM.ServicesEn,
	IL.Language,
	IL.Subject,
	IV.Question,
	IV.Answer,
	Pinned,  
	Document,
	IV.PostedDate,
	IV.ReplayDate,
	IV.IsActive,
	StudentDocument
	

	FROM	[InboxView]IV WITH(NOLOCK)
	  join InboxList IL
	  on IV.QandAListId = IL.Id

	  left join testdb .. [User] CPD
	 ON IL.CounsellorId = CPD.Id

     left join testdb .. [User] SPD
	 on IL.StudentId = SPD.Id

	 join CategoryMaster CM
	 on IL.CategoryId = CM.CategoryId

	  join ServicesMaster SM
	 on IL.ServiceId = SM.ServicesId

	where QandAListId  = @Id and IV.Isactive=1
	
   	ORDER BY (
				CASE WHEN @StudentId IS NULL or @StudentId = 0 THEN IV.PostedDate ELSE IV.ReplayDate END
			) DESC
If (@StudentId != null or @StudentId != 0)
	UPDATE InboxList set
	Status = 1
	where Id = @Id
	
END


GO


