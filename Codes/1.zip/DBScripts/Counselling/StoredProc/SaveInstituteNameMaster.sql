USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[SaveInstituteNameMaster]    Script Date: 13-01-2022 13:03:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER  PROCEDURE [dbo].[SaveInstituteNameMaster]

@ReferenceId int OUT,
@Id int=0,
@Institute	        NVARCHAR(250)=NULL


AS 
BEGIN
  -- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	set @ReferenceId=@Id
 IF(@Id=0)
   BEGIN
      INSERT INTO
        [dbo].InstituteNameMaster( 
		[Institute]
		
		) 
      VALUES
         (
		  @Institute
		 
         )
		set @ReferenceId=SCOPE_IDENTITY()
   END
END
GO


