USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[SaveReviewDetail]    Script Date: 13-01-2022 13:07:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[SaveReviewDetail]
(
    @Id BigInt=0,
	@AppointmentId BigInt=0,
	@ReviewedBy BigInt=0,
	@ReviewedFor BigInt=0,
	@RateGiven int=0,
	@CounsellorAttendSession bit=false,
	@Reviewcontent NVARCHAR(1000)=NULL,
	@CreatedBy nvarchar(20)=NULL,	
	@UpdatedBy nvarchar(20)=NULL,
	@IsActive bit=0

	
)
AS
BEGIN
IF not Exists (Select 1 from Review where AppointmentId=@AppointmentId)
BEGIN
  INSERT INTO Review(
	AppointmentId,
	ReviewedBy,
	ReviewedFor,
	RateGiven,
	CounsellorAttendSession,
	Reviewcontent,
	CreatedBy,
	CreatedDate,
	IsActive

	)
VALUES(
	@AppointmentId,
	@ReviewedBy,
	@ReviewedFor,
	@RateGiven,
	@CounsellorAttendSession,
	@Reviewcontent,
	@CreatedBy,
	GETDATE(),
	@IsActive
	
)
update VirtualAppointments set CouncellorAttandance = @CounsellorAttendSession where Id= @AppointmentId

   SELECT @Id= SCOPE_IDENTITY()

			SELECT @Id 
END

ELSE
  BEGIN
		 UPDATE Review
		 SET
	AppointmentId = @AppointmentId,
	ReviewedBy = @ReviewedBy,
	ReviewedFor = @ReviewedFor,
	RateGiven = @RateGiven,
	CounsellorAttendSession = @CounsellorAttendSession,
	Reviewcontent = @Reviewcontent,	
	UpdatedBy = @UpdatedBy,
	UpdatedDate = GETDATE(),
	IsActive=@IsActive
	WHERE AppointmentId =@AppointmentId
	END
	SELECT @Id
END
GO


