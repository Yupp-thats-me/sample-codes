USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetEducationDetailId]    Script Date: 12-01-2022 17:05:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetEducationDetailId]
@Id BigInt
AS
BEGIN
 SELECT 	
	Id,
	CounsellorId,
	ED.HigherEducationId as HigherEducationId,
	HE.HigherEducationEn as HigherEducationEn,
	HE.HigherEducationAr as HigherEducationAr,
	ED.MajorId as MajorId,
	MM.MajorName as MajorName,
	MM.ArMajorName as ArMajorName,
	ED.InstituteId as InstituteId,
	INM.Institute as Institute,
	StartDate,
	Pursuing,
	EndDate,
	CreatedBy,
	CreatedDate,
	UpdatedBy,
	UpdatedDate,
	IsActive

	FROM [EducationDetails]ED WITH(NOLOCK)
	JOIN HigherEducationMaster HE
	on HE.HigherEducationId = ED.HigherEducationId

	Join MajorMaster MM
	on MM.MajorId = ED.MajorId

	join InstituteNameMaster INM
	on INM.InstituteId = ED.InstituteId

	Where CounsellorId = @Id
	AND IsActive=1
    ORDER BY (CASE 
          WHEN UpdatedDate IS NULL 
          THEN CreatedDate ELSE UpdatedDate 
          END) 
    DESC
	
END
GO


