USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[GetInstituteNameMaster]    Script Date: 13-01-2022 11:56:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[GetInstituteNameMaster]
AS
BEGIN
		SELECT  
		    InstituteId,
			Institute	
		FROM	InstituteNameMaster WITH(NOLOCK)
END
GO


