USE SJCounselling
GO

/****** Object:  StoredProcedure [dbo].[GetSortMaster]    Script Date: 11/9/2021 12:22:18 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetSortMaster]
AS
BEGIN
SELECT  [sortId]
      ,[sortEn]
      ,[SortAr]
  FROM SortMaster with (nolock)
END
GO


