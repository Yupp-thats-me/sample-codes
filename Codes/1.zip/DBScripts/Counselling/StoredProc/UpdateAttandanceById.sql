USE [SJCounselling]
GO

/****** Object:  StoredProcedure [dbo].[UpdateAttandanceById]    Script Date: 13-01-2022 13:09:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[UpdateAttandanceById] 
(
	 @Id BIGINT
	,@StudentAttandance bit
	,@CouncellorAttandance bit
	,@UpdatedBy NVARCHAR(20)= null
	
)
AS
  BEGIN
		UPDATE VirtualAppointments
		 SET	   
			  StudentAttandance=@StudentAttandance,
			  CouncellorAttandance = @CouncellorAttandance,
			  UpdatedBy=@UpdatedBy,
			  UpdatedDate=GETDATE()
				WHERE Id =@Id
	END



GO


