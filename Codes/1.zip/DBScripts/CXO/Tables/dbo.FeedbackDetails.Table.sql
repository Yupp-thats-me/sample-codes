USE [SJCXO]
GO

/****** Object:  Table [dbo].[FeedbackDetails]    Script Date: 24-08-2021 00:56:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
DROP TABLE [dbo].[FeedbackDetails]
CREATE TABLE [dbo].[FeedbackDetails](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[PublicationtypeID] [bigint] NULL,
	[UserId] [bigint] NULL,
	[Content] [int] NULL,
	[Design] [int] NULL,
	[Personalization] [int] NULL,
	[Functionality] [int] NULL,
	[CreatedBy] [nchar](100) NULL,
	[CreatedDate] [date] NULL,
 CONSTRAINT [PK_FeedbackDetails] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


