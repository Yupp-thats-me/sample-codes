ALTER     PROCEDURE [dbo].[SaveFeedbackDetails]  
  
@ReferenceId BIGINT NULL OUTPUT ,  
@Id BIGINT NULL, 
@PublicationtypeID BIGINT = NULL,
@UserId BIGINT = NULL,
@Content INT,  
@Design INT,  
@Personalization INT, 
@Functionality INT,
@CreatedBy nvarchar(50)=null,
@CreatedDate DATETIME = null
  
AS  
  
BEGIN  
   
SET NOCOUNT ON;  
  
IF(ISNULL(@Id, 0) = 0)  
BEGIN  
INSERT INTO  
[dbo].FeedBackDetails  
(  
 --,FeedbackType
  PublicationtypeID
 ,UserId
 ,Content
 ,Design
 ,Personalization
 ,Functionality
,CreatedBy  
,CreatedDate  

  
)  
VALUES  
(
--,@FeedbackType
 @PublicationtypeID
,@UserId
,@Content
,@Design
,@Personalization
,@Functionality
,@CreatedBy  
,GETUTCDATE() 
)  
SET @ReferenceId = SCOPE_IDENTITY();  
END  
ELSE  
BEGIN  
UPDATE  
dbo.FeedBackDetails  
SET  
--FeedbackType=@FeedbackType,  
PublicationtypeID = @PublicationtypeID,
UserId = @UserId,
Content=@Content,  
Design=@Design,  
Personalization=@Personalization,  
Functionality=@Functionality  
WHERE Id=@Id  
  
SET @ReferenceId=@Id  
END  
  
END
