USE [SJCXO]
GO
/** Object:  StoredProcedure [dbo].[report.getCxoListingStatistics]    Script Date: 5/5/2022 3:46:06 PM **/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER   PROCEDURE [dbo].[report.getCxoListingStatistics]
	@StartDate datetime = null,
	@EndDate datetime = null,
	@PostType int =0,
	@OrganizationType int = 0
	

AS
BEGIN
 

 IF(@PostType=2 or @PostType=1)
 BEGIN

	SELECT 
	DISTINCT
	CONCAT(U.FirstName,' ',U.LastName) AS AdminName,
	
	sum(case when (ED.Status=3)AND (U.RequestedRole=5)then 1 else 0 end)as TotalCXOApproved,
		sum(case when (ED.Status=4)AND (U.RequestedRole=5)then 1 else 0 end)as TotalCXORejected,
			sum(case when (ED.Status=2)AND (U.RequestedRole=5)then 1 else 0 end)as TotalCXOPending,
			count(case when (ED.Status!=1)AND (U.RequestedRole=5)then 1 else 0 end)as TotalCXOPosted

	From [dbo].EventDetails ED WITH(NOLOCK) 
	JOIN ProfileDetails PD WITH (NOLOCK) ON PD.CXOId=ED.CXOId
	LEFT JOIN [SJIdentity].[dbo].[User] U WITH(NOLOCK) 
	ON U.ID=ED.CreatedBy

	WHERE ED.CreatedDate Between @StartDate AND @EndDate
	And (U.IsActive = 1) AND (U.ApprovalStatus = 3)
    AND (@OrganizationType=0 OR @OrganizationType = PD.CXOTypeId)



	GROUP BY

	CONCAT(U.FirstName,' ',U.LastName)
	  
END

ELSE IF (@PostType=3 or @PostType=4  OR @PostType=5)


BEGIN




	SELECT 
	Distinct
	CONCAT(U.FirstName,' ',U.LastName) AS AdminName,


		sum(case when (CD.Status=3)AND (U.RequestedRole=5)then 1 else 0 end)as TotalCXOApproved,
		sum(case when (CD.Status=4)AND (U.RequestedRole=5)then 1 else 0 end)as TotalCXORejected,
			sum(case when (CD.Status=2)AND (U.RequestedRole=5)then 1 else 0 end)as TotalCXOPending,
			count(case when (CD.Status!=1)AND (U.RequestedRole=5)then 1 else 0 end)as TotalCXOPosted






	From [dbo].PublicationDetail CD WITH(NOLOCK) 
	JOIN ProfileDetails PD WITH (NOLOCK) ON PD.CXOId=CD.CXOId
	LEFT JOIN [SJIdentity].[dbo].[User] U WITH(NOLOCK) 
	ON U.ID=CD.CreatedBy

	WHERE CD.CreatedDate Between @StartDate AND @EndDate
	And (U.IsActive = 1) AND (U.ApprovalStatus = 3)
	--AND (@StartDate is null or Convert(date ,CD.CreatedDate ) = Convert(date,@StartDate))
 --   AND (@EndDate is null or Convert(date ,CD.ExpiryDate ) = Convert(date,@EndDate))
    AND (@OrganizationType=0 OR @OrganizationType = PD.CXOTypeId)	




	--   GROUP BY (
	--CASE WHEN CD.UpdatedDate IS NULL THEN CD.CreatedDate ELSE CD.UpdatedDate END
	--) DESC


	GROUP BY
	CONCAT(U.FirstName,' ',U.LastName) 


END


  end

	  
 



--SELECT * FROM eventDetails

--SELECT * FROM PublicationDetail

--select * from ProfileDetails

--EXEC [report.getCxoListingStatistics] '2021-12-19','2022-04-24',3,0