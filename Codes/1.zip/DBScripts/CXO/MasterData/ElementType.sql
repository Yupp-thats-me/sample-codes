USE [SJCXO]
GO 
INSERT INTO [ElementType]
      ([ElementTypeName])
Values
     ('Industry'),
	 ('Designation'),
	 ('Company'),
	 ('CompanyZone')
GO