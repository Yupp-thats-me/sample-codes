USE [SJScholarships]
GO

/****** Object:  StoredProcedure [dbo].[GetMajorMasterDetails]    Script Date: 27-07-2021 17:44:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE OR ALTER     PROCEDURE [dbo].[GetMajorMasterDetails]

AS  
BEGIN  
  
 SET NOCOUNT ON;  
 SELECT
 MajorId
,MajorValueEn
,MajorValueAr
,isnull(ParentId, 0) 'ParentID'
,IsActive
 FROM
 InternshipMajorMaster WITH(NOLOCK)   
 WHERE IsActive=1
 ORDER BY MajorValueEn ASC  
  
END 
GO


