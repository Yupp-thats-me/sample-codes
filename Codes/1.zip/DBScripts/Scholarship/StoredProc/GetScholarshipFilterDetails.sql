CREATE OR ALTER  PROC [dbo].[GetScholarshipFilterDetails]    
@Id     BIGINT =NULL  
 
AS  
  
BEGIN  
SELECT   
    
      SD.Id	
     ,SD.CreatedDate
	 ,SD.ExpiryDate
	 ,CONCAT(US.FirstName,' ',US.LastName) AS AdminName
	
	   
    FROM   
    [dbo].ScholarshipDetails SD WITH(NOLOCK) 
    JOIN [SJIdentity].[dbo].[User] US WITH(NOLOCK) 
    ON US.ID=SD.CreatedBy
    WHERE SD.ID=@Id OR @Id IS NULL and SD.Active=1  
	ORDER BY (
	CASE WHEN UpdatedDate IS NULL THEN SD.CreatedDate ELSE UpdatedDate END
	) DESC
  
END  