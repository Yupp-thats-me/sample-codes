﻿USE SJScholarships
GO
INSERT INTO ScholarshipDropdownMaster           
           (DropdownValueEn
           ,DropdownValueAr
           ,Category
           ,IsActive)
VALUES
--On Behalf Of--
          ('HEI Admin',N'HEI مسؤل','OnBehalfOf','1'),
          ('Employer Admin',N'رب العمل المسؤول','OnBehalfOf','1'),
          ('General User',N'مستخدم عام','OnBehalfOf','1'),
          ('MoE Admin',N'وزارة التربية المشرف','OnBehalfOf','1'),

--Nationality---
          ('All',N'الكل','Nationality','1'),
          ('UAE Nationals',N'مواطني دولة الإمارات العربية المتحدة','Nationality','1'),
          ('Non-Nationals',N'غير المواطنين','Nationality','1'),

--Higher Education--
         ('Undergraduate',N'المرحلة الجامعية','Higher Education','1'),
         ('Postgraduate',N'الدراسات العليا','Higher Education','1'),
         ('Vocational',N'المهني','Higher Education','1')

--Major-----
        ('Accounting',N'محاسبة','Major',1),
		('Accounting & Financing',N'المحاسبة والتمويل','Major',1
		('Acting',N'التمثيل','Major',1)
--Year---
        ('All',N'الكل','Year',1),
		('Freshman',N'طالبة',1)

GO
