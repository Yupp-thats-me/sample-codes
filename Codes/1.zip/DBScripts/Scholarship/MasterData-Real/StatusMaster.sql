

USE [SJScholarships]
GO

INSERT INTO [dbo].[StatusMaster]
           ([Status])
     VALUES
           ('Draft'),
		   ('Pending Approval'),
		   ('Approved'),
		   ('Rejected')
GO