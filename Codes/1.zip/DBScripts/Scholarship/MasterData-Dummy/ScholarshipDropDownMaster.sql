﻿USE SJScholarships
GO
INSERT INTO ScholarshipDropdownMaster           
           (DropdownValueEn
           ,DropdownValueAr
           ,Category
           ,IsActive)
VALUES

    --Major-----
        ('Accounting',N'محاسبة','Major',1),
		('Accounting & Financing',N'المحاسبة والتمويل','Major',1),
		('Acting',N'التمثيل','Major',1)
     --Year---
        ('All',N'الكل','Year',1),
		('Freshman',N'طالبة','Year',1)
GO
