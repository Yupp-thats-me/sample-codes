USE [SJScholarships]
GO

ALTER TABLE [dbo].[FeedBackDetails] DROP CONSTRAINT [FK__FeedBackD__Schol__73BA3083]
GO

/****** Object:  Table [dbo].[FeedBackDetails]    Script Date: 29-07-2021 17:22:15 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FeedBackDetails]') AND type in (N'U'))
DROP TABLE [dbo].[FeedBackDetails]
GO

/****** Object:  Table [dbo].[FeedBackDetails]    Script Date: 29-07-2021 17:22:15 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[FeedBackDetails](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[Content] [int] NULL,
	[Design] [int] NULL,
	[Personalization] [int] NULL,
	[Functionality] [int] NULL,
	[CreatedBy] [nvarchar](100) NULL,
	[CreatedDate] [date] NULL,
	[UpdatedBy] [nvarchar](100) NULL,
	[UpdatedDate] [date] NULL,
	[ScholarshipId] [bigint] NULL,
	[StudentId] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[FeedBackDetails]  WITH CHECK ADD FOREIGN KEY([ScholarshipId])
REFERENCES [dbo].[ScholarshipDetails] ([ID])
GO


