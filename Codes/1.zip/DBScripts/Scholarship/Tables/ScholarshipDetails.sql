USE [SJScholarships]
GO

/****** Object:  Table [dbo].[ScholarshipDetails]    Script Date: 3/28/2022 8:25:13 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ScholarshipDetails](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[TitleEn] [nvarchar](100) NOT NULL,
	[TitleAr] [nvarchar](100) NULL,
	[DescriptionEn] [nvarchar](max) NOT NULL,
	[DescriptionAr] [nvarchar](max) NULL,
	[BenefitsEn] [nvarchar](max) NULL,
	[BenefitsAr] [nvarchar](max) NULL,
	[NationalityId] [bigint] NULL,
	[HigherEducationId] [nvarchar](100) NULL,
	[MajorId] [nvarchar](100) NULL,
	[SpecializationId] [int] NULL,
	[YearId] [nvarchar](100) NULL,
	[EligibilityEn] [nvarchar](max) NULL,
	[EligibilityAr] [nvarchar](max) NULL,
	[HowToApplyEn] [nvarchar](max) NULL,
	[HowToApplyAr] [nvarchar](max) NULL,
	[ExpiryDate] [date] NOT NULL,
	[UploadImage] [nvarchar](600) NULL,
	[StatusId] [int] NULL,
	[OnBehalfOf] [int] NULL,
	[Active] [bit] NULL,
	[CreatedBy] [nvarchar](200) NULL,
	[CreatedDate] [datetime] NULL,
	[UpdatedBy] [nvarchar](200) NULL,
	[UpdatedDate] [datetime] NULL,
	[ApplicationUrl] [nvarchar](500) NULL,
	[ContactEmail] [nvarchar](50) NULL,
	[Reason] [nvarchar](500) NULL,
	[Scholarshiptype] [int] NULL,
	[Scholarshipfeature] [int] NULL,
	[TotalViews] [bigint] NULL,
 CONSTRAINT [PK__Scholars__3214EC27234D816A] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[ScholarshipDetails]  WITH CHECK ADD  CONSTRAINT [FK__Scholarsh__Natio__6E01572D] FOREIGN KEY([NationalityId])
REFERENCES [dbo].[ScholarshipDropdownMaster] ([DropdownId])
GO

ALTER TABLE [dbo].[ScholarshipDetails] CHECK CONSTRAINT [FK__Scholarsh__Natio__6E01572D]
GO

ALTER TABLE [dbo].[ScholarshipDetails]  WITH CHECK ADD  CONSTRAINT [FK__Scholarsh__Statu__6C190EBB] FOREIGN KEY([StatusId])
REFERENCES [dbo].[StatusMaster] ([StatusId])
GO

ALTER TABLE [dbo].[ScholarshipDetails] CHECK CONSTRAINT [FK__Scholarsh__Statu__6C190EBB]
GO


