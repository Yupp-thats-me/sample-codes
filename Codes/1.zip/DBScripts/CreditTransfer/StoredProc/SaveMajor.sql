USE [SJCreditTransfer]
GO

/****** Object:  StoredProcedure [dbo].[SaveMajor]    Script Date: 8/9/2021 8:33:05 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[SaveMajor]
@ReferenceId           Int OUTPUT,
@MajorId               Int,
@MajorNameAr		   NVARCHAR(255),
@MajorNameEn           NVARCHAR(255)

AS 
BEGIN
	SET NOCOUNT ON;
	IF(ISNULL(@MajorId, 0) = 0) 
   BEGIN
      INSERT INTO
        [dbo].MajorMaster( 
		[MajorNameEn],
		[MajorNameAr]
		) 
      VALUES
         (
		 @MajorNameEn,
		 @MajorNameAr
         )
		 SET @ReferenceId = SCOPE_IDENTITY();
   END
   ELSE
		BEGIN
			UPDATE 
			dbo.MajorMaster
			SET 
			 MajorNameEn = @MajorNameEn,
		     MajorNameAr = @MajorNameAr
			WHERE MajorId=@MajorId

			SET @ReferenceId = @MajorId;
		END
END


--
GO


