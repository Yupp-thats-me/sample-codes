USE [SJCreditTransfer]
GO

/****** Object:  StoredProcedure [dbo].[GetScholarshipGrid]    Script Date: 4/20/2022 3:52:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

 
CREATE   PROC [dbo].[GetScholarshipGrid]

@Id					BIGINT =NULL

AS

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
				SELECT SD.Id
					,TitleEn
					,TitleAr
					,ExpiryDate
					,StatusId
					,OnBehalfOf
					,Active
					,(UD.FirstName+' '+ UD.LastName) AS CreatedBy
					,CreatedDate
					,UpdatedBy
					,UpdatedDate
					,Reason
					
				FROM 
				[dbo].ScholarshipDetails SD WITH(NOLOCK) 
				JOIN [SJIdentity].[dbo].usersdetails UD WITH(NOLOCK) 
				ON SD.CreatedBy=UD.ID
				WHERE SD.ID=@Id OR @Id IS NULL	and Active=1
			    ORDER BY (
	            CASE WHEN UpdatedDate IS NULL THEN CreatedDate ELSE UpdatedDate END
				) DESC

END


GO


