USE [SJCreditTransfer]
GO

/****** Object:  StoredProcedure [dbo].[SaveApprovalDetails]    Script Date: 7/13/2021 1:14:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROC [dbo].[SaveApprovalDetails]

@ReferenceId		BIGINT NULL OUTPUT ,
@Id					BIGINT NULL,
@StatusId           INT=null,
@UpdatedBy        NVARCHAR(50)=null,
@UpdatedOn        NVARCHAR(50)=null,
@Reason             NVARCHAR(50)=null



AS

BEGIN
  -- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		BEGIN
			UPDATE 
			dbo.CreditTransferDetails
			SET
			StatusId=@StatusId,
			UpdatedBy=@UpdatedBy,
			UpdatedOn=GETUTCDATE(),
			Reason=@Reason
			WHERE Id=@Id

			SET @ReferenceId=@Id
		END
		BEGIN
			INSERT INTO
        [dbo].AuditCreditTransfer 
		(
		   CreditTransferId
		  ,UpdatedBy
		  ,UpdatedOn
		  ,StatusId
		  ,Reason
		) 
      VALUES
         (
		 @ReferenceId
		 ,@UpdatedBy
		 ,GETUTCDATE()
		 ,@StatusId
		 ,@Reason
         )
	
		END

END
GO


