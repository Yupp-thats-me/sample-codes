USE [SJCreditTransfer]
GO

/****** Object:  StoredProcedure [dbo].[GetCreditTransferDetailsStudent]    Script Date: 6/9/2021 4:39:02 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetCreditTransferDetailsStudent]
@AcademicYear int = null,
@FromHEI int = null,
@ToHEI int = null,
@Department nvarchar(50) = null,
@Major nvarchar(50) = null

AS

BEGIN
 
SET NOCOUNT ON;

SELECT  
 [Id]
,[FromHEI]
,[ToHEI]
,[AcademicYear]
,[DepartmentFromEn]
,[DepartmentToEn]
,[DepartmentFromAr]
,[DepartmentToAr]
,[MajorFromEn]
,[MajorToEn]
,[MajorFromAr]
,[MajorToAr]
,[ExpiryDate]
,[UploadFile]
,[StatusId]
,[OnBehalfOf]
,[Active]
,[CreatedBy]
,[CreatedOn]
,[UpdatedBy]
,[UpdatedOn]
,[UploadId]
,[Reason]



FROM [SJCreditTransfer].[dbo].CreditTransferDetails WITH(NOLOCK)
WHERE	(AcademicYear=@AcademicYear OR @AcademicYear IS NULL) 
AND (FromHEI=@FromHEI OR @FromHEI IS NULL)
AND (ToHEI=@ToHEI OR @ToHEI IS NULL) 
AND (DepartmentFromEn=@Department  OR @Department IS NULL)
AND (MajorFromEn=@Major OR @Major IS NULL)

END
GO


