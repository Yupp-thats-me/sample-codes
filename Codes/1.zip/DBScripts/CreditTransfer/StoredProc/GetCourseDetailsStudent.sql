USE [SJCreditTransfer]
GO

/****** Object:  StoredProcedure [dbo].[GetCourseDetailsStudent]    Script Date: 6/9/2021 3:10:39 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetCourseDetailsStudent]
@Id Bigint = null,
@Course nvarchar(50) = null

AS

BEGIN
 
SET NOCOUNT ON;

SELECT   A.Id
		,CreditTransferId
		,CourseFromEn
		,CourseToEn
		,CourseFromAr
		,CourseToAr 
FROM	[SJCreditTransfer].[dbo].[CreditTransferDetails] C WITH(NOLOCK)
INNER JOIN [SJCreditTransfer].[dbo].[Courses] A WITH(NOLOCK) ON C.Id=A.CreditTransferId
WHERE	((C.Id=@Id) or ((CourseFromEn=@Course OR @Course IS NULL) and A.CreditTransferId = @Id))


END
GO


