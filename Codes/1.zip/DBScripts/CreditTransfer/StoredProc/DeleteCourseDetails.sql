USE [SJCreditTransfer]
GO

/****** Object:  StoredProcedure [dbo].[DeleteCourseDetails]    Script Date: 5/25/2021 11:38:30 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[DeleteCourseDetails]	 
	-- Add the parameters for the stored procedure here
	@CreditTransferId					BIGINT NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

         DELETE FROM Courses
         WHERE [CreditTransferId] = @CreditTransferId
END
GO


