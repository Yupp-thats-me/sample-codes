USE [SJCreditTransfer]
GO

/****** Object:  StoredProcedure [dbo].[GetHigherEducationInstitute]    Script Date: 5/18/2021 3:33:37 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetHigherEducationInstitute]
AS
BEGIN
	SELECT  
		[HeiId]
		,[HeiName]
	FROM [SJCreditTransfer].[dbo].[HeiMaster] WITH(NOLOCK)
END
GO


