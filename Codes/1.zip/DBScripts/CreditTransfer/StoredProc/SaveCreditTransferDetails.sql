USE [SJCreditTransfer]
GO

/****** Object:  StoredProcedure [dbo].[SaveCreditTransferDetails]    Script Date: 8/9/2021 8:33:51 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER   PROC [dbo].[SaveCreditTransferDetails]

@ReferenceId		BIGINT NULL OUTPUT,
@Id					BIGINT NULL,
@FromHEI            INT,
@ToHEI              INT,
@AcademicYear       INT,
@DepartmentFromEn   INT=null,
@DepartmentToEn     INT=null,
@DepartmentFromAr   INT=null,
@DepartmentToAr     INT=null,
@MajorFromEn        INT=null,
@MajorToEn          INT=null,
@MajorFromAr        INT=null,
@MajorToAr          INT=null,
@ExpiryDate         DATETIME,
@UploadFile         NVARCHAR(1200)=null,
@StatusId           INT,
@OnBehalfOf         INT,
@Active				BIT,
@Created_By			NVARCHAR(128)=null,
@Created_Date		DATETIME=null,
@Updated_By			NVARCHAR(128)=null, 
@Updated_Date		DATETIME=null,
@UploadId           BIGINT=null,
@Reason             NVARCHAR(50)=null



AS

BEGIN
  -- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	IF  EXISTS
				   (SELECT 1 FROM CreditTransferDetails
				    WHERE AcademicYear = @AcademicYear AND FromHEI = @FromHEI AND ToHEI = @ToHEI
					AND DepartmentFromEn = @DepartmentFromEn AND DepartmentFromAr =@DepartmentFromAr 
					AND MajorFromEn =@MajorFromEn AND MajorFromAr = @MajorFromAr
					 AND Id!=@Id)

				THROW 50001, 'Duplicate Entry Found.', 1;
    ELSE
	IF(ISNULL(@Id, 0) = 0) 
		BEGIN
			INSERT INTO
        [dbo].CreditTransferDetails 
		(
		  FromHEI
		 ,ToHEI
		 ,AcademicYear
		 ,DepartmentFromEn
		 ,DepartmentToEn
		 ,DepartmentFromAr
		 ,DepartmentToAr
		 ,MajorFromEn
		 ,MajorToEn
		 ,MajorFromAr
		 ,ExpiryDate
		 ,UploadFile
		 ,StatusId
		 ,OnBehalfOf
		 ,Active
		 ,CreatedBy
		 ,CreatedOn
		 ,MajorToAr
		 ,UploadId
		 ,Reason

		) 
      VALUES
         (
		  @FromHEI
		 ,@ToHEI
		 ,@AcademicYear
		 ,@DepartmentFromEn
		 ,@DepartmentToEn
		 ,@DepartmentFromAr
		 ,@DepartmentToAr
		 ,@MajorFromEn
		 ,@MajorToEn
		 ,@MajorFromAr
		 ,@ExpiryDate
		 ,@UploadFile
		 ,@StatusId
		 ,@OnBehalfOf
		 ,@Active
		 ,@Created_By
		 ,GETUTCDATE() 
		 ,@MajorToAr
		 ,@UploadId
		 ,@Reason

         )
			SET @ReferenceId = SCOPE_IDENTITY();
		END
	ELSE
		BEGIN
			UPDATE 
			dbo.CreditTransferDetails
			SET 
			FromHEI=@FromHEI,
			ToHEI=@ToHEI,
			AcademicYear=@AcademicYear,
			DepartmentFromEn=@DepartmentFromEn,
			DepartmentToEn=@DepartmentToEn,
			DepartmentFromAr=@DepartmentFromAr,
			DepartmentToAr=@DepartmentToAr,
			MajorFromEn=@MajorFromEn,
		    MajorToEn=@MajorToEn,
			MajorFromAr=@MajorFromAr,
			MajorToAr=@MajorToAr,
			ExpiryDate=@ExpiryDate,
			UploadFile=@UploadFile,
			StatusId=@StatusId,
			OnBehalfOf=@OnBehalfOf,
			Active=@Active,
			UploadId=@UploadId,
			UpdatedBy=@Created_By,
			UpdatedOn=GETUTCDATE(),
			Reason=@Reason
			WHERE Id=@Id

			SET @ReferenceId=@Id
		END
		BEGIN
			INSERT INTO
        [dbo].AuditCreditTransfer 
		(
		   CreditTransferId
		  ,UpdatedBy
		  ,UpdatedOn
		  ,StatusId
		  ,Reason
		) 
      VALUES
         (
		 @ReferenceId
		 ,@Created_By
		 ,GETUTCDATE()
		 ,@StatusId
		 ,@Reason
         )
	
		END
END
GO


