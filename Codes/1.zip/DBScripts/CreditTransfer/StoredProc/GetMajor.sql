USE [SJCreditTransfer]
GO

/****** Object:  StoredProcedure [dbo].[GetMajor]    Script Date: 6/9/2021 4:40:07 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetMajor]
AS
BEGIN
	SELECT  
		[MajorId]
		,[MajorNameEn]
		,[MajorNameAr]
	FROM [SJCreditTransfer].[dbo].[MajorMaster] WITH(NOLOCK)
END
GO


