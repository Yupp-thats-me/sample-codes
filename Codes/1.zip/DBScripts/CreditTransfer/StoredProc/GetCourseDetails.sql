USE [SJCreditTransfer]
GO

/****** Object:  StoredProcedure [dbo].[GetCourseDetails]    Script Date: 5/25/2021 11:42:07 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetCourseDetails]
@Id Bigint = null

AS

BEGIN
 
SET NOCOUNT ON;

SELECT   A.Id
		,CreditTransferId
		,CourseFromEn
		,CourseToEn
		,CourseFromAr
		,CourseToAr 
FROM	[SJCreditTransfer].[dbo].[CreditTransferDetails] C WITH(NOLOCK)
INNER JOIN [SJCreditTransfer].[dbo].[Courses] A WITH(NOLOCK) ON C.Id=A.CreditTransferId
WHERE	((C.Id=@Id OR @Id IS NULL))


END
GO


