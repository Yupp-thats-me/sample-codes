USE [SJCreditTransfer]
GO

/****** Object:  StoredProcedure [dbo].[GetAcademicYear]    Script Date: 6/2/2021 11:18:01 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetAcademicYear]
AS
BEGIN
	SELECT  
		[AcademicId]
		,[AcademicYear]
	FROM [SJCreditTransfer].[dbo].[AcademicYearMaster] WITH(NOLOCK)
END
GO


