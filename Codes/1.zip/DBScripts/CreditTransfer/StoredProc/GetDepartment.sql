USE [SJCreditTransfer]
GO

/****** Object:  StoredProcedure [dbo].[GetDepartment]    Script Date: 6/9/2021 4:39:35 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetDepartment]
AS
BEGIN
	SELECT  
		[DepartmentId]
		,[DepartmentNameEn]
		,[DepartmentNameAr]
	FROM [SJCreditTransfer].[dbo].[DepartmentMaster] WITH(NOLOCK)
END
GO


