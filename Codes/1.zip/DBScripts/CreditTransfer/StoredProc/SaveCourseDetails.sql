USE [SJCreditTransfer]
GO

/****** Object:  StoredProcedure [dbo].[SaveCourseDetails]    Script Date: 5/25/2021 11:44:14 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROC [dbo].[SaveCourseDetails]

@ReferenceId		BIGINT NULL OUTPUT ,
@Id					BIGINT NULL,
@CreditTransferId   BIGINT NULL,
@CourseFromEn       nVarchar(200),
@CourseToEn			nVarchar(200),
@CourseFromAr		nVarchar(200),
@CourseToAr			nVarchar(200)



AS

BEGIN
  -- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF(ISNULL(@Id, 0) = 0) 
		BEGIN
			INSERT INTO
        [dbo].Courses 
		(
		  CreditTransferId
		 ,CourseFromEn
		 ,CourseToEn
		 ,CourseFromAr
		 ,CourseToAr
		) 
      VALUES
         (
		 @CreditTransferId
		,@CourseFromEn
		,@CourseToEn
		,@CourseFromAr
		,@CourseToAr
         )
			SET @ReferenceId = SCOPE_IDENTITY();
		END
	ELSE
		BEGIN
			UPDATE 
			dbo.Courses
			SET 
			CreditTransferId=@CreditTransferId,
			CourseFromEn=@CourseFromEn,
			CourseToEn=@CourseToEn,
			CourseFromAr=@CourseFromAr,
			CourseToAr=@CourseToAr
			WHERE Id=@Id

			SET @ReferenceId=@Id
		END

END
GO


