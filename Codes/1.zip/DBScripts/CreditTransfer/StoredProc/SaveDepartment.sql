USE [SJCreditTransfer]
GO

/****** Object:  StoredProcedure [dbo].[SaveDepartment]    Script Date: 8/9/2021 8:32:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[SaveDepartment]

@ReferenceId		        Int NULL OUTPUT,
@DepartmentId               Int,
@DepartmentNameAr			NVARCHAR(255),
@DepartmentNameEn           NVARCHAR(255)

AS 
BEGIN
	SET NOCOUNT ON;
		IF(ISNULL(@DepartmentId, 0) = 0) 
   BEGIN
      INSERT INTO
        [dbo].DepartmentMaster( 
		[DepartmentNameEn],
		[DepartmentNameAr]
		) 
      VALUES
         (
		 @DepartmentNameEn,
		 @DepartmentNameAr
         )
		SET @ReferenceId = SCOPE_IDENTITY();

   END
   ELSE
		BEGIN
			UPDATE 
			dbo.DepartmentMaster
			SET 
			 DepartmentNameEn = @DepartmentNameEn,
		     DepartmentNameAr = @DepartmentNameAr
			WHERE DepartmentId=@DepartmentId

			SET @ReferenceId = @DepartmentId;
		END
END


--
GO


