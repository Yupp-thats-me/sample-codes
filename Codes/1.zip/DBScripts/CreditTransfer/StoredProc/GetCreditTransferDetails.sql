USE [SJCreditTransfer]
GO

/****** Object:  StoredProcedure [dbo].[GetCreditTransferDetails]    Script Date: 7/28/2021 12:27:01 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER   PROCEDURE [dbo].[GetCreditTransferDetails]
@Id BIGINT = null

AS

BEGIN
 
SET NOCOUNT ON;

SELECT  
 [Id]
,[FromHEI]
,[ToHEI]
,CD.AcademicYear
,AM.AcademicYear as AcademicYears
,HM1.HeiName as FromHei
,HM2.HeiName as ToHei
,DM1.DepartmentNameEn as DepartmentFromEns 
,DM2.DepartmentNameEn as DepartmentToEns
,DM3.DepartmentNameAr as DepartmentFromArs
,DM4.DepartmentNameAr as DepartmentToArs
,[DepartmentFromEn]
,[DepartmentToEn]
,[DepartmentFromAr]
,[DepartmentToAr]
,MM1.MajorNameEn as MajorFromEns 
,MM2.MajorNameEn as MajorToEns
,MM3.MajorNameAr as MajorFromArs
,MM4.MajorNameAr as MajorToArs
,[MajorFromEn]
,[MajorToEn]
,[MajorFromAr]
,[MajorToAr]
,[ExpiryDate]
,[UploadFile]
,[StatusId]
,[OnBehalfOf]
,[Active]
,[CreatedBy]
,[CreatedOn]
,[UpdatedBy]
,[UpdatedOn]
,[UploadId]
,[Reason]
,[TotalViews]



FROM [SJCreditTransfer].[dbo].CreditTransferDetails CD WITH(NOLOCK)
   JOIN DepartmentMaster DM1  WITH(NOLOCK) ON CD.DepartmentFromEn=DM1.DepartmentId 
   JOIN DepartmentMaster DM2  WITH(NOLOCK) ON CD.DepartmentToEn=DM2.DepartmentId 
   JOIN DepartmentMaster DM3  WITH(NOLOCK) ON CD.DepartmentFromAr=DM3.DepartmentId 
   JOIN DepartmentMaster DM4  WITH(NOLOCK) ON CD.DepartmentToAr=DM4.DepartmentId
  
   JOIN MajorMaster MM1  WITH(NOLOCK) ON CD.MajorFromEn=MM1.MajorId 
   JOIN MajorMaster MM2  WITH(NOLOCK) ON CD.MajorToEn=MM2.MajorId 
   JOIN MajorMaster MM3  WITH(NOLOCK) ON CD.MajorFromAr=MM3.MajorId 
   JOIN MajorMaster MM4  WITH(NOLOCK) ON CD.MajorToAr=MM4.MajorId 
  
   join AcademicYearMaster AM
  ON CD.AcademicYear=AM.AcademicId

  join HeiMaster HM1 ON CD.FromHEI=HM1.HeiId 
  join HeiMaster HM2 ON CD.ToHEI=HM2.HeiId 
WHERE	(Id=@Id OR @Id IS NULL) AND Active = 1
ORDER BY (
	CASE WHEN UpdatedOn IS NULL THEN CreatedOn ELSE UpdatedOn END
	) DESC

END

-- exec GetCreditTransferDetails