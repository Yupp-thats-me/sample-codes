﻿USE [SJCreditTransfer]
GO
INSERT INTO HeiMaster
          ( HeiName,
		   HeiNameAr)
Values
        ('Abu Dhabi University',N'جامعة أبوظبي'),
		('Al Ain University',N'جامعة العين'),
		('Emirates Diplomatic Academy',N'أكاديمية الإمارات الدبلوماسية'),
		('Emirates Institute For Banking And Financial Studies',N'معهد الإمارات للدراسات المصرفية والمالية'),
		('Emirates Institute For Citizenship And Residence',N'معهد الإمارات للجنسية والإقامة'),
		('European International College',N'الكلية الأوروبية الدولية'),
		('Fatima College of Health Science',N'كلية فاطمة للعلوم الصحية'),
		('Higher Colleges of Technology',N'كليات التقنية العليا')

GO
		