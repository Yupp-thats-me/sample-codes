﻿USE [SJCreditTransfer]
GO
INSERT INTO MajorMaster
         ([MajorNameEn]
      ,[MajorNameAr])
Values
    ('Computer Science',N'علوم الكمبيوتر'),
	('Communications',N'مجال الاتصالات'),
	('Biology',N'مادة الاحياء'),
	('Nursing ',N'التمريض'),
	('Psychology',N'علم النفس'),
	('Literature',N'المؤلفات'),
	('HomeScience',N'علم الوطن'),
	('Aero Space',N'ايرو سبيس')

GO
