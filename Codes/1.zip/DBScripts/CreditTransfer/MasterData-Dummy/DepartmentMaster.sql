﻿USE [SJCreditTransfer]
GO
INSERT INTO DepartmentMaster
        (
		DepartmentNameEn,
		DepartmentNameAr)
Values
       ('Civil Engineering',N'هندسة مدنية'),
	   ('Mechincal ',N'ميكانيكي'),
	   ('Science and Humanity',N'العلم والإنسانية'),
	   ('Aero space',N'الفضاء الجوي')
GO
	