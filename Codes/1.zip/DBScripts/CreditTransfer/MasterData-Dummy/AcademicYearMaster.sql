USE SJCreditTransfer
GO
INSERT INTO AcademicYearMaster
             (AcademicId,
              AcademicYear)
Values
          (1,'2020-2021'),
          (2,'2021-2022'),
          (3,'2022-2023')

GO