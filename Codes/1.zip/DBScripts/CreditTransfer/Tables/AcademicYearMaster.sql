USE [SJCreditTransfer]
GO

/****** Object:  Table [dbo].[AcademicYearMaster]    Script Date: 6/2/2021 11:15:02 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AcademicYearMaster](
	[AcademicId] [int] IDENTITY(1,1) NOT NULL,
	[AcademicYear] [nchar](100) NULL,
 CONSTRAINT [PK_AcademicYearMaster] PRIMARY KEY CLUSTERED 
(
	[AcademicId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


