USE [SJCreditTransfer]
GO

/****** Object:  Table [dbo].[AuditCreditTransfer]    Script Date: 7/15/2021 4:04:45 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AuditCreditTransfer](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[CreditTransferId] [bigint] NULL,
	[UpdatedBy] [bigint] NULL,
	[UpdatedOn] [datetime] NULL,
	[StatusId] [int] NULL,
	[Reason] [nvarchar](1000) NULL,
 CONSTRAINT [PK_AuditCreditTransfer] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[AuditCreditTransfer]  WITH CHECK ADD FOREIGN KEY([CreditTransferId])
REFERENCES [dbo].[CreditTransferDetails] ([Id])
GO


