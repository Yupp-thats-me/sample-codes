USE [SJCreditTransfer]
GO

/****** Object:  Table [dbo].[HeiMaster]    Script Date: 5/18/2021 6:38:27 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[HeiMaster](
	[HeiId] [int] NULL,
	[HeiName] [nvarchar](250) NULL
) ON [PRIMARY]
GO


