USE [SJCreditTransfer]
GO

/****** Object:  Table [dbo].[CreditTransferDetails]    Script Date: 7/15/2021 4:02:30 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CreditTransferDetails](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[AcademicYear] [int] NOT NULL,
	[FromHEI] [int] NOT NULL,
	[ToHEI] [int] NOT NULL,
	[OnBehalfOf] [int] NULL,
	[UploadFile] [nvarchar](max) NULL,
	[ExpiryDate] [datetime] NULL,
	[Active] [bit] NULL,
	[StatusId] [int] NOT NULL,
	[CreatedBy] [nvarchar](200) NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedBy] [nvarchar](200) NULL,
	[UpdatedOn] [datetime] NULL,
	[UploadId] [bigint] NULL,
	[Reason] [nvarchar](50) NULL,
	[DepartmentFromEn] [int] NULL,
	[DepartmentToEn] [int] NULL,
	[DepartmentFromAr] [int] NULL,
	[DepartmentToAr] [int] NULL,
	[MajorFromEn] [int] NULL,
	[MajorToEn] [int] NULL,
	[MajorFromAr] [int] NULL,
	[MajorToAr] [int] NULL,
 CONSTRAINT [PK_CreditTransferDetails] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[CreditTransferDetails]  WITH CHECK ADD FOREIGN KEY([AcademicYear])
REFERENCES [dbo].[AcademicYearMaster] ([AcademicId])
GO

ALTER TABLE [dbo].[CreditTransferDetails]  WITH CHECK ADD FOREIGN KEY([DepartmentFromEn])
REFERENCES [dbo].[DepartmentMaster] ([DepartmentId])
GO

ALTER TABLE [dbo].[CreditTransferDetails]  WITH CHECK ADD FOREIGN KEY([DepartmentToEn])
REFERENCES [dbo].[DepartmentMaster] ([DepartmentId])
GO

ALTER TABLE [dbo].[CreditTransferDetails]  WITH CHECK ADD FOREIGN KEY([DepartmentFromAr])
REFERENCES [dbo].[DepartmentMaster] ([DepartmentId])
GO

ALTER TABLE [dbo].[CreditTransferDetails]  WITH CHECK ADD FOREIGN KEY([DepartmentToAr])
REFERENCES [dbo].[DepartmentMaster] ([DepartmentId])
GO

ALTER TABLE [dbo].[CreditTransferDetails]  WITH CHECK ADD FOREIGN KEY([FromHEI])
REFERENCES [dbo].[HeiMaster] ([HeiId])
GO

ALTER TABLE [dbo].[CreditTransferDetails]  WITH CHECK ADD FOREIGN KEY([MajorFromEn])
REFERENCES [dbo].[MajorMaster] ([MajorId])
GO

ALTER TABLE [dbo].[CreditTransferDetails]  WITH CHECK ADD FOREIGN KEY([MajorToEn])
REFERENCES [dbo].[MajorMaster] ([MajorId])
GO

ALTER TABLE [dbo].[CreditTransferDetails]  WITH CHECK ADD FOREIGN KEY([MajorFromAr])
REFERENCES [dbo].[MajorMaster] ([MajorId])
GO

ALTER TABLE [dbo].[CreditTransferDetails]  WITH CHECK ADD FOREIGN KEY([MajorToAr])
REFERENCES [dbo].[MajorMaster] ([MajorId])
GO

ALTER TABLE [dbo].[CreditTransferDetails]  WITH CHECK ADD FOREIGN KEY([StatusId])
REFERENCES [dbo].[StatusMaster] ([StatusId])
GO

ALTER TABLE [dbo].[CreditTransferDetails]  WITH CHECK ADD FOREIGN KEY([ToHEI])
REFERENCES [dbo].[HeiMaster] ([HeiId])
GO


