USE [SJCreditTransfer]
GO
INSERT INTO StatusMaster
   (StatusName)
 values
   ('Draft' ),                                                                                         
   ('Pending/Approval '),                                                                                 
   ('Approved'),                                                                                           
   ('Rejected ')  

GO