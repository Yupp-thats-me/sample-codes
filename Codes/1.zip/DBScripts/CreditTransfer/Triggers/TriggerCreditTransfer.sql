USE [SJCreditTransfer]
GO

/****** Object:  Trigger [dbo].[TriggerCreditTransfer]    Script Date: 6/1/2021 8:10:04 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER TRIGGER [dbo].[TriggerCreditTransfer]
ON [dbo].[CreditTransferDetails]
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO AuditCreditTransfer(
       CreditTransferId,
	   UpdatedBy,
	   UpdatedOn,
	   Reason,
	   StatusId
    )
    SELECT
        i.Id,
		Isnull(i.UpdatedBy,i.CreatedBy),
		GETUTCDATE() ,
		i.Reason,
		i.StatusId
    FROM
        inserted i
    
END
GO

ALTER TABLE [dbo].[CreditTransferDetails] ENABLE TRIGGER [TriggerCreditTransfer]
GO


