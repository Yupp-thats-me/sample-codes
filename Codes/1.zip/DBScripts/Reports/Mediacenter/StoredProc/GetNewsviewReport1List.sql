USE [SJMediaCenter]
GO

/****** Object:  StoredProcedure [dbo].[GetNewsviewReport1List]    Script Date: 4/20/2022 2:47:06 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [dbo].[GetNewsviewReport1List]


(
@DatePublished Datetime=null,
@DateExpiry Datetime=null,
@CreatedBy int=0,
@Industry int=0,
@Theme NVARCHAR(50)=null
)
 
AS
BEGIN

if @Theme='null'
begin
set @Theme=null
end

DECLARE @Type1 NVARCHAR(50), @Type2 NVARCHAR(50), @Type3 NVARCHAR(50) , @Type4 NVARCHAR(50) ,@Type5 INT , @Type6 INT

SET @Type1=(SELECT TOP 1 TitleEn FROM MediaDetails  WHERE MediaType=3 AND IsActive=1 ORDER BY TotalViews DESC )
SET @Type2=(SELECT TOP 1 TitleAr FROM MediaDetails  WHERE MediaType=3 AND IsActive=1 ORDER BY TotalViews DESC )
SET @Type3=(SELECT TOP 1 TitleEn FROM MediaDetails  WHERE MediaType=3 AND IsActive=1 ORDER BY TotalViews ASC )
SET @Type4=(SELECT TOP 1 TitleAr FROM MediaDetails  WHERE MediaType=3 AND IsActive=1 ORDER BY TotalViews ASC )
SET @Type5=(SELECT count(RequestedRole) From SJIdentity..[User] US 
    JOIN MediaDetails MD WITH(NOLOCK) 
    ON MD.CreatedBy=US.ID
	where MediaType=3)
--SET @Type6=(SELECT count(RequestedRole) From SJIdentity..[User] US 
--    JOIN MediaDetails MD WITH(NOLOCK) 
--    ON MD.CreatedBy=US.ID
--	where RequestedRole=1000 AND MediaType=3)

SET NOCOUNT ON;
SELECT 
MD.Id,
CONCAT(US.FirstName,' ',US.LastName) AS CreatedBy,
TitleEn,
TitleAr,
DateAnnounced AS DatePublished,
ExpiryDate AS DateExpiry,
SourceEn,
SourceAr,
PageLink,
PlaceEn,
PlaceAr,
TotalViews,
LoggedinViews,
@Type1 AS MostViewedNewsEn,
@Type2 AS MostViewedNewsAr,
@Type3 AS LeastViewedNewsEn,
@Type4 AS LeastViewedNewsAr,
@Type5 AS TotalNewsSummary,
US.RequestedRole



FROM MediaDetails MD
JOIN [SJIdentity].[dbo].[User] US WITH(NOLOCK) 
ON US.ID=MD.CreatedBy
LEFT JOIN Industry IND  
ON IND.Id = MD.Industry



WHERE MediaType=3 AND MD.IsActive=1  
AND  MD.CreatedDate Between @DatePublished AND @DateExpiry
  --AND (@DatePublished is null or Convert(date ,DateAnnounced ) = Convert(date,@DatePublished))
  --AND (@DateExpiry is null or Convert(date ,ExpiryDate ) = Convert(date,@DateExpiry))
  AND (@CreatedBy = 0 or US.RequestedRole = @CreatedBy ) 
  AND (@Industry=0 OR MD.Industry=@Industry)
  AND (@theme is null or MD.Theme LIKE @Theme+'%')

ORDER BY (
CASE WHEN MD.UpdatedDate IS NULL THEN MD.CreatedDate ELSE MD.UpdatedDate END
) DESC

END

 
 --exec GetNewsviewReport1List '2021-12-02 00:00:00.000','2022-02-20 00:00:00.000',2000,0,'null'

 --select * from SJMediaCenter..MediaDetails
GO


