﻿USE [SJAcademics]
GO
INSERT INTO EmiratesMaster
      ([EmiratesId]
      ,[EmiratesName]
      ,[arEmiratesName])
Values
   ('Abu','Abu Dhabi',N'أبوظبي'),
   ('Ajm','Ajman',N'عجمان'),
   ('Ala','Al Ain',N'العين'),
   ('Ald','Al Dhafra',N'الظفرة'),
   ('Dub','Dubai',N'دبي'),
   ('Fuj','Fujairah',N'الفجيرة'),
   ('Ras','Ras Al Khaimah',N'رأس الخيمة'),
   ('Sha','Sharjah',N'الشارقة'),
   ('Uaq','Umm Al Quwain',N'أم القيوين')
 GO