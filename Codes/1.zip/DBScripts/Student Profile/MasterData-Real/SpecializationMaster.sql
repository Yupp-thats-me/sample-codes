﻿USE [SJAcademics]
Go
INSERT INTO SpecializationMaster
      ( [SpecializationId]
      ,[SpecializationName]
      ,[ArSpecializationName])
Values
       (1,'Agribusiness',N'الأعمال الزراعية'),
       (2,'Horticulture',N'البستنة'),
       (3,'Marine Fisheries And Animal Sc',N'مصايد الأسماك البحرية والحيوانية'),
       (4,'Veterinary Laboratory',N'مختبر بيطري'),
       (5,'Veterinary Science',N'العلوم البيطرية'),
       (6,'Acting',N'التمثيل'),
       (7,'Applied Foreign Languages',N'اللغات الأجنبية التطبيقية'),
       (8,'Arabic Language',N'اللغة العربية'),
	   (9,'Archaeology',N'علم الآثار'),
	   (10,'Art & Design',N'دراسات فنية'),
	   (11,'Cultural Conservation',N'الحفاظ على الثقافة'),
	   (12,'Dance',N'الرقص'),
	   (13,'Dramatic Writing',N'الكتابة الدرامية'),
	   (14,'English Language',N'اللغة الانجليزية'),
	   (15,'English Language & Literature',N'اللغة الإنجليزية وآدابها'),
	   (16,'Fashion Design',N'تصميم الأزياء'),
	   (17,'Film and video production',N'إنتاج الأفلام والفيديو'),
	   (18,'General Arts',N'الفنون العامة'),
	   (19,'Graphic Design & Multimedia',N'التصميم الجرافيكي والوسائط المتعددة'),
	   (20,'History',N'تاريخ'),
	   (21,'History of Art',N'تاريخ الفن'),
	   (22,'Interior Architecture & Design',N'العمارة الداخلية والتصميم'),
	   (23,'Islamic Studies',N'الدراسات الإسلامية'),
	   (24,'Japanese Language',N'اللغة اليابانية'),
	   (25,'Liberal Arts',N'الفنون الليبرالية'),
	   (26,'Linguistics',N'اللغويات'),
	   (27,'Multimedia Design',N'تصميم الوسائط المتعددة'),
	   (28,'Music',N'موسيقى'),
	   (29,'Philosophy',N'فلسفة'),
	   (30,'Product Design',N'تصميم المنتج'),
	   (31,'Radio & Television',N'راديو وتلفزيون'),
	   (32,'Sign Language',N'لغة الإشارة'),
	   (33,'Spanish',N'الأسبانية'),
	   (34,'Theatre',N'مسرح'),
	   (35,'Translation Studies',N'دراسات الترجمة'),
	   (36,'Accounting',N'محاسبة'),
	   (37,'Accounting & Finance',N'المحاسبة والمالية'),
	   (38,'Advertising',N'دعاية'),
	   (39,'Air and Space Law',N'قانون الجو والفضاء'),
	   (40,'Banking',N'الخدمات المصرفية'),
	   (41,'Business',N'عمل'),
	   (42,'Business Administration',N'إدارة الأعمال'),
	   (43,'Business Analytics',N'تحليل الأعمال'),
	   (44,'Business Management',N'ادارة اعمال'), 
	   (45,'Criminal Justice',N'العدالة الجنائية'),
	   (46,'Criminal Science',N'العلم الجريمه'),
	   (47,'Design Management',N'إدارة التصميم')
	   (48,'Dispute Resolution',N'حل النزاعات'),
	   (49,'E-Business',N'الأعمال الإلكترونية'),
	   (50,'ENGINEERING MANAGEMENT',N'الإدارة الهندسية')

GO