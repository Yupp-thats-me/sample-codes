
USE [SJAcademics]
GO
INSERT INTO [InstituteNameMaster]
       ([Institute])
VALUES
      ('Abu Dhabi University'),
	  ('Al Ain University'),
	  ('Emirates Diplomatic Academy'),
	  ('Emirates Institute For Banking And Financial Studies'),
	  ('Emirates Institute For Citizenship And Residence'),
	  ('European International College'),
	  ('Higher Colleges of Technology'),
	  ('Khalifa University of Science and Technology'),
	  ('National Defense College')
GO