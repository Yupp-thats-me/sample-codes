﻿USE [SJAcademics]
GO
INSERT INTO MajorMaster
      ([MajorId]
      ,[MajorName]
      ,[ArMajorName])
VALUES
   
  (1,'Agriculture, Forestry, Fisheries & Veterinary',N'الزراعة والغابات ومصايد الأسماك والطب البيطري'),
  (2,'Arts & Humanities',N'الآداب والعلوم الإنسانية'),
  (3,'Business, Administration and Law',N'الأعمال والإدارة والقانون'),
  (4,'Education',N'تعليم'),
  (5,'Engineering, Manufacturing & Construction',N'الهندسة والتصنيع والبناء'),
  (6,'Health & Welfare',N'الصحة والرفاهية'),
  (7,'Natural Sciences, Mathematics & Statistics',N''),  
  (8,'Health & Welfare',N'الصحة والرفاهية'),
  (9,'Information and Communication Technologies',N'تكنولوجيا المعلومات والاتصالات'),
  (10,'Natural Sciences, Mathematics & Statistics',N'العلوم الطبيعية والرياضيات والإحصاء'),
  (11,'Services',N'خدمات'),
  (12,'Social Sciences, Journalism & Information',N'العلوم الاجتماعية والصحافة والمعلومات')
  
  
  
 GO
