USE [SJAcademics]
GO
INSERT INTO DocumentTypesMaster 
     (DocumentTypeName)
Values
      ('Resume'),
      ('Cover Letters'),
      ('Others')
GO



