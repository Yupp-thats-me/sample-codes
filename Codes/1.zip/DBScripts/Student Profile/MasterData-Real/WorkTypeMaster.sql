﻿
  USE [SJAcademics]
  GO
  INSERT INTO WorkTypeMaster
      ( [WorkTypeId],
	    [WorkType]
      , [ArWorkType])
Values
     (1,'Internships',N'التدريب'),
	 (2,'Professional Experience',N'الخبرة العملية'),
	 (3,'Work Placement',N'مكان العمل')

GO