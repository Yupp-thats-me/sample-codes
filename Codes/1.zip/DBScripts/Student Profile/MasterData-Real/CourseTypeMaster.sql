﻿USE [SJAcademics]
GO
Insert into [CourseTypeMaster]
            ([CourseTypeName]
             ,[arCourseTypeName])
Values

       (1,'Full Time',N'وقت كامل'),
	   (2,'Part Time',N'دوام جزئى')
GO