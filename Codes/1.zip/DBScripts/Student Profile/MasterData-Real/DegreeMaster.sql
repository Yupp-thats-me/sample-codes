﻿USE [SJAcademics]
GO
INSERT INTO DegreeMaster
   (DegreeName,
   ArDegreeName)
Values
   ('Ph.D',N'دكتوراه'),
   ('Master',N'سادة'),
   ('Bachelor',N'البكالوريوس'),
   ('Vocational Education',N'التعليم المهني'),
   ('High School (12th Grade)',N'المدرسة الثانوية'),
   ('School (10th Grade)',N'المدرسة')
GO