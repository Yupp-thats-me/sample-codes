USE [SJAcademics]
GO

/****** Object:  StoredProcedure [dbo].[DeleteWorkExperience]    Script Date: 18-05-2021 15:24:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[DeleteWorkExperience]

@Id					BIGINT NULL

AS 
BEGIN
	SET NOCOUNT ON;
      BEGIN

         DELETE FROM WorkExperience
         WHERE
            [Id] = @Id 
      END
END


-- EXEC  [DeleteWorkExperience]
GO


