USE [SJAcademics]
GO

/****** Object:  StoredProcedure [dbo].[DeleteAccomplishmentDetails]    Script Date: 18-05-2021 15:13:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[DeleteAccomplishmentDetails]

@Id					BIGINT NULL

AS 
BEGIN
	SET NOCOUNT ON;
      BEGIN

         DELETE FROM AccomplishmentDetails
         WHERE
            [Id] = @Id 
      END
END


-- EXEC  [DeleteAccomplishmentDetails] 
GO


