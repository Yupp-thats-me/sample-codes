USE [SJAcademics]
GO

/****** Object:  StoredProcedure [dbo].[SaveDegreeDetails]    Script Date: 1/5/2022 3:41:44 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[SaveDegreeDetails]
(
@ReferenceId        BIGINT NULL OUTPUT,
@StudentId			BIGINT NULL ,
@Id					BIGINT NULL,
@DegreeId			NVARCHAR(5),
@MajorId		    NVARCHAR(100)=NULL,
@CompletionYear		DATETIME= NULL,
@CourseTypeId		NVARCHAR(5)= NULL,
@SpecializationId   NVARCHAR (5)=NULL,
@Institute			NVARCHAR (250),
@GPA				NVARCHAR(20) = NULL,
@Percentage         NVARCHAR(20)= NULL,
@Created_By			NVARCHAR(128),
@Created_Date		DATETIME = NULL,
@Updated_By			NVARCHAR(128), 
@Updated_Date		DATETIME= NULL,
@CourseNameEn       NVARCHAR(50) = NULL,
@CourseNameAr       NVARCHAR(50) = NULL
)
AS 
BEGIN
  -- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE 
	@InstituteId int

	SELECT @InstituteId=InstituteId FROM InstituteNameMaster WHERE Institute=@Institute
	if(@Percentage = 'NULL')
		set @Percentage = null
	If(@GPA = 'NULL')
		set @GPA = null
   IF(ISNULL(@Id, 0) = 0) 
   BEGIN
      INSERT INTO
         [dbo].[DegreeDetails] ( 
		 [StudentId]
		,[DegreeId]
		,[MajorId]
		,[SpecializationId]
		,[CompletionYear]
		,[CourseTypeId]
		,[Institute]
		,[GPA]
		,[Percentage]
		,[CreatedBy]
		,[CreatedDate] 
		,CourseNameEn
		,CourseNameAr) 
      VALUES
         (
		   @StudentId,
           @DegreeId,
		   CASE WHEN @MajorId = 0 THEN NULL
		   ELSE @MajorId
		   END,
		   CASE WHEN @SpecializationId = 0 THEN NULL
		   ELSE @SpecializationId
		   END,
		   @CompletionYear,
		   CASE WHEN @CourseTypeId=0 THEN NULL
		   ELSE	@CourseTypeId
		   END,
		   @InstituteId,
		   (select CONVERT (decimal(10,2),@GPA)),
		   (select CONVERT (decimal(10,2),@Percentage)),
		   @Created_By , 
		   GETUTCDATE() ,
		   @CourseNameEn,
		   @CourseNameAr
			
			--1, 1 , 
			
         )
		 SET @ReferenceId = SCOPE_IDENTITY();
   END
   ELSE
      BEGIN
         UPDATE
            [dbo].[DegreeDetails] 
         SET
			[StudentId]=@StudentId,
			[DegreeId]=@DegreeId,
			[MajorId]=CASE WHEN @MajorId = 0 THEN NULL
		   ELSE @MajorId
		   END,
			[SpecializationId]= CASE WHEN @SpecializationId = 0 THEN NULL
		   ELSE @SpecializationId
		   END,
			[CompletionYear]=@CompletionYear,
			[CourseTypeId]=
			CASE WHEN @CourseTypeId=0 THEN NULL
		    ELSE @CourseTypeId
		    END,
			[Institute]=@InstituteId,
			[GPA]=(select CONVERT (decimal(10,2),@GPA)),
			[Percentage]=(select CONVERT (decimal(10,2),@Percentage)),
			--[RecordVersion] = [RecordVersion] + 1 , 
			[UpdatedBy] = @Updated_By , 
			[UpdatedDate] = GETUTCDATE() ,
			CourseNameEn=@CourseNameEn,
			CourseNameAr=@CourseNameAr
			
         WHERE
            [Id] = @Id 

			SET @ReferenceId =@Id
      END
END
GO


