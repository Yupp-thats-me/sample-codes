USE [SJAcademics]
GO

/****** Object:  StoredProcedure [dbo].[SaveInstituteNameMaster]    Script Date: 18-05-2021 16:51:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[SaveInstituteNameMaster]


@Institute	        NVARCHAR(250),
@Created_By			NVARCHAR(128)=null,
@Created_Date		DATETIME=null,
@Updated_By			NVARCHAR(128)=null, 
@Updated_Date		DATETIME=null

AS 
BEGIN
  -- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   BEGIN
      INSERT INTO
        [dbo].InstituteNameMaster( 
		[Institute]
		--,[CreatedBy]
		--,[CreatedDate]
		) 
      VALUES
         (
		  @Institute
		  --,@Created_By
		  --,GETUTCDATE() 
			--1, 1 , 
         )
   END
END


--
GO


