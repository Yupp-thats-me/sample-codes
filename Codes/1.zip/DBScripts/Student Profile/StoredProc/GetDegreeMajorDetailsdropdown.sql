USE [SJAcademics]
GO

/****** Object:  StoredProcedure [dbo].[GetDegreeMajorDetailsdropdown]    Script Date: 1/5/2022 3:39:12 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[GetDegreeMajorDetailsdropdown]
AS
BEGIN
	SELECT  
	 MajorId,
	 MajorName,
	 ArMajorName,
	 DegreeId 
	
	FROM MajorMaster  with (nolock)
	

END
GO


