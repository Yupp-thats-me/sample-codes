USE [SJAcademics]
GO

/****** Object:  StoredProcedure [dbo].[GetVolunteeringDetail]    Script Date: 18-05-2021 15:41:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[GetVolunteeringDetail]
	@StudentId BIGINT
AS
BEGIN
	SELECT  [Id]
      ,[StudentId]
      ,[Organization]
      ,[DateOfEvent]
      ,[NameOfEvent]
      ,[Description]
      ,[Hrs]
      ,[CreatedBy]
      ,[CreatedDate]
      ,[UpdatedBy]
      ,[UpdatedDate]
  FROM [SJAcademics].[dbo].[VolunteeringDetails] WITH(NOLOCK)
  WHERE	StudentId=@StudentId
  ORDER BY (
	CASE WHEN UpdatedDate IS NULL THEN CreatedDate ELSE UpdatedDate END
	) DESC

END
GO


