USE [SJAcademics]
GO
/****** Object:  StoredProcedure [dbo].[GetWorkTypeMaster]    Script Date: 30-05-2021 13:10:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetWorkTypeMaster]
AS
BEGIN
	SELECT  [WorkTypeId]
           ,[WorkType]
		   ,[ArWorkType]
  FROM [SJAcademics].[dbo].[WorkTypeMaster] WITH(NOLOCK)

END
