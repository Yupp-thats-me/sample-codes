USE [SJAcademics]
GO

/****** Object:  StoredProcedure [dbo].[GetVolunteeringDetails]    Script Date: 18-05-2021 15:42:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[GetVolunteeringDetails]
	
AS
BEGIN
	SELECT  [Id]
      ,[StudentId]
      ,[Organization]
      ,[DateOfEvent]
      ,[NameOfEvent]
      ,[Description]
      ,[Hrs]
      ,[CreatedBy]
      ,[CreatedDate]
      ,[UpdatedBy]
      ,[UpdatedDate]
  FROM [SJAcademics].[dbo].[VolunteeringDetails] WITH(NOLOCK)
  ORDER BY (
	CASE WHEN UpdatedDate IS NULL THEN CreatedDate ELSE UpdatedDate END
	) DESC

  

END
GO


