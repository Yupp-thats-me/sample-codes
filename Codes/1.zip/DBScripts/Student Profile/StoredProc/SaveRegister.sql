USE [SJAcademics]
GO

/****** Object:  StoredProcedure [dbo].[SaveRegister]    Script Date: 18-05-2021 16:54:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[SaveRegister]
(
	@FirstName NVARCHAR(50),
	@LastName NVARCHAR(50),
	@Email NVARCHAR(50),
	@Password NVARCHAR(50),
	@Id BIGINT OUT
)
AS
BEGIN
	SELECT 8

	  -- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF(ISNULL(@Id,0)=0)
	BEGIN
		INSERT INTO dbo.Register (
			FirstName,
			LastName,Email,
			Password
		)
		VALUES
		(
			@FirstName,
			@LastName,
			@Email,
			@Password
		)

		SET @Id=SCOPE_IDENTITY();

	END
	ELSE
	BEGIN
		UPDATE dbo.Register
		SET FirstName=@FirstName,
			LastName=@LastName,
			Email=@Email,
			Password=@Password
		WHERE Id=@Id

		
	END
END
GO


