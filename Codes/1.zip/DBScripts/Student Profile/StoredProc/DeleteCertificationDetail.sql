USE [SJAcademics]
GO

/****** Object:  StoredProcedure [dbo].[DeleteCertificationDetail]    Script Date: 18-05-2021 15:15:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[DeleteCertificationDetail]

@Id					BIGINT NULL

AS 
BEGIN
	SET NOCOUNT ON;
      BEGIN

         DELETE FROM CertificationDetails
         WHERE
            [Id] = @Id ;
      END
END


-- EXEC  [DeleteDegreeDetails]
GO


