USE [SJAcademics]
GO

/****** Object:  StoredProcedure [dbo].[GetMajorSpecializationdropdown]    Script Date: 1/5/2022 3:40:12 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[GetMajorSpecializationdropdown]
AS
BEGIN
	SELECT	MajorId,
	        SpecializationId,
			SpecializationName,
			ArSpecializationName
	FROM	[SJAcademics].[dbo].[SpecializationMaster]  with (nolock)
	
END




GO


