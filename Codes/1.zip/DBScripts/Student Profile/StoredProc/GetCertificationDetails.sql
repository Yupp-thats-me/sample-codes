USE [SJAcademics]
GO

/****** Object:  StoredProcedure [dbo].[GetCertificationDetails]    Script Date: 18-05-2021 15:25:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[GetCertificationDetails]
	
AS
BEGIN
	SET NOCOUNT ON;


	SELECT	Id,
			StudentId,
			CertificationName,
			--(ISNULL(CompletedMonth,'Not')) AS CompletedMonth,
			--(ISNULL(completedYear,'Applicable')) AS completedYear,			
			completedYear,
			IssuingAuthority,
			INM.[Institute] as Institute,
			NotExpire 
	FROM	SJAcademics.dbo.CertificationDetails CD WITH(NOLOCK)
	JOIN   InstituteNameMaster INM
	ON INM.InstituteId=CD.Institute
	  ORDER BY (
	CASE WHEN UpdatedDate IS NULL THEN CreatedDate ELSE UpdatedDate END
	) DESC
		  

END
GO


