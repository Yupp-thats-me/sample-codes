USE [SJAcademics]
GO

/****** Object:  StoredProcedure [dbo].[SaveSkillMaster]    Script Date: 18-05-2021 16:58:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[SaveSkillMaster]


@SkillName			NVARCHAR(100),
@Created_By			NVARCHAR(128)=null,
@Created_Date		DATETIME=null,
@Updated_By			NVARCHAR(128)=null, 
@Updated_Date		DATETIME=null

AS 
BEGIN
  -- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

   BEGIN
      INSERT INTO
        [dbo].SkillMaster( 
		[SkillName]
		--,[CreatedBy]
		--,[CreatedDate]
		) 
      VALUES
         (
		  @SkillName
		  --,@Created_By
		  --,GETUTCDATE() 
			--1, 1 , 
         )
   END
END


--
GO


