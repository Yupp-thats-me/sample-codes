USE [SJAcademics]
GO

/****** Object:  StoredProcedure [dbo].[DeleteDegreeDetails]    Script Date: 18-05-2021 15:19:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[DeleteDegreeDetails]

@Id					BIGINT NULL

AS 
BEGIN
	SET NOCOUNT ON;
      BEGIN

         DELETE FROM DegreeDetails
         WHERE
            [Id] = @Id ;
      END
END


-- EXEC  [DeleteDegreeDetails]
GO


