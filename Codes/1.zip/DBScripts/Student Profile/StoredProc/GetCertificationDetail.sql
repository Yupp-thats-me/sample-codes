USE [SJAcademics]
GO

/****** Object:  StoredProcedure [dbo].[GetCertificationDetail]    Script Date: 18-05-2021 15:25:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[GetCertificationDetail]
	@StudentId BIGINT
AS
BEGIN
	SET NOCOUNT ON;


	SELECT	Id,
			StudentId,
			CertificationName,
			completedYear,
			IssuingAuthority,
			INM.[Institute] as Institute,
			NotExpire 
	FROM	SJAcademics.dbo.CertificationDetails CD WITH(NOLOCK)
	JOIN   InstituteNameMaster INM
	ON INM.InstituteId=CD.Institute
	WHERE	StudentId=@StudentId
	ORDER BY (
	CASE WHEN UpdatedDate IS NULL THEN CreatedDate ELSE UpdatedDate END
	) DESC
	  

END
GO


