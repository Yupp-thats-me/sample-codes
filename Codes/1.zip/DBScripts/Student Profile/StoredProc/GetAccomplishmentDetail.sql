USE [SJAcademics]
GO

/****** Object:  StoredProcedure [dbo].[GetAccomplishmentDetail]    Script Date: 18-05-2021 15:24:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

  
CREATE OR ALTER PROCEDURE [dbo].[GetAccomplishmentDetail]  
   
 @Id BIGINT =null,  
 @StudentId BIGINT =null,  
 @AccomplishmentId BIGINT = NULL,  
 @StartDate datetime =null,  
 @EndDate datetime = null  
AS  
BEGIN  
 SET NOCOUNT ON;  
  
  
 SELECT  [Id]  
      ,[StudentId]  
      ,[AccomplishmentId]  
      ,[TiTle]  
      ,[Description]  
      ,[StartDate]  
      ,[EndDate]
      ,[URLLink]  
      ,[IsWorkingOn]  
      ,[Publisher]  
      ,[TestScore]  
      ,[CreatedBy]  
      ,[CreatedDate]  
      ,[UpdatedBy]  
      ,[UpdatedDate]  
  FROM [SJAcademics].[dbo].[AccomplishmentDetails] WITH(NOLOCK)  
 WHERE   
 (@StudentId = 0 OR StudentId=@StudentId) AND  
 (@AccomplishmentId = 0 OR AccomplishmentId=@AccomplishmentId) AND  
 (@StartDate IS NULL OR StartDate>=@StartDate) AND  
 (@EndDate IS NULL OR EndDate<=@EndDate) AND  
 (@Id  = 0 OR Id=@Id) 
   ORDER BY (
  CASE WHEN UpdatedDate IS NULL THEN CreatedDate ELSE UpdatedDate END
  ) DESC

  
     
  
END  

--exec [GetAccomplishmentDetail] @StudentId=124 ,@AccomplishmentId=5,@Id=0

GO


