USE [SJAcademics]
GO

/****** Object:  StoredProcedure [dbo].[SaveSkillDetails]    Script Date: 18-05-2021 16:55:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[SaveSkillDetails]

@ReferenceId		BIGINT NULL OUTPUT ,
@StudentId			BIGINT NULL ,
@Id					BIGINT NULL,
@SkillName			NVARCHAR(200),
--@Experience			NVARCHAR(100),
@ExpInYears         DECIMAL(5,2),
--@ExpInMonths        INT,
@SelfRating			INT,
@Created_By			NVARCHAR(128),
@Created_Date		DATETIME=null,
@Updated_By			NVARCHAR(128), 
@Updated_Date		DATETIME=null

AS 
BEGIN
  -- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE 
	@SkillId int

	SELECT @SkillId=SkillId FROM SkillMaster WHERE SkillName=@SkillName

   IF(ISNULL(@Id, 0) = 0) 
   BEGIN
      INSERT INTO
        [dbo].[SkillDetails] ( 
		 [StudentId]
		,[SkillName]
		--,[Experience]
		,[ExperienceInYear]
		--,[ExperienceInMonth]
		,[SelfRating]
		,[CreatedBy]
		,[CreatedDate] ) 
      VALUES
         (
		   @StudentId
		  ,@SkillId
		  --,@Experience
		  ,@ExpInYears
		  --,@ExpInMonths
		  ,@SelfRating
		  ,@Created_By
		  ,GETUTCDATE() 
			--1, 1 , 
			
         )
		 SET @ReferenceId = SCOPE_IDENTITY();
   END
   ELSE
      BEGIN
         UPDATE
            [dbo].[SkillDetails] 
         SET
			[StudentId]=@StudentId,
			[SkillName]=@SkillId,
			--[Experience]=@Experience,
			[ExperienceInYear]=@ExpInYears,
			--[ExperienceInMonth]=@ExpInMonths,
			[SelfRating]=@SelfRating,
			--[RecordVersion] = [RecordVersion] + 1 , 
			[UpdatedBy] = @Updated_By , 
			[UpdatedDate] = GETUTCDATE() 
         WHERE
            [Id] = @Id 

			SET @ReferenceId =@Id
      END
END


--
GO


