USE [SJAcademics]
GO

/****** Object:  StoredProcedure [dbo].[GetDegreeDetails]    Script Date: 1/5/2022 3:38:06 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE   PROCEDURE [dbo].[GetDegreeDetails]
AS
BEGIN
	SELECT DD.Id
      ,[StudentId]
      ,DD.DegreeId as DegreeId
	  ,DM.DegreeName as DegreeName
	  ,DM.ArDegreeName as ArDegreeName
      ,[CompletionYear]
      ,[CourseTypeId]
	  ,DD.CourseNameEn as CourseTypeIdName
	  ,DD.CourseNameAr as arCourseTypeName	  
	  ,DD.MajorId  as MajorId
	  ,MM.MajorName as MajorName  
	  ,MM.ArMajorName as ArMajorName
	  ,DD.SpecializationId as SpecializationId
	  ,SM.SpecializationName as SpecializationName
	  ,SM.ArSpecializationName as ArSpecializationName
      ,INM.[Institute] as Institute
      ,convert(NVARCHAR , [GPA]) as GPA
	  ,convert (NVARCHAR , [Percentage]) as Percentage
      ,[CreatedBy]
      ,[CreatedDate]
      ,[UpdatedBy]
      ,[UpdatedDate]
	 

  FROM [DegreeDetails] DD WITH (NOLOCK)
  join DegreeMaster DM WITH (NOLOCK)
  ON DD.DegreeId = DM.DegreeId
  join MajorMaster MM WITH (NOLOCK)
  ON DD.MajorId = MM.MajorId
  JOIN SpecializationMaster SM WITH (NOLOCK)
  ON DD.SpecializationId = SM.SpecializationId
 JOIN   InstituteNameMaster INM WITH (NOLOCK)
	ON INM.InstituteId=DD.Institute
	 ORDER BY (
		CASE WHEN UpdatedDate IS NULL THEN CreatedDate ELSE UpdatedDate END
	 ) DESC
END
GO


