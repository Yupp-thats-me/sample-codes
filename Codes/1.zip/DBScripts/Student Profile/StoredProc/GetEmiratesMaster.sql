USE [SJAcademics]
GO

/****** Object:  StoredProcedure [dbo].[GetEmiratesMaster]    Script Date: 18-05-2021 15:31:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[GetEmiratesMaster]
AS
BEGIN
	SELECT  [EmiratesId]
           ,[EmiratesName]
		   ,[arEmiratesName]
  FROM [SJAcademics].[dbo].[EmiratesMaster] WITH(NOLOCK)

END
GO


