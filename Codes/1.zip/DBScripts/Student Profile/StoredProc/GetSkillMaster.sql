USE [SJAcademics]
GO

/****** Object:  StoredProcedure [dbo].[GetSkillMaster]    Script Date: 18-05-2021 15:34:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[GetSkillMaster]
AS
BEGIN
		SELECT  
				--SkillId,
				SkillName
				--arSkillName
		FROM	SkillMaster WITH(NOLOCK)
END
GO


