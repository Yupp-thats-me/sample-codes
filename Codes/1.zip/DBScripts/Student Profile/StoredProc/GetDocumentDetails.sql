USE [SJAcademics]
GO

/****** Object:  StoredProcedure [dbo].[GetDocumentDetails]    Script Date: 18-05-2021 15:29:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[GetDocumentDetails] 
	-- Add the parameters for the stored procedure here
	@StudentId BIGINT = NULL,
	@Id BIGINT = NULL,
	@DocumentTypeId INT = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT DD.Id,
			[StudentId],
			[DocumentTypeId],
			[Title],
			[FileName],
			[FileSaveName],
			[CreatedBy],
			[CreatedDate],
			[UpdatedBy],
			[UpdatedDate],
			DT.DocumentTypeName
			FROM DocumentDetails DD
			INNER JOIN DocumentTypesMaster DT on DD.DocumentTypeId = DT.Id
			WHERE
			((ISNULL(@Id, 0) = 0 ) OR @Id = DD.Id)
			AND ((ISNULL(@StudentId, 0) = 0 ) OR @StudentId = StudentId)
			AND ((ISNULL(@DocumentTypeId, 0) = 0 ) OR @DocumentTypeId = DD.DocumentTypeId)
			ORDER BY (
			CASE WHEN UpdatedDate IS NULL THEN CreatedDate ELSE UpdatedDate END
			) DESC
END

--exec GetDocumentDetails 
GO


