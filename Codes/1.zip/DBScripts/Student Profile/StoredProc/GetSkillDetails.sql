USE [SJAcademics]
GO

/****** Object:  StoredProcedure [dbo].[GetSkillDetails]    Script Date: 18-05-2021 15:34:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE OR ALTER PROCEDURE [dbo].[GetSkillDetails]
	
AS
BEGIN
	SET NOCOUNT ON;


	SELECT  [Id]
      ,[StudentId]
      ,SM.[SkillName]
      ,CONCAT(( LEFT([ExperienceInYear],CHARINDEX('.',[ExperienceInYear])-1) )+' Year ',(RIGHT([ExperienceInYear], LEN([ExperienceInYear])-CHARINDEX('.', [ExperienceInYear])) )+' Months')  as [Experience]
	  ,[ExperienceInYear]
	  --,[ExperienceInMonth]
      ,[SelfRating]
      ,SD.[CreatedBy]
      ,SD.[CreatedDate]
      ,SD.[UpdatedBy]
      ,SD.[UpdatedDate]
	FROM [SJAcademics].[dbo].[SkillDetails] SD 
	JOIN SkillMaster SM
	ON SM.SkillId=SD.SkillName
	ORDER BY (
	CASE WHEN SD.UpdatedDate IS NULL THEN SD.CreatedDate ELSE SD.UpdatedDate END
	) DESC
		  

END
GO


