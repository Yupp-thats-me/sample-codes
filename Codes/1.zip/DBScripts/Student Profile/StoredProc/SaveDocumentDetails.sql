USE [SJAcademics]
GO

/****** Object:  StoredProcedure [dbo].[SaveDocumentDetails]    Script Date: 18-05-2021 16:50:15 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[SaveDocumentDetails]
	-- Add the parameters for the stored procedure here
	@ReferenceId        BIGINT NULL OUTPUT,
	@StudentId			BIGINT NULL ,
	@Id					BIGINT NULL,
	@Title				NVARCHAR(300)= NULL,
	@DocumentTypeId		INT NULL,
	@FileName			NVARCHAR(128),
	@Created_By			NVARCHAR(128),
	@Created_Date		DATETIME = NULL,
	@Updated_By			NVARCHAR(128), 
	@Updated_Date		DATETIME = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF(ISNULL(@Id, 0) = 0) 
   BEGIN
      INSERT INTO
        [dbo].[DocumentDetails] ( 
		 StudentId
		 ,Title
		 ,DocumentTypeId,
		 [FileName],
		 [CreatedBy],
		 [CreatedDate] ) 
      VALUES
         (
			@StudentId
		   ,@Title
		   ,@DocumentTypeId
		   ,@FileName,
			@Created_By , 
		   GETUTCDATE() 
			--1, 1 , 
			
         )
		 SET @ReferenceId = SCOPE_IDENTITY();
   END
   ELSE
      BEGIN
         UPDATE
            [dbo].[DocumentDetails] 
         SET
		    [StudentId] = @StudentId,
			[Title] = @Title,
			[DocumentTypeId] = @DocumentTypeId,
		    [FileName] = @FileName,
			--[RecordVersion] = [RecordVersion] + 1 , 
			[UpdatedBy] = @Updated_By, 
			[UpdatedDate] = GETUTCDATE() 
         WHERE
            [Id] = @Id 

			SET @ReferenceId = @Id
      END
END
GO


