USE [SJAcademics]
GO

/****** Object:  Table [dbo].[DegreeDetails]    Script Date: 1/5/2022 1:17:49 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DegreeDetails](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[StudentId] [bigint] NOT NULL,
	[DegreeId] [int] NOT NULL,
	[CompletionYear] [datetime] NULL,
	[CourseTypeId] [int] NULL,
	[Institute] [int] NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[UpdatedBy] [nvarchar](100) NULL,
	[UpdatedDate] [datetime] NULL,
	[MajorId] [int] NULL,
	[SpecializationId] [int] NULL,
	[Percentage] [decimal](10, 2) NULL,
	[GPA] [decimal](10, 2) NULL,
	[CourseNameEn] [nvarchar](50) NULL,
	[CourseNameAr] [nvarchar](50) NULL,
 CONSTRAINT [PK_DegreeDetailId] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[DegreeDetails]  WITH CHECK ADD FOREIGN KEY([MajorId])
REFERENCES [dbo].[MajorMaster] ([MajorId])
GO

ALTER TABLE [dbo].[DegreeDetails]  WITH CHECK ADD  CONSTRAINT [FK_CourseTypeId] FOREIGN KEY([CourseTypeId])
REFERENCES [dbo].[CourseTypeMaster] ([Id])
GO

ALTER TABLE [dbo].[DegreeDetails] CHECK CONSTRAINT [FK_CourseTypeId]
GO

ALTER TABLE [dbo].[DegreeDetails]  WITH CHECK ADD  CONSTRAINT [FK_DegreeId] FOREIGN KEY([DegreeId])
REFERENCES [dbo].[DegreeMaster] ([DegreeId])
GO

ALTER TABLE [dbo].[DegreeDetails] CHECK CONSTRAINT [FK_DegreeId]
GO

ALTER TABLE [dbo].[DegreeDetails]  WITH CHECK ADD  CONSTRAINT [FK_InstituteId] FOREIGN KEY([Institute])
REFERENCES [dbo].[InstituteNameMaster] ([InstituteId])
GO

ALTER TABLE [dbo].[DegreeDetails] CHECK CONSTRAINT [FK_InstituteId]
GO

ALTER TABLE [dbo].[DegreeDetails]  WITH CHECK ADD  CONSTRAINT [FK_SpecializationId] FOREIGN KEY([SpecializationId])
REFERENCES [dbo].[SpecializationMaster] ([SpecializationId])
GO

ALTER TABLE [dbo].[DegreeDetails] CHECK CONSTRAINT [FK_SpecializationId]
GO


