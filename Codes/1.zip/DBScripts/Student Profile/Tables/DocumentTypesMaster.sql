USE [SJAcademics]
GO

/****** Object:  Table [dbo].[DocumentTypesMaster]    Script Date: 20-05-2021 18:51:05 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DocumentTypesMaster]') AND type in (N'U'))
DROP TABLE [dbo].[DocumentTypesMaster]
GO

/****** Object:  Table [dbo].[DocumentTypesMaster]    Script Date: 20-05-2021 18:51:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DocumentTypesMaster](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DocumentTypeName] [nvarchar](300) NULL,
 CONSTRAINT [PK_DocumentTypes] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


