USE [SJAcademics]
GO

ALTER TABLE [dbo].[DocumentDetails] DROP CONSTRAINT [FK_DocumentDetails_StudentPersonalDetails]
GO

ALTER TABLE [dbo].[DocumentDetails] DROP CONSTRAINT [FK_DocumentDetails_DocumentTypes]
GO

/****** Object:  Table [dbo].[DocumentDetails]    Script Date: 20-05-2021 18:50:09 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DocumentDetails]') AND type in (N'U'))
DROP TABLE [dbo].[DocumentDetails]
GO

/****** Object:  Table [dbo].[DocumentDetails]    Script Date: 20-05-2021 18:50:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DocumentDetails](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[StudentId] [bigint] NOT NULL,
	[Title] [nvarchar](500) NOT NULL,
	[DocumentTypeId] [int] NOT NULL,
	[FileName] [nvarchar](300) NULL,
	[FileSaveName] [nvarchar](300) NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[UpdatedBy] [nvarchar](100) NULL,
	[UpdatedDate] [datetime] NULL,
 CONSTRAINT [PK_DocumentDetails] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[DocumentDetails]  WITH CHECK ADD  CONSTRAINT [FK_DocumentDetails_DocumentTypes] FOREIGN KEY([DocumentTypeId])
REFERENCES [dbo].[DocumentTypesMaster] ([Id])
GO

ALTER TABLE [dbo].[DocumentDetails] CHECK CONSTRAINT [FK_DocumentDetails_DocumentTypes]
GO

ALTER TABLE [dbo].[DocumentDetails]  WITH CHECK ADD  CONSTRAINT [FK_DocumentDetails_StudentPersonalDetails] FOREIGN KEY([StudentId])
REFERENCES [dbo].[StudentPersonalDetails] ([Id])
GO

ALTER TABLE [dbo].[DocumentDetails] CHECK CONSTRAINT [FK_DocumentDetails_StudentPersonalDetails]
GO


