USE [SJAcademics]
GO

/****** Object:  Table [dbo].[EmiratesMaster]    Script Date: 20-05-2021 18:53:44 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EmiratesMaster]') AND type in (N'U'))
DROP TABLE [dbo].[EmiratesMaster]
GO

/****** Object:  Table [dbo].[EmiratesMaster]    Script Date: 20-05-2021 18:53:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[EmiratesMaster](
	[EmiratesId] [varchar](255) NOT NULL,
	[EmiratesName] [varchar](500) NULL,
	[arEmiratesName] [nvarchar](250) NULL,
PRIMARY KEY CLUSTERED 
(
	[EmiratesId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


