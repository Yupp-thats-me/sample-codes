USE [SJAcademics]
GO

/****** Object:  Table [dbo].[WorkTypeMaster]    Script Date: 30-05-2021 12:47:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[WorkTypeMaster](
	[WorkTypeId] [int] NOT NULL,
	[WorkType] [nvarchar](100) NULL,
	[ArWorkType] [nvarchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[WorkTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


