USE [SJAcademics]
GO

ALTER TABLE [dbo].[CertificationDetails] DROP CONSTRAINT [FK_InstituteCerId]
GO

ALTER TABLE [dbo].[CertificationDetails] DROP CONSTRAINT [FK_CertificationStudentId]
GO

/****** Object:  Table [dbo].[CertificationDetails]    Script Date: 20-05-2021 18:47:38 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[CertificationDetails]') AND type in (N'U'))
DROP TABLE [dbo].[CertificationDetails]
GO

/****** Object:  Table [dbo].[CertificationDetails]    Script Date: 20-05-2021 18:47:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CertificationDetails](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[StudentId] [bigint] NOT NULL,
	[CertificationName] [nvarchar](100) NULL,
	[completedYear] [datetime] NULL,
	[IssuingAuthority] [nvarchar](100) NULL,
	[Institute] [int] NULL,
	[NotExpire] [bit] NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[UpdatedBy] [nvarchar](100) NULL,
	[UpdatedDate] [datetime] NULL,
 CONSTRAINT [PK_CertificationDetailId] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[CertificationDetails]  WITH CHECK ADD  CONSTRAINT [FK_CertificationStudentId] FOREIGN KEY([StudentId])
REFERENCES [dbo].[StudentPersonalDetails] ([Id])
GO

ALTER TABLE [dbo].[CertificationDetails] CHECK CONSTRAINT [FK_CertificationStudentId]
GO

ALTER TABLE [dbo].[CertificationDetails]  WITH CHECK ADD  CONSTRAINT [FK_InstituteCerId] FOREIGN KEY([Institute])
REFERENCES [dbo].[InstituteNameMaster] ([InstituteId])
GO

ALTER TABLE [dbo].[CertificationDetails] CHECK CONSTRAINT [FK_InstituteCerId]
GO


