USE [SJAcademics]
GO

ALTER TABLE [dbo].[SkillDetails] DROP CONSTRAINT [FK_SkillStudentId]
GO

/****** Object:  Table [dbo].[SkillDetails]    Script Date: 20-05-2021 18:58:45 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SkillDetails]') AND type in (N'U'))
DROP TABLE [dbo].[SkillDetails]
GO

/****** Object:  Table [dbo].[SkillDetails]    Script Date: 20-05-2021 18:58:45 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SkillDetails](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[StudentId] [bigint] NOT NULL,
	[SkillName] [nvarchar](200) NULL,
	[ExperienceInYear] [decimal](5, 1) NULL,
	[SelfRating] [int] NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[UpdatedBy] [nvarchar](100) NULL,
	[UpdatedDate] [datetime] NULL,
 CONSTRAINT [PK_SkillDetailId] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[SkillDetails]  WITH CHECK ADD  CONSTRAINT [FK_SkillStudentId] FOREIGN KEY([StudentId])
REFERENCES [dbo].[StudentPersonalDetails] ([Id])
GO

ALTER TABLE [dbo].[SkillDetails] CHECK CONSTRAINT [FK_SkillStudentId]
GO


