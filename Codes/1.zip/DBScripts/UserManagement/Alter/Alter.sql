alter table [User] ADD EntryVia INT NULL

