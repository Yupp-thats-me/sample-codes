
ALTER TABLE [User]
  ADD CONSTRAINT IdentityIdNotNull CHECK (
  (IdentityId IS NOT NULL) 
  OR (RequestedRole IN (1000)))

ALTER TABLE [User]
	ADD CONSTRAINT EducationCategoryIdNotNull CHECK (
	(EducationCategoryId IS NOT NULL OR RequestedRole NOT IN (1,6,7))
	OR (RequestedRole IN (1000,2000,2001)))

ALTER TABLE [User]
	ADD CONSTRAINT EducationLevelIdNotNull CHECK (
	(EducationLevelId IS NOT NULL OR RequestedRole NOT IN (1))
	OR (RequestedRole IN (1000,2000,2001)))
		
ALTER TABLE [User]
	ADD CONSTRAINT ShortBioNotNull CHECK (
	(ShortBio IS NOT NULL OR RequestedRole NOT IN (5))
	OR (RequestedRole IN (1000,2000,2001)))
	
ALTER TABLE [User]
	ADD CONSTRAINT OrganizationNameNotNull CHECK (
	(OrganizationName IS NOT NULL OR RequestedRole IN (1,8))
	OR (RequestedRole IN (1000)))


ALTER TABLE [User]
	ADD CONSTRAINT CityIdNotNull CHECK (
	(CityId IS NOT NULL OR RequestedRole IN (1,8))
	OR (RequestedRole IN (1000,2000,2001)))
			
ALTER TABLE [User]
	ADD CONSTRAINT DOBNotNull CHECK (
	(DOB IS NOT NULL)
	OR (RequestedRole IN (1000,2000,2001)))

ALTER TABLE [User]
	ADD CONSTRAINT InstituteIdNotNull CHECK (
	(InstituteId IS NOT NULL OR RequestedRole IN (4,5,8))
	OR (RequestedRole IN (1000)))


ALTER TABLE [User]
	ADD CONSTRAINT POBOXNotNull CHECK (
	(CurrentAddress IS NULL OR (POBox IS NOT NULL))
	OR (RequestedRole IN (1000)))

ALTER TABLE [User]
	ADD CONSTRAINT IndustryIdNotNull CHECK (
	(IndustryId IS NOT NULL OR RequestedRole IN (1,7,2,3,6,8))
	OR (RequestedRole IN (1000,2000,2001)))

 ALTER TABLE [User]
	ADD CONSTRAINT CategoryTypeNotNull CHECK (
	(CategoryType IS NOT NULL OR RequestedRole NOT IN (6))
	OR (RequestedRole IN (1000,2000,2001)))

ALTER TABLE [User]
	ADD CONSTRAINT ServiceIdNotNull CHECK (
	(ServiceId IS NOT NULL OR RequestedRole NOT IN (6))
	OR (RequestedRole IN (1000,2000,2001)))