
ALTER TABLE [User]
Add CONSTRAINT UC_User UNIQUE (IdentityId, Email, PhoneNumber)