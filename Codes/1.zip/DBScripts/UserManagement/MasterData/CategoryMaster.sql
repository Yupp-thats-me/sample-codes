SET IDENTITY_INSERT [dbo].[CategoryMaster] ON 

INSERT [dbo].[CategoryMaster] ([Id], [NameEn], [NameAr], [ServiceMasterId],[CreatedBy],[CreatedDate]) VALUES (1, N'Academic UAE/Overseas', N'أكاديمي في الإمارات العربية المتحدة / في الخارج', NULL, 'system',GetDate())
INSERT [dbo].[CategoryMaster] ([Id], [NameEn], [NameAr], [ServiceMasterId],[CreatedBy],[CreatedDate]) VALUES (2, N'Wellbeing', N'لرفاهية', NULL, 'system',GetDate())
INSERT [dbo].[CategoryMaster] ([Id], [NameEn], [NameAr], [ServiceMasterId],[CreatedBy],[CreatedDate]) VALUES (3, N'Career', N'المهنة', NULL, 'system',GetDate())
SET IDENTITY_INSERT [dbo].[CategoryMaster] OFF