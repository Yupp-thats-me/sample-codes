

insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Abu Dhabi International School',N'مدرسة أبوظبي الدولية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Canadian International School',N'المدرسة الكندية الدولية',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('American International School, Abu Dhabi',N'المدرسة الأمريكية الدولية، أبوظبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Al Sanawbar School',N'مدرسة السنوبار
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Al Ain English Speaking School',N'مدرسة العين الناطقة باللغة الإنجليزية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Abu Dhabi Indian School',N'مدرسة أبوظبي الهندية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Abu Dhabi Indian School-Branch 1, Al Wathba',N'مدرسة أبوظبي الهندية - فرع 1، الوثبة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Abu Dhabi Model School',N'مدرسة أبوظبي النموذجية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('ADNOC Schools',N'مدارس أدنوك
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Al Dhafra Private School',N'مدرسة الظفرة الخاصة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Al Nahda National Schools',N'مدارس النهضة الوطنية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Al Yasmina School',N'مدرسة الياسمينة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Al Worood Academy',N'أكاديمية الورود
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('American Community School of Abu Dhabi',N'مدرسة المجتمع الأمريكي في أبوظبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('International Indian School, Abu Dhabi',N'المدرسة الهندية الدولية، أبوظبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('British International School, Abu Dhabi',N'المدرسة البريطانية الدولية، أبوظبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('The British School – Al Khubairat',N'المدرسة البريطانية – الخبيرات
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Dunes International School, Abu Dhabi',N'مدرسة الكثبان الدولية، أبوظبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Educational Zone',N'المنطقة التعليمية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Emirates National Schools',N'مدارس الإمارات الوطنية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Emirates Future International Academy',N'أكاديمية الإمارات للمستقبل الدولي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('GEMS American Academy, Abu Dhabi',N'الأكاديمية الأمريكية للأحجار الكريمة، أبوظبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Indian School, Al-Ain',N'المدرسة الهندية، العين
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Islamia English School',N'مدرسة إسلاميا الإنجليزية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Japanese School in Abu Dhabi',N'المدرسة اليابانية في أبوظبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Lycée Français Théodore Monod (United Arab Emirates)',N'ليسيه فرانسوا تيودور مونود (الإمارات العربية المتحدة)
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Lycée Louis Massignon',N'ليسيه لويس ماسينيون
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('The Military High School, Al-Ain',N'الثانوية العسكرية، العين
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Merryland International School',N'مدرسة ميريلاند الدولية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Our Own English High School, Al Ain',N'مدرستنا الثانوية الإنجليزية الخاصة، العين
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Reach British School',N'الوصول إلى المدرسة البريطانية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Raha International School',N'مدرسة رحا الدولية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Rawafed Private School',N'مدرسة روافق الخاصة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('St Joseph''s School (Abu Dhabi)',N'مدرسة القديس يوسف (أبوظبي)
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Shaikh Khalifa Bin Zayed Bangladesh Islamia School',N'مدرسة الشيخ خليفة بن زايد البنجلاديشية الإسلامية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Bright Riders School (Abu Dhabi)',N'مدرسة برايت رايدرز (أبوظبي)
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Zayed Al Awwal Secondary School',N'مدرسة زايد العوال الثانوية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Sheikh Zayed Private Academy For Girls',N'أكاديمية الشيخ زايد الخاصة للبنات
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Sunrise English Private School',N'مدرسة الشروق الإنجليزية الخاصة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Sheikh Zayed Private Academy For Boys',N'أكاديمية الشيخ زايد الخاصة للبنين
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Madar International School',N'مدرسة مدار الدولية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('',N'',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Indian School Ajman',N'المدرسة الهندية عجمان
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('British International School, Ajman',N'المدرسة البريطانية الدولية، عجمان
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Woodlem Park School, Ajman[1]',N'مدرسة وودليم بارك، عجمان[1]
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('The Royal Academy, Ajman[2]',N'الأكاديمية الملكية، عجمان[2]
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Al Ameer English School, Ajman',N'مدرسة أمير الإنجليزية، عجمان
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Habitat Private School',N'مدرسة الموئل الخاصة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('International Indian School Ajman',N'المدرسة الهندية الدولية عجمان
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('City School Ajman',N'مدرسة المدينة عجمان
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Ajman Academy',N'أكاديمية عجمان
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Ajman Modern School',N'أكاديمية عجمان
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Applied Technology High School',N'مدرسة التكنولوجيا التطبيقية الثانوية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Delhi Private School, Ajman',N'مدرسة دلهي الخاصة، عجمان
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('',N'',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Arcadia School',N'مدرسة أركاديا
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Newlands School',N'مدرسة نيولاندز
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('The City School International',N'مدرسة المدينة الدولية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('United International Private School, Dubai, UAE',N'المدرسة الخاصة الدولية المتحدة، دبي، الإمارات العربية المتحدة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Dubai Heights Academy in Al-Barsha South',N'أكاديمية دبي هايتس في البرشة الجنوبية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('JSS International School',N'مدرسة JSS الدولية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('American Academy in Al-Mizhar',N'الأكاديمية الأمريكية في المزهر
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('American School of Creative Science Al Barsha, Dubai',N'المدرسة الأمريكية للعلوم الإبداعية البرشة، دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('American School of Dubai',N'المدرسة الأمريكية في دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Arab Unity School',N'مدرسة الوحدة العربية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Buds Public School, Dubai',N'مدرسة بادز العامة، دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Cambridge International School, Dubai',N'مدرسة كامبردج الدولية، دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Clarion School, Dubai',N'مدرسة كلاريون، دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Credence High School, Dubai',N'مدرسة كريدينس الثانوية، دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Delhi Private School, Dubai',N'مدرسة دلهي الخاصة، دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Dubai National Charity School',N'مدرسة دبي الخيرية الوطنية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Dubai Carmel School',N'مدرسة دبي الكرمل
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Dubai American Academy',N'أكاديمية دبي الأمريكية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Dubai British School',N'مدرسة دبي البريطانية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Dubai College',N'كلية دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Dubai English Speaking College',N'كلية دبي الناطقة بالإنجليزية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Dubai Gem Private School',N'مدرسة دبي جيم الخاصة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Dubai International Academy',N'أكاديمية دبي العالمية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Dubai International School',N'مدرسة دبي الدولية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Dubai Japanese School',N'مدرسة دبي اليابانية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('GEMS Modern Academy',N'أكاديمية جيمس الحديثة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Dubai National School, Al Barsha',N'مدرسة دبي الوطنية، البرشة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Dubai National School, Al Twar',N'مدرسة دبي الوطنية، الطوار
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Dubai Scholars Private School',N'مدرسة دبي للعلماء الخاصة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Dwight School, Dubai',N'مدرسة دوايت، دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Emirates International School – Jumeirah',N'مدرسة الإمارات الدولية – جميرا
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('English College Dubai',N'الكلية الإنجليزية دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Rising School Dubai',N'مدرسة دبي الصاعدة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('English Language School, Dubai',N'مدرسة اللغة الإنجليزية، دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('GEMS Royal Dubai School, Al-Mizhar',N'مدرسة جيمس رويال دبي، المزهر
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('GEMS Wellington International School',N'مدرسة جيمس ويلينغتون الدولية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('GEMS World Academy',N'أكاديمية جيمس العالمية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('GEMS Winchester School',N'مدرسة جيمس وينشستر
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Apple International School',N'مدرسة أبل الدولية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Greenfield Community School',N'مدرسة غرينفيلد المجتمعية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Greenwood International School',N'مدرسة غرينوود الدولية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Gulf Indian High School',N'مدرسة الخليج الهندية الثانوية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Gulf Model School',N'مدرسة الخليج النموذجية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Global Indian International School',N'المدرسة الدولية الهندية العالمية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Horizon English School, Dubai',N'مدرسة هورايزون الإنجليزية، دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Horizon International School, Dubai',N'مدرسة هورايزون الدولية، دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('International School of Creative Science Nad Al Sheba, Dubai',N'المدرسة الدولية للعلوم الإبداعية ناد الشيبة، دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('International School of Choueifat, Dubai',N'المدرسة الدولية للشويفات، دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('The Central School,Dubai',N'المدرسة المركزية,دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('The Indian High School, Dubai',N'المدرسة الثانوية الهندية، دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('The Winchester School, Jebel Ali',N'مدرسة وينشستر، جبل علي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('JSS Private School',N'مدرسة JSS الخاصة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('JSS International School',N'مدرسة JSS الدولية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Jumeira Baccalaureate School',N'مدرسة جميرا باكالوريا
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Jumeirah College',N'كلية جميرا
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Jumeirah English Speaking School JESS',N'مدرسة جميرا الناطقة باللغة الإنجليزية JESS
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Kent College Dubai',N'كلية كينت دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Latifa School for Girls',N'مدرسة لطيفة للبنات
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Lycee Francais International de Dubai',N'ليسيه فرانسيز إنترناشيونال دي دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('New Indian Model School',N'المدرسة النموذجية الهندية الجديدة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Next Generation School',N'مدرسة الجيل القادم
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Nord Anglia International School Dubai',N'مدرسة نورد أنجليا الدولية دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('North American International School',N'مدرسة أمريكا الشمالية الدولية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Our Own High School',N'مدرستنا الثانوية الخاصة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Pakistan Education Academy',N'أكاديمية التعليم الباكستانية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('The Oxford School',N'مدرسة أكسفورد
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('The Philippine School, Dubai',N'المدرسة الفلبينية، دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Raffles International School – South Campus',N'مدرسة رافلز الدولية – الحرم الجامعي الجنوبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Rashid School For Boys',N'مدرسة راشد للبنين
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Regent International School',N'مدرسة ريجنت الدولية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Repton School Dubai',N'مدرسة ريبتون دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('St. Mary''s Catholic High School, Dubai',N'مدرسة سانت ماري الثانوية الكاثوليكية، دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Swiss International Scientific School Dubai',N'المدرسة السويسرية العلمية الدولية دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Sabri Indian School, Dubai',N'مدرسة صبري الهندية، دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Westminster School, Dubai',N'مدرسة وستمنستر، دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('The Millennium School, Dubai',N'مدرسة الألفية، دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Amled, Dubai',N'أمليد، دبي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Sunmarke School',N'مدرسة سونماركي
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Jumeirah International Nurseries',N'مشاتل جميرا الدولية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('',N'',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Our Own English High School, Fujairah',N'مدرستنا الثانوية الإنجليزية الخاصة، الفجيرة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('St. Mary''s Catholic High School, Fujairah',N'مدرسة سانت ماري الثانوية الكاثوليكية، الفجيرة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Indian Public High School',N'المدرسة الثانوية العامة الهندية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Indian School, Ras al-Khaimah',N'المدرسة الهندية، رأس الخيمة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Ras Al Khaimah Academy',N'أكاديمية رأس الخيمة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Scholars Indian School',N'مدرسة العلماء الهندية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Emirates National School',N'مدرسة الإمارات الوطنية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Scholars International Academy',N'الأكاديمية الدولية للباحثين
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('New World American Pvt School, Al Falah Suburb, Near to Sharjah National Park, Sharjah',N'مدرسة العالم الجديد الأمريكية، ضاحية الفلاح، بالقرب من حديقة الشارقة الوطنية، الشارقة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Wesgreen International School',N'مدرسة فيسغرين الدولية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Progressive English School Sharjah',N'مدرسة اللغة الإنجليزية التقدمية الشارقة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('India International School',N'مدرسة الهند الدولية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Gems Millenium School Sharjah',N'مدرسة جيمز ميلينيوم الشارقة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Leaders Private School Sharjah',N'مدرسة القادة الخاصة الشارقة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('American Academy in Al-Mizhar',N'الأكاديمية الأمريكية في المزهر
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('American Community School Sharjah',N'مدرسة المجتمع الأمريكي الشارقة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('American School of Creative Science Al Layyah, Sharjah',N'المدرسة الأمريكية للعلوم الإبداعية اليحية، الشارقة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Al Amaal English High School',N'مدرسة أمال الثانوية الإنجليزية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Delhi Private School, Sharjah',N'مدرسة دلهي الخاصة، الشارقة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('International School of Choueifat',N'المدرسة الدولية للشويفات
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('International School of Creative Science Muwaileh, Sharjah',N'المدرسة الدولية للعلوم الإبداعية معويلة، الشارقة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Our Own English High School, Sharjah',N'مدرستنا الثانوية الإنجليزية الخاصة، الشارقة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Pakistan Islamia Higher Secondary School',N'باكستان - مدرسة إسلامية ثانوية عليا
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Sharjah American International School',N'مدرسة الشارقة الأمريكية الدولية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Sharjah English School',N'مدرسة الشارقة الإنجليزية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Sharjah Indian School',N'مدرسة الشارقة الهندية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('ASPAM Indian International School',N'مدرسة ASPAM الهندية الدولية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Al Wahda School',N'مدرسة الوحدة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Sharjah British International School Sharjah',N'مدرسة الشارقة البريطانية الدولية الشارقة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('PACE British School, Sharjah',N'مدرسة بيس البريطانية، الشارقة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('PACE International School',N'مدرسة PACE الدولية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('School of Knowledge',N'مدرسة المعرفة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Leaders Private School',N'مدرسة القادة الخاصة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Al Ma''arifa International Private School',N'مدرسة المشرفة الدولية الخاصة
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Al Ameer Secondary School',N'مدرسة أمير الثانوية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Choueifat School Umm Al Quwain',N'مدرسة الشويفات أم القيوين
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Delhi Private School, Umm Al Quwain',N'مدرسة دلهي الخاصة، أم القيوين
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('East English School',N'مدرسة شرق الإنجليزية
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Elite American Private School UAQ',N'مدرسة النخبة الأمريكية الخاصة UAQ
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('New Indian School Umm Al Quwain',N'المدرسة الهندية الجديدة أم القيوين
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Sharjah American School UAQ',N'مدرسة الشارقة الأمريكية UAQ
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('The English School, Umm al-Quwain',N'مدرسة اللغة الإنجليزية، أم القيوين
',GetDate(),'system',3)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('Umm Al Qura Private School',N'مدرسة أم القرى الخاصة
',GetDate(),'system',3)

insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('ABU DHABI POLYTECHNIC',N'بوليتيكنيك أبوظبي',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('ABU DHABI SCHOOL OF MANAGEMENT',N'كلية أبوظبي للإدارة',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('ABU DHABI UNIVERSITY',N'جامعة أبوظبى',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('ABU DHABI VOCATIONAL EDUCATION AND TRAINING INSTITUTE',N'معهد أبوظبي للتعليم والتدريب المهني',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('AJMAN UNIVERSITY',N'جامعة عجمان',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('AL AIN UNIVERSITY (PREVIOUSLY, AL AIN UNIVERSITY OF SCIENCE & TECHNOLOGY)',N'جامعة العين (سابقا، جامعة العين للعلوم والتكنولوجيا)',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('AL FALAH UNIVERSITY',N'جامعة الفلاح',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('AL GHURAIR UNIVERSITY',N'جامعة الغرير',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('AL KHAWARIZMI INTERNATIONAL COLLEGE',N'كلية الخوارزمى الدولية',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('AL QASIMIYA UNIVERSITY',N'جامعة القاسمية',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('AL WASL UNIVERSITY (FORMERLY: ISLAMIC AND ARABIC STUDIES COLLEGE - DUBAI)',N'جامعة الوصل (سابقا، كلية الدراسات الاسلامية والعربية بدبى)',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('AMERICAN UNIVERSITY IN DUBAI',N'الجامعة الأمريكية فى دبي',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('AMERICAN UNIVERSITY IN THE EMIRATES',N'الجامعة الأمريكية في الإمارات',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('AMERICAN UNIVERSITY OF RAS AL KHAIMAH',N'الجامعة الأمريكية في رأس الخيمة',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('AMERICAN UNIVERSITY OF SHARJAH',N'الجامعة الأمريكية فى الشارقة',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('ANWAR GARGASH DIPLOMATIC ACADEMY (FORMERLY: EMIRATES DIPLOMATIC ACADEMY)',N'أكاديمية أنور قرقاش الدبلوماسية (سابقا، أكاديمية الإمارات الدبلوماسية)',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('ARAB ACADEMY FOR SCIENCE, TECHNOLOGY AND MARITIME TRANSPORT',N'الأكاديمية العربية للعلوم والتكنولوجيا والنقل البحري',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('BRITISH UNIVERSITY IN DUBAI',N'الجامعة البريطانية فى دبي',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('CANADIAN UNIVERSITY DUBAI',N'الجامعة الكندية في دبي',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('CITY UNIVERSITY COLLEGE OF AJMAN',N'كلية المدينة الجامعية بعجمان',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('DUBAI INSTITUTE OF DESIGN AND INNOVATION',N'معهد دبي للتصميم والابتكار',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('DUBAI MEDICAL COLLEGE FOR GIRLS',N'كلية دبي الطبية للبنات',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('DUBAI PHARMACY COLLEGE FOR GIRLS',N'كلية دبي للصيدلة',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('DUBAI POLICE ACADEMY',N'أكاديمية شرطة دبي',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('EMIRATES ACADEMY FOR IDENTITY & CITIZENSHIP (FORMERLY: EMIRATES INSTITUTE FOR CITIZENSHIP AND RESIDENCE)',N'أكاديمية الإمارات للهوية والجنسية (سابقا: معهد الإمارات للجنسية والإقامة)',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('EMIRATES ACADEMY OF HOSPITALITY MANAGEMENT',N'أكاديمية الإمارات لإدارة الضيافة',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('EMIRATES AVIATION UNIVERSITY',N'جامعة الإمارات للطيران',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('EMIRATES COLLEGE FOR ADVANCED EDUCATION',N'كلية الإمارات للتطوير التربوي',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('EMIRATES INSTITUTE FOR BANKING AND FINANCIAL STUDIES',N'معهد الإمارات للدراسات المصرفية والمالية',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('FATIMA COLLEGE OF HEALTH SCIENCES',N'كلية فاطمة للعلوم الصحية',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('GULF MEDICAL UNIVERSITY',N'جامعة الخليج الطبية',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('HAMDAN BIN MOHAMMED SMART UNIVERSITY',N'جامعة حمدان بن محمد الذكية',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('HIGHER COLLEGES OF TECHNOLOGY',N'كليات التقنية العليا',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('IMAM MALIK COLLEGE FOR ISLAMIC SHARIA AND LAW',N'كلية الإمام مالك للشريعة الإسلامية والقانون',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('INSEAD- THE BUSINESS SCHOOL FOR THE WORLD, ABU DHABI',N'إنسياد- كلية إدارة الأعمال العالمية- أبوظبي',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('JOINT COMMAND AND STAFF COLLEGE - ABU DHABI',N'كلية القيادة والأركان المشتركة - أبوظبي',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('JUMEIRA UNIVERSITY',N'جامعة جميرا',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('KHALIFA BIN ZAYED AIR COLLEGE',N'كلية خليفة بن زايد الجوية',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('KHALIFA UNIVERSITY (FORMERLY: KHALIFA UNIVERSITY OF SCIENCE AND TECHNOLOGY)',N'جامعة خليفة (سابقاً: جامعة خليفة للعلوم والتكنولوجيا)',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('LIWA COLLEGE OF TECHNOLOGY (FORMERLY:EMIRATES COLLEGE OF TECHNOLOGY)',N'كلية ليوا للتكنولوجيا (سابقاً: كلية الإمارات للتكنولوجيا)',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('LONDON BUSINESS SCHOOL, DUBAI CAMPUS',N'كلية لندن لإدارة الاعمال فرع دبي',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('MOHAMED BIN ZAYED UNIVERSITY FOR HUMANITIES (FORMERLY: MOHAMMED V UNIVERSITY- ABU DHABI)',N'جامعة محمد بن زايد للعلوم الإنسانية (سابقا، جامعة محمد الخامس -ابوظبي)',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('MOHAMED BIN ZAYED UNIVERSITY OF ARTIFICIAL INTELLIGENCE',N'جامعة محمد بن زايد للذكاء الاصطناعي',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('MOHAMMED BIN RASHID SCHOOL OF GOVERNMENT',N'كلية محمد بن راشد للإدارة الحكومية',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('MOHAMMED BIN RASHID UNIVERSITY OF MEDICINE AND HEALTH SCIENCES',N'جامعة محمد بن راشد للطب والعلوم الصحية',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('NATIONAL DEFENSE COLLEGE',N'كلية الدفاع الوطني',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('NEW YORK UNIVERSITY, ABU DHABI',N'جامعة نيويورك',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('POLICE COLLEGE, ABU DHABI',N'كلية الشرطة - أبوظبي',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('POLICE SCIENCES ACADEMY- SHARJAH',N'أكاديمية العلوم الشرطية بالشارقة',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('RABDAN ACADEMY',N'أكاديمية ربدان',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('RAS AL KHAIMAH MEDICAL AND HEALTH SCIENCES UNIVERSITY',N'جامعة رأس الخيمة للطب والعلوم الصحية',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('RASHID BIN SAEED AL MAKTOUM NAVAL COLLEGE ‎',N'كلية راشد بن سعيد آل مكتوم البحرية',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('ROCHESTER INSTITUTE OF TECHNOLOGY- DUBAI',N'معهد روشيستر للتكنولوجيا',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('ROYAL COLLEGE OF SURGEONS IN IRELAND- DUBAI',N'الكلية الملكية للجراحين في أيرلندة',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('SAINT JOSEPH UNIVERSITY',N'جامعة سان جوزف',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('SHARJAH PERFORMING ARTS ACADEMY',N'أكاديمية الشارقة للفنون الأدائية',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('SKYLINE UNIVERSITY COLLEGE',N'كلية الأفق الجامعية',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('SORBONNE UNIVERSITY, ABU DHABI (PREVIOUSLY, PARIS SORBONNE UNIVERSITY, ABU DHABI)',N'جامعة السوربون - أبوظبي (سابقاً جامعة باريس السوربون- أبوظب',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('UMM AL QUWAIN UNIVERSITY (FORMERLY: EMIRATES CANADIAN UNIVERSITY COLLEGE)',N'جامعة أم القيوين (سابقاً: الكلية الإماراتية الكندية الجامعية',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('UNITED ARAB EMIRATES UNIVERSITY',N'جامعة الإمارات العربية المتحدة',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('UNIVERSITY OF BIRMINGHAM DUBAI',N'جامعة برمنجهام دبي',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('UNIVERSITY OF DUBAI',N'جامعة دبي',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('UNIVERSITY OF FUJAIRAH',N'جامعة الفجيرة',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('UNIVERSITY OF SCIENCE AND TECHNOLOGY OF FUJAIRAH',N'جامعة العلوم والتقنية في الفجيرة',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('UNIVERSITY OF SHARJAH',N'جامعة الشارقة',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('UNIVERSITY OF STRATHCLYDE BUSINESS SCHOOL- UAE',N'جامعة ستراثكليد- كلية إدارة الأعمال بالإمارات',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('UNIVERSITY OF WOLLONGONG IN DUBAI',N'جامعة ولونغونغ فى دبى',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('ZAYED II MILITARY COLLEGE',N'كلية زايد الثاني العسكرية',GetDate(),'system',2)
insert into InstituteMasters (InstituteNameEn, InstituteNameAr, CreatedDate, CreatedBy, EducationCategoryId) values ('ZAYED UNIVERSITY',N'جامعة زايد',GetDate(),'system',2)

