
GO


INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (2, 1, N'Ph.D', N'دكتوراه', 'PhD','system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (3, 1, N'Master', N'سادة', 'Master','system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (4, 1, N'Bachelor', N'البكالوريوس', 'Bachelor','system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (5, 1, N'Vocational Education', N'التعليم المهني', NULL,'system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (6, 1, N'High School (12th Grade)', N'المدرسة الثانوية', NULL,'system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (7, 1, N'School (10th Grade)', N'المدرسة', NULL,'system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (8, 2, N'Abu Dhabi', N'أبوظبي', N'Abu','system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (9, 2, N'Ajman', N'عجمان', N'Ajm','system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (10, 2, N'Al Ain', N'العين', N'Ala','system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (11, 2, N'Al Dhafra', N'الظفرة', N'Ald','system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (12, 2, N'Dubai', N'دبي', N'Dub','system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (13, 2, N'Fujairah', N'الفجيرة', N'Fuj','system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (14, 2, N'Ras Al Khaimah', N'رأس الخيمة', N'Ras','system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (15, 2, N'Sharjah', N'الشارقة', N'Sha','system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (16, 2, N'Umm Al Quwain', N'أم القيوين', N'Uaq','system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (17, 3, N'Agriculture, Forestry, Fisheries & Veterinary', N'الزراعة والغابات ومصايد الأسماك والطب البيطري', NULL,'system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (18, 3, N'Arts & Humanities', N'الآداب والعلوم الإنسانية', NULL,'system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (19, 3, N'Business, Administration and Law', N'الأعمال والإدارة والقانون', NULL,'system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (20, 3, N'Education', N'تعليم', NULL,'system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (21, 3, N'Engineering, Manufacturing & Construction', N'الهندسة والتصنيع والبناء', NULL,'system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (22, 3, N'Health & Welfare', N'الصحة والرفاهية', NULL,'system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (23, 3, N'Natural Sciences, Mathematics & Statistics', N'', NULL,'system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (24, 3, N'Health & Welfare', N'الصحة والرفاهية', NULL,'system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (25, 3, N'Information and Communication Technologies', N'تكنولوجيا المعلومات والاتصالات', NULL,'system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (26, 3, N'Natural Sciences, Mathematics & Statistics', N'العلوم الطبيعية والرياضيات والإحصاء', NULL,'system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (27, 3, N'Services', N'خدمات', NULL,'system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (28, 3, N'Social Sciences, Journalism & Information', N'العلوم الاجتماعية والصحافة والمعلومات', NULL,'system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (29, 4, N'Ph.D', N'دكتوراه', NULL,'system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (30, 4, N'Master', N'سادة', NULL,'system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (31, 4, N'Bachelor', N'البكالوريوس', NULL,'system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (32, 4, N'Vocational Education', N'التعليم المهني', NULL,'system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (33, 4, N'High School (12th Grade)', N'المدرسة الثانوية', NULL,'system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (34, 4, N'School (10th Grade)', N'المدرسة', NULL,'system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (35, 5, N'Class 10', NULL, 'Cycle1','system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (36, 5, N'Class 11', NULL, 'Cycle2','system', GetDate())
INSERT [dbo].[Elements] ([Id], [ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (37, 5, N'Class 12', NULL, 'Cycle3','system', GetDate())


INSERT [dbo].[Elements] ([ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (7, N'Higher Education', 'تعليم عالى', 'HE','system', GetDate())
INSERT [dbo].[Elements] ([ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (7, N'General Education', 'تعليم عام', 'GE','system', GetDate())

INSERT [dbo].[Elements] ([ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (8, N'Full Time', 'وقت كامل', NULL,'system', GetDate())
INSERT [dbo].[Elements] ([ElementType], [ElementNameEn], [ElementNameAr], [ElementShortName], [CreatedBy], [CreatedDate]) VALUES (8, N'Part Time', 'دوام جزئى', NULL,'system', GetDate())


insert into [Elements] (ElementType, ElementNameEn, ElementNameAr, CreatedBy, CreatedDate)
values (9, N'Accounting', N'محاسبة', 'system', GetDate())

insert into [Elements] (ElementType, ElementNameEn, ElementNameAr, CreatedBy, CreatedDate)
values (9, N'Banking', N'الخدمات المصرفية', 'system', GetDate())
insert into [Elements] (ElementType, ElementNameEn, ElementNameAr, CreatedBy, CreatedDate)
values (9, N'Engineering', N'هندسة', 'system', GetDate())
insert into [Elements] (ElementType, ElementNameEn, ElementNameAr, CreatedBy, CreatedDate)
values (9, N'Finance', N'تمويل', 'system', GetDate())
insert into [Elements] (ElementType,ElementNameEn, ElementNameAr, CreatedBy, CreatedDate)
values (9, N'FMCG', N'سلع استهلاكية', 'system', GetDate())
insert into [Elements] (ElementType, ElementNameEn, ElementNameAr, CreatedBy, CreatedDate)
values (9, N'Insurance', N'تأمين', 'system', GetDate())
insert into [Elements] (ElementType, ElementNameEn, ElementNameAr, CreatedBy, CreatedDate)
values (9, N'IT', N'هو - هي', 'system', GetDate())







Go
INSERT INTO [Elements]
      ( [ElementType]
      ,[ElementNameEn]
      ,[ElementNameAr]
	  ,[CreatedBy]
	  ,[CreatedDate])
Values
       (6,'Agribusiness',N'الأعمال الزراعية','system',GetDate()),
       (6,'Horticulture',N'البستنة','system',GetDate()),
       (6,'Marine Fisheries And Animal Sc',N'مصايد الأسماك البحرية والحيوانية','system',GetDate()),
       (6,'Veterinary Laboratory',N'مختبر بيطري','system',GetDate()),
       (6,'Veterinary Science',N'العلوم البيطرية','system',GetDate()),
       (6,'Acting',N'التمثيل','system',GetDate()),
       (6,'Applied Foreign Languages',N'اللغات الأجنبية التطبيقية','system',GetDate()),
       (6,'Arabic Language',N'اللغة العربية','system',GetDate()),
	   (6,'Archaeology',N'علم الآثار','system',GetDate()),
	   (6,'Art & Design',N'دراسات فنية','system',GetDate()),
	   (6,'Cultural Conservation',N'الحفاظ على الثقافة','system',GetDate()),
	   (6,'Dance',N'الرقص','system',GetDate()),
	   (6,'Dramatic Writing',N'الكتابة الدرامية','system',GetDate()),
	   (6,'English Language',N'اللغة الانجليزية','system',GetDate()),
	   (6,'English Language & Literature',N'اللغة الإنجليزية وآدابها','system',GetDate()),
	   (6,'Fashion Design',N'تصميم الأزياء','system',GetDate()),
	   (6,'Film and video production',N'إنتاج الأفلام والفيديو','system',GetDate()),
	   (6,'General Arts',N'الفنون العامة','system',GetDate()),
	   (6,'Graphic Design & Multimedia',N'التصميم الجرافيكي والوسائط المتعددة','system',GetDate()),
	   (6,'History',N'تاريخ','system',GetDate()),
	   (6,'History of Art',N'تاريخ الفن','system',GetDate()),
	   (6,'Interior Architecture & Design',N'العمارة الداخلية والتصميم','system',GetDate()),
	   (6,'Islamic Studies',N'الدراسات الإسلامية','system',GetDate()),
	   (6,'Japanese Language',N'اللغة اليابانية','system',GetDate()),
	   (6,'Liberal Arts',N'الفنون الليبرالية','system',GetDate()),
	   (6,'Linguistics',N'اللغويات','system',GetDate()),
	   (6,'Multimedia Design',N'تصميم الوسائط المتعددة','system',GetDate()),
	   (6,'Music',N'موسيقى','system',GetDate()),
	   (6,'Philosophy',N'فلسفة','system',GetDate()),
	   (6,'Product Design',N'تصميم المنتج','system',GetDate()),
	   (6,'Radio & Television',N'راديو وتلفزيون','system',GetDate()),
	   (6,'Sign Language',N'لغة الإشارة','system',GetDate()),
	   (6,'Spanish',N'الأسبانية','system',GetDate()),
	   (6,'Theatre',N'مسرح','system',GetDate()),
	   (6,'Translation Studies',N'دراسات الترجمة','system',GetDate()),
	   (6,'Accounting',N'محاسبة','system',GetDate()),
	   (6,'Accounting & Finance',N'المحاسبة والمالية','system',GetDate()),
	   (6,'Advertising',N'دعاية','system',GetDate()),
	   (6,'Air and Space Law',N'قانون الجو والفضاء','system',GetDate()),
	   (6,'Banking',N'الخدمات المصرفية','system',GetDate()),
	   (6,'Business',N'عمل','system',GetDate()),
	   (6,'Business Administration',N'إدارة الأعمال','system',GetDate()),
	   (6,'Business Analytics',N'تحليل الأعمال','system',GetDate()),
	   (6,'Business Management',N'ادارة اعمال','system',GetDate()), 
	   (6,'Criminal Justice',N'العدالة الجنائية','system',GetDate()),
	   (6,'Criminal Science',N'العلم الجريمه','system',GetDate()),
	   (6,'Design Management',N'إدارة التصميم','system',GetDate()),
	   (6,'Dispute Resolution',N'حل النزاعات','system',GetDate()),
	   (6,'E-Business',N'الأعمال الإلكترونية','system',GetDate()),
	   (6,'ENGINEERING MANAGEMENT',N'الإدارة الهندسية','system',GetDate())

GO




SET IDENTITY_INSERT [dbo].[Elements] OFF
GO
