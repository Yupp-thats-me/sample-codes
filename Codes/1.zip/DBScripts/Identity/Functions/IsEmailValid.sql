USE [SJIdentity]
GO

/****** Object:  UserDefinedFunction [dbo].[IsEmailValid]    Script Date: 18-05-2021 11:31:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER FUNCTION [dbo].[IsEmailValid] (@Email nvarchar(max))

RETURNS bit


BEGIN

 If Exists (SELECT * FROM [SJIdentity].[dbo].[UsersDetails] WHERE Email=@Email)
	BEGIN
		Return 1
	END

	Return 0;
END
GO


