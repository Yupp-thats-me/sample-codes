USE [SJIdentity]
GO

/****** Object:  StoredProcedure [dbo].[SaveRegister]    Script Date: 18-05-2021 12:07:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE OR ALTER PROCEDURE [dbo].[SaveRegister]
(
	@AccountType NVARCHAR(10),
	@FirstName NVARCHAR(50)=null,
	@MiddleName NVARCHAR(50)=null,
	@LastName NVARCHAR(50)=null,
	@Email NVARCHAR(50)=null,
	@UserName NVARCHAR(512)=null,
	@PasswordHash NVARCHAR(MAX)=null,
	@Salt NVARCHAR(MAX)=null,
	@Gender NVARCHAR(10)=null,
	@AddressL1 NVARCHAR(100)=null,
	@AddressL2 NVARCHAR(100)=null,
	@POBoxNumber NVARCHAR(100)=null,
	@Emirate NVARCHAR(50)=null,
	@MobileNo bigint=0,
	@PhoneNo NVARCHAR(50)=null,
	@PhoneCode NVARCHAR(10)=null,
	@Residency NVARCHAR(10)=null,
	@EmirateId NVARCHAR(50)=null,
	@CountryId NVARCHAR(50)=null,
	@PassportNo  NVARCHAR(50)=null,
	@DocumentNo NVARCHAR(50)=null,
	@QuestionId NVARCHAR(10)=null,
	@QuestionAns NVARCHAR(500)=null,
	
	@InstituteName NVARCHAR(500)=NULL,
	@EducationalZone NVARCHAR(500)=null,
	@LicenseNumber NVARCHAR(50)=NULL,
	@LicenseExpDate DATETIME =NULL,
	@EducationalActivities NVARCHAR(500)=NULL,
	@CXOcompanyName NVARCHAR(500)=NULL,
	@CXOEmployerCatgory NVARCHAR(500)=NULL,
	@CXOEmployeeId NVARCHAR(500)=NULL,
	@CXOEmployerZone NVARCHAR(500)=NULL,
	@CXOLicenseNumber NVARCHAR(500)=NULL,
	@CXOLicenseExpiryDate DATETIME = NULL,
	@EmployerName NVARCHAR(500)= NULL,
	@EmployerEmpId NVARCHAR(500)=NULL,
	@EmployerCatgory NVARCHAR(500)=NULL,
	@EmployerZone NVARCHAR(500)=null,
	@EmpLicenseNumber NVARCHAR(500)=NULL,
	@EmpLicenseExpiryDate DATETIME =NULL,


	@Id BIGINT OUT
)
AS
BEGIN
	

	  -- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF(@CXOLicenseExpiryDate='1900-01-01 00:00:00.000')
		SET @CXOLicenseExpiryDate=NULL;


	IF(ISNULL(@Id,0)=0)
	BEGIN

		INSERT INTO dbo.[UsersDetails] (
			AccountType,
			[Email],
			[UserName],
			[PasswordHash],
			Salt,
			EmailConfirmed,
			LockoutEnabled,
			PhoneNumberConfirmed,
			TwoFactorEnabled,

			FirstName ,
		MiddleName  ,
		LastName ,
		Gender ,
		AddressL1  ,
		AddressL2  ,
		POBoxNumber  ,
		Emirate  ,
		MobileNo  ,
		PhoneNo  ,
		PhoneCode  ,
		Residency  ,
		EmirateId  ,
		CountryId  ,
		PassportNo   ,
		DocumentNo  ,
		QuestionId  ,
		QuestionAns  ,
	
		InstituteName  ,
		EducationalZone  ,
		LicenseNumber  ,
		LicenseExpDate   ,
		EducationalActivities  ,
		CXOcompanyName  ,
		CXOEmployerCatgory  ,
		CXOEmployeeId  ,
		CXOEmployerZone  ,
		CXOLicenseNumber  ,
		CXOLicenseExpiryDate    ,
		EmployerName   ,
		EmployerEmpId  ,
		EmployerCatgory  ,
		EmployerZone  ,
		EmpLicenseNumber  ,
		EmpLicenseExpiryDate   

		)
		VALUES
		(
			@AccountType,
			@Email,
			@UserName,
			@PasswordHash,
			@Salt,
			0,0,0,0,

			@FirstName ,
			@MiddleName  ,
			@LastName ,
			@Gender ,
			@AddressL1  ,
			@AddressL2  ,
			@POBoxNumber  ,
			@Emirate  ,
			@MobileNo  ,
			@PhoneNo  ,
			@PhoneCode  ,
			@Residency  ,
			@EmirateId  ,
			@CountryId  ,
			@PassportNo   ,
			@DocumentNo  ,
			@QuestionId  ,
			@QuestionAns  ,
			@InstituteName  ,
			@EducationalZone  ,
			@LicenseNumber  ,
			@LicenseExpDate   ,
			@EducationalActivities  ,
			@CXOcompanyName  ,
			@CXOEmployerCatgory  ,
			@CXOEmployeeId  ,
			@CXOEmployerZone  ,
			@CXOLicenseNumber  ,
			@CXOLicenseExpiryDate    ,
			@EmployerName   ,
			@EmployerEmpId  ,
			@EmployerCatgory  ,
			@EmployerZone  ,
			@EmpLicenseNumber  ,
			@EmpLicenseExpiryDate   
 

		)

		SET @Id=SCOPE_IDENTITY();

		IF(@AccountType='1')
		BEGIN
			INSERT INTO SJAcademics..StudentPersonalDetails (FirstName,MiddleName,LastName,Email,MobileNo,PhoneNumber,CurrentAddressLine1,CurrentAddressLine2,CurrentPoBox,CreatedBy,CreatedDate,UserId)
			SELECT @FirstName,@MiddleName,@LastName,@Email,@MobileNo,@PhoneNo,@AddressL1,@AddressL2,@POBoxNumber,@Id,GETDATE(),@Id
		END
		

	END
	ELSE
	BEGIN
		UPDATE dbo.[UsersDetails]
		SET [UserName]=@UserName,
			[PasswordHash]=@PasswordHash,
			Email=@Email,
			Salt=@Salt,

			FirstName=@FirstName ,
			MiddleName=@MiddleName  ,
			LastName=@LastName ,
			Gender=@Gender ,
			AddressL1=@AddressL1  ,
			AddressL2 =@AddressL2  ,
			POBoxNumber=@POBoxNumber  ,
			Emirate =@Emirate  ,
			MobileNo =@MobileNo  ,
			PhoneNo=@PhoneNo  ,
			PhoneCode=@PhoneCode  ,
			Residency =@Residency  ,
			EmirateId  =@EmirateId  ,
			CountryId=@CountryId  ,
			PassportNo=@PassportNo   ,
			DocumentNo =@DocumentNo  ,
			QuestionId=@QuestionId  ,
			QuestionAns=@QuestionAns  ,
			InstituteName=@InstituteName  ,
			EducationalZone=@EducationalZone  ,
			LicenseNumber =@LicenseNumber  ,
			LicenseExpDate =@LicenseExpDate   ,
			EducationalActivities=@EducationalActivities  ,
			CXOcompanyName=@CXOcompanyName  ,
			CXOEmployerCatgory=@CXOEmployerCatgory  ,
			CXOEmployeeId=@CXOEmployeeId  ,
			CXOEmployerZone=@CXOEmployerZone  ,
			CXOLicenseNumber=@CXOLicenseNumber  ,
			CXOLicenseExpiryDate=@CXOLicenseExpiryDate    ,
			EmployerName=@EmployerName   ,
			EmployerEmpId =@EmployerEmpId  ,
			EmployerCatgory=@EmployerCatgory  ,
			EmployerZone =@EmployerZone  ,
			EmpLicenseNumber =@EmpLicenseNumber  ,
			EmpLicenseExpiryDate=@EmpLicenseExpiryDate   

		WHERE Id=@Id

		
	END
END
GO


