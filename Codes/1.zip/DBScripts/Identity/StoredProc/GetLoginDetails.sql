USE [SJIdentity]
GO

/****** Object:  StoredProcedure [dbo].[GetLoginDetails]    Script Date: 18-05-2021 12:01:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE OR ALTER PROCEDURE [dbo].[GetLoginDetails]
(
	
	@EmailAddress	NVARCHAR(50)=NULL,
	@Response NVARCHAR(max) OUTPUT
)
AS
BEGIN

SET NOCOUNT ON;
	
	IF NOT EXISTS(SELECT 1 From UsersDetails WHERE Email=@EmailAddress)
	
		BEGIN 
			SET @Response='Invalid Email Id'	
		END

	ELSE

		BEGIN
			SELECT UD.Email,PasswordHash,Salt,UD.Id,UserName,ISNULL(SPD.Id,0) AS StudentId
			FROM [SJIdentity].[dbo].[UsersDetails] UD WITH(NOLOCK)
			LEFT JOIN SJAcademics..StudentPersonalDetails SPD WITH(NOLOCK)
			ON	SPD.UserId=UD.Id
			WHERE  UD.Email=@EmailAddress
		END 
END
GO


