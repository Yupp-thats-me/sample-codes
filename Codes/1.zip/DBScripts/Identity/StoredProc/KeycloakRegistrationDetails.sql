USE [SJIdentity]
GO

/****** Object:  StoredProcedure [dbo].[KeycloakRegistrationDetails]    Script Date: 18-05-2021 12:05:58 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[KeycloakRegistrationDetails]  
(  
 @EmailId NVARCHAR(100),  
 @UserName NVARCHAR(100),  
 @FirstName NVARCHAR(100),  
 @LastName NVARCHAR(100),   
 @AccountType NVARCHAR(10)=null,  
 @Response NVARCHAR(100) OUT,  
 @Id BIGINT OUT,  
 @StudentId BIGINT OUT ,
 @EmirateId NVARCHAR(50) OUT
)  
AS  
BEGIN  
 SET NoCOUNT ON;  
 --DECLARE @Id BIGINT;  
 SET @Response ='Success';  
 SET @id=0;  
 SET @StudentId=0; 
 SET @EmirateId='';
  
 IF NOT EXISTS (SELECT 1 FROM SJIdentity..UsersDetails WITH(NOLOCK) WHERE Email=@EmailId)  
 BEGIN  
  INSERT INTO SJIdentity..UsersDetails (Email,FirstName,LastName,UserName,AccountTYpe, CreatedOn)  
  VALUES(@EmailId,@FirstName,@LastName,@UserName,@AccountType,GETDATE())  
  
  SET @Id=SCOPE_IDENTITY();  
  
  if(@AccountType='HES')  
  BEGIN  
   INSERT INTO SJAcademics..StudentPersonalDetails (FirstName,LastName,Email,UserId, CreatedBy,CreatedDate)   
   VALUES (@FirstName,@LastName,@EmailId,@Id,@Id,GETDATE())  
  
   SET @StudentId=SCOPE_IDENTITY();  
  END  
 END  
 ELSE  
 BEGIN  
  SET @Response='Already exists'  
  
  SELECT @Id=Id,@EmirateId=isnull(EmirateId, '')  FROM SJIdentity..UsersDetails WITH(NOLOCK) WHERE Email=@EmailId  
  
  if(@AccountType='HES')  
  BEGIN  
   SELECT @StudentId=Id FROM SJAcademics..StudentPersonalDetails WITH(NOLOCK)  
   WHERE UserId=@Id AND Email=@EmailId  
  END  
  
 END  
END  
GO


