USE [SJIdentity]
GO

/****** Object:  StoredProcedure [dbo].[GetPasswordSalt]    Script Date: 18-05-2021 12:02:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER procedure [dbo].[GetPasswordSalt] 
(
@Id Bigint,
@Salt nvarchar(max) out
)
As
Begin
Select @Salt=Salt  from UsersDetails with(NOlock)
where Id=@Id
END

GO


