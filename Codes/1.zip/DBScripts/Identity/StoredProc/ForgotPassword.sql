USE [SJIdentity]
GO

/****** Object:  StoredProcedure [dbo].[ForgotPassword]    Script Date: 18-05-2021 10:16:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER procedure [dbo].[ForgotPassword] 
(
@EmailId NVARCHAR(50)=NULL,
@Error NVARCHAR(max) OUTPUT
)
As
Begin
IF NOT EXISTS(SELECT 1 From UsersDetails WHERE Email=@EmailId)
	
	BEGIN
		SET @Error='Invalid Email Id'
    END 
		

	ELSE

	BEGIN 
			
			SELECT Email
			FROM [SJIdentity].[dbo].[UsersDetails] WITH(NOLOCK)
			WHERE Email=@EmailId
		
	END

		
END
GO


