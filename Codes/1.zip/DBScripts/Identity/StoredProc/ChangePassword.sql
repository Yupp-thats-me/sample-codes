USE [SJIdentity]
GO

/****** Object:  StoredProcedure [dbo].[ChangePassword]    Script Date: 18-05-2021 10:14:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[ChangePassword]
(
	@UserID int
	, @CurrentPwd nvarchar(500)
	, @NewPwd nvarchar(500)
)
AS
BEGIN

SET NOCOUNT ON;

IF Exists(Select 1 from UsersDetails where PasswordHash = @CurrentPwd and ID=@UserID) 
	UPdate UsersDetails set PasswordHash = @NewPwd where ID = @UserID
Else
RAISERROR('Incorrect current Password', 16, 1)
End
GO


