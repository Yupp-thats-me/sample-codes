USE [SJIdentity]
GO

/****** Object:  StoredProcedure [dbo].[KeycloakRegistration]    Script Date: 18-05-2021 12:02:59 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[KeycloakRegistration]


@FirstName   		NVARCHAR(50)=null,
@LastName			NVARCHAR(50)=null,
@UserName			NVARCHAR(50)=null,
@Email				NVARCHAR(50)=null, 
@AccountType		NVARCHAR(50)=null,
@Id                 BIGINT=NULL ,
@Response			NVARCHAR(MAX)=NULL OUTPUT

AS 
BEGIN
  -- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF EXISTS(SELECT 1 From UsersDetails where Email=@Email)

		BEGIN

		  INSERT INTO
		    [dbo].UsersDetails( 
			[FirstName],
			[LastName],
			[UserName],
			[Email],
			[AccountTYpe]
			--,[CreatedBy]
			--,[CreatedDate]
			) 

		  VALUES
		     (
			@FirstName,
			@LastName,
			@UserName,
			@Email,
			@AccountType
		     )

			 SET @Response='Registered Successfully'

			 SET @Id=SCOPE_IDENTITY();

			IF (@AccountType='HES')

				BEGIN
					INSERT INTO SJAcademics..StudentPersonalDetails (FirstName,LastName,Email,CreatedBy,CreatedDate)
					SELECT @FirstName,@LastName,@Email,@Id,GETDATE()
				END
		END

	ELSE

		BEGIN
			SET @Response='User Already Exists' 
		END 
END

 
GO


