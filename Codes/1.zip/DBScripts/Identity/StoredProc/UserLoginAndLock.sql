USE [SJIdentity]
GO

/****** Object:  StoredProcedure [dbo].[UserLoginAndLock]    Script Date: 18-05-2021 12:07:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER PROCEDURE [dbo].[UserLoginAndLock]
(
	@UserName NVARCHAR(50) =NULL,
	@EmailAddress	NVARCHAR(50)=NULL,
	@PasswordHash NVARCHAR(max)=NULL,
	@Count int=0,
	@AccessFailedCount int=0,
	@Response nvarchar(max)=NULL OUTPUT
)
AS
BEGIN

SET NOCOUNT ON;

	 IF Exists(SELECT 1 FROM UsersDetails WHERE Email=@EmailAddress AND PasswordHash=@PasswordHash)

		BEGIN

			SELECT UD.Email,PasswordHash,Salt,UserName,UD.Id as UserId,SPD.Id as StudentId
			FROM [SJIdentity].[dbo].[UsersDetails] UD WITH(NOLOCK)
			JOIN SJAcademics .. StudentPersonalDetails SPD WITH(NOLOCK)
			ON SPD.Id=UD.id
			WHERE  UD.Email=@EmailAddress
			SET @Response='Success'

		END

	ELSE 

		BEGIN
		
		SELECT @AccessFailedCount=ISNULL(AccessFailedCount,0) FROM UsersDetails WITH(NOLOCK)
		WHERE Email=@EmailAddress

		IF	(ISNULL(@AccessFailedCount,0)<4 )

		BEGIN

			UPDATE UsersDetails
			SET AccessFailedCount=ISNULL(AccessFailedCount,0)+1
			WHERE Email=@EmailAddress

			SET @Response='Login Failed' 
		END

		ELSE 

			BEGIN 

				UPDATE UsersDetails
				SET LockoutEnabled=1,
				AccessFailedCount=@AccessFailedCount+1
				WHERE Email=@EmailAddress

			SET @Response='Login Failed and Account Locked'

			END
		END
END
GO


