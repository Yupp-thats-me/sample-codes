USE [SJInternships]
GO

/****** Object:  Table [dbo].[UserProfileDetails]    Script Date: 19-09-2021 16:29:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[UserProfileDetails](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[InternshipId] [bigint] NULL,
	[StudentId] [bigint] NULL,
	[UploadDocument] [nvarchar](600) NULL,
	[DocumentTitle] [nvarchar](50) NULL,
	[KeySkills] [nvarchar](100) NULL,
	[ProbableJoiningDate] [datetime] NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[CreatedDate] [datetime] NULL,
	[IsStudentProfile] [bit] NULL,
	[StatusId] [int] NULL,
	[UpdatedBy] [nvarchar](50) NULL,
	[UpdatedDate] [datetime] NULL,
	[IsDisagreed] [bit] NULL,
	[DisagreedDate] [datetime] NULL,
	[DisagreedReason] [nvarchar](500) NULL
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[UserProfileDetails]  WITH CHECK ADD FOREIGN KEY([InternshipId])
REFERENCES [dbo].[InternshipDetails] ([Id])
GO

ALTER TABLE [dbo].[UserProfileDetails]  WITH CHECK ADD FOREIGN KEY([InternshipId])
REFERENCES [dbo].[InternshipDetails] ([Id])
GO


