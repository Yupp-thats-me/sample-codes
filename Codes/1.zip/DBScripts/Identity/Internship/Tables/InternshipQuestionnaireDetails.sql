USE [SJInternships]
GO

/****** Object:  Table [dbo].[InternshipQuestionnaireDetails]    Script Date: 7/12/2021 6:46:12 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[InternshipQuestionnaireDetails](
	[QuestionnaireId] [bigint] IDENTITY(1,1) NOT NULL,
	[InternshipId] [bigint] NULL,
	[Type] [int] NULL,
	[Questions] [nvarchar](500) NULL,
	[Options1] [nvarchar](100) NULL,
	[Options2] [nvarchar](100) NULL,
	[Options3] [nvarchar](100) NULL,
	[Options4] [nvarchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[QuestionnaireId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[InternshipQuestionnaireDetails]  WITH CHECK ADD  CONSTRAINT [FK__Internshi__Inter__2D27B809] FOREIGN KEY([InternshipId])
REFERENCES [dbo].[InternshipDetails] ([Id])
GO

ALTER TABLE [dbo].[InternshipQuestionnaireDetails] CHECK CONSTRAINT [FK__Internshi__Inter__2D27B809]
GO


