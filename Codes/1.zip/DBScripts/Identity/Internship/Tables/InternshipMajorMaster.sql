USE [SJInternships]
GO

/****** Object:  Table [dbo].[InternshipMajorMaster]    Script Date: 07-07-2021 18:14:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[InternshipMajorMaster](
	[MajorId] [bigint] IDENTITY(1,1) NOT NULL,
	[MajorValueEn] [nvarchar](100) NULL,
	[MajorValueAr] [nvarchar](100) NULL,
	[ParentId] [bigint] NULL,
	[IsActive] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[MajorId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[InternshipMajorMaster]  WITH CHECK ADD FOREIGN KEY([ParentId])
REFERENCES [dbo].[InternshipMajorMaster] ([MajorId])
GO


