USE [SJInternships]
GO

/****** Object:  Table [dbo].[UserFeedbackDetails]    Script Date: 10-08-2021 13:00:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[UserFeedbackDetails](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[InternshipId] [bigint] NULL,
	[Content] [int] NULL,
	[Design] [int] NULL,
	[Personalization] [int] NULL,
	[Functionality] [int] NULL,
	[CreatedBy] [nvarchar](100) NULL,
	[CreatedDate] [date] NULL,
	[StudentId] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[UserFeedbackDetails]  WITH CHECK ADD  CONSTRAINT [FK__UserFeedB__Inter__778AC167] FOREIGN KEY([InternshipId])
REFERENCES [dbo].[InternshipDetails] ([Id])
GO

ALTER TABLE [dbo].[UserFeedbackDetails] CHECK CONSTRAINT [FK__UserFeedB__Inter__778AC167]
GO


