USE [SJInternships]
GO

/****** Object:  Table [dbo].[AdminFeedbackRating]    Script Date: 10/4/2021 3:32:14 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AdminFeedbackRating](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[FeedbackId] [bigint] NOT NULL,
	[ParameterId] [bigint] NULL,
	[Rating] [int] NULL,
	[IsApplicable] [bit] NULL,
	[CreatedBy] [nvarchar](100) NULL,
	[CreatedDate] [date] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[AdminFeedbackRating]  WITH CHECK ADD  CONSTRAINT [FK_AdminFeedbackRating] FOREIGN KEY([FeedbackId])
REFERENCES [dbo].[AdminFeedbackDetails] ([FeedbackId])
GO

ALTER TABLE [dbo].[AdminFeedbackRating] CHECK CONSTRAINT [FK_AdminFeedbackRating]
GO


