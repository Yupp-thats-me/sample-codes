USE [SJInternships]
GO

/****** Object:  Table [dbo].[InternshipStatusMaster]    Script Date: 18-05-2021 13:47:51 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[InternshipStatusMaster](
	[StatusId] [bigint] IDENTITY(1,1) NOT NULL,
	[StatusNameEn] [nvarchar](100) NULL,
	[StatusNameAr] [nvarchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[StatusId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


