USE [SJInternships]
GO

/****** Object:  Table [dbo].[InternshipRoleMaster]    Script Date: 6/28/2021 6:53:49 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[InternshipRoleMaster](
	[InternshipRoleId] [int] IDENTITY(1,1) NOT NULL,
	[InternshipRoleNameEn] [nvarchar](100) NULL,
	[InternshipRoleNameAr] [nvarchar](100) NULL
) ON [PRIMARY]
GO


