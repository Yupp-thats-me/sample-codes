USE [SJInternships]
GO

/****** Object:  Table [dbo].[InternshipDetails]    Script Date: 12/7/2021 12:13:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[InternshipDetails](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[UploadImage] [nvarchar](600) NULL,
	[InternshipTitleEn] [nvarchar](50) NULL,
	[InternshipTitleAr] [nvarchar](50) NULL,
	[DescriptionEn] [nvarchar](max) NULL,
	[DescriptionAr] [nvarchar](max) NULL,
	[EligibilityEn] [nvarchar](max) NULL,
	[EligibilityAr] [nvarchar](max) NULL,
	[CountryId] [nvarchar](50) NULL,
	[EmirateId] [nvarchar](50) NULL,
	[HigherEducationId] [nvarchar](50) NULL,
	[GenderId] [int] NULL,
	[AgeId] [int] NULL,
	[JoiningDate] [datetime] NULL,
	[Duration] [nvarchar](50) NULL,
	[NumberOfPositionsId] [int] NULL,
	[MinimumHoursRequiredId] [int] NULL,
	[OrganizationLink] [nvarchar](100) NULL,
	[IndustryName] [nvarchar](100) NULL,
	[InternshipRoleNameEn] [nvarchar](100) NULL,
	[InternshipRoleNameAr] [nvarchar](100) NULL,
	[MonthlySalaryRangeId] [int] NULL,
	[HowToApplyEn] [nvarchar](max) NULL,
	[HowToApplyAr] [nvarchar](max) NULL,
	[ContactEmail] [nvarchar](50) NULL,
	[ExpiryDate] [datetime] NULL,
	[StatusId] [int] NULL,
	[OnBehalfOf] [int] NULL,
	[IsActive] [bit] NULL,
	[CreatedBy] [nvarchar](100) NULL,
	[CreatedDate] [datetime] NULL,
	[UpdatedBy] [nvarchar](100) NULL,
	[UpdatedDate] [datetime] NULL,
	[Reason] [nvarchar](500) NULL,
	[InternshipTypeId] [int] NULL,
	[MajorId] [nvarchar](50) NULL,
	[IsProbable] [bit] NULL,
	[LastProbableJoiningDate] [datetime] NULL,
	[InternshipFor] [int] NULL,
	[UserId] [bigint] NULL,
	[ApplicationDeadline] [datetime] NULL,
	[CompanyNameEn] [nvarchar](50) NULL,
	[CompanyNameAr] [nvarchar](50) NULL,
	[Stream] [nvarchar](70) NULL,
 CONSTRAINT [PK__Intershi__3214EC07D0C4DADA] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


