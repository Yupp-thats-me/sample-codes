USE [SJInternships]
GO

/****** Object:  StoredProcedure [dbo].[GetInternshipDetailsById]    Script Date: 07-07-2021 16:21:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE OR ALTER   PROC [dbo].[GetInternshipDetailsUserviewById]

@Id BIGINT = null  
  
AS  
BEGIN
  
SET NOCOUNT ON;   
  
SELECT    
 ID.Id,  
 CASE WHEN InternshipTitleEn IS NOT NULL 
 THEN InternshipTitleEn
 ELSE IRM1.InternshipRoleNameEn
 END AS InternshipTitleEn
,CASE WHEN InternshipTitleAr IS NOT NULL 
 THEN InternshipTitleAr
 ELSE IRM1.InternshipRoleNameAr 
 END AS InternshipTitleAr  
,EmirateId
,OrganizationLink  
,IDM1.DropdownValueEn AS IndustryNameEn  
,IDM1.DropdownValueAr AS IndustryNameAr  
,IRM1.InternshipRoleNameEn  
,IRM2.InternshipRoleNameAr  
,InternshipTypeId
,MinimumHoursRequiredId
,JoiningDate  
,IDM2.DropdownValueEn AS MonthlySalaryRangeEn  
,IDM2.DropdownValueAr AS MonthlySalaryRangeAr  
,Duration
,NumberOfPositionsId
,DescriptionEn  
,DescriptionAr  
,HigherEducationId
,IDM3.DropdownValueEn AS AgeEn  
,IDM3.DropdownValueAr As AgeAr  
,GenderId 
,CountryId
,EligibilityEn  
,EligibilityAr  
,HowToApplyEn  
,HowToApplyAr  
,ExpiryDate  
,LastProbableJoiningDate
,UploadImage 
,CompanyNameEn
,CompanyNameAr
,ApplicationDeadline
,UPD.StudentId
  
FROM SJInternships..InternshipDetails ID WITH(NOLOCK)  
JOIN SJInternships..InternshipDropdownMaster IDM1  
ON IDM1.DropdownId=ID.IndustryName   
JOIN SJInternships..InternshipDropdownMaster IDM2
ON IDM2.DropdownId=ID.MonthlySalaryRangeId   
JOIN SJInternships..InternshipDropdownMaster IDM3
ON IDM3.DropdownId=ID.AgeId   
JOIN SJInternships..InternshipRoleMaster IRM1  
ON IRM1.InternshipRoleId=ID.InternshipRoleNameEn  
JOIN SJInternships..InternshipRoleMaster IRM2  
ON IRM2.InternshipRoleId=ID.InternshipRoleNameAr  
LEFT JOIN  SJInternships..UserProfileDetails UPD
ON UPD.InternshipId = ID.Id

WHERE  ID.StatusId=3   
AND ID.Id=@Id  
ORDER BY ID.Id DESC  
END  
  
--EXEC [GetInternshipDetailsUserviewById] 393
GO


