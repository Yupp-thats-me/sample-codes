USE [SJInternships]
GO

/****** Object:  StoredProcedure [dbo].[GetStudentDetails]    Script Date: 26-08-2021 18:59:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER       PROC [dbo].[GetStudentDetails]  
  
@StudentId BIGINT = NULL,
@InternshipId BIGINT = NULL

AS

BEGIN  
 
       SET NOCOUNT ON;  

    SELECT 

     DISTINCT
	 UPD.Id
	,UPD.InternshipId
	,UPD.StudentId
	,CONCAT(PermanentAddressLine1,',
',PermanentAddressLine2,',
',PermanentZipCode,',
',PermanentCityName) AS PermanentAddressLine1
	,Email
	,MobileNo
	,Emirate
	,SPD.Filename
	,CASE WHEN UPD.IsStudentProfile = 1
	 THEN UPD.UploadDocument
	 ELSE DOC.FileName
	 END 
	 AS Resume 
	,CASE WHEN UPD.IsStudentProfile = 1
	 THEN UPD.Id
	 ELSE DOC.Id
	 END 
	 AS ResumeId
  FROM  SJInternships..UserProfileDetails UPD WITH(NOLOCK) 
  INNER JOIN SJAcademics..DocumentDetails DOC WITH(NOLOCK) 
  ON DOC.StudentId = UPD.StudentId
  INNER JOIN  SJAcademics..studentPersonalDetails SPD WITH(NOLOCK) 
  ON  UPD.StudentId = SPD.Id
  LEFT JOIN  SJInternships..UserAnswerDetails UAD WITH(NOLOCK) 
  ON UAD.StudentId = UPD.StudentId
  LEFT JOIN SJInternships..InternshipQuestionnaireDetails IQD WITH(NOLOCK) 
  ON IQD.QuestionnaireId = UAD.QuestionnaireId

  WHERE  UPD.StudentId = @StudentId AND UPD.InternshipId = @InternshipId

END  
GO
