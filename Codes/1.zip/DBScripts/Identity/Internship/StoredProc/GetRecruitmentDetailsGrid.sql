USE [SJInternships]
GO

/****** Object:  StoredProcedure [dbo].[GetRecruitmentDetailsGrid]    Script Date: 24-08-2021 14:05:02 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER     PROC [dbo].[GetRecruitmentDetailsGrid]  
  
AS  
  
BEGIN  
 
 SET NOCOUNT ON;  

 DECLARE @temp TABLE
(
	RowId INT Identity(1,1),
	Id bigint,
	EmirateId nvarchar(50),
	DropdownValueEn Nvarchar(200),
	DropdownValueAr nvarchar(1000)

)
DECLARE @temp2 table
		
		(
			RowId INT Identity(1,1),
			EmirateId nvarchar(100),
	        EmirateValueEn nvarchar(200),
	        EmirateValueAr nvarchar(200)
		)

INSERT INTO @temp (Id, EmirateId)
select Id, EmirateId from InternshipDetails


DECLARE @startcount int=1,
	    @endCount int;

SELECT @endCount = count(*) FROM @temp

WHILE (@startCount<=@endCount)
BEGIN
	DECLARE 
	      @EmirateId nvarchar(100),
	      @DropdownValueEn nvarchar(200),
		  @DropdownValueAr nvarchar(200),
	      @ResultEmirateEn nvarchar(200),
	      @ResultEmirateAR nvarchar(200)


	
	select @EmirateId=EmirateId from @temp where RowId=@startcount
	
 DELETE FROM @temp2
	INSERT INTO @temp2 (EmirateId)
	SELECT items FROM [SJScholarships].[dbo].[Split] (@EmirateId, ',')

    UPDATE @temp2 SET EmirateValueEn=CASE When EmirateId = DropdownId THEN DropdownValueEn END ,
	                 EmirateValueAr=CASE When EmirateId = DropdownId THEN DropdownValueAr END 
    FROM @temp2 AS T
	JOIN SJInternships..InternshipDropdownMaster IDM
	ON IDM.DropdownId=T.EmirateId

	set @ResultEmirateEn=''
	set @ResultEmirateAr=''

	SELECT @ResultEmirateEn = COALESCE( @ResultEmirateEn + ',' , '') + EmirateValueEn,
		   @ResultEmirateAr= COALESCE( @ResultEmirateAr + ',' , '') + EmirateValueAr
	FROM @temp2


	update @temp
	SET   DropdownValueEn = Stuff(@ResultEmirateEn, 1,1, ''),
		  DropdownValueAr =Stuff(@ResultEmirateAr, 1,1, '') 
	WHERE RowId=@startcount

 SET @startcount = @startCount+1


	
END


--select  * from @temp

    SELECT 
	  DISTINCT
	  ID.Id	
	 ,InternshipFor
     ,IRM1.InternshipRoleNameEn
	 ,IRM2.InternshipRoleNameAr
     ,ID.ExpiryDate  
     ,ID.InternshipTypeId
	 ,IDM.DropdownValueEn AS IndustryNameEn
	 ,IDM.DropdownValueAr AS IndustryNameAr
	 ,T.DropdownValueEn AS EmirateEn
	 ,T.DropdownValueAr AS EmirateAr
	 ,ID.EmirateId
     ,ID.IsActive  
     ,ID.CreatedBy  
     ,ID.CreatedDate  
     ,ID.UpdatedBy  
     ,ID.UpdatedDate  
       
    FROM   
    [dbo].InternshipDetails ID WITH(NOLOCK) 
	JOIN InternshipRoleMaster IRM1 WITH(NOLOCK)
	ON ID.InternshipRoleNameEn = IRM1.InternshipRoleId
	JOIN InternshipRoleMaster IRM2 WITH(NOLOCK)
	ON ID.InternshipRoleNameAr = IRM2.InternshipRoleId
	JOIN InternshipDropdownMaster IDM  WITH(NOLOCK)
	ON ID.IndustryName = IDM.DropdownId
	--INNER JOIN UserProfileDetails UPD WITH(NOLOCK)
	--ON UPD.InternshipId = ID.Id
	JOIN @temp T
	ON T.EmirateId = ID.EmirateId
    WHERE ID.IsActive=1 AND ID.StatusId = 3 AND
	ID.ExpiryDate >=  CAST( GETDATE() AS Date )
	ORDER BY CreatedDate DESC
 
  
END  

--EXEC [GetRecruitmentDetailsGrid]
  
  
GO


