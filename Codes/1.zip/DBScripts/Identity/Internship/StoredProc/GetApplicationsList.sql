USE [SJInternships]
GO

/****** Object:  StoredProcedure [dbo].[GetApplicationsList]    Script Date: 01-09-2021 16:56:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROC [dbo].[GetApplicationsList]  

@StudentId BIGINT = NULL
  
AS  
  
BEGIN  
 
 SET NOCOUNT ON;  

    SELECT 

	  UPD.Id
	 ,UPD.InternshipId AS UserInternshipId
     ,IRM1.InternshipRoleNameEn
	 ,IRM2.InternshipRoleNameAr
	 ,CompanyNameEn
	 ,CompanyNameAr 
	 ,UPD.StatusId 
     ,UPD.CreatedBy  
     ,UPD.CreatedDate  
	 ,UPD.UpdatedBy  
     ,UPD.UpdatedDate  
        
    FROM   
    [dbo].UserProfileDetails UPD  WITH(NOLOCK) 
	JOIN InternshipDetails ID WITH(NOLOCK)
	ON UPD.InternshipId = ID.Id
	JOIN InternshipRoleMaster IRM1 WITH(NOLOCK)
	ON ID.InternshipRoleNameEn = IRM1.InternshipRoleId
	JOIN InternshipRoleMaster IRM2 WITH(NOLOCK)
	ON ID.InternshipRoleNameAr = IRM2.InternshipRoleId 
	WHERE UPD.StudentId = @StudentId
	ORDER BY UPD.CreatedDate DESC
 
 
END  

--EXEC [GetApplicationsList] 122
  
  
 


GO


