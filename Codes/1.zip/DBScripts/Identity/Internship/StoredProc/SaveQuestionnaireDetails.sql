USE [SJInternships]
GO

/****** Object:  StoredProcedure [dbo].[SaveQuestionnaireDetails]    Script Date: 24-05-2021 13:59:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


 
 
CREATE OR ALTER   PROC [dbo].[SaveQuestionnaireDetails]

@ReferenceId		BIGINT NULL OUTPUT ,
@QuestionnaireId    BIGINT NULL,
@InternshipId       BIGINT NULL,
@Type               INT,
@Questions		    nVarchar(500),
@Options1		    nVarchar(200) = Null,
@Options2           nVarchar(200) = Null,
@Options3           nVarchar(200) = Null,
@Options4           nVarchar(200)  = Null


AS

BEGIN
  -- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

IF(ISNULL(@QuestionnaireId, 0) = 0) 
		BEGIN
			INSERT INTO
        [dbo].InternshipQuestionnaireDetails 
		(
		  InternshipId
         ,Type
         ,Questions
         ,Options1
         ,Options2
         ,Options3
         ,Options4
		 
		) 
      VALUES
         (
		  
		 @InternshipId
		,@Type
		,@Questions
		,@Options1
		,@Options2
		,@Options3
		,@Options4
		
         )
			SET @ReferenceId = SCOPE_IDENTITY();
END
	
ELSE
		BEGIN
			UPDATE 
			dbo.InternshipQuestionnaireDetails
			SET 
			InternshipId=@InternshipId,
			Type=@Type,
			Questions=@Questions,
			Options1=@Options1,
			Options2=@Options2,
			Options3=@Options3,
			Options4=@Options4
			
			WHERE QuestionnaireId=@QuestionnaireId

			SET @ReferenceId=@QuestionnaireId
		END

END
GO


