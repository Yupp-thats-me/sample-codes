USE [SJInternships]
GO

/****** Object:  StoredProcedure [dbo].[GetMajorMasterDetails]    Script Date: 07-07-2021 18:12:08 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetMajorMasterDetails]

AS  
BEGIN  
  
 SET NOCOUNT ON;  
 SELECT
 MajorId
,MajorValueEn
,MajorValueAr
,isnull(ParentId, 0) 'ParentID'
,IsActive
 FROM
 InternshipMajorMaster WITH(NOLOCK)   
 WHERE IsActive=1
 ORDER BY MajorValueEn ASC  
  
END 
GO


