CREATE OR ALTER  PROC [dbo].[GetDisagreedList]  
 
AS

BEGIN  
 
       SET NOCOUNT ON;  

  SELECT 

     UPD.Id
	,UPD.InternshipId
	,UPD.StudentId
	,CONCAT(FirstName,' ',LastName) AS StudentName
	,IRM1.InternshipRoleNameEn
	,IRM2.InternshipRoleNameAr
	,CompanyNameEn
	,CompanyNameAr 
    ,UPD.DisagreedDate
	,UPD.DisagreedReason
	,UPD.StatusId

  FROM  SJInternships..UserProfileDetails UPD WITH(NOLOCK) 
  JOIN  SJAcademics..studentPersonalDetails SPD WITH(NOLOCK) 
  ON SPD.Id = UPD.StudentId
  JOIN InternshipDetails ID WITH(NOLOCK)
  ON UPD.InternshipId = ID.Id
  JOIN InternshipRoleMaster IRM1 WITH(NOLOCK)
  ON ID.InternshipRoleNameEn = IRM1.InternshipRoleId
  JOIN InternshipRoleMaster IRM2 WITH(NOLOCK)
  ON ID.InternshipRoleNameAr = IRM2.InternshipRoleId 
  WHERE UPD.IsDisagreed=1
  ORDER BY UPD.CreatedDate DESC

END  
 


