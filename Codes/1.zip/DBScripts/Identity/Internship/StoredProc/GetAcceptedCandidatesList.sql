CREATE OR ALTER  PROC [dbo].[GetAcceptedCandidatesList]  
  
@InternshipId BIGINT = NULL

AS

BEGIN  
 
       SET NOCOUNT ON;  

  SELECT 

     UPD.Id
	,UPD.InternshipId
	,UPD.StudentId
	,CONCAT(FirstName,' ',LastName) AS StudentName
	,Email
	,MobileNo
	,UPD.ProbableJoiningDate
	,UPD.StatusId

  FROM  SJInternships..UserProfileDetails UPD WITH(NOLOCK) 
  JOIN  SJAcademics..studentPersonalDetails SPD WITH(NOLOCK) 
  ON SPD.Id = UPD.StudentId
  WHERE UPD.InternshipId = @InternshipId
  AND UPD.StatusId IN (9,12)
  AND UPD.ProbableJoiningDate = CAST( GETDATE() AS Date )
  ORDER BY UPD.CreatedDate DESC

END  
 


