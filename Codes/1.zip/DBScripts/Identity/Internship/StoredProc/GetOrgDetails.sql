USE [SJInternships]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetOrgDetails]    
   
AS        
BEGIN    
     
   SELECT DISTINCT 
   ID,CompanyNameEn,CompanyNameAr   
   FROM InternshipDetails WITH(NOLOCK)   
   WHERE IsActive=1 AND StatusId=3
   ORDER BY CompanyNameEn ASC     
   
END
GO