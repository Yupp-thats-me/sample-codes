 

CREATE OR ALTER PROCEDURE [dbo].[SaveIsActiveInternshipById]

@Id					BIGINT NULL

AS 
BEGIN
	SET NOCOUNT ON;
      BEGIN

         UPDATE InternshipDetails SET IsActive = 0
	     WHERE Id = @Id
	
      END
END
GO


