USE [SJInternships]
GO

/****** Object:  StoredProcedure [dbo].[GetInternshipDropdownDetails]    Script Date: 18-05-2021 13:14:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetInternshipDropdownDetails]    
   
AS    
    
BEGIN    
     
   SELECT   
    DropdownId  
   ,DropdownValueEn  
   ,DropdownValueAr  
   ,Category  
   ,IsActive   
   FROM InternshipDropdownMaster WITH(NOLOCK)   
   WHERE IsActive=1
   ORDER BY DropdownValueEn ASC  
   
   
END
GO


