USE [SJInternships]
GO

/****** Object:  StoredProcedure [dbo].[SaveApplyDetails]    Script Date: 10-08-2021 13:13:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE OR ALTER   PROCEDURE [dbo].[SaveApplyDetails]  
@ReferenceId BIGINT NULL OUTPUT ,  
@Id BIGINT, 
@InternshipId BIGINT = NULL,
@StudentId BIGINT = NULL,
@Content INT,  
@Design INT,  
@Personalization INT, 
@Functionality INT,
@UploadDocument  nvarchar(600) = NULL,
@DocumentTitle nvarchar(50) = NULL,  
@KeySkills nvarchar(100) = NULL, 
@ProbableJoiningDate DATETIME = null,
@IsStudentProfile BIT = NULL,
@CreatedBy nvarchar(50) = NULL,
@CreatedDate DATETIME = NULL,
@StatusId INT = NULL
  
AS  
  
BEGIN  
   
  SET NOCOUNT ON;  
  
IF(ISNULL(@Id, 0) = 0)  
  BEGIN  

INSERT INTO  
[dbo].UserFeedbackDetails  
(  
  InternshipId
 ,StudentId
 ,Content
 ,Design
 ,Personalization
 ,Functionality
 ,CreatedBy  
 ,CreatedDate   
)  
VALUES  
(
 @InternshipId
,@StudentId
,@Content
,@Design
,@Personalization
,@Functionality
,@CreatedBy  
,GETUTCDATE() 
)  
SET @ReferenceId = SCOPE_IDENTITY();  
  END  

  BEGIN
INSERT INTO  
[dbo].UserProfileDetails
(  
  InternshipId
 ,StudentId
 ,UploadDocument
 ,DocumentTitle
 ,KeySkills
 ,ProbableJoiningDate
 ,IsStudentProfile
 ,CreatedBy  
 ,CreatedDate   
 ,StatusId
)  
VALUES  
(
  @InternshipId
 ,@StudentId
 ,@UploadDocument
 ,@DocumentTitle
 ,@KeySkills
 ,@ProbableJoiningDate
 ,@IsStudentProfile
 ,@CreatedBy  
 ,GETUTCDATE() 
 ,@StatusId
)  
SET @ReferenceId = SCOPE_IDENTITY();  
END
   
  
END



GO


	