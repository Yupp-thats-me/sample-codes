CREATE OR ALTER  PROCEDURE [dbo].[GetQuestionAnswerDetails]
@Id Bigint = null,
@StudentId Bigint = null

AS

BEGIN
 
SET NOCOUNT ON;

SELECT   IQD.InternshipId  
        ,IQD.QuestionnaireId
		,IQD.Type
		,IQD.Questions
		,IQD.Options1
		,IQD.Options2
		,IQD.Options3
		,IQD.Options4
		,UAD.Answers
		
FROM	[SJInternships].[dbo].[InternshipQuestionnaireDetails] IQD WITH(NOLOCK)
INNER JOIN [SJInternships].[dbo].[InternshipDetails] ID WITH(NOLOCK) ON ID.Id=IQD.InternshipId
LEFT JOIN [SJInternships].[dbo].UserAnswerDetails UAD WITH(NOLOCK) ON IQD.QuestionnaireId=UAD.QuestionnaireId
WHERE	((ID.Id=@Id OR @Id IS NULL)) AND UAD.StudentId = @StudentId
ORDER BY IQD.QuestionnaireId

END

--EXEC [GetQuestionAnswerDetails] 411,146
 


