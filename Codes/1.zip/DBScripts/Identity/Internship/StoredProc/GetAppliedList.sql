USE [SJInternships]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROC [dbo].[GetAppliedList]  

AS
BEGIN  
 
  SET NOCOUNT ON;  

  SELECT 

     UPD.Id
	,UPD.InternshipId
	,IRM1.InternshipRoleNameEn
	,IRM2.InternshipRoleNameAr
	,ID.CompanyNameEn
	,ID.CompanyNameAr
	,UPD.StudentId
	,CONCAT(FirstName,' ',LastName) AS StudentName
    ,UPD.CreatedDate
	,DATEADD(HOUR,48,UPD.CreatedDate) AS CutoffDate
	,UPD.StatusId
	,CASE WHEN DATEADD(HOUR,48,UPD.CreatedDate)<GETDATE() THEN 'ALLOW' ELSE 'DENY'  END AS CutOffReturn

  FROM  SJInternships..UserProfileDetails UPD WITH(NOLOCK) 
  JOIN  SJAcademics..studentPersonalDetails SPD WITH(NOLOCK) 
  ON SPD.Id = UPD.StudentId
  JOIN SJInternships..InternshipDetails ID WITH(NOLOCK)
  ON ID.Id=UPD.InternshipId
  JOIN SJInternships..InternshipRoleMaster IRM1 WITH(NOLOCK)
  ON IRM1.InternshipRoleId=ID.InternshipRoleNameEn
  JOIN SJInternships..InternshipRoleMaster IRM2 WITH(NOLOCK)
  ON IRM2.InternshipRoleId=ID.InternshipRoleNameAr
  WHERE ID.ExpiryDate > GETDATE() 
  AND UPD.IsDisagreed IS NULL
  ORDER BY IRM1.InternshipRoleNameEn

END  
GO


