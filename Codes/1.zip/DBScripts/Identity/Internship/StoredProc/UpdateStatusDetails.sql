USE [SJInternships]
GO

/****** Object:  StoredProcedure [dbo].[UpdateStatusDetails]    Script Date: 04-09-2021 16:07:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROC [dbo].[UpdateStatusDetails]
 
@Id	BIGINT NULL,
@StatusId  INT=NULL,
@UpdatedBy NVARCHAR(50) = NULL,
@UpdatedDate DATETIME =  NULL

AS

BEGIN
 
	SET NOCOUNT ON;
 
			UPDATE 
			dbo.UserProfileDetails
			SET
			StatusId = @StatusId,
			UpdatedBy = @UpdatedBy,
			UpdatedDate = GETUTCDATE() 
			WHERE Id=@Id

 
END
GO


