USE [SJInternships]
GO

/****** Object:  StoredProcedure [dbo].[GetQuestionnaireDetails]    Script Date: 24-05-2021 14:01:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER  PROCEDURE [dbo].[GetQuestionnaireDetails]
@Id Bigint = null

AS

BEGIN
 
SET NOCOUNT ON;

SELECT   IQD.InternshipId  
        ,IQD.QuestionnaireId
		,IQD.Type
		,IQD.Questions
		,IQD.Options1
		,IQD.Options2
		,IQD.Options3
		,IQD.Options4
		
FROM	[SJInternships].[dbo].[InternshipQuestionnaireDetails] IQD WITH(NOLOCK)
INNER JOIN [SJInternships].[dbo].[InternshipDetails] ID WITH(NOLOCK) ON ID.Id=IQD.InternshipId
WHERE	((ID.Id=@Id OR @Id IS NULL))
ORDER BY IQD.QuestionnaireId

END
GO


