USE [SJInternships]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROC [dbo].[UpdateDisagreeDetails]
 
@Id	BIGINT NULL,
@UpdatedBy NVARCHAR(50) = NULL,
@UpdatedDate DATETIME =  NULL,
@IsDisagreed BIT=NULL,
@DisagreedDate DATETIME =  NULL,
@DisagreedReason NVARCHAR(500) = NULL

AS

BEGIN
 
	SET NOCOUNT ON;
 
			UPDATE 
			dbo.UserProfileDetails
			SET
			UpdatedBy = @UpdatedBy,
			UpdatedDate = GETUTCDATE(),
			IsDisagreed=@IsDisagreed,
			DisagreedDate= GETUTCDATE(),
			DisagreedReason=@DisagreedReason
			WHERE Id=@Id

 
END
GO


