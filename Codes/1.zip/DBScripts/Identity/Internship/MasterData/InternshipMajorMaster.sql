﻿USE [SJInternships]
GO
INSERT INTO [InternshipMajorMaster]
     ( [MajorValueEn]
      ,[MajorValueAr]
      ,[ParentId]
      ,[IsActive])
VALUES
     ('Agriculture, Forestry, Fisheries & Veterinary',N'الزراعة والغابات ومصايد الأسماك والبيطرية ',NULL,1),
	 ('Arts & Humanities',N'الفنون والعلوم الإنسانية ',NULL,1),
	 ('Business, Administration and Law',N'الأعمال والإدارة والقانون',NULL,1),
	 ('Education',N'تعليم',NULL,1),
	 ('Engineering, Manufacturing & Construction',N'الهندسة والتصنيع والبناء ',NULL,1),
	 ('Health & Welfare',N'الصحة والرعاية الاجتماعية',NULL,1),
	 ('Information and Communication Technologies',N'تكنولوجيا المعلومات والاتصالات ',NULL,1),
	 ('Natural Sciences, Mathematics & Statistics',N'العلوم الطبيعية والرياضيات والإحصاء ',NULL,1),
	 ('Services',N'خدمات ',NULL,1),
	 ('Social Sciences, Journalism & Information',N'العلوم الاجتماعية والصحافة والإعلام ',NULL,1),
	 ('Agribusiness',N'الصناعات الزراعيه',1,1),
	 ('Horticulture',N'البستنه ',1,1),
	 ('Acting ',N'يتصرف ',2,1),
	 ('Art & Design ',N'الفن والتصميم',2,1),
	 ('Accounting',N'محاسبة ',3,1),
	 ('Accounting & Finance',N'المحاسبة والمالية',3,1),
	 ('Arabic & Islamic Studies Teaching',N'تدريس اللغة العربية والدراسات الإسلامية ',4,1),
	 ('Architectural Engineering',N'الهندسة المعمارية',5,1),
	 ('Anesthetics',N'المسكنات',6,1),
	 ('Artificial Intelligence',N'الذكاء الاصطناعي',7,1),
	 ('Actuarial Studies',N'الدراسات الاكتوارية',8,1),
	 ('Aviation Management',N'إدارة الطيران',9,1),
	 ('Anthropology',N'الانثروبولوجيا',10,1)
GO
