USE [SJInternships]
GO

INSERT INTO [dbo].[InternshipStatusMaster]
           ([StatusNameEn]
      ,[StatusNameAr])
     VALUES
           ('Draft',NULL),
		   ('Pending Approval',NULL),
		   ('Approved',NULL),
		   ('Rejected',NULL)
GO