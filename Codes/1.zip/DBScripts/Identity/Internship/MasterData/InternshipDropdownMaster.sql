﻿USE [SJInternships]
GO
INSERT INTO InternshipDropdownMaster ([DropdownValueEn]
      ,[DropdownValueAr]
      ,[Category]
      ,[IsActive])
VALUES
     ('HEI Admin',N'إدارة HEI','OnBehalfOf',1),
     ('Employer Admin',N'مسؤول صاحب العمل','OnBehalfOf',1),
     ('General User',N'مستخدم عام','OnBehalfOf',1),
     ('MOE Admin',N'وزارة التربية والتعليم','OnBehalfOf',1),
     ('Part-Time',N'دوام جزئى','InternshipType',1),
     ('Full-Time',N'وقت كامل','InternshipType',1),
     ('Afghanistan',N'أفغانستان','Country',1),
     ('Albania',N'ألبانيا','Country',1),
     ('Abu Dhabi',N'أبو ظبي','Emirate',1),
	 ('Ajman',N'عجمان','Emirate',1),
	 ('Bachelors',N'البكالوريوس','HigherEducation',1),
	 ('Masters',N'سادة','HigherEducation',1),
	 ('Vocational',N'مهني','HigherEducation',1),
	 ('18+',N'18+','Age',1),
	 ('Unpaid',N'غير مدفوعة','MonthlySalary',1),
	 ('AED 0 - 1000',N'0 - 1000 درهم إماراتي','MonthlySalary',1),
	 ('AED 1000 - 2000',N'1000 - 2000 درهم إماراتي','MonthlySalary',1),
	 ('Objective',N' هدف','QuestionnaireType',1),
	 ('Subjective',N' شخصي','QuestionnaireType',1),
	 ('PhD',N'دكتوراه','HigherEducation',1),
	 ('Accounting & Consulting',N'محاسبة واستشارات','Industry',1),
	 ('Agriculture',N'زراعة','Industry',1)

GO
	


