USE [SJIdentity]
GO

/****** Object:  Table [dbo].[UsersDetails]    Script Date: 18-05-2021 11:45:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[UsersDetails](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[AccessFailedCount] [int] NULL,
	[ConcurrencyStamp] [nvarchar](max) NULL,
	[Email] [nvarchar](256) NULL,
	[EmailConfirmed] [bit] NULL,
	[LockoutEnabled] [bit] NULL,
	[LockoutEnd] [datetimeoffset](7) NULL,
	[NormalizedEmail] [nvarchar](256) NULL,
	[NormalizedUserName] [nvarchar](256) NULL,
	[PasswordHash] [nvarchar](max) NULL,
	[PhoneNumber] [nvarchar](max) NULL,
	[PhoneNumberConfirmed] [bit] NULL,
	[SecurityStamp] [nvarchar](max) NULL,
	[TwoFactorEnabled] [bit] NULL,
	[UserName] [nvarchar](256) NULL,
	[Salt] [nvarchar](max) NULL,
	[FirstName] [nvarchar](50) NULL,
	[MiddleName] [nvarchar](50) NULL,
	[LastName] [nvarchar](50) NULL,
	[Gender] [nvarchar](10) NULL,
	[AddressL1] [nvarchar](100) NULL,
	[AddressL2] [nvarchar](100) NULL,
	[POBoxNumber] [nvarchar](100) NULL,
	[Emirate] [nvarchar](50) NULL,
	[MobileNo] [bigint] NULL,
	[PhoneNo] [nvarchar](50) NULL,
	[PhoneCode] [nvarchar](10) NULL,
	[Residency] [nvarchar](10) NULL,
	[EmirateId] [nvarchar](50) NULL,
	[CountryId] [nvarchar](50) NULL,
	[PassportNo] [nvarchar](50) NULL,
	[DocumentNo] [nvarchar](50) NULL,
	[QuestionId] [nvarchar](10) NULL,
	[QuestionAns] [nvarchar](500) NULL,
	[InstituteName] [nvarchar](500) NULL,
	[EducationalZone] [nvarchar](500) NULL,
	[LicenseNumber] [nvarchar](50) NULL,
	[LicenseExpDate] [datetime] NULL,
	[EducationalActivities] [nvarchar](500) NULL,
	[CXOcompanyName] [nvarchar](500) NULL,
	[CXOEmployerCatgory] [nvarchar](500) NULL,
	[CXOEmployeeId] [nvarchar](500) NULL,
	[CXOEmployerZone] [nvarchar](500) NULL,
	[CXOLicenseNumber] [nvarchar](500) NULL,
	[CXOLicenseExpiryDate] [datetime] NULL,
	[EmployerName] [nvarchar](500) NULL,
	[EmployerEmpId] [nvarchar](500) NULL,
	[EmployerCatgory] [nvarchar](500) NULL,
	[EmployerZone] [nvarchar](500) NULL,
	[EmpLicenseNumber] [nvarchar](500) NULL,
	[EmpLicenseExpiryDate] [datetime] NULL,
	[AccountTYpe] [nvarchar](10) NULL,
 CONSTRAINT [PK_UsersDetails] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


ALTER TABLE SJIdentity..UsersDetails
ADD CreatedOn DATETIME

