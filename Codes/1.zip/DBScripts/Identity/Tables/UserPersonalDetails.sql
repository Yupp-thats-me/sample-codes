USE [SJIdentity]
GO

/****** Object:  Table [dbo].[UserPersonalDetails]    Script Date: 18-05-2021 13:37:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[UserPersonalDetails](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[UserId] [nvarchar](450) NOT NULL,
	[AccountTypeId] [int] NOT NULL,
	[FirstName] [nvarchar](50) NOT NULL,
	[MiddleName] [nvarchar](50) NULL,
	[LastName] [nvarchar](50) NOT NULL,
	[Gender] [nvarchar](10) NOT NULL,
	[MobileNo] [int] NOT NULL,
	[PhoneNo] [int] NULL,
	[Address] [nvarchar](500) NULL,
	[ResidencyTypeId] [int] NOT NULL,
	[UAEEmirateId] [int] NULL,
	[EmirateId] [int] NULL,
	[CountryId] [int] NULL,
	[PassportNumber] [int] NULL,
	[DocumentNumber] [int] NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[UpdatedBy] [nvarchar](100) NULL,
	[UpdatedDate] [datetime] NULL,
 CONSTRAINT [PK_PersonalDetailId] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[UserPersonalDetails]  WITH CHECK ADD  CONSTRAINT [FK_UserPersonalDetails_Countries] FOREIGN KEY([CountryId])
REFERENCES [dbo].[Countries] ([Id])
GO

ALTER TABLE [dbo].[UserPersonalDetails] CHECK CONSTRAINT [FK_UserPersonalDetails_Countries]
GO

ALTER TABLE [dbo].[UserPersonalDetails]  WITH CHECK ADD  CONSTRAINT [FK_UserPersonalDetails_Emirates] FOREIGN KEY([UAEEmirateId])
REFERENCES [dbo].[UAEEmirates] ([Id])
GO

ALTER TABLE [dbo].[UserPersonalDetails] CHECK CONSTRAINT [FK_UserPersonalDetails_Emirates]
GO

ALTER TABLE [dbo].[UserPersonalDetails]  WITH CHECK ADD  CONSTRAINT [FK_UserPersonalDetails_ResidencyTypes] FOREIGN KEY([ResidencyTypeId])
REFERENCES [dbo].[ResidencyTypes] ([Id])
GO

ALTER TABLE [dbo].[UserPersonalDetails] CHECK CONSTRAINT [FK_UserPersonalDetails_ResidencyTypes]
GO

ALTER TABLE [dbo].[UserPersonalDetails]  WITH CHECK ADD  CONSTRAINT [FK_UserPersonalDetails_UAEEmirates] FOREIGN KEY([UAEEmirateId])
REFERENCES [dbo].[UAEEmirates] ([Id])
GO

ALTER TABLE [dbo].[UserPersonalDetails] CHECK CONSTRAINT [FK_UserPersonalDetails_UAEEmirates]
GO

ALTER TABLE [dbo].[UserPersonalDetails]  WITH CHECK ADD  CONSTRAINT [FK_UserPersonalDetails_UserAccountTypes] FOREIGN KEY([AccountTypeId])
REFERENCES [dbo].[UserAccountTypes] ([Id])
GO

ALTER TABLE [dbo].[UserPersonalDetails] CHECK CONSTRAINT [FK_UserPersonalDetails_UserAccountTypes]
GO

ALTER TABLE [dbo].[UserPersonalDetails]  WITH CHECK ADD  CONSTRAINT [FK_UserPersonalDetails_Users] FOREIGN KEY([UserId])
REFERENCES [dbo].[Users] ([Id])
GO

ALTER TABLE [dbo].[UserPersonalDetails] CHECK CONSTRAINT [FK_UserPersonalDetails_Users]
GO


