USE [SJInternships]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROC [dbo].[GetCounselorFeedbackReceived]  

AS
BEGIN  
 
  SET NOCOUNT ON;  
		
  SELECT  

     SFD.StudentFeedbackId
	,SFD.InternshipId
	,ID.CompanyNameEn
	,ID.CompanyNameAr
	,SFD.Department
	,IRM1.InternshipRoleNameEn
	,IRM2.InternshipRoleNameAr
	,StudentId
	,CONCAT(US.FirstName,' ',US.LastName) AS StudentName
	,US.Email
	,US.PhoneNumber

  FROM  SJInternships..StudentFeedbackDetails SFD WITH(NOLOCK) 
  JOIN SJIdentity..[User] US WITH(NOLOCK)
  ON SFD.StudentId=US.Id
  JOIN SJInternships..InternshipDetails ID WITH(NOLOCK)
  ON ID.Id=SFD.InternshipId
  JOIN SJInternships..InternshipRoleMaster IRM1 WITH(NOLOCK)
  ON ID.InternshipRoleNameEn=IRM1.InternshipRoleId
  JOIN SJInternships..InternshipRoleMaster IRM2 WITH(NOLOCK)
  ON ID.InternshipRoleNameAr=IRM2.InternshipRoleId
  --WHERE HEI=@HEI
  --Where SFD.EmployerId=198
  	ORDER BY (
	CASE WHEN UpdatedDate IS NULL THEN ID.CreatedDate ELSE UpdatedDate END
	) DESC
END  
GO

