USE [SJInternships]
GO
/****** Object:  StoredProcedure [dbo].[GetAdminFeedback]    Script Date: 10/9/2021 6:47:12 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER  PROCEDURE [dbo].[GetStudentFeedback]  

       
  @Id BIGINT = NULL
  
AS  
  
BEGIN  
 
 SET NOCOUNT ON;
 SELECT
	 UPD.InternshipId
	,UPD.StudentId
    ,UPD.CreatedDate
	,UPD.StatusId
	,CONCAT(SPD.FirstName,' ',SPD.LastName) AS StudentName
	,SPD.Email
	,CONCAT(SPD.PermanentAddressLine1,' ',SPD.PermanentAddressLine1) AS PermanentAddressLine1
	,INM.InstituteNameEn AS Institute
	,MM.ElementNameEn AS MajorId
	,IRM.InternshipRoleNameEn
	 ,CONCAT(UD.FirstName,' ',UD.LastName) AS EmployerName
	 ,CONCAT(UD.AddressL1,' ',UD.AddressL2) AS Location
	 ,UD.AccountTYpe
	 ,ID.MinimumHoursRequiredId
     ,SFD.StudentFeedbackId
     ,SFR.ParameterId
     ,SFR.Rating
     ,SFR.IsApplicable
     ,SFD.InternshipId 
     ,SFD.StudentId  
     ,SFD.Term
     ,SFD.EmployerId
     ,SFD.SupervisorName 
     ,SFD.SupervisorDesignation 
     ,SFD.SupervisorEmailId
     ,SFD.AnyFeedback
	 ,ID.UserId

  FROM  SJInternships..UserProfileDetails UPD WITH(NOLOCK) 
  JOIN  SJAcademics..studentPersonalDetails SPD WITH(NOLOCK) 
  ON SPD.Id = UPD.StudentId
  LEFT JOIN SJIdentity..[EducationalDetails] DD WITH(NOLOCK)
  ON SPD.ID = DD.UserId
  LEFT JOIN SJIdentity..InstituteMasters INM
  ON DD.Institute= INM.InstituteId
  LEFT JOIN [SJIdentity]..[Elements] MM
  ON MM.Id = DD.MajorId   
  LEFT JOIN SJInternships..InternshipDetails ID WITH(NOLOCK)
  ON UPD.InternshipId = ID.Id
  LEFT JOIN SJInternships..InternshipRoleMaster IRM
  ON ID.InternshipRoleNameEn = IRM.InternshipRoleId
    JOIN SJIdentity..UsersDetails UD WITH(NOLOCK)
  ON UD.Id=ID.UserId
  LEFT JOIN SJInternships..StudentFeedbackDetails SFD
  ON SFD.InternshipId = UPD.InternshipId   
  LEFT JOIN SJInternships..StudentFeedbackRating SFR
  ON SFD.StudentFeedbackId = SFR.StudentFeedbackId 


  Where UPD.Id=@Id

  END

