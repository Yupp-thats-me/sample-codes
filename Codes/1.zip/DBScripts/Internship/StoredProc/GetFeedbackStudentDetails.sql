USE [SJInternships]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER  PROC [dbo].[GetFeedbackStudentDetails]  

@StudentFeedbackId BIGINT = NULL

AS


BEGIN  
 
       SET NOCOUNT ON;  


  SELECT 

     UPD.Id
	,UPD.InternshipId
	,UPD.StudentId   
	,CONCAT(US.FirstName,' ',US.LastName) AS StudentName
	--,SPD.Email
	,CONCAT(US.FirstName,' ',US.LastName) AS StudentName
	,US.Email
	,US.PermanentAddress AS StudentLocation
	,IM.InstituteNameEn as Institute
	,MM.ElementNameEn AS MajorEn 
	,MM.ElementNameAr As MajorAr
	,IRM.InternshipRoleNameEn
	,IRM.InternshipRoleNameAr
	,CASE WHEN MonthlySalaryRangeId = 24
	 THEN  1 
	 ELSE  0
	 END 
	 AS MonthlySalaryRangeId 
	--,MonthlySalaryRangeId
	, U.Id AS EmployerId
	 ,CONCAT(U.FirstName,' ',U.LastName) AS EmployerName
	 ,CONCAT(US.CurrentAddress,' ',US.PermanentAddress) As Location
	 ,MinimumHoursRequiredId
	 ,Duration
	 ,JoiningDate
	 ,Term
	 ,Department
	 ,SupervisorName
	 ,SupervisorDesignation
	 ,SupervisorEmailId
	 ,AnyFeedback
	 ,ISP.CreatedBy
	 ,SFD.StudentFeedbackId
	 ,SFD.CreatedDate

  FROM  SJInternships..UserProfileDetails UPD WITH(NOLOCK) 
  JOIN  SJIdentity..[User] US WITH(NOLOCK) 
  ON US.Id = UPD.StudentId
  JOIN SJIdentity..[EducationalDetails] DD WITH(NOLOCK)
  ON US.Id = DD.UserId  
  JOIN SJIdentity..InstituteMasters IM
  ON DD.InstituteId= IM.Id
  JOIN SJInternships..InternshipDetails ISP WITH(NOLOCK)
  ON UPD.InternshipId = ISP.Id
  JOIN SJInternships..InternshipRoleMaster IRM
  ON ISP.InternshipRoleNameEn = IRM.InternshipRoleId
  JOIN [SJIdentity]..[Elements] MM  
  ON MM.Id = DD.MajorId  
  JOIN SJIdentity..[User] U WITH(NOLOCK)  
  ON cast(U.ID as nvarchar)= ISP.CreatedBy  
  JOIN SJInternships..StudentFeedbackDetails SFD WITH(NOLOCK)
  ON SFD.InternshipId=UPD.InternshipId
  AND SFD.StudentId=UPD.StudentId

  WHERE SFD.StudentFeedbackId=@StudentFeedbackId

  --Exec GetFeedbackStudentDetails 39

END 
  


