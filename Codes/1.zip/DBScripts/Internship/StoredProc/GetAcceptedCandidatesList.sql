CREATE OR ALTER  PROC [dbo].[GetAcceptedCandidatesList]  
  
@InternshipId BIGINT = NULL

AS

BEGIN  
 
       SET NOCOUNT ON;  

  SELECT 

     UPD.Id
	,UPD.InternshipId
	,UPD.StudentId
	,CONCAT(FirstName,' ',LastName) AS StudentName
	,Email
	,PhoneNumber As MobileNo
	,UPD.ProbableJoiningDate
	,UPD.StatusId

  FROM  SJInternships..UserProfileDetails UPD WITH(NOLOCK) 
  JOIN  SJIdentity..[User] US WITH(NOLOCK) 
  ON US.Id = UPD.StudentId
  WHERE UPD.InternshipId = @InternshipId
  AND UPD.StatusId IN (9,12)
  AND UPD.ProbableJoiningDate = CAST( GETDATE() AS Date )
  ORDER BY UPD.CreatedDate DESC

END  
 

 -- exec GetAcceptedCandidatesList 10496
