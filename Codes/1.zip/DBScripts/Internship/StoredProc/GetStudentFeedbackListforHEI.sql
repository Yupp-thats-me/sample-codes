CREATE OR ALTER    PROC [dbo].[GetStudentFeedbackListforHEI]  


AS  

BEGIN  

 SELECT 
      ID.CompanyNameEn
	 ,ID.CompanyNameAr
	 ,AFD.Department
     ,IRM1.InternshipRoleNameEn
	 ,IRM2.InternshipRoleNameAr
	 ,CONCAT(US.FirstName,' ',US.LastName) AS StudentName
	 ,US.Email
	 ,US.PhoneNumber As MobileNo
	 ,AFD.InternshipId
	 ,AFD.FeedbackId
	 ,AFD.StudentId
	FROM
	[dbo].InternshipDetails ID WITH(NOLOCK) 
	JOIN InternshipRoleMaster IRM1 WITH(NOLOCK)
	ON ID.InternshipRoleNameEn = IRM1.InternshipRoleId
	JOIN InternshipRoleMaster IRM2 WITH(NOLOCK)
	ON ID.InternshipRoleNameAr = IRM2.InternshipRoleId
	JOIN AdminFeedbackDetails AFD WITH(NOLOCK)
	ON AFD.InternshipId = ID.Id
    JOIN  SJIdentity..[User] US WITH(NOLOCK) 
    ON US.Id = AFD.StudentId

  
  
END  

--EXEC [GetStudentFeedbackListforHEI] 
  
   

GO


