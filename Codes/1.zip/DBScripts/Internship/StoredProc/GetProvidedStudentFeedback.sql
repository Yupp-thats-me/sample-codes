USE [SJInternships]
GO
/****** Object:  StoredProcedure [dbo].[GetProvidedStudentFeedback]    Script Date: 13-04-2022 09:04:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER   PROC [dbo].[GetProvidedStudentFeedback]  
  
@StudentId BIGINT = NULL,@CreatedBy nvarchar(100) = NULL

AS

BEGIN  
 
       SET NOCOUNT ON;  
	   Declare @CompletionDate Date,@Duration Nvarchar(max),@ProbableJoiningDate Datetime,@CutOffDate DateTime,@InternshipId Bigint
	   Select @ProbableJoiningDate=UPD.ProbableJoiningDate from UserProfileDetails UPD
	   Select @Duration=ID.Duration from InternshipDetails  ID   
	   JOIN SJInternships..UserProfileDetails UPD
	   ON ID.Id = UPD.InternshipId  WHERE UPD.StudentId=@StudentId

  SELECT 

	 SFD.InternshipId
	,SFD.StudentId
    ,SFD.CreatedDate
	,IRM.InternshipRoleNameEn
	,IRM.InternshipRoleNameAr
	,CompanyNameEn
	,CompanyNameAr
	,Duration
	,SFD.CreatedBy
	,UPD.ProbableJoiningDate
	,DATEADD(WEEK,CAST(ID.Duration AS int),UPD.ProbableJoiningDate) AS CompletionDate
	,DATEADD(WEEK, 1,DATEADD(WEEK,CAST(ID.Duration AS int),UPD.ProbableJoiningDate)) AS CutOffDate
	,SFD.Department
	,SFD.SupervisorDesignation
	,SFD.StudentFeedbackId

    FROM  SJInternships..UserProfileDetails UPD WITH(NOLOCK) 
    LEFT JOIN  SJAcademics..DegreeDetails DD WITH(NOLOCK) 
    ON DD.StudentId = UPD.StudentId AND UPD.StatusId=11
 	JOIN SJInternships..StudentFeedbackDetails SFD
	ON SFD.StudentId=UPD.StudentId AND SFD.InternshipId=UPD.InternshipId
    JOIN SJInternships..InternshipDetails ID 
    ON SFD.InternshipId = ID.Id
	JOIN SJInternships..InternshipRoleMaster IRM
    ON ID.InternshipRoleNameEn = IRM.InternshipRoleId


  WHERE SFD.StudentId = @StudentId AND SFD.CreatedBy=@CreatedBy
  AND DATEADD(WEEK,CAST(ID.Duration AS int),UPD.ProbableJoiningDate) < GETDATE()
  AND DATEADD(WEEK, 1,DATEADD(WEEK,CAST(ID.Duration AS int),UPD.ProbableJoiningDate)) > GETDATE()
  	ORDER BY (
	CASE WHEN UPD.UpdatedDate IS NULL THEN UPD.CreatedDate ELSE UPD.UpdatedDate END
	) DESC

 

END  
