USE [SJInternships]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER PROC [dbo].[UpdateExpiryList]  
 (
  @Id BIGINT  NULL
 ,@ExpiryDate DATETIME  NULL
 --,@UpdatedBy NVARCHAR(200)  NULL
 --,@UpdatedDate DATETIME  NULL
 )
AS

BEGIN  
 
       SET NOCOUNT ON;  

  UPDATE SJInternships..InternshipDetails SET
	  ExpiryDate=@ExpiryDate
	 --,UpdatedBy=@UpdatedBy
	 --,UpdatedDate=GETDATE()
	 
	 WHERE Id=@Id
	 	 
END  
 


