USE [SJInternships]
GO
/****** Object:  StoredProcedure [dbo].[GetAdminFeedbackDetails]    Script Date: 10/11/2021 6:09:18 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER  PROC [dbo].[GetFeedbackDetails]  


@InternshipId BIGINT = NULL,@StudentId BIGINT = NULL

AS


BEGIN  
 
       SET NOCOUNT ON;  


  SELECT 

     UPD.Id
	,UPD.InternshipId
	,UPD.StudentId
    ,UPD.CreatedDate
	,CONCAT(SPD.FirstName,' ',SPD.LastName) AS StudentName
	,SPD.Email
	,CONCAT(PermanentAddressLine1,' ',PermanentAddressLine2) AS StudentLocation
	,IM.InstituteNameEn as Institute  
	,MM.ElementNameEn AS MajorId
	,IRM.InternshipRoleNameEn
	,IRM.InternshipRoleNameAr
	,MonthlySalaryRangeId
	, UD.Id AS UserId
	 ,CONCAT(UD.FirstName,' ',UD.LastName) AS EmployerName
	 ,CONCAT(AddressL1,' ',AddressL2) AS Location
	 ,AccountTYpe
	 ,MinimumHoursRequiredId
	 ,Duration
	 ,JoiningDate
	 ,ISP.CreatedBy
	 ,Term
	 ,Department
	 ,SupervisorDesignation
	 ,SupervisorName
	 ,SupervisorEmailId

	

  FROM  SJInternships..UserProfileDetails UPD WITH(NOLOCK) 
  JOIN  SJAcademics..studentPersonalDetails SPD WITH(NOLOCK) 
  ON SPD.Id = UPD.StudentId
  JOIN SJIdentity..[EducationalDetails] DD WITH(NOLOCK)
   ON SPD.Id = DD.UserId  
  JOIN SJIdentity..InstituteMasters IM  
    ON DD.InstituteId= IM.Id  
  JOIN SJInternships..InternshipDetails ISP WITH(NOLOCK)
  ON UPD.InternshipId = ISP.Id
  JOIN SJInternships..InternshipRoleMaster IRM
  ON ISP.InternshipRoleNameEn = IRM.InternshipRoleId
  JOIN SJAcademics..MajorMaster MM
  ON MM.MajorId = DD.MajorId 
  JOIN SJIdentity..UsersDetails UD WITH(NOLOCK)
  ON UD.ID= ISP.CreatedBy
  LEFT JOIN SJInternships..AdminFeedbackDetails AFD
  ON AFD.InternshipId= UPD.InternshipId


  WHERE UPD.InternshipId = @InternshipId AND UPD.StudentId =@StudentId

END 
  

