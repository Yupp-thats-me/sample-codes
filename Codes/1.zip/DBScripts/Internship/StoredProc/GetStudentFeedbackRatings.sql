USE [SJInternships]
GO
/****** Object:  StoredProcedure [dbo].[GetAdminFeedbackRatings]    Script Date: 10/11/2021 7:01:39 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER    PROCEDURE [dbo].[GetStudentFeedbackRatings]
@Id Bigint = null

AS

BEGIN
 
SET NOCOUNT ON;

SELECT   
  
		 DropdownId
		,DropdownValueEn
		,DropdownValueAr
        		
		
FROM	[SJInternships].[dbo].[InternshipDropdownMaster] IDM WITH (NOLOCK)


Where Category='StudentFeedback' 


END


 


