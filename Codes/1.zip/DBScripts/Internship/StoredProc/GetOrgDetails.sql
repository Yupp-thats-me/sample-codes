﻿USE [SJInternships]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetOrgDetails]    
   
AS        
BEGIN    
     
    SELECT Id, CompanyNameEn,CompanyNameAr FROM InternshipDetails WITH(NOLOCK)
	WHERE Id IN (
    SELECT MIN(Id)
    FROM InternshipDetails
    GROUP BY CompanyNameEn )
	ORDER BY CompanyNameEn ASC
     
END
GO