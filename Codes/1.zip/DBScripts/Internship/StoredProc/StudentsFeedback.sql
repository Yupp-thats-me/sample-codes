CREATE OR ALTER PROC [dbo].[StudentsFeedback]
(
  @StartDate datetime = null,
  @EndDate datetime = null,
  @EducationCategory int = 0,
  @EducationLevel int = 0,
  @CompanyName NVARCHAR(50)=null
)
AS
BEGIN
if @CompanyName='null' 
begin
set @CompanyName=null 
end

SET NOCOUNT ON;
	
SELECT 
(U.FirstName + ' ' + U.LastName) AS StudentName, 
I.CompanyNameEn,
I.CompanyNameAr,
U.InstituteId, 
EL.ElementNameEn As MajorEn,
EL.ElementNameAr As MajorAr, 
S.SupervisorName, 
S.SupervisorDesignation, 
I.JoiningDate as DateofInternship, 
IRM.InternshipRoleNameEn As InternshipRoleEn,
IRM.InternshipRoleNameAr As InternshipRoleAr,
INS.InstituteNameEn, 
INS.InstituteNameAr,
S.AnyFeedBack AS AnyFeedBackForEmployer,


SUM(CASE WHEN rating.ParameterId = 70 THEN rating.Rating ELSE 0 END) as EmployerOrientation,
SUM(CASE WHEN rating.ParameterId = 71 THEN rating.Rating ELSE 0 END) as TaskAssinged,
SUM(CASE WHEN rating.ParameterId = 72 THEN rating.Rating ELSE 0 END) as Employerliaise,
SUM(CASE WHEN rating.ParameterId = 74 THEN rating.Rating ELSE 0 END) as EmployerAgreeplan,
SUM(CASE WHEN rating.ParameterId = 75 THEN rating.Rating ELSE 0 END) as EmployerConductInterview,
SUM(CASE WHEN rating.ParameterId = 76 THEN rating.Rating ELSE 0 END) as ClearWhoYourManager,
SUM(CASE WHEN rating.ParameterId = 77 THEN rating.Rating ELSE 0 END) as SupervisorPerformance,
SUM(CASE WHEN rating.ParameterId = 78 THEN rating.Rating ELSE 0 END) as SupervisorTeamMeeting,
SUM(CASE WHEN rating.ParameterId = 79 THEN rating.Rating ELSE 0 END) as Exceptation,
SUM(CASE WHEN rating.ParameterId = 80 THEN rating.Rating ELSE 0 END) as RecommendEmployer,
SUM(CASE WHEN rating.ParameterId = 81 THEN rating.Rating ELSE 0 END) as OverallRating,
SUM(CASE WHEN rating.ParameterId = 81 AND InternshipFor= 1 THEN rating.Rating ELSE 0 END ) as GeneralSatisfactory,
SUM(CASE WHEN rating.ParameterId = 81 AND InternshipFor= 2 THEN rating.Rating ELSE 0 END ) as HigherSatisfactory


from 
StudentFeedbackDetails S

	INNER JOIN InternshipDetails I ON I.Id = S.InternshipId
	INNER JOIN [SJIdentity]..[User] U ON U.Id = S.StudentId
	INNER JOIN SJIdentity..EducationalDetails ED On ED.UserId=U.Id
    INNER JOIN SJIdentity..Elements EL ON EL.Id=ED.MajorId
	INNER JOIN [SJIdentity]..InstituteMasters INS on INS.Id = U.InstituteId
	INNER JOIN StudentFeedbackRating rating on S.StudentFeedbackId = rating.StudentFeedbackId
    INNER JOIN InternshipRoleMaster IRM ON I.InternshipRoleNameEn= IRM.InternshipRoleId
	JOIN InternshipDropdownMaster IDM ON Cast(IDM.DropdownId as nvarchar)=I.HigherEducationId

WHERE 
cast(S.CreatedDate as date) Between cast(@StartDate as date) AND cast(@EndDate as date)
		AND (@EducationCategory = 0 OR ED.EducationCategoryId=@EducationCategory)
		AND (@EducationLevel = 0 OR @EducationLevel = ED.EducationLevelId)
		AND (@CompanyName is null or I.CompanyNameEn=@CompanyName)

GROUP BY 
(U.FirstName + ' ' + U.LastName), 
U.InstituteId,
EL.ElementNameEn,
EL.ElementNameAr,
S.SupervisorName,
S.SupervisorDesignation, 
I.JoiningDate , 
IRM.InternshipRoleId, 
I.CompanyNameEn, 
I.CompanyNameAr,
IRM.InternshipRoleNameEn, 
IRM.InternshipRoleNameAr,
INS.InstituteNameEn, 
INS.InstituteNameAr,
EL.ElementNameEn, 
EL.ElementNameAr,
I.InternshipFor,
IDM.DropdownValueEn,
S.AnyFeedback

END

--select * from StudentFeedbackDetails 
--EXEC StudentsFeedback '2021-12-01','2022-04-29',1,35,'null'
--EXEC StudentsFeedback '2021-12-12','2022-04-29',2,30,null

--select * from SJIdentity..Elements


