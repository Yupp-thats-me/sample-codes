USE [SJInternships]
GO

/****** Object:  StoredProcedure [dbo].[GetUpdateList]    Script Date: 29-09-2021 23:37:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER         PROC [dbo].[GetUpdateList]    
    
@InternshipId BIGINT = NULL  
  
AS  
  
BEGIN    
   
       SET NOCOUNT ON;    
  
  SELECT   
  
  UPD.Id  
 ,UPD.InternshipId  
 ,UPD.StudentId  
 ,UPD.CreatedDate  
 ,CONCAT(FirstName,' ',LastName) AS StudentName  
 ,StatusId  
 ,CASE WHEN StatusId =4   THEN 1  
  ELSE 0  
  END AS Withdrawn  
 ,CASE WHEN StatusId = 11 OR StatusId = 9 OR StatusId = 10 OR StatusId = 8 OR  
  StatusId = 6 OR StatusId = 7 OR StatusId = 2 OR StatusId = 5 THEN 1  
  ELSE 0  
  END AS Shortlisted  
 ,CASE WHEN StatusId = 3  THEN 1  
  ELSE 0  
  END AS Rejected  
 ,CASE WHEN StatusId = 11 OR StatusId = 9 OR StatusId = 10 OR StatusId = 8 OR   
  StatusId = 7 OR StatusId = 5 THEN 1  
  ELSE 0  
  END AS Interviewed  
 ,CASE WHEN StatusId = 11 OR StatusId = 9 OR StatusId = 10 OR StatusId = 8 OR   
  StatusId = 7 OR StatusId = 5 THEN 1  
  ELSE 0  
  END AS IsInterviewed 
 ,CASE WHEN StatusId = 6  THEN 1  
  ELSE 0  
  END AS DroppedOut  
 ,CASE WHEN StatusId = 6  THEN 1  
  ELSE 0  
  END AS IsDroppedOut 
 ,CASE WHEN StatusId = 11 OR StatusId = 9 OR StatusId = 10 OR StatusId = 7 THEN 1  
  ELSE 0  
  END AS Offered  
 ,CASE WHEN StatusId = 8    THEN 1  
  ELSE 0  
  END AS ScreenedOut  
 ,CASE WHEN StatusId = 10  THEN 1  
  ELSE 0  
  END AS Declined  
 ,CASE WHEN StatusId =  11 OR StatusId = 9 THEN 1  
  ELSE 0  
  END AS Accepted  
 ,CASE WHEN StatusId =  11  THEN 1  
  ELSE 0  
  END AS Hired  
    
  FROM  SJInternships..UserProfileDetails UPD WITH(NOLOCK)   
  JOIN  SJIdentity..[User] US WITH(NOLOCK)   
  ON US.Id = UPD.StudentId  
  WHERE UPD.InternshipId = @InternshipId  
  
END    
   
  -- exec GetUpdateList 10496
  
GO


