USE [SJInternships]
GO

/****** Object:  StoredProcedure [dbo].[GetCandidatesListGrid]    Script Date: 26-08-2021 18:59:35 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER       PROC [dbo].[GetCandidatesListGrid]  
  
@InternshipId BIGINT = NULL

AS

BEGIN  
 
       SET NOCOUNT ON;  

  SELECT 

     UPD.Id
	,UPD.InternshipId
	,UPD.StudentId
    ,UPD.CreatedDate
	,CONCAT(FirstName,' ',LastName) AS StudentName
	,Email
	,PhoneNumber As MobileNo
	,UPD.StatusId
	,IRM1.InternshipRoleNameEn
	,IRM2.InternshipRoleNameAr

  FROM  SJInternships..UserProfileDetails UPD WITH(NOLOCK) 
  JOIN  SJIdentity..[User] US WITH(NOLOCK) 
  ON US.Id = UPD.StudentId
  JOIN SJInternships..InternshipDetails ID WITH(NOLOCK) 
  ON ID.id=UPD.InternshipId
  JOIN SJInternships..InternshipRoleMaster IRM1 WITH(NOLOCK) 
  ON IRM1.InternshipRoleId=ID.InternshipRoleNameEn
  JOIN SJInternships..InternshipRoleMaster IRM2 WITH(NOLOCK) 
  ON IRM2.InternshipRoleId=ID.InternshipRoleNameAr
  WHERE UPD.InternshipId = @InternshipId

END  
GO


