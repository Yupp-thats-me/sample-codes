USE [SJInternships]
GO
/****** Object:  StoredProcedure [dbo].[GetRatingsAdmin]    Script Date: 10/12/2021 12:34:04 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER PROCEDURE [dbo].[GetRatingsStudent]
@StudentFeedbackId Bigint = null,@InternshipId bigint = null

AS

BEGIN
 
SET NOCOUNT ON;

SELECT   
          Id
		,SFR.StudentFeedbackId
		,ParameterId
		,Rating
		,DropdownValueEn
		,DropdownValueAr
		


FROM [SJInternships].[dbo].[StudentFeedbackDetails] SFD WITH (NOLOCK)
JOIN    [SJInternships].[dbo].[StudentFeedbackRating] SFR 
ON SFD.StudentFeedbackId=SFR.StudentFeedbackId
RIGHT JOIN    [SJInternships].[dbo].[InternshipDropdownMaster] IDM 
ON IDM.DropdownId=SFR.ParameterId



Where Category='StudentFeedback' AND SFR.StudentFeedbackId=@StudentFeedbackId

END