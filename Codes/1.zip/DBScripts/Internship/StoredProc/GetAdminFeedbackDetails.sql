CREATE OR ALTER   PROC [dbo].[GetAdminFeedbackDetails]    
  
  
@InternshipId BIGINT = NULL  
,@StudentId BIGINT = NULL  
  
AS  
  
  
BEGIN    
   
       SET NOCOUNT ON;    
  
  
  SELECT   
  
  UPD.Id  
 ,UPD.InternshipId  
 ,UPD.StudentId  
 ,UPD.CreatedDate  
 ,CONCAT(US.FirstName,' ',US.LastName) AS StudentName  
 ,US.Email  
 ,US.CurrentAddress AS StudentLocation  
 ,IM.InstituteNameEn as Institute  
 ,MM.ElementNameEn AS MajorEn   
 ,MM.ElementNameAr As MajorAr  
 ,IRM.InternshipRoleNameEn  
 ,IRM.InternshipRoleNameAr 
 ,CASE WHEN MonthlySalaryRangeId = 24
     THEN  1 
	 ELSE  0
	 END 
	 AS MonthlySalaryRangeId 
 --,MonthlySalaryRangeId  
 ,U.Id AS UserId  
 ,CONCAT(U.FirstName,' ',U.LastName) AS EmployerName  
 ,US.PermanentAddress As Location  
 -- ,US.RequestedRole As AccountTYpe  
 ,MinimumHoursRequiredId  
 ,Duration  
 ,JoiningDate  
 ,ISP.CreatedBy  
   
  FROM  SJInternships..UserProfileDetails UPD WITH(NOLOCK)   
  JOIN  SJIdentity..[User] US WITH(NOLOCK)   
  ON US.Id = UPD.StudentId  
  JOIN SJIdentity..[EducationalDetails] DD WITH(NOLOCK)  
  ON US.Id = DD.UserId  
  JOIN SJIdentity..InstituteMasters IM  
  ON DD.InstituteId= IM.Id  
  JOIN SJInternships..InternshipDetails ISP WITH(NOLOCK)  
  ON UPD.InternshipId = ISP.Id  
  JOIN SJInternships..InternshipRoleMaster IRM  
  ON ISP.InternshipRoleNameEn = IRM.InternshipRoleId  
  JOIN [SJIdentity]..[Elements] MM  
  ON MM.Id = DD.MajorId  
  JOIN SJIdentity..[User] U WITH(NOLOCK)  
  ON cast(U.ID as nvarchar)= ISP.CreatedBy  
  
  
  WHERE UPD.InternshipId = @InternshipId AND UPD.StudentId = @StudentId  
  
-- EXEC GetAdminFeedbackDetails 10538,41  
  
END

 
 