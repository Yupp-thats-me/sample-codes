USE [SJInternships]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER  PROC [dbo].[GetProvidedAdminFeedback]  


@InternshipId BIGINT = NULL,@CreatedBy nvarchar(100) = NULL
AS


BEGIN  
 
       SET NOCOUNT ON;  


  SELECT 

     UPD.Id
	,UPD.InternshipId
	,UPD.StudentId
    ,UPD.CreatedDate
	,CONCAT(US.FirstName,' ',US.LastName) AS StudentName
	,US.Email
	,US.PhoneNumber As MobileNo
	,AFD.CreatedBy
	,AFD.FeedbackId
	

  FROM  SJInternships..UserProfileDetails UPD WITH(NOLOCK) 
  JOIN  SJIdentity..[User] US WITH(NOLOCK) 
  ON US.Id = UPD.StudentId
  JOIN SJInternships..AdminFeedbackDetails AFD WITH(NOLOCK)
  ON US.Id= AFD.StudentId
  AND  AFD.InternshipId=UPD.InternshipId


  WHERE UPD.InternshipId =@InternshipId AND AFD.CreatedBy=@CreatedBy and StatusId=11
  	ORDER BY (
	CASE WHEN UpdatedDate IS NULL THEN UPD.CreatedDate ELSE UpdatedDate END
	) DESC

  -- Exec GetProvidedAdminFeedback 10487,2

END 
  





