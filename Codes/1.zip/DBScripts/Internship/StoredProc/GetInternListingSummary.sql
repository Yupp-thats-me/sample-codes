USE [SJInternships]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER  PROCEDURE [dbo].[GetInternListingSummary]  
    
(
@StartDate DateTime = NULL,
@EndDate DateTime = NULL,
@PostedBy int = 0,
@InternRole nvarchar(70)=NULL
)  
 
AS

if @InternRole='null'
begin
set @InternRole=null
end
  
BEGIN  
 Declare @Type1 BIGINT,@Type2 BIGINT,@Type3 BIGINT,@Type4 BIGINT,@Type5 BIGINT

 set @Type1=(Select count(id)from InternshipDetails where CreatedDate Between @StartDate AND @EndDate)
 set @Type2=(Select count(id)from InternshipDetails where InternshipTypeId=3 and CreatedDate Between @StartDate AND @EndDate)
 set @Type3=(select Top 1 (CompanyNameEn) from InternshipDetails where  CreatedDate Between @StartDate AND @EndDate)
 set @Type4=(select count(id)from InternshipDetails where InternshipFor=1 and CreatedDate Between @StartDate AND @EndDate)
 set @Type5=(select count(id)from InternshipDetails where InternshipFor=2 and CreatedDate Between @StartDate AND @EndDate)
 
 SET NOCOUNT ON;

 SELECT
  Id.CompanyNameEn As CompanyNameEn
 ,Id.CompanyNameAr As CompanyNameAr
 ,Id.InternshipTitleEn As InternshipTitleEn
 ,Id.InternshipTitleAr As InternshipTitleAr
 ,IRM.InternshipRoleNameEn As InternshipRoleEn
 ,IRM.InternshipRoleNameAr As InternshipRoleAr
 ,Id.NumberOfPositionsId As NumberofPositions
 ,Id.InternshipTypeId As InternshipType
 ,IDD.DropdownValueEn As Industry
 ,ID.Stream As StudentsMajor
 ,ID.InternshipFor As EducationCategory
 ,IDM.DropdownValueEn As Education
 ,ID.CreatedDate As PostedDate
 ,ID.ApplicationDeadline As ApplicationDeadline
 ,Id.JoiningDate As StartDate
 ,Id.Duration As InternshipDuration
 ,Id.ExpiryDate As EndDate
 ,@Type1 As TotalInternshipPosted
 ,@Type2 As TotalFullTimePosted
 ,@Type3 As MostInternshipByCompany
 ,@Type4 As TotalGeneralPosted
 ,@Type5 As TotalHigherPosted
 
 From InternshipDetails ID 
 JOIN SJIdentity..[User] U
 On U.Id=ID.CreatedBy
 JOIN InternshipRoleMaster IRM
 ON ID.InternshipRoleNameEn= IRM.InternshipRoleId
 JOIN InternshipDropdownMaster IDM
 ON CAST(IDM.DropdownId AS nvarchar)=ID.HigherEducationId
 JOIN InternshipDropdownMaster IDD
 ON IDD.DropdownId=ID.IndustryName

 WHERE ID.CreatedDate Between @StartDate AND @EndDate

  
	AND (@PostedBy = 0 or (U.RequestedRole = @PostedBy))
    AND (@InternRole is Null or IRM.InternshipRoleId=@InternRole Or IRM.InternshipRoleId=@InternRole)
	ORDER BY (
	CASE WHEN UpdatedDate IS NULL THEN ID.CreatedDate ELSE UpdatedDate END
	) DESC

 END

 -- exec [GetInternListingSummary] '2022-04-01 00:00:00.000','2022-04-29 00:00:00.000',4,'1929'
  -- exec [GetInternListingSummary] '2022-04-01 00:00:00.000','2022-04-29 00:00:00.000',4,null


