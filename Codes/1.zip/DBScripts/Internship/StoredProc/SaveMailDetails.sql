USE [SJInternships]
GO

/****** Object:  StoredProcedure [dbo].[SaveMailDetails]    Script Date: 21-10-2021 19:11:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER   PROCEDURE [dbo].[SaveMailDetails]
(
    @ReferenceId BIGINT NULL OUTPUT ,  
    @Id BIGINT,
	@StudentId BIGINT = NULLigint ,
	@InternshipId BIGINT = NULL,
	@FromEmail nvarchar(500)=NULL,
	@ToEmail nvarchar(500)=NULL,
	@CcEmail nvarchar(500)=NULL,
	@Subject nvarchar(500)=NULL,
	@EmailContent nvarchar(500)=NULL,
	@Attachment nvarchar(500)=NULL,
	@Status nvarchar(500)=NULL,
	@CreatedBy nvarchar(20)=NULL	
)
AS
BEGIN
  SET NOCOUNT ON; 
 IF ISNULL(@Id, 0) = 0
  BEGIN
    INSERT INTO MailTracking(
  StudentId,
  InternshipId, 
  FromEmail,
  ToEmail,
  CcEmail,
  [Subject],
  EmailContent,
  Attachment,
  [Status],
  CreatedBy,
  CreatedDate
 )
  values
  (
    @StudentId,
    @InternshipId ,
	@FromEmail,
    @ToEmail,
	@CcEmail,
	@Subject,
    @EmailContent,
	@Attachment,
    @Status,
    @CreatedBy,
	GETUTCDATE()
	)
	   SET @ReferenceId = SCOPE_IDENTITY(); 
  END
END


GO


