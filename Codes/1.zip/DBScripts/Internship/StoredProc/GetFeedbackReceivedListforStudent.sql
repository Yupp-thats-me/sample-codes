USE [SJInternships]
GO

/****** Object:  StoredProcedure [dbo].[GetFeedbackReceivedListforStudent]    Script Date: 12-10-2021 18:32:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER    PROC [dbo].[GetFeedbackReceivedListforStudent]  

@StudentId BIGINT = NULL

AS  

BEGIN  

 SELECT 
      IRM1.InternshipRoleNameEn
	 ,IRM2.InternshipRoleNameAr
	 ,AFD.CreatedDate
	 ,ID.CompanyNameEn
	 ,ID.CompanyNameAr
	 ,AFD.Department
	 ,AFD.SupervisorDesignation
	 ,AFD.InternshipId
	 ,AFD.FeedbackId
	 ,AFD.StudentId

	FROM
	[dbo].InternshipDetails ID WITH(NOLOCK) 
	JOIN InternshipRoleMaster IRM1 WITH(NOLOCK)
	ON ID.InternshipRoleNameEn = IRM1.InternshipRoleId
	JOIN InternshipRoleMaster IRM2 WITH(NOLOCK)
	ON ID.InternshipRoleNameAr = IRM2.InternshipRoleId
	JOIN AdminFeedbackDetails AFD WITH(NOLOCK)
	ON AFD.InternshipId = ID.Id
    WHERE StudentId = @StudentId
	ORDER BY (
	CASE WHEN UpdatedDate IS NULL THEN ID.CreatedDate ELSE UpdatedDate END
	) DESC

  
  
END  

--EXEC [GetFeedbackReceivedListforStudent] 148
  
   

GO

 


