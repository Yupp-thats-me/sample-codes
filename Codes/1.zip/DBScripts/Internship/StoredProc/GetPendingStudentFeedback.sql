USE [SJInternships]
GO
/** Object:  StoredProcedure [dbo].[GetPendingAdminFeedback]    Script Date: 10/12/2021 12:24:48 PM **/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROC [dbo].[GetPendingStudentFeedback]  
 
@StudentId BIGINT = NULL
AS
BEGIN  
 	   Declare @CompletionDate Date,@Duration Nvarchar(max),@ProbableJoiningDate Datetime,@CutOffDate DateTime,@InternshipId Bigint
	   Select @ProbableJoiningDate=UPD.ProbableJoiningDate from UserProfileDetails UPD
	   Select @Duration=ID.Duration from InternshipDetails  ID   
	   JOIN SJInternships..UserProfileDetails UPD
	   ON ID.Id = UPD.InternshipId  WHERE UPD.StudentId=@StudentId 

  SELECT 
	 UPD.InternshipId
	,UPD.StudentId
    ,UPD.CreatedDate
	,IRM.InternshipRoleNameEn
	,IRM.InternshipRoleNameAr
	,ID.CompanyNameEn
	,ID.CompanyNameAr
	,ID.Duration 
	,UPD.CreatedBy
	,UPD.ProbableJoiningDate
	,DATEADD(WEEK,CAST(ID.Duration AS int),UPD.ProbableJoiningDate) AS CompletionDate
	,DATEADD(WEEK, 1,DATEADD(WEEK,CAST(ID.Duration AS int),UPD.ProbableJoiningDate)) AS CutOffDate
	,AFD.Department
	,AFD.SupervisorDesignation

  FROM  SJInternships..UserProfileDetails UPD WITH(NOLOCK) 
  JOIN  SJIdentity..[User] US WITH(NOLOCK) 
  ON US.Id = UPD.StudentId AND UPD.StudentId = @StudentId  AND UPD.StatusId=11
  JOIN SJInternships..InternshipDetails ID WITH(NOLOCK)
  ON UPD.InternshipId = ID.Id
  JOIN SJInternships..InternshipRoleMaster IRM
  ON ID.InternshipRoleNameEn = IRM.InternshipRoleId
  JOIN SJInternships..AdminFeedbackDetails AFD
  ON AFD.StudentId=UPD.StudentId AND AFD.InternshipId=UPD.InternshipId
  AND DATEADD(WEEK,CAST(ID.Duration AS int),UPD.ProbableJoiningDate) < GETDATE()
  AND DATEADD(WEEK, 1,DATEADD(WEEK,CAST(ID.Duration AS int),UPD.ProbableJoiningDate)) > GETDATE()
  WHERE AFD.InternshipId NOT IN ( SELECT InternshipId FROM SJInternships..StudentFeedbackDetails where StudentId=@StudentId)
  	ORDER BY (
	CASE WHEN ID.UpdatedDate IS NULL THEN ID.CreatedDate ELSE ID.UpdatedDate END
	) DESC
 


 -- Exec GetPendingStudentFeedback 13


 

END