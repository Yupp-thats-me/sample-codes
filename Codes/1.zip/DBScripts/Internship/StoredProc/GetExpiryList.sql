USE [SJInternships]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER PROC [dbo].[GetExpiryList]  
 (
 @UserId NVARCHAR(50) = NULL
 )
AS

BEGIN  
 
       SET NOCOUNT ON;  

  SELECT 

      ID.Id
	 ,ID.CreatedDate	 
	 ,IRM1.InternshipRoleNameEn
	 ,IRM2.InternshipRoleNameAr
	 ,ID.ExpiryDate

	 FROM SJInternships..InternshipDetails ID
	 JOIN InternshipRoleMaster IRM1 WITH(NOLOCK)
	 ON ID.InternshipRoleNameEn = IRM1.InternshipRoleId
	 JOIN InternshipRoleMaster IRM2 WITH(NOLOCK)
	 ON ID.InternshipRoleNameAr = IRM2.InternshipRoleId 
	 WHERE ID.CreatedBy=@UserId AND
	 ID.ExpiryDate BETWEEN GETDATE() and DATEADD(dd,7,GETDATE())
	 ORDER BY ExpiryDate,CreatedDate
	 	 
END  
 


