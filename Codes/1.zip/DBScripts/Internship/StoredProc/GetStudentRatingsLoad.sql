USE [SJInternships]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE OR ALTER    PROCEDURE [dbo].[GetStudentRatingsLoad]
@DropdownId Bigint = null

AS

BEGIN
 
SET NOCOUNT ON;

SELECT   

		 DropdownId
		,DropdownValueEn
		,DropdownValueAr
        		
		
FROM	[SJInternships].[dbo].[InternshipDropdownMaster] IDM WITH (NOLOCK)

Where Category='StudentFeedback' AND (DropdownId=@DropdownId OR @DropdownId IS NULL)

END




