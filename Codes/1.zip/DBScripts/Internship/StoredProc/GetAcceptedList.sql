USE [SJInternships]
GO

/****** Object:  StoredProcedure [dbo].[GetAcceptedList]    Script Date: 09-09-2021 13:55:45 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER   PROC [dbo].[GetAcceptedList]  

@StudentId BIGINT = NULL
  
AS  
  
BEGIN  
 
 SET NOCOUNT ON;  

    SELECT 

	  UPD.Id
	 ,UPD.InternshipId AS UserInternshipId
     ,IRM1.InternshipRoleNameEn
	 ,IRM2.InternshipRoleNameAr
	 ,CompanyNameEn
	 ,CompanyNameAr 
	 ,UPD.StatusId 
     ,UPD.CreatedBy  
     ,UPD.CreatedDate  
	 ,UPD.UpdatedBy  
     ,UPD.UpdatedDate  
	 ,UPD.ProbableJoiningDate AS LastProbableJoiningDate
        
    FROM   
    [dbo].UserProfileDetails UPD  WITH(NOLOCK) 
	JOIN InternshipDetails ID WITH(NOLOCK)
	ON UPD.InternshipId = ID.Id
	JOIN InternshipRoleMaster IRM1 WITH(NOLOCK)
	ON ID.InternshipRoleNameEn = IRM1.InternshipRoleId
	JOIN InternshipRoleMaster IRM2 WITH(NOLOCK)
	ON ID.InternshipRoleNameAr = IRM2.InternshipRoleId 
	WHERE UPD.StudentId = @StudentId
	AND UPD.StatusId = 9
	AND UPD.ProbableJoiningDate = CAST( GETDATE() AS Date )
	ORDER BY UPD.CreatedDate DESC
 
 
END  

--EXEC GetAcceptedList 13
  
 


GO


