USE [SJInternships]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



CREATE OR ALTER   PROCEDURE [dbo].[SaveStudentFeedbackDetails]  
@ReferenceId BIGINT NULL OUTPUT , 
@StudentFeedbackId BIGINT, 
@InternshipId INT = NULL,  
@StudentId INT= NULL, 
@Term INT = NULL,
@EmployerId INT= NULL,
@Department nvarchar (100),
@SupervisorName nvarchar(100),
@SupervisorDesignation nvarchar(100),
@SupervisorEmailId nvarchar(100),
@AnyFeedback nvarchar(250)= NULL,
@CreatedBy nvarchar(30) = NULL,
@CreatedDate DATETIME = NULL

  
AS
  
BEGIN  
   
  SET NOCOUNT ON;  
  
IF(ISNULL(@StudentFeedbackId, 0) = 0)  
  BEGIN  

INSERT INTO  
[dbo].StudentFeedbackDetails
(  

 InternshipId 
,StudentId  
,Term 
,EmployerId
,Department
,SupervisorName 
,SupervisorDesignation 
,SupervisorEmailId
,AnyFeedback
,CreatedBy  
,CreatedDate   
)  
VALUES  
(
@InternshipId  
,@StudentId
,@Term 
,@EmployerId 
,@Department
,@SupervisorName 
,@SupervisorDesignation 
,@SupervisorEmailId 
,@AnyFeedback
,@CreatedBy  
,GETUTCDATE() 
)  
SET @ReferenceId = SCOPE_IDENTITY();  
  END  


   
  
END



