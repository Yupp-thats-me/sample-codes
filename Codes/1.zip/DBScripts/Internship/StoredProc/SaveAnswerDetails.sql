USE [SJInternships]
GO

/** Object:  StoredProcedure [dbo].[SaveAnswerDetails]    Script Date: 10-08-2021 14:07:25 **/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

 

CREATE OR ALTER   PROCEDURE [dbo].[SaveAnswerDetails]  
@ReferenceId BIGINT NULL OUTPUT ,  
@Id BIGINT, 
@QuestionnaireId BIGINT = NULL,
@StudentId BIGINT = NULL,
@Answers nvarchar(500) = NULL, 
@CreatedBy nvarchar(50)=null,
@CreatedDate DATETIME = null
  
AS  
  
BEGIN  
   
  SET NOCOUNT ON;  
  
IF(ISNULL(@Id, 0) = 0)  
  BEGIN  

INSERT INTO  
[dbo].UserAnswerDetails  
(  
  QuestionnaireId
 ,Answers
 ,StudentId  
 ,CreatedBy  
 ,CreatedDate    
)  
VALUES  
(
 @QuestionnaireId 
,@Answers
,@StudentId
,@CreatedBy  
,GETUTCDATE() 
)  
SET @ReferenceId = SCOPE_IDENTITY();  
  END  

 
  
END
 


GO