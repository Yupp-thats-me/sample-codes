

CREATE OR ALTER  PROC [dbo].[GetFlowChartDetails]    
    
@InternshipId BIGINT = NULL  
  
AS  
  
BEGIN    
   
SET NOCOUNT ON;    
  
SELECT 
SUM(CASE WHEN StatusId in (1)  THEN 1 ELSE 0 END) AS Applied,
SUM(CASE WHEN StatusId in (2)  THEN 1 ELSE 0 END) AS Shortlisted,
SUM(CASE WHEN StatusId in (3)  THEN 1 ELSE 0 END) AS Rejected,
SUM(CASE WHEN StatusId in (4)  THEN 1 ELSE 0 END) AS Withdrawn,
SUM(CASE WHEN StatusId in (5)  THEN 1 ELSE 0 END) AS Interviewed,
SUM(CASE WHEN StatusId in (6)  THEN 1 ELSE 0 END) AS DroppedOut,
SUM(CASE WHEN StatusId in (7)  THEN 1 ELSE 0 END) AS Offered,
SUM(CASE WHEN StatusId in (8)  THEN 1 ELSE 0 END) AS ScreenedOut,
SUM(CASE WHEN StatusId in (9)  THEN 1 ELSE 0 END) AS Accepted,
SUM(CASE WHEN StatusId in (10)  THEN 1 ELSE 0 END) AS Declined,
SUM(CASE WHEN StatusId in (11)  THEN 1 ELSE 0 END) AS Hired
FROM UserProfileDetails 
WHERE InternshipId=@InternshipId
  
END    
  


