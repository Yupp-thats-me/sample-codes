USE [SJInternships]
GO

/****** Object:  Table [dbo].[StudentFeedbackDetails]    Script Date: 10/14/2021 2:42:05 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[StudentFeedbackDetails](
	[StudentFeedbackId] [bigint] IDENTITY(1,1) NOT NULL,
	[InternshipId] [bigint] NULL,
	[StudentId] [bigint] NULL,
	[Term] [int] NULL,
	[EmployerId] [bigint] NULL,
	[Department] [nvarchar](100) NULL,
	[SupervisorName] [nvarchar](100) NULL,
	[SupervisorDesignation] [nvarchar](100) NULL,
	[SupervisorEmailId] [nvarchar](100) NULL,
	[AnyFeedback] [nvarchar](250) NULL,
	[CreatedBy] [nvarchar](100) NULL,
	[CreatedDate] [date] NULL,
 CONSTRAINT [PK_StudentFeedbackId] PRIMARY KEY CLUSTERED 
(
	[StudentFeedbackId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


