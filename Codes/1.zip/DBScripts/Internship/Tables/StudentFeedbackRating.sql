USE [SJInternships]
GO

/****** Object:  Table [dbo].[StudentFeedbackRating]    Script Date: 10/9/2021 12:33:21 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[StudentFeedbackRating](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[StudentFeedbackId] [bigint] NOT NULL,
	[ParameterId] [bigint] NULL,
	[Rating] [int] NULL,
	[IsApplicable] [bit] NULL,
	[CreatedBy] [nvarchar](100) NULL,
	[CreatedDate] [date] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[StudentFeedbackRating]  WITH CHECK ADD  CONSTRAINT [FK_StudentFeedbackRating] FOREIGN KEY([StudentFeedbackId])
REFERENCES [dbo].[StudentFeedbackDetails] ([StudentFeedbackId])
GO

ALTER TABLE [dbo].[StudentFeedbackRating] CHECK CONSTRAINT [FK_StudentFeedbackRating]
GO

