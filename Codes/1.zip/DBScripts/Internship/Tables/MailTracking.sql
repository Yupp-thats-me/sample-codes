USE [SJInternships]
GO

/****** Object:  Table [dbo].[MailTracking]    Script Date: 26-10-2021 16:16:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[MailTracking](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[StudentId] [bigint] NULL,
	[InternshipId] [bigint] NULL,
	[FromEmail] [nvarchar](250) NULL,
	[ToEmail] [nvarchar](250) NULL,
	[CcEmail] [nvarchar](250) NULL,
	[Subject] [nvarchar](250) NULL,
	[EmailContent] [nvarchar](1000) NULL,
	[Status] [int] NULL,
	[CreatedBy] [nvarchar](20) NULL,
	[CreatedDate] [datetime] NULL,
	[Attachment] [nvarchar](600) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


