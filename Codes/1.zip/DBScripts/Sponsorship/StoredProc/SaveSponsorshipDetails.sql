USE [SJSponsorships]
GO

/****** Object:  StoredProcedure [dbo].[SaveSponsorshipDetails]    Script Date: 18-05-2021 14:34:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[SaveSponsorshipDetails]  
  
@ReferenceId BIGINT NULL OUTPUT ,  
@Id BIGINT NULL,  
@TitleEn NVARCHAR(100),  
@TitleAr NVARCHAR(100),  
@DescriptionEn NVARCHAR(MAX),  
@DescriptionAr NVARCHAR(MAX),  
@BenefitsEn NVARCHAR(MAX),  
@BenefitsAr NVARCHAR(MAX),  
@NationalityId INT,  
@HigherEducationId INT,  
@MajorId INT,  
@YearId INT,  
@EligibilityEn NVARCHAR(MAX),  
@EligibilityAr NVARCHAR(MAX),  
@HowToApplyEn NVARCHAR(MAX),  
@HowToApplyAr NVARCHAR(MAX),  
@ExpiryDate DATETIME,  
@UploadImage NVARCHAR(1200),  
@StatusId INT,  
@OnBehalfOf INT,  
@Active BIT,  
@SponsorshipTypeId INT,  
@ApplicationUrl NVARCHAR(100),  
@ContactEmail NVARCHAR(50),
@CreatedBy NVARCHAR(200),  
@UpdatedBy NVARCHAR(200)=null,  
@CreatedDate DATETIME = null,
@UpdateDate DATETIME=null
  
AS  
  
BEGIN  
   
SET NOCOUNT ON;  
  
IF(ISNULL(@Id, 0) = 0)  
BEGIN  
INSERT INTO  
[dbo].SponsorshipDetails  
(  
TitleEn 
,TitleAr
,DescriptionEn  
,DescriptionAr
,BenefitsEn 
,BenefitsAr  
,NationalityId  
,HigherEducationId  
,MajorId  
,YearId  
,EligibilityEn  
,EligibilityAr
,HowToApplyEn
,HowToApplyAr
,ExpiryDate  
,UploadImage  
,StatusId  
,OnBehalfOf  
,Active  
,SponsorshipTypeId  
,ApplicationUrl  
,ContactEmail  
,CreatedBy  
,CreatedDate  

  
)  
VALUES  
(  
@TitleEn 
,@TitleAr
,@DescriptionEn
,@DescriptionAr 
,@BenefitsEn  
,@BenefitsAr 
,@NationalityId  
,@HigherEducationId  
,@MajorId  
,@YearId  
,@EligibilityEn  
,@EligibilityAr 
,@HowToApplyEn  
,@HowToApplyAr
,@ExpiryDate  
,@UploadImage  
,@StatusId  
,@OnBehalfOf  
,@Active  
,@SponsorshipTypeId  
,@ApplicationUrl  
,@ContactEmail 
,@CreatedBy  
,GETUTCDATE() 
)  
SET @ReferenceId = SCOPE_IDENTITY();  
END  
ELSE  
BEGIN  
UPDATE  
dbo.SponsorshipDetails  
SET  
TitleEn=@TitleEn,  
TitleAr=@TitleAr,  
DescriptionEn=@DescriptionEn,  
DescriptionAr=@DescriptionAr,  
BenefitsEn=@BenefitsEn,  
BenefitsAr=@BenefitsAr,  
NationalityId=@NationalityId,  
HigherEducationId=@HigherEducationId,  
MajorId=@MajorId,  
YearId=@YearId,  
EligibilityEn=@EligibilityEn,  
EligibilityAr=@EligibilityAr,  
HowToApplyEn=@HowToApplyEn,  
HowToApplyAr=@HowToApplyAr,  
ExpiryDate=@ExpiryDate,  
UploadImage=@UploadImage,  
StatusId=@StatusId,  
OnBehalfOf=@OnBehalfOf,  
Active=@Active,  
SponsorshipTypeId=@SponsorshipTypeId,  
ApplicationUrl=@ApplicationUrl,  
ContactEmail=@ContactEmail,
UpdatedBy=@UpdatedBy,
UpdatedDate=GETUTCDATE() 
WHERE Id=@Id  
  
SET @ReferenceId=@Id  
END  
  
END
GO


