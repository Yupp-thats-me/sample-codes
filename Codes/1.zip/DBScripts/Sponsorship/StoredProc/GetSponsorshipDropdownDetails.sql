USE [SJSponsorships]
GO

/****** Object:  StoredProcedure [dbo].[GetSponsorshipDropdownDetails]    Script Date: 18-05-2021 14:33:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER PROCEDURE [dbo].[GetSponsorshipDropdownDetails]  
 
AS  
  
BEGIN  
   
   SELECT 
   DropdownId
   ,DropdownValueEn
   ,DropdownValueAr
   ,Category
   ,IsActive 
   FROM SponsorshipDropdownMaster WITH(NOLOCK) 
   ORDER BY DropdownValueEn ASC
 

 END
GO


