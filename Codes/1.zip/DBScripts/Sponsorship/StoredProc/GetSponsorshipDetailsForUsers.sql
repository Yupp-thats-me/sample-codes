USE [SJSponsorships]
GO

/****** Object:  StoredProcedure [dbo].[GetSponsorshipDetailsForUsers]    Script Date: 18-05-2021 14:10:35 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

 
CREATE OR ALTER PROC [dbo].[GetSponsorshipDetailsForUsers]

@Id BIGINT = null

AS

BEGIN

SET NOCOUNT ON;

SELECT  TOP 9 
Id,
TitleEn
,TitleAr
,DescriptionEn
,DescriptionAr
,BenefitsEn
,BenefitsAr
,NationalityId
,HigherEducationId
,MajorId
,YearId
,EligibilityEn
,EligibilityAr
,HowToApplyEn
,HowToApplyAr
,ExpiryDate
,UploadImage
,StatusId
,OnBehalfOf
,Active
,SponsorshipTypeId
,ApplicationUrl
,ContactEmail
,CreatedBy
,CreatedDate
,UpdatedBy
,UpdatedDate


FROM [SJSponsorships].[dbo].SponsorshipDetails WITH(NOLOCK)
WHERE 	StatusId=1
ORDER BY Id DESC

END

GO


