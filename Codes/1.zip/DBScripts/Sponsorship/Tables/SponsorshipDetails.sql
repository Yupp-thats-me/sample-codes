USE [SJSponsorships]
GO

/****** Object:  Table [dbo].[SponsorshipDetails]    Script Date: 5/18/2021 7:20:35 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SponsorshipDetails](
	[Id] [bigint] IDENTITY(1,1) NOT NULL,
	[TitleEn] [nvarchar](50) NULL,
	[TitleAr] [nvarchar](50) NULL,
	[DescriptionEn] [nvarchar](max) NULL,
	[DescriptionAr] [nvarchar](max) NULL,
	[BenefitsEn] [nvarchar](max) NULL,
	[BenefitsAr] [nvarchar](max) NULL,
	[NationalityId] [int] NULL,
	[HigherEducationId] [int] NULL,
	[MajorId] [int] NULL,
	[YearId] [int] NULL,
	[EligibilityEn] [nvarchar](max) NULL,
	[EligibilityAr] [nvarchar](max) NULL,
	[HowToApplyEn] [nvarchar](max) NULL,
	[HowToApplyAr] [nvarchar](max) NULL,
	[ExpiryDate] [datetime] NOT NULL,
	[UploadImage] [nvarchar](600) NULL,
	[StatusId] [int] NULL,
	[OnBehalfOf] [int] NULL,
	[Active] [bit] NULL,
	[CreatedBy] [nvarchar](100) NULL,
	[CreatedDate] [datetime] NULL,
	[UpdatedBy] [nvarchar](100) NULL,
	[UpdatedDate] [datetime] NULL,
	[SponsorshipTypeId] [int] NULL,
	[ApplicationUrl] [nvarchar](100) NULL,
	[ContactEmail] [nvarchar](50) NULL,
 CONSTRAINT [PK__Sponsors__3214EC275C2AD5D9] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


