﻿using SJP.Common.EmailService;
using SJP.Core.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Context
{
    public class ContextContainer
    {
        public readonly IEmailService emailService;

        public readonly IFileUtility fileUtility;
        public ContextContainer(IEmailService emailService, IFileUtility fileUtility)
        {
            this.emailService = emailService;
            this.fileUtility = fileUtility;
        }



    }
}
