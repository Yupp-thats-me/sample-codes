﻿using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using SJP.Account.API.Models;
using SJP.Common.EmailService;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SJP.Account.API.Email
{
    public static class EmailContent
    {
        private static IConfiguration configuration;
        private static EmailConfiguration emailConfig;

        public static string EmailTemplateStr => Path.Combine(System.IO.Directory.GetCurrentDirectory(), "emailTemplateEn.json");

        public static List<EmailTemplate> Read()
        {
            return JsonConvert.DeserializeObject<List<EmailTemplate>>(File.ReadAllText(EmailTemplateStr));
        }

        public static void InitConfiguration(IConfiguration _configuration)
        {
            configuration = _configuration;

            emailConfig = new EmailConfiguration();
            configuration.Bind("EmailConfiguration", emailConfig);
        }
        public static List<EmailAddress> GetSystemEmailAddress()
        {
            EmailAddress systemAddress = new EmailAddress() { Address = emailConfig.systemFromEmail, Name = "System" };

            return new List<EmailAddress> { systemAddress };
        }

        public static string BuildPasswordRecoveryContent(ResetDataModel model)
        {
            StringBuilder content = new StringBuilder("");

            content.Append("Hello! Please click to reset password: ");

            var param = new Dictionary<string, string>
            {
                {"token", model.Token },
                {"email", model.Email },
            };

            var link = QueryHelpers.AddQueryString(model.ClientURI, param);

            content.Append(link);

            return content.ToString();
        }

        public static string BuildEmailConfirmationContent(ResetDataModel model)
        {
            StringBuilder content = new StringBuilder("");

            content.Append("Hello! Please click to verify your email address ");

            var param = new Dictionary<string, string>
            {
                {"token", model.Token },
                {"email", model.Email },
            };

            var link = QueryHelpers.AddQueryString(model.ClientURI, param);

            content.Append(link);

            return content.ToString();
        }

        public static EmailTemplate Read(string category)
        {
            return Read().Where(a => a.EmailCategory == category).FirstOrDefault();
        }
    }
    public class EmailTemplate : EmailMessage
    {
        /// <summary>
        /// refers static class EmailCategory
        /// </summary>
        public string EmailCategory { get; set; }

        //public List<EmailAddress> ToAddress { get; set; }
        //public List<EmailAddress> FromAddress { get; set; }
        //public List<EmailAddress> CcAddress { get; set; }
        //public List<EmailAddress> BccAddress { get; set; }
        //public string Content { get; set; }
        //public string Subject { get; set; }
        ////public IFormFile Attachment { get; set; }
        //public string HeaderHTML { get; set; }
        //public string FooterHTML { get; set; }
        //public string Body { get; set; }
        //public string[] BodyHTML { get; set; }

        public EmailTemplate()
        {
            FromAddress = new List<EmailAddress>();
            ToAddress = new List<EmailAddress>();
            CcAddress = new List<EmailAddress>();
            BccAddress = new List<EmailAddress>();
        }
    }

    public static class EmailCategory
    {
        public static readonly string Registration = "Registration";
        public static readonly string ResetPassword = "ResetPassword";
    }
}
