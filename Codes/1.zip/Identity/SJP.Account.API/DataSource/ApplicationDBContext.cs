﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using SJP.Account.API.DataSource.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.DataSource
{
    public class ApplicationDBContext : IdentityDbContext<Users, Roles, long>// to use brand new tables and columns.
    {
        public ApplicationDBContext(DbContextOptions options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);


            modelBuilder.Entity<RoleClaim>(builder =>
            {
                builder.HasOne(roleClaim => roleClaim.Role).WithMany(role => role.Claims).HasForeignKey(roleClaim => roleClaim.RoleId);
                builder.ToTable("RoleClaim");
            });
            modelBuilder.Entity<Roles>(builder =>
            {
                builder.ToTable("Role");
            });
            modelBuilder.Entity<UserClaim>(builder =>
            {
                builder.HasOne(userClaim => userClaim.User).WithMany(user => user.Claims).HasForeignKey(userClaim => userClaim.UserId);
                builder.ToTable("UserClaim");
            });
            modelBuilder.Entity<UserLogins>(builder =>
            {
                builder.HasOne(userLogin => userLogin.User).WithMany(user => user.Logins).HasForeignKey(userLogin => userLogin.UserId);
                builder.ToTable("UserLogin");
            });
            modelBuilder.Entity<Users>(builder =>
            {
                builder.ToTable("User");
                builder.Property(a => a.Id).ValueGeneratedOnAdd(); // Introduced in EF7 :)
            });

            modelBuilder.Entity<UserRoles>(builder =>
            {
                builder.HasOne(userRole => userRole.Role).WithMany(role => role.Users).HasForeignKey(userRole => userRole.RoleId);
                builder.HasOne(userRole => userRole.User).WithMany(user => user.Roles).HasForeignKey(userRole => userRole.UserId);
                builder.ToTable("UserRole");
            });
            modelBuilder.Entity<UserToken>(builder =>
            {
                builder.HasOne(userToken => userToken.User).WithMany(user => user.UserTokens).HasForeignKey(userToken => userToken.UserId);
                builder.ToTable("UserToken");
            });
        }

        public virtual DbSet<Elements> Elements { get; set; }
        public virtual DbSet<InstituteMaster> InstituteMasters { get; set; }

        public virtual DbSet<CategoryMaster> CategoryMaster { get; set; }

        public virtual DbSet<ServiceMaster> ServiceMaster { get; set; }

        public virtual DbSet<ProfessionalDetails> ProfessionalDetails { get; set; }

        public virtual DbSet<EducationalDetails> EducationalDetails { get; set; }
        
    }
}
