﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using SJP.Account.API.DataSource.Models;
using SJP.Account.API.Models;
using SJP.Core.Model;
using SJP.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.DataSource
{
    public static class IdentityDataInitializer
    {
        private static IConfigurationSection SuperAdmin;
        private static RoleManager<Roles> roleManager;
        private static UserManager<Users> userManager;

        public static List<UserConfiguration> UserConfiguration;
        public static void SeedData(UserManager<Users> _userManager, RoleManager<Roles> _roleManager, IConfiguration config)
        {
            UserConfiguration = new List<UserConfiguration>();

            config.Bind("Users", UserConfiguration);

            userManager = _userManager;
            roleManager = _roleManager;

            SeedRoles(roleManager);
            SeedUsers();
        }

        public static void SeedUsers()
        {
            foreach (var user in UserConfiguration)
            {
                CreateAdmin(user);
            }
        }

        private static void CreateAdmin(UserConfiguration user)
        {
            var table = userManager.FindByEmailAsync(user.EmailId);

            if (table.Result == null)
            {
                var userTable = new Users()
                {
                    FirstName = user.DisplayName,
                    Email = user.EmailId,
                    EmailConfirmed = true,
                    IsActive = true,
                    UserName = user.Username,
                    ApprovalStatus = (int)Status.Approved,
                    RequestedRole = (int)user.Role,
                };

                var IdentityResult = userManager.CreateAsync(userTable, user.Password).Result;

                if (IdentityResult.Succeeded)
                {
                    userManager.AddToRoleAsync(userTable, user.RoleName).Wait();
                }
            }
        }
        public static void SeedRoles(RoleManager<Roles> roleManager)
        {
            var roles = RoleModel.ToList();

            foreach (var role in roles)
            {
                if (role != RoleModel.None)
                {
                    if (!String.IsNullOrEmpty(role.Code) && (!roleManager.RoleExistsAsync(role.Name).Result))
                    {
                        Roles table = new Roles();
                        table.Id = (int)role.Role;
                        table.Name = role.Name;
                        table.NameAr = role.NameAr;
                        table.CreatedBy = "System";
                        table.CreatedDate = DateTime.Now;
                        IdentityResult roleResult = roleManager.CreateAsync(table).Result;
                    }
                }
            }
        }

        public static void CreateSuperAdmin(UserManager<Users> userManager)
        {
            var user = userManager.FindByNameAsync(SuperAdmin["Username"]);

            if (user.Result == null)
            {
                var userTable = new Users()
                {
                    FirstName = SuperAdmin["DisplayName"],
                    Email = SuperAdmin["EmailId"],
                    EmailConfirmed = true,
                    IsActive = true,
                    UserName = SuperAdmin["Username"],
                    ApprovalStatus = (int)Status.Approved,
                    RequestedRole = (int)Role.SuperAdmin,
                };

                var IdentityResult = userManager.CreateAsync(userTable, SuperAdmin["Password"]).Result;

                if (IdentityResult.Succeeded)
                {
                    userManager.AddToRoleAsync(userTable, RoleModel.SuperAdmin.Name).Wait();
                }
            }
        }


    }
}
