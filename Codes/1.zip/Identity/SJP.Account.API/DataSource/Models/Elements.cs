﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.DataSource.Models
{
    public class Elements
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int ElementType { get; set; }

        [MaxLength(100)]
        public string ElementNameEn { get; set; }

        [MaxLength(100)]
        public string ElementNameAr { get; set; }

        [MaxLength(100)]
        public string ElementShortName { get; set; }


        [MaxLength(100)]
        [Required]
        public string CreatedBy { get; set; }

        [MaxLength(100)]
        public string ModifiedBy { get; set; }

        [Required]
        public DateTime CreatedDate { get; set; }
        
        public DateTime? ModifiedDate { get; set; }
    }
}
