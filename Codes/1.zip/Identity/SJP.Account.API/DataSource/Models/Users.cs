﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using SJP.Core.Api.Models.UserManagement;
using SJP.Core.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.DataSource.Models
{
    public class Users : IdentityUser<long>
    {
        [Key]
        public override long Id { get => base.Id; set => base.Id = value; }

        [MaxLength(100)]
        public string IdentityId { get; set; }  //EmirateId/LicenseNumber

        [Required]
        [MaxLength(100)]
        public string FirstName { get; set; }

        [MaxLength(100)]
        public string MiddleName { get; set; }

        [Required]
        [MaxLength(100)]
        public string LastName { get; set; }

        [Required]
        [MaxLength(1)]
        public int Gender { get; set; }

        public DateTime DOB { get; set; }

        [MaxLength(100)]
        public string CurrentAddress { get; set; }

        [MaxLength(100)]
        public string PermanentAddress { get; set; }

        [MaxLength(7)]
        public int? CityId { get; set; }

        [MaxLength(7)]
        public int? InstituteId { get; set; }

        [MaxLength(100)]
        public string OrganizationName { get; set; }
        public int? OrganizationType { get; set; }

        [MaxLength(6)]
        public long POBox { get; set; }

        [MaxLength(7)]
        public long UserCode { get; set; } // StudentId or EmployeeId

        [MaxLength(4)]
        [Required]
        public int RequestedRole { get; set; }

        [Required]
        [MaxLength(1)]
        public int ApprovalStatus { get; set; }

        [MaxLength(100)]
        public string Reason { get; set; }
        //public string LastPassword { get; set; }

        [MaxLength(10)]
        public string CategoryId { get; set; }

        [MaxLength(300)]
        public string ServicesId { get; set; }

        [MaxLength(500)]
        public string ShortBio { get; set; }

        [MaxLength(7)]
        public int? DepartmentId { get; set; }

        [MaxLength(2)]
        public int FailedAttempts { get; set; }

        public Guid ProviderId { get; set; }

        public bool IsActive { get; set; }

        public bool IsDeleted { get; set; }

        [MaxLength(200)]
        public string OnlineProfile { get; set; }

        [MaxLength(100)]
        public string ProfilePicFileName { get; set; }

        [MaxLength(100)]
        public string Language { get; set; }

        [MaxLength(10)]
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }

        public DateTime CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }

        public string Token { get; set; }

       // public int? EntryVia { get; set; }

        public string RefreshToken { get; set; }
        public DateTime? RefreshTokenExpiryTime { get; set; }

        public int? EntryVia { get; set; }

        public virtual ICollection<UserToken> UserTokens { get; set; }

        public virtual ICollection<UserRoles> Roles { get; set; }

        public virtual ICollection<UserLogins> Logins { get; set; }

        public virtual ICollection<UserClaim> Claims { get; set; }
        public virtual ICollection<EducationalDetails> EducationalDetails { get; set; }

        public virtual ICollection<ProfessionalDetails> ProfessionalDetails { get; set; }
    }
}
