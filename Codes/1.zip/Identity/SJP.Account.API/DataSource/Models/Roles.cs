﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SJP.Account.API.DataSource.Models
{
    public class Roles : IdentityRole<long>
    {
        [Key]
        public override long Id { get => base.Id; set => base.Id = value; }
        public Roles() : base()
        {

        }
        public Roles(string roleName) : base(roleName)
        {

        }

        public string NameAr { get; set; }

        [Required]
        [MaxLength(100)]
        public string CreatedBy { get; set; }

        [MaxLength(100)]
        public string ModifiedBy { get; set; }

        [Required]
        public DateTime CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }

        public virtual ICollection<UserRoles> Users { get; set; }
        public virtual ICollection<RoleClaim> Claims { get; set; }
    }
}
