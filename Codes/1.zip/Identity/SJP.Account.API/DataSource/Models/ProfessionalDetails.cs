﻿using Microsoft.EntityFrameworkCore;
using SJP.Core.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.DataSource.Models
{
    public class ProfessionalDetails
    {
        [Key]
        public long Id { get; set; }

        [MaxLength(100)]
        public string Title { get; set; }

        [MaxLength(100)]
        public string OrganizationName { get; set; }

        [MaxLength(500)]
        public string JobDescription { get; set; }

        public int? CityId { get; set; }

        [MaxLength(100)]
        public string IssuingAuthority { get; set; }

        public int? EntryType { get; set; }

        public int ApprovalStatus { get; set; }

        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        public bool InProgress { get; set; }

        public int? EntityType { get; set; }

        public int? IndustryId { get; set; }

        [Required]
        public long UserId { get; set; }

        public bool IsDeleted { get; set; }

        [Required]
        [MaxLength(100)]
        public string CreatedBy { get; set; }


        [MaxLength(100)]
        public string ModifiedBy { get; set; }

        [Required]
        public DateTime CreatedDate { get; set; }
        
        public DateTime? ModifiedDate { get; set; }

        public ICollection<Elements> City { get; set; }
    }
}
