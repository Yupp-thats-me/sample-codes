﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.DataSource.Models
{
    public class EducationalDetails
    {
        [Key]
        public long Id { get; set; }

        public int? EducationLevelId { get; set; }

        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        public DateTime? YearOfCompletition { get; set; }

        public int? ScoreType { get; set; }

        public int? MajorId { get; set; }

        public int? SpecializationId { get; set; }


        /// <summary>
        /// GPA / Percentage
        /// </summary>
        public string Score { get; set; }

        public int? EducationCategoryId { get; set; }

        /// <summary>
        /// FullTime or PartTime
        /// </summary>
        public int? CourseType { get; set; }

        /// <summary>
        /// Public or Private
        /// </summary>
        public int? EntityType { get; set; }

        public long UserId { get; set; }

        public long? InstituteId { get; set; }

        public int ApprovalStatus { get; set; }

        public bool IsDeleted { get; set; }

        [Required]
        [MaxLength(100)]
        public string CreatedBy { get; set; }

        [MaxLength(100)]
        public string ModifiedBy { get; set; }

        [Required]
        public DateTime CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }

        public virtual ICollection<InstituteMaster> Institute { get; set; }

        public virtual ICollection<Elements> EducationLevel { get; set; }

        public virtual ICollection<Elements> EducationCategory { get; set; }
        public virtual ICollection<Users> User { get; set; }

    }
}