﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.DataSource.Models
{
    public class ServiceMaster
    {
        [Key]
        public long Id { get; set; }

        [Required]
        [MaxLength(200)]
        public string NameEn { get; set; }
        
        [Required]
        [MaxLength(200)]
        public string NameAr { get; set; }

        [Required]
        public long CategoryId { get; set; }

        [Required]
        public DateTime CreatedDate { get; set; }
        
        [Required]
        [MaxLength(100)]
        public string CreatedBy { get; set; }

        public DateTime? ModifiedDate { get; set; }

        [MaxLength(100)]
        public string ModifiedBy { get; set; }

        public virtual DbSet<CategoryMaster> Category { get; set; }
    }
}
