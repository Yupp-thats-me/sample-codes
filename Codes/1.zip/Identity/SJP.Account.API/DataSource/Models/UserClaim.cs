﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.DataSource.Models
{
    public class UserClaim : IdentityUserClaim<long>
    {
        [Key]
        public override int Id { get => base.Id; set => base.Id = value; }
        public virtual Users User { get; set; }

        [Required]
        public DateTime CreatedDate { get; set; }

        [Required]
        [MaxLength(100)]
        public string CreatedBy { get; set; }

        public DateTime? ModifiedDate { get; set; }

        [MaxLength(100)]
        public string ModifiedBy { get; set; }


    }
}
