﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.DataSource.Models
{
    public class InstituteMaster
    {
        [Key]
        public long Id { get; set; }

        public int EducationCategoryId { get; set; }
        
        
        [Required]
        [MaxLength(200)]
        public string InstituteNameEn { get; set; }
        
        [Required]
        [MaxLength(200)]
        public string InstituteNameAr { get; set; }

        [Required]
        [MaxLength(100)]
        public string CreatedBy { get; set; }

        [MaxLength(100)]
        public string ModifiedBy { get; set; }

        [Required]
        public DateTime CreatedDate { get; set; }
        
        public DateTime? ModifiedDate { get; set; }
    }
}
