﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Localization;
using Microsoft.Extensions.Localization;
using SJP.Account.API.Controllers.Areas.v1;
using SJP.Account.API.Localization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.DataSource.Factory
{
    //public class MultilanguageIdentityErrorDescriber : IdentityErrorDescriber
    //{
    //    private readonly IStringLocalizer<AccountController> _localizer;
    //    private readonly HttpContext context;

    //    public MultilanguageIdentityErrorDescriber(IStringLocalizer<AccountController> localizer, HttpContext context)
    //    {
    //        _localizer = localizer;
    //        this.context = context;
    //    }

    //    public override IdentityError DuplicateEmail(string email)
    //    {
    //        return new IdentityError()
    //        {   
    //            Code = nameof(DuplicateEmail),
    //            Description = string.Format(_localizer["Email {0} is already taken."], email)
    //        };
    //    }

    //    public override IdentityError DuplicateUserName(string userName)
    //    {

    //        return new IdentityError()
    //        {
    //            Code = nameof(DuplicateEmail),
    //            Description = string.Format(_localizer["Email {0} is already taken."], userName)
    //        };
    //    }
    //    public override IdentityError PasswordRequiresUpper()
    //    {
    //        var rqf = this.context.Request.HttpContext.Features.Get<IRequestCultureFeature>();
    //        var culture = rqf.RequestCulture.Culture.ToString();

    //        return base.PasswordRequiresUpper();    
    //    }
    //}
}
