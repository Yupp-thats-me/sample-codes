﻿using SJP.Account.API.DataSource.Models;
using SJP.Account.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.DataSource.DataAccess.Interfaces
{
    public interface IAccountDataAccess
    {
        public Task<bool> AddUser(Users user);

        public Task<bool> AddUsers(IEnumerable<Users> users);

        public Task<bool> DeleteUser(long id);

        public Task<Users> GetUser(long id);

        /// <summary>
        /// Comma separated ids.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<Users> GetUsers(string id);

        public Task UserApproval(ApprovalModel model);


    }
}
