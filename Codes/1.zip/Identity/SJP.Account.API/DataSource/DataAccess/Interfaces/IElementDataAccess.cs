﻿using SJP.Account.API.DataSource.Models;
using SJP.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.DataSource.DataAccess.Interfaces
{
    public interface IElementDataAccess
    {
        public Task<IEnumerable<Elements>> GetElements(string elementTypeId);
        public Task<IEnumerable<InstituteMaster>> GetInstituteMaster();

    }
}
