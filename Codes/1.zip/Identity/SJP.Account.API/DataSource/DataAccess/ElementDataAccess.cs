﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Account.API.DataSource.DataAccess.Interfaces;
using SJP.Account.API.DataSource.Models;
using SJP.Core.Model;
using SJP.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.DataSource.DataAccess
{
    public class ElementDataAccess : DataAccessBase, IElementDataAccess
    {
        private readonly ILogger logger;
        protected ILogger Logger => logger;

        private ApplicationDBContext dbContext;
        public ElementDataAccess(ILogger<ElementDataAccess> logger, IConfiguration configuration, ApplicationDBContext dbContext) : base(configuration)
        {
            this.logger = logger;
            this.dbContext = dbContext;
        }

        /// <summary>
        /// Returns async executed result
        /// </summary>
        /// <param name="elementTypeId"></param>
        /// <param name="i18"></param>
        /// <returns>ToListAsync</returns>
        public async Task<IEnumerable<Elements>> GetElements(string elementTypeId)
        {
            try
            {
                var elementTypeIds = String.IsNullOrWhiteSpace(elementTypeId) ? new int[] { } : elementTypeId.Split(',').Select(a => int.Parse(a));

                var elements = await (from temp in dbContext.Elements
                                      where elementTypeIds.Contains(temp.ElementType)
                                      select temp).ToListAsync();

                return elements;
            }
            catch (Exception e)
            {

                throw;
            }
        }

        
        public async Task<IEnumerable<InstituteMaster>> GetInstituteMaster()
        {
            try
            {
                var elements = await (from temp in dbContext.InstituteMasters
                                      select temp).ToListAsync();

                return elements;
            }
            catch (Exception e)
            {

                throw;
            }
        }
    }
}
