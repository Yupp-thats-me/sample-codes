﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Account.API.DataSource.DataAccess.Interfaces;
using SJP.Account.API.DataSource.Models;
using SJP.Account.API.Models;
using SJP.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.DataSource.DataAccess
{
    public class AccountDataAccess : DataAccessBase, IAccountDataAccess
    {
        private readonly ILogger logger;
        protected ILogger Logger => logger;
        public AccountDataAccess(ILogger<AccountDataAccess> logger, IConfiguration configuration) : base(configuration)
        {
            this.logger = logger;
        }

        public async Task<bool> AddUser(Users user)
        {
            try
            {
                // IMapper can be used here.
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public Task<bool> AddUsers(IEnumerable<Users> users)
        {
            throw new NotImplementedException();
        }

        public Task<bool> DeleteUser(long id)
        {
            throw new NotImplementedException();
        }

        public Task<Users> GetUser(long id)
        {
            throw new NotImplementedException();
        }

        public Task<Users> GetUsers(string id)
        {
            throw new NotImplementedException();
        }

        public Task UserApproval(ApprovalModel model)
        {
            throw new NotImplementedException();
        }
    }
}
