﻿//using Microsoft.AspNetCore.Mvc;
//using Microsoft.AspNetCore.Mvc.Filters;
//using SJP.Account.API.Models;
//using SJP.Core.Models;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Security.Claims;
//using System.Threading.Tasks;

//namespace SJP.Account.API.Handlers
//{
//    //public class PermissionAuthorizeAttribute : TypeFilterAttribute
//    //{
//    //    public PermissionAuthorizeAttribute(string claimType, string claimValue) : base(typeof(PermissionAuthorizeFilter))
//    //    {
//    //        Arguments = new object[] { new Claim(claimType, claimValue) };
//    //    }
//    //}

//    //public class PermissionAuthorizeFilter : IAuthorizationFilter
//    //{
//    //    readonly Claim _claim;

//    //    public PermissionAuthorizeFilter(Claim claim)
//    //    {
//    //        _claim = claim;
//    //    }   

//    //    public void OnAuthorization(AuthorizationFilterContext context)
//    //    {
//    //        var hasClaim = context.HttpContext.User.Claims.Any(c => c.Type == _claim.Type && c.Value == _claim.Value);
//    //        if (!hasClaim)
//    //        {
//    //            context.Result = new UnauthorizedResult();
//    //        }
//    //    }
//    //}
//    public class ActionAuthorizeAttribute : TypeFilterAttribute
//    {
//        public ActionAuthorizeAttribute(Role role) : base(typeof(ActionAuthorizeFilter))
//        {
//            Arguments = new object[] { new Claim(ClaimTypes.Role, ((RoleModel)role).Name) };
//        }

//        //public ActionAuthorizeAttribute(params object[] roles) : base(typeof(ActionAuthorizeFilter))
//        //{
//        //    var args = new object[] { };

//        //    foreach (var role in roles)
//        //    {
//        //        args.Append(new Claim(ClaimTypes.Role, ((RoleModel)role).Name));
//        //    }
//        //}
//    }

//    public class ActionAuthorizeFilter : IAuthorizationFilter
//    {
//        readonly Claim _claim;

//        public ActionAuthorizeFilter(Claim claim)
//        {
//            _claim = claim;
//        }

//        public void OnAuthorization(AuthorizationFilterContext context)
//        {
//            var roles = String.IsNullOrEmpty(_claim.Value) ? new string[] { } : _claim.Value.Split(',');

//            bool isAll = roles.Any(a => a == RoleModel.All.Name);

//            if (!isAll && roles.Length > 0)
//            {
//                if (!context.HttpContext.User.Identity.IsAuthenticated)
//                {
//                    context.Result = new UnauthorizedResult();
//                }
//                else
//                {
//                    if (!String.IsNullOrEmpty(_claim.Value))
//                    {
//                        var hasClaim = context.HttpContext.User.Claims.Any(c => c.Type == ClaimTypes.Role && roles.Contains(c.Value));

//                        if (!hasClaim)
//                        {
//                            context.Result = new ForbidResult();
//                        }
//                    }
//                }
//            }
//        }
//    }
//}
