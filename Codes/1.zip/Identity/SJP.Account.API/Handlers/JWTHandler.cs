﻿using Google.Apis.Auth;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using SJP.Account.API.DataSource.Models;
using SJP.Account.API.Models;
using SJP.Common.JWTConfiguration;
using SJP.Core.Api.Models.UserManagement;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace SJP.Account.API.Handlers
{
    public class JWTHandler
    {
        private readonly HttpClient client;

        private readonly IConfiguration _configuration;
        private readonly IConfigurationSection _jwtSettings;
        private readonly IConfigurationSection _goolgeSettings;

        public JWTHandler(IConfiguration configuration, HttpClient client)
        {
            _configuration = configuration;
            _jwtSettings = _configuration.GetSection("Authentication").GetSection("JWTAuthSettings");
            _goolgeSettings = _configuration.GetSection("Authentication").GetSection("Google");

            this.client = client;
        }

        public SigningCredentials GetSigningCredentials()
        {
            var key = Encoding.UTF8.GetBytes(_jwtSettings.GetSection("Key").Value);
            var secret = new SymmetricSecurityKey(key);

            return new SigningCredentials(secret, SecurityAlgorithms.HmacSha256);
        }

        public List<Claim> GetClaims(ApplicationUser user, IList<string> roles)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Email, user.EmailId),
                new Claim("EmirateId", String.IsNullOrEmpty(user.IdentityId) ? "11111" : user.IdentityId.ToString()),
                new Claim("StudentCategory", user.EducationCategoryId!=null ?  user.EducationCategoryId.ToString() : "")
            };

            foreach (var role in roles)
            {
                claims.Add(new Claim(ClaimTypes.Role, role));
            }

            claims.Add(new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()));

            return claims;
        }

        public JwtSecurityToken GenerateTokenOptions(SigningCredentials signingCredentials, List<Claim> claims)
        {
            var tokenOptions = new JwtSecurityToken(
                claims: claims,
                expires: DateTime.Now.AddMinutes(Convert.ToDouble(_jwtSettings.GetSection("expiryInMinutes").Value)),
                signingCredentials: signingCredentials);

            return tokenOptions;
        }

        public string GenerateRefreshToken()
        {
            var randomNumber = new byte[32];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(randomNumber);
                return Convert.ToBase64String(randomNumber);
            }
        }

        public ClaimsPrincipal GetPrincipalFromExpiredToken(string token)
        {
            var authenticationConfig = new AuthenticationConfig();

            _configuration.Bind("Authentication", authenticationConfig);

            var tokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuer = false,
                ValidateAudience = false,
                ValidateLifetime = false,
                ValidateIssuerSigningKey = false,
                IssuerSigningKey = new Microsoft.IdentityModel.Tokens.SymmetricSecurityKey(
                        System.Text.Encoding.UTF8.GetBytes(authenticationConfig.JWTAuthSettings.Key))
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            SecurityToken securityToken;
            var principal = tokenHandler.ValidateToken(token, tokenValidationParameters, out securityToken);
            var jwtSecurityToken = securityToken as JwtSecurityToken;

            if (jwtSecurityToken == null || !jwtSecurityToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase))
                throw new SecurityTokenException("Invalid token");

            return principal;
        }

        public async Task<GoogleJsonWebSignature.Payload> VerifyGoogleTokenAsync(string token, string provider)
        {
            try
            {
                var settings = new GoogleJsonWebSignature.ValidationSettings()
                {
                    Audience = new List<string>() { _goolgeSettings.GetSection("ClientId").Value }
                };

                var payload = await GoogleJsonWebSignature.ValidateAsync(token, settings);

                return payload;
            }
            catch (Exception ex)
            {
                //log an exception
                return null;
            }
        }

        public async Task<bool> HasCHedsAlmanhalData(string token, string emirateId)
        {
            try
            {
                var hasData = false;

                var ssoConfig = _configuration.GetSection("SSO");

                string chedsURL = ssoConfig["CHEDS"];

                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var chedsDataResult = await client.GetAsync(chedsURL + "/" + emirateId);

                if (chedsDataResult.IsSuccessStatusCode)
                {
                    var chedsData = await chedsDataResult.Content.ReadAsAsync<ChedsAlmanhalModel>();

                    if (chedsData.Data != null)
                    {
                        hasData = true;
                    }
                }

                //if (!chedsDataResult.IsSuccessStatusCode)
                //{
                //    string almanhalURL = ssoConfig["almanhal"];

                //    var almanhalData = await client.GetAsync(almanhalURL + "/" + emirateId);

                //    if (almanhalData.IsSuccessStatusCode)
                //    {
                //        hasData = true;
                //    }
                //}
                //else
                //{
                //    dynamic chedsData = await chedsDataResult.Content.ReadAsAsync<IEnumerable<ApplicationUser>>();
                //    hasData = true;
                //}

                return hasData;
            }
            catch (Exception ex)
            {
                //log an exception
                throw;
            }
        }
    }
}
