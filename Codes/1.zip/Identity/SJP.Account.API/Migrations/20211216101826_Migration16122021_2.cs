﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SJP.Account.API.Migrations
{
    public partial class Migration16122021_2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.AddColumn<int>(
            //    name: "EducationCategoryId",
            //    table: "InstituteMasters",
            //    type: "int",
            //    nullable: false,
            //    defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "EducationCategoryId",
                table: "InstituteMasters");
        }
    }
}
