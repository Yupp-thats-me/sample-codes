﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SJP.Account.API.Migrations
{
    public partial class Migration16122021_3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.RenameColumn(
            //    name: "NameSr",
            //    table: "ServiceMaster",
            //    newName: "NameAr");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "NameAr",
                table: "ServiceMaster",
                newName: "NameSr");
        }
    }
}
