﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace SJP.Account.API.Migrations
{
    public partial class Migration16122021 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.CreateTable(
            //    name: "AspNetRoleClaims",
            //    columns: table => new
            //    {
            //        Id = table.Column<int>(type: "int", nullable: false)
            //            .Annotation("SqlServer:Identity", "1, 1"),
            //        RoleId = table.Column<long>(type: "bigint", nullable: false),
            //        ClaimType = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_AspNetRoleClaims", x => x.Id);
            //    });

            //migrationBuilder.CreateTable(
            //    name: "AspNetUserClaims",
            //    columns: table => new
            //    {
            //        Id = table.Column<int>(type: "int", nullable: false)
            //            .Annotation("SqlServer:Identity", "1, 1"),
            //        UserId = table.Column<long>(type: "bigint", nullable: false),
            //        ClaimType = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_AspNetUserClaims", x => x.Id);
            //    });

            //migrationBuilder.CreateTable(
            //    name: "AspNetUserLogins",
            //    columns: table => new
            //    {
            //        LoginProvider = table.Column<string>(type: "nvarchar(450)", nullable: false),
            //        ProviderKey = table.Column<string>(type: "nvarchar(450)", nullable: false),
            //        ProviderDisplayName = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        UserId = table.Column<long>(type: "bigint", nullable: false)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_AspNetUserLogins", x => new { x.LoginProvider, x.ProviderKey });
            //    });

            //migrationBuilder.CreateTable(
            //    name: "AspNetUserRoles",
            //    columns: table => new
            //    {
            //        UserId = table.Column<long>(type: "bigint", nullable: false),
            //        RoleId = table.Column<long>(type: "bigint", nullable: false)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_AspNetUserRoles", x => new { x.UserId, x.RoleId });
            //    });

            //migrationBuilder.CreateTable(
            //    name: "AspNetUserTokens",
            //    columns: table => new
            //    {
            //        UserId = table.Column<long>(type: "bigint", nullable: false),
            //        LoginProvider = table.Column<string>(type: "nvarchar(450)", nullable: false),
            //        Name = table.Column<string>(type: "nvarchar(450)", nullable: false),
            //        Value = table.Column<string>(type: "nvarchar(max)", nullable: true)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_AspNetUserTokens", x => new { x.UserId, x.LoginProvider, x.Name });
            //    });

            //migrationBuilder.CreateTable(
            //    name: "Role",
            //    columns: table => new
            //    {
            //        Id = table.Column<long>(type: "bigint", nullable: false),
            //        CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
            //        ModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
            //        Name = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
            //        NormalizedName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
            //        ConcurrencyStamp = table.Column<string>(type: "nvarchar(max)", nullable: true)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_Role", x => x.Id);
            //    });

            //migrationBuilder.CreateTable(
            //    name: "ServiceMaster",
            //    columns: table => new
            //    {
            //        Id = table.Column<long>(type: "bigint", nullable: false)
            //            .Annotation("SqlServer:Identity", "1, 1"),
            //        NameEn = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        NameSr = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        CategoryId = table.Column<long>(type: "bigint", nullable: false),
            //        CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
            //        CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        ModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
            //        ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_ServiceMaster", x => x.Id);
            //    });

            //migrationBuilder.CreateTable(
            //    name: "User",
            //    columns: table => new
            //    {
            //        Id = table.Column<long>(type: "bigint", nullable: false)
            //            .Annotation("SqlServer:Identity", "1, 1"),
            //        IdentityId = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        FirstName = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        MiddleName = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        LastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        Gender = table.Column<int>(type: "int", nullable: false),
            //        DOB = table.Column<DateTime>(type: "datetime2", nullable: false),
            //        CurrentAddress = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        PermanentAddress = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        CityId = table.Column<int>(type: "int", nullable: true),
            //        InstituteId = table.Column<int>(type: "int", nullable: true),
            //        OrganizationName = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        POBox = table.Column<long>(type: "bigint", nullable: false),
            //        UserCode = table.Column<long>(type: "bigint", nullable: false),
            //        RequestedRole = table.Column<int>(type: "int", nullable: false),
            //        ApprovalStatus = table.Column<int>(type: "int", nullable: false),
            //        Reason = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        CategoryId = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        ServicesId = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        ShortBio = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        DepartmentId = table.Column<int>(type: "int", nullable: true),
            //        FailedAttempts = table.Column<int>(type: "int", nullable: false),
            //        ProviderId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
            //        IsActive = table.Column<bool>(type: "bit", nullable: false),
            //        IsDeleted = table.Column<bool>(type: "bit", nullable: false),
            //        OnlineProfile = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        ProfilePicFileName = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        Language = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
            //        ModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
            //        Token = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        RefreshToken = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        RefreshTokenExpiryTime = table.Column<DateTime>(type: "datetime2", nullable: false),
            //        UserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
            //        NormalizedUserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
            //        Email = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
            //        NormalizedEmail = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
            //        EmailConfirmed = table.Column<bool>(type: "bit", nullable: false),
            //        PasswordHash = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        SecurityStamp = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        ConcurrencyStamp = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        PhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        PhoneNumberConfirmed = table.Column<bool>(type: "bit", nullable: false),
            //        TwoFactorEnabled = table.Column<bool>(type: "bit", nullable: false),
            //        LockoutEnd = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
            //        LockoutEnabled = table.Column<bool>(type: "bit", nullable: false),
            //        AccessFailedCount = table.Column<int>(type: "int", nullable: false)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_User", x => x.Id);
            //    });

            //migrationBuilder.CreateTable(
            //    name: "RoleClaim",
            //    columns: table => new
            //    {
            //        Id = table.Column<int>(type: "int", nullable: false),
            //        CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
            //        ModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: true)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_RoleClaim", x => x.Id);
            //        table.ForeignKey(
            //            name: "FK_RoleClaim_AspNetRoleClaims_Id",
            //            column: x => x.Id,
            //            principalTable: "AspNetRoleClaims",
            //            principalColumn: "Id",
            //            onDelete: ReferentialAction.Restrict);
            //    });

            //migrationBuilder.CreateTable(
            //    name: "UserLogin",
            //    columns: table => new
            //    {
            //        LoginProvider = table.Column<string>(type: "nvarchar(450)", nullable: false),
            //        ProviderKey = table.Column<string>(type: "nvarchar(450)", nullable: false),
            //        CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
            //        ModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: true)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_UserLogin", x => new { x.LoginProvider, x.ProviderKey });
            //        table.ForeignKey(
            //            name: "FK_UserLogin_AspNetUserLogins_LoginProvider_ProviderKey",
            //            columns: x => new { x.LoginProvider, x.ProviderKey },
            //            principalTable: "AspNetUserLogins",
            //            principalColumns: new[] { "LoginProvider", "ProviderKey" },
            //            onDelete: ReferentialAction.Restrict);
            //    });

            //migrationBuilder.CreateTable(
            //    name: "CategoryMaster",
            //    columns: table => new
            //    {
            //        Id = table.Column<long>(type: "bigint", nullable: false)
            //            .Annotation("SqlServer:Identity", "1, 1"),
            //        NameEn = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        NameAr = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
            //        CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        ModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
            //        ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        ServiceMasterId = table.Column<long>(type: "bigint", nullable: true)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_CategoryMaster", x => x.Id);
            //        table.ForeignKey(
            //            name: "FK_CategoryMaster_ServiceMaster_ServiceMasterId",
            //            column: x => x.ServiceMasterId,
            //            principalTable: "ServiceMaster",
            //            principalColumn: "Id",
            //            onDelete: ReferentialAction.Restrict);
            //    });

            //migrationBuilder.CreateTable(
            //    name: "EducationalDetails",
            //    columns: table => new
            //    {
            //        Id = table.Column<long>(type: "bigint", nullable: false)
            //            .Annotation("SqlServer:Identity", "1, 1"),
            //        EducationLevelId = table.Column<int>(type: "int", nullable: true),
            //        StartDate = table.Column<DateTime>(type: "datetime2", nullable: true),
            //        EndDate = table.Column<DateTime>(type: "datetime2", nullable: true),
            //        YearOfCompletition = table.Column<DateTime>(type: "datetime2", nullable: true),
            //        ScoreType = table.Column<int>(type: "int", nullable: true),
            //        MajorId = table.Column<int>(type: "int", nullable: true),
            //        SpecializationId = table.Column<int>(type: "int", nullable: true),
            //        Score = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        EducationCategoryId = table.Column<int>(type: "int", nullable: true),
            //        CourseType = table.Column<int>(type: "int", nullable: true),
            //        EntityType = table.Column<int>(type: "int", nullable: true),
            //        UserId = table.Column<long>(type: "bigint", nullable: false),
            //        InstituteId = table.Column<long>(type: "bigint", nullable: true),
            //        ApprovalStatus = table.Column<int>(type: "int", nullable: false),
            //        IsDeleted = table.Column<bool>(type: "bit", nullable: false),
            //        CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
            //        ModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
            //        UsersId = table.Column<long>(type: "bigint", nullable: true)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_EducationalDetails", x => x.Id);
            //        table.ForeignKey(
            //            name: "FK_EducationalDetails_User_UsersId",
            //            column: x => x.UsersId,
            //            principalTable: "User",
            //            principalColumn: "Id",
            //            onDelete: ReferentialAction.Restrict);
            //    });

            //migrationBuilder.CreateTable(
            //    name: "ProfessionalDetails",
            //    columns: table => new
            //    {
            //        Id = table.Column<long>(type: "bigint", nullable: false)
            //            .Annotation("SqlServer:Identity", "1, 1"),
            //        Title = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        OrganizationName = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        JobDescription = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        CityId = table.Column<int>(type: "int", nullable: true),
            //        IssuingAuthority = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        EntryType = table.Column<int>(type: "int", nullable: true),
            //        ApprovalStatus = table.Column<int>(type: "int", nullable: false),
            //        StartDate = table.Column<DateTime>(type: "datetime2", nullable: true),
            //        EndDate = table.Column<DateTime>(type: "datetime2", nullable: true),
            //        InProgress = table.Column<bool>(type: "bit", nullable: false),
            //        EntityType = table.Column<int>(type: "int", nullable: true),
            //        IndustryId = table.Column<int>(type: "int", nullable: true),
            //        UserId = table.Column<long>(type: "bigint", nullable: false),
            //        IsDeleted = table.Column<bool>(type: "bit", nullable: false),
            //        CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
            //        ModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
            //        UsersId = table.Column<long>(type: "bigint", nullable: true)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_ProfessionalDetails", x => x.Id);
            //        table.ForeignKey(
            //            name: "FK_ProfessionalDetails_User_UsersId",
            //            column: x => x.UsersId,
            //            principalTable: "User",
            //            principalColumn: "Id",
            //            onDelete: ReferentialAction.Restrict);
            //    });

            //migrationBuilder.CreateTable(
            //    name: "UserRole",
            //    columns: table => new
            //    {
            //        UserId = table.Column<long>(type: "bigint", nullable: false),
            //        RoleId = table.Column<long>(type: "bigint", nullable: false),
            //        CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
            //        ModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: true)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_UserRole", x => new { x.UserId, x.RoleId });
            //        table.ForeignKey(
            //            name: "FK_UserRole_AspNetUserRoles_UserId_RoleId",
            //            columns: x => new { x.UserId, x.RoleId },
            //            principalTable: "AspNetUserRoles",
            //            principalColumns: new[] { "UserId", "RoleId" },
            //            onDelete: ReferentialAction.Restrict);
            //        table.ForeignKey(
            //            name: "FK_UserRole_Role_RoleId",
            //            column: x => x.RoleId,
            //            principalTable: "Role",
            //            principalColumn: "Id",
            //            onDelete: ReferentialAction.Cascade);
            //        table.ForeignKey(
            //            name: "FK_UserRole_User_UserId",
            //            column: x => x.UserId,
            //            principalTable: "User",
            //            principalColumn: "Id",
            //            onDelete: ReferentialAction.Cascade);
            //    });

            //migrationBuilder.CreateTable(
            //    name: "UserToken",
            //    columns: table => new
            //    {
            //        UserId = table.Column<long>(type: "bigint", nullable: false),
            //        LoginProvider = table.Column<string>(type: "nvarchar(450)", nullable: false),
            //        Name = table.Column<string>(type: "nvarchar(450)", nullable: false),
            //        CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
            //        ModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: true)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_UserToken", x => new { x.UserId, x.LoginProvider, x.Name });
            //        table.ForeignKey(
            //            name: "FK_UserToken_AspNetUserTokens_UserId_LoginProvider_Name",
            //            columns: x => new { x.UserId, x.LoginProvider, x.Name },
            //            principalTable: "AspNetUserTokens",
            //            principalColumns: new[] { "UserId", "LoginProvider", "Name" },
            //            onDelete: ReferentialAction.Restrict);
            //        table.ForeignKey(
            //            name: "FK_UserToken_User_UserId",
            //            column: x => x.UserId,
            //            principalTable: "User",
            //            principalColumn: "Id",
            //            onDelete: ReferentialAction.Cascade);
            //    });

            //migrationBuilder.CreateTable(
            //    name: "UserClaim",
            //    columns: table => new
            //    {
            //        Id = table.Column<int>(type: "int", nullable: false),
            //        CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
            //        ModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
            //        RoleClaimId = table.Column<int>(type: "int", nullable: true)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_UserClaim", x => x.Id);
            //        table.ForeignKey(
            //            name: "FK_UserClaim_AspNetUserClaims_Id",
            //            column: x => x.Id,
            //            principalTable: "AspNetUserClaims",
            //            principalColumn: "Id",
            //            onDelete: ReferentialAction.Restrict);
            //        table.ForeignKey(
            //            name: "FK_UserClaim_RoleClaim_RoleClaimId",
            //            column: x => x.RoleClaimId,
            //            principalTable: "RoleClaim",
            //            principalColumn: "Id",
            //            onDelete: ReferentialAction.Restrict);
            //    });

            //migrationBuilder.CreateTable(
            //    name: "InstituteMasters",
            //    columns: table => new
            //    {
            //        Id = table.Column<long>(type: "bigint", nullable: false)
            //            .Annotation("SqlServer:Identity", "1, 1"),
            //        InstituteNameEn = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        InstituteNameAr = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
            //        ModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
            //        EducationalDetailsId = table.Column<long>(type: "bigint", nullable: true)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_InstituteMasters", x => x.Id);
            //        table.ForeignKey(
            //            name: "FK_InstituteMasters_EducationalDetails_EducationalDetailsId",
            //            column: x => x.EducationalDetailsId,
            //            principalTable: "EducationalDetails",
            //            principalColumn: "Id",
            //            onDelete: ReferentialAction.Restrict);
            //    });

            //migrationBuilder.CreateTable(
            //    name: "Elements",
            //    columns: table => new
            //    {
            //        Id = table.Column<int>(type: "int", nullable: false)
            //            .Annotation("SqlServer:Identity", "1, 1"),
            //        ElementType = table.Column<int>(type: "int", nullable: false),
            //        ElementNameEn = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        ElementNameAr = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        ElementShortName = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        CreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        ModifiedBy = table.Column<string>(type: "nvarchar(max)", nullable: true),
            //        CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
            //        ModifiedDate = table.Column<DateTime>(type: "datetime2", nullable: true),
            //        EducationalDetailsId = table.Column<long>(type: "bigint", nullable: true),
            //        EducationalDetailsId1 = table.Column<long>(type: "bigint", nullable: true),
            //        ProfessionalDetailsId = table.Column<long>(type: "bigint", nullable: true)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_Elements", x => x.Id);
            //        table.ForeignKey(
            //            name: "FK_Elements_EducationalDetails_EducationalDetailsId",
            //            column: x => x.EducationalDetailsId,
            //            principalTable: "EducationalDetails",
            //            principalColumn: "Id",
            //            onDelete: ReferentialAction.Restrict);
            //        table.ForeignKey(
            //            name: "FK_Elements_EducationalDetails_EducationalDetailsId1",
            //            column: x => x.EducationalDetailsId1,
            //            principalTable: "EducationalDetails",
            //            principalColumn: "Id",
            //            onDelete: ReferentialAction.Restrict);
            //        table.ForeignKey(
            //            name: "FK_Elements_ProfessionalDetails_ProfessionalDetailsId",
            //            column: x => x.ProfessionalDetailsId,
            //            principalTable: "ProfessionalDetails",
            //            principalColumn: "Id",
            //            onDelete: ReferentialAction.Restrict);
            //    });

            //migrationBuilder.CreateIndex(
            //    name: "IX_CategoryMaster_ServiceMasterId",
            //    table: "CategoryMaster",
            //    column: "ServiceMasterId");

            //migrationBuilder.CreateIndex(
            //    name: "IX_EducationalDetails_UsersId",
            //    table: "EducationalDetails",
            //    column: "UsersId");

            //migrationBuilder.CreateIndex(
            //    name: "IX_Elements_EducationalDetailsId",
            //    table: "Elements",
            //    column: "EducationalDetailsId");

            //migrationBuilder.CreateIndex(
            //    name: "IX_Elements_EducationalDetailsId1",
            //    table: "Elements",
            //    column: "EducationalDetailsId1");

            //migrationBuilder.CreateIndex(
            //    name: "IX_Elements_ProfessionalDetailsId",
            //    table: "Elements",
            //    column: "ProfessionalDetailsId");

            //migrationBuilder.CreateIndex(
            //    name: "IX_InstituteMasters_EducationalDetailsId",
            //    table: "InstituteMasters",
            //    column: "EducationalDetailsId");

            //migrationBuilder.CreateIndex(
            //    name: "IX_ProfessionalDetails_UsersId",
            //    table: "ProfessionalDetails",
            //    column: "UsersId");

            //migrationBuilder.CreateIndex(
            //    name: "RoleNameIndex",
            //    table: "Role",
            //    column: "NormalizedName",
            //    unique: true,
            //    filter: "[NormalizedName] IS NOT NULL");

            //migrationBuilder.CreateIndex(
            //    name: "EmailIndex",
            //    table: "User",
            //    column: "NormalizedEmail");

            //migrationBuilder.CreateIndex(
            //    name: "UserNameIndex",
            //    table: "User",
            //    column: "NormalizedUserName",
            //    unique: true,
            //    filter: "[NormalizedUserName] IS NOT NULL");

            //migrationBuilder.CreateIndex(
            //    name: "IX_UserClaim_RoleClaimId",
            //    table: "UserClaim",
            //    column: "RoleClaimId");

            //migrationBuilder.CreateIndex(
            //    name: "IX_UserRole_RoleId",
            //    table: "UserRole",
            //    column: "RoleId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CategoryMaster");

            migrationBuilder.DropTable(
                name: "Elements");

            migrationBuilder.DropTable(
                name: "InstituteMasters");

            migrationBuilder.DropTable(
                name: "UserClaim");

            migrationBuilder.DropTable(
                name: "UserLogin");

            migrationBuilder.DropTable(
                name: "UserRole");

            migrationBuilder.DropTable(
                name: "UserToken");

            migrationBuilder.DropTable(
                name: "ServiceMaster");

            migrationBuilder.DropTable(
                name: "ProfessionalDetails");

            migrationBuilder.DropTable(
                name: "EducationalDetails");

            migrationBuilder.DropTable(
                name: "AspNetUserClaims");

            migrationBuilder.DropTable(
                name: "RoleClaim");

            migrationBuilder.DropTable(
                name: "AspNetUserLogins");

            migrationBuilder.DropTable(
                name: "AspNetUserRoles");

            migrationBuilder.DropTable(
                name: "Role");

            migrationBuilder.DropTable(
                name: "AspNetUserTokens");

            migrationBuilder.DropTable(
                name: "User");

            migrationBuilder.DropTable(
                name: "AspNetRoleClaims");
        }
    }
}
