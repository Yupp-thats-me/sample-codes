﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

using SJP.Core.Api.Extensions;
using SJP.Account.API.DataSource;
using SJP.Logger.Extensions;
using SJP.Common.EmailService;
using System.Configuration;
using SJP.Communication.Http;
using SJP.Account.API.DataSource.DataAccess.Interfaces;
using SJP.Account.API.Services.Interfaces;
using SJP.Account.API.Services;
using SJP.Account.API.DataSource.DataAccess;
using SJP.Account.API.Handlers;
using Microsoft.Extensions.Localization;
using SJP.Account.API.Localization;
using System.Net.Http;

namespace SJP.Account.API.Extensions
{
    public static class Extensions
    {
        public static IServiceCollection AddServices(this IServiceCollection services)
        {
            services.AddDatabaseLogger();
            services.AddDistributedMemCache();

            services.AddHttpCommunicatorWithOAuth();

            services.AddHttpCommunicator();


            services.AddScoped<IAccountDataAccess, AccountDataAccess>();
            services.AddScoped<IElementDataAccess, ElementDataAccess>();

            services.AddScoped<IAccountService, AccountService>();
            services.AddScoped<IDataService, DataService>();
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IReportService, ReportService>();

            services.AddScoped<ServiceFactory>();
            services.AddScoped<IExternalLoginService, ExternalLoginService>();
            services.AddScoped<IAccountEmailService, AccountEmailService>();

            services.AddScoped<HttpClient>();




            services.AddScoped<JWTHandler>();

            //services.AddScoped<IStringLocalizer<Resource_ar>>();

            return services;
        }

        public static IApplicationBuilder UseServices(this IApplicationBuilder app)
        {
            app.UseDatabaseLogger();
            return app;
        }
    }
}
