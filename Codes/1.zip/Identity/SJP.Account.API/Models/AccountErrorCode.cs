﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Models
{
    public enum AccountErrorCode
    {
        AlreadyExists = 900,
        DoesNotExists = 901,
        NotApproved = 902,
        EmailNotVerified = 903,
        Deactivated = 904,
        Failed = 905,
        InvalidPassword = 906,
        EmailExists = 907,
        EmirateIdExists = 908,
        PhoneNumberExists = 909,
    }
}