﻿using SJP.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Models
{
    public class UserConfiguration
    {
        public string RoleName { get; set; }

        public Role Role
        {
            get
            {
                return ((RoleModel)RoleName).Role;
            }
        }

        public string Username { get; set; }
        public string DisplayName { get; set; }
        public string EmailId { get; set; }
        public string Password { get; set; }
        public bool ForceCreate { get; set; }
    }
}
