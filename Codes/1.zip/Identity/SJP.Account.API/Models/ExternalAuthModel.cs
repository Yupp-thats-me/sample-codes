﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Models
{
    public class ExternalAuthModel
    {
        public string Token { get; set; }

        public string Provider { get; set; }

    }
}
