﻿using SJP.Common.EmailService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Models
{
    public class EmailInfoModel
    {
        public List<EmailAddress> ToAddress { get; set; }

        public string Token { get; set; }
        public string EmailId { get; set; }

        public string ClientURI { get; set; }
    }
}
