﻿using Microsoft.AspNetCore.Identity;
using SJP.Account.API.DataSource.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Models
{
    public class UserIdentityResult
    {
        public Users User { get; set; }

        public bool Exists { get; set; }

        public string ExistColumns { get; set; }

        public IdentityResult IdentityResult { get; set; }
    }
}
