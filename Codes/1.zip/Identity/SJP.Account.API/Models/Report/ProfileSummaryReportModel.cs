﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Models.Report
{
    public class ProfileSummaryReportModel
    {
        public long Registered { get; set; }
        public long Pending { get; set; }

        public long Approved { get; set; }

        public long Rejected { get; set; }

    }
}
