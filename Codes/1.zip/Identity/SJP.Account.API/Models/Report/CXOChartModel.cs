﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Models.Report
{
    public class CXOChartModel
    {
        public string Period { get; set; }
        public long TotalPublicCXO { get; set; }
        public long TotalPrivateCXO { get; set; }

        public long TotalRegistered { get; set; }
    }
}

