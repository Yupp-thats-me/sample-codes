﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Models.Report
{
    public class StudentChartModel
    {


        public string Period { get; set; }
        public long TotalBachelors { get; set; }
        public long TotalMasters { get; set; }
        public long TotalPhd { get; set; }
        public long TotalHE { get; set; }
        public long TotalGE { get; set; }
        public long TotalCycle2 { get; set; }
        public long TotalCycle3 { get; set; }
    }
        
}
