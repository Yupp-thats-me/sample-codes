﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SJP.Core.Model;
using SJP.Core.Models;
using System;

namespace SJP.Account.API.Models.Report
{
    public class FilterModel
    {
        [FromQuery]
        public Role? Role { get; set; }

        [FromQuery]
        public DateTime? StartDate { get; set; }
        [FromQuery]
        public DateTime? EndDate { get; set; }

        [FromQuery]
        public long? OrganizationType { get; set; }

        public int? Emirates { get; set; }
        public int? EducationCategory { get; set; }
        public int? EducationLevel { get; set; }

        public PeriodType PeriodType { get; set; }

    }
}
