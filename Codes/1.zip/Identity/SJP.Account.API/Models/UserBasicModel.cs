﻿using Newtonsoft.Json;
using SJP.Core.Model;
using SJP.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Models
{
    public class UserBasicModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public string EmailId { get; set; }

        public DateTime DOB { get; set; }

        public Gender Gender { get; set; }

        public string Phone { get; set; }

        public string Address { get; set; }

        public long? POBox { get; set; }
        public string OrganizationName { get; set; }

        public Role RequestedRole { get; set; }

        public long? UserCode { get; set; }

        public string IdentityId { get; set; }

        public int? EntryVia { get; set; }

        public string EmailVerificationURI { get; set; }
        public string Password { get; set; }
    }
}
