﻿using SJP.Core.Api.Models.UserManagement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Models
{
    public class LoginModel
    {
        public int? Id { get; set; }
        public string Username { get; set; }    // Email or EmirateId
        public string Password { get; set; }
        public bool RememberMe { get; set; }

        public string Identifier { get; set; }
        public string Secret { get; set; }
        public virtual ApplicationUser User { get; set; }

        public string EmailVerificationURI { get;set; }
        public virtual ProviderType Provider
        {
            get
            {
                return (ProviderType)ProviderType;
            }
        }

        public virtual string ProviderType { get; set; }

        public string EmirateId { get; set; }


    }
}
