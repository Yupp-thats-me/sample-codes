﻿using SJP.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Models
{
    public class UserReportModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public Gender Gender { get; set; }
        public long? EducationCategoryId { get; set; }
        public long? EducationLevelId { get; set; }
        public string IdentityId { get; set; } // EmirateId/LicenseNo

        public string DisplayName
        {
            get
            {
                return FirstName + " " + LastName;
            }
        }

        public string EducationCategoryNameEn { get; internal set; }
        public string EducationCategoryNameAr { get; internal set; }
        public string EducationLevelNameEn { get; internal set; }
        public string EducationLevelNameAr { get; internal set; }

        public string Nationality { get; set; }

        public string CoursetypeEn { get; set; }
        public string CoursetypeAr { get; set; }

        public string InstitutenameEn { get; set; }
        public string InstitutenameAr { get; set; }

        public int InstituteId { get; set; }

        public string MajorEn { get; set; }
        public string MajorAr { get; set; }
        public DateTime Dob { get; set; }
        public string Emirate { get; set; }
        public string Email { get; set; }
        public string Mobilenumber { get; set; }
        public long Lastvisitedtimestamp { get; set; }


    }
}