﻿using SJP.Account.API.DataSource.Models;
using SJP.Core.Api.Models.UserManagement;
using SJP.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Models
{
    public class LoggedInUserModel
    {

        public string token { get; set; }

        public string refreshToken { get; set; }
        public string Email { get; set; }
        public IList<string> Roles { get; set; }

        public ApplicationUser UserDetails { get; set; }
        public bool Succeeded { get; set; }

        public IList<string> Errors { get; set; }

        public AccountErrorCode ErrorCode { get; set; }

        public Status Status { get; set; }

    }
}
