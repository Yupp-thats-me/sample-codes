﻿using Newtonsoft.Json;
using SJP.Core.Api.Models.UserManagement;
using SJP.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Models
{
    public class RegistrationModel
    {
        public string UserName { get; set; }
        public string Password { get; set; }

        public string EmailVerificationURI { get; set; }

        [JsonIgnore]
        internal string DisplayName
        {
            get
            {
                if (PersonalDetails != null)
                    return PersonalDetails.FirstName + " " + PersonalDetails.LastName;

                return "";
            }
        }

        public ApplicationUser PersonalDetails { get; set; }

        public EducationDetailModel EducationalDetails { get; set; }

        public ProfessionalDetailModel ProfessionalDetails { get; set; }

        [JsonIgnore]
        internal bool RequireProfessionalDetails
        {
            get
            {
                if (PersonalDetails != null)
                {
                    var role = PersonalDetails.RequestedRole;

                    if (Array.IndexOf(new Role[] { Role.Employer, Role.CXO, Role.Counsellor }, role) > -1)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        [JsonIgnore]
        internal bool RequireEducationalDetails
        {
            get
            {
                if (PersonalDetails != null)
                {
                    var role = PersonalDetails.RequestedRole;

                    if (Array.IndexOf(new Role[] { Role.Student, Role.HEI, Role.GEI, Role.Counsellor, Role.InternshipCounsellor }, role) > -1)
                    {
                        return true;
                    }
                }

                return false;
            }
        }

        public string ExternalToken { get; set; }

        public string Provider { get; set; }
    }
}