﻿using SJP.Core.Model;
using SJP.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Models
{
    public class ApprovalModel : DomainObject
    {
        public long UserId { get; set; }
        public Role Role { get; set; }
        public Status Status { get; set; }

        public string Reason { get; set; }
    }
}
