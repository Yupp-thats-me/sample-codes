﻿using Microsoft.AspNetCore.Mvc.Rendering;
using SJP.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Models
{
    public class ProviderType
    {
        private static readonly Dictionary<string, ProviderType> Values = new Dictionary<string, ProviderType>();
        private static readonly List<ProviderType> ProviderList = new List<ProviderType>();

        public static readonly ProviderType SJP = new ProviderType("3ABD03C7-2112-46A2-896D-86FD891B426E", "SJP");

        public static readonly ProviderType SSO = new ProviderType("1C423E60-2B18-4C02-85E4-E62000FB5636", "SSO");

        public static readonly ProviderType UAE = new ProviderType("2FA425E1-5398-4323-BB6E-EB42770360E2", "UAE");

        public static readonly ProviderType EmirateId = new ProviderType("3CB2FA4D-E857-417A-9845-855DD2950B3B", "Emirate");

        public static readonly ProviderType Unknown = new ProviderType("", "Unknown");

        public string Code;
        public string Name;

        public ProviderType(string code, string name)
        {
            this.Code = code;
            this.Name = name;

            Values[code] = this;

            ProviderList.RemoveAll(a => a.Code.Equals(code));
            ProviderList.Add(this);
        }

        public static implicit operator ProviderType(string code)
        {
            if (Values.ContainsKey(code))
            {
                return Values[code];
            }

            foreach (var item in Values)
            {
                if (item.Value.Code.Equals(code))
                    return item.Value;
            }
            return Unknown;
        }

        public static implicit operator string(ProviderType provider)
        {
            return provider.Code;
        }

        public static List<DropdownDataModel> ToList()
        {
            return Values.Select(a => new DropdownDataModel
            {
                Id = a.Key,
                Text = a.Value.Name
            }).ToList();
        }
    }
}
