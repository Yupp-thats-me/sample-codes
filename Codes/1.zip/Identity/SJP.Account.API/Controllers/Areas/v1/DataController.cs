﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Account.API.DataSource;
using SJP.Account.API.Models;
using SJP.Account.API.Services;
using SJP.Account.API.Services.Interfaces;
using SJP.Core.Api.Controllers;
using SJP.Core.Composition;
using SJP.Core.Model;
using SJP.Core.Models;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Controllers.Areas.v1
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class DataController : BaseApiController
    {
        private readonly IDataService service;
        private readonly ServiceFactory serviceFactory;

        public IConfiguration config;
        public readonly ApplicationDBContext dbContext;

        public DataController(ServiceFactory serviceFactory, ILogger<DataController> logger, IDataService service, IConfiguration config, ApplicationDBContext dbContext) : base(logger)
        {
            this.service = service;
            this.dbContext = dbContext;
            this.service.Init(dbContext, HttpContext);
            this.serviceFactory = serviceFactory;
            this.config = config;
        }

        [HttpGet("elements/{elementTypeId}")]
        public async Task<IActionResult> GetElements(string elementTypeId)
        {
            try
            {
                var elements = await this.service.GetElements(elementTypeId);

                return Success("", elements);
            }
            catch (System.Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetElements Method" + e);
                return Error("");
            }
        }

        [HttpGet("categories")]
        public async Task<IActionResult> GetCategories()
        {
            try
            {
                var data = await this.service.GetCategories();

                return Success("", data);
            }
            catch (System.Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetCategories Method" + e);
                return Error("");
            }
        }

        [HttpGet("services/{id?}")]
        public async Task<IActionResult> GetServices(string id)
        {
            try
            {
                var data = await this.service.GetServices(id);

                return Success("", data);
            }
            catch (System.Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetServices Method" + e);
                return Error("");
            }
        }

        [HttpGet("institute-master/{instituteType}")]
        public async Task<IActionResult> GetInstituteMaster(Role? instituteType)
        {
            try
            {
                var elements = await this.service.GetInstituteMaster(instituteType);

                return Success("", elements);
            }
            catch (System.Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetInstituteMaster Method" + e);
                return Error("");
            }
        }

        //[AuthorizeByRole(Role.SuperAdmin)]
        [HttpGet("roles")]
        public IActionResult GetRoles()
        {
            try
            {
                var roles = RoleModel.ToDropdownList();

                return Success("", roles);
            }
            catch (System.Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetRoles Method" + e);
                return Error("");
            }
        }

        [HttpGet("external-roles")]
        public IActionResult GetExternalRoles()
        {
            try
            {
                var roles = RoleModel.ExternalRoles();

                var data = roles.Select(a => new DropdownDataModel
                {
                    Id = (int)a.Role,
                    Text = a.Name,
                    TextAr = a.NameAr
                }).ToList();

                return Success("", data);
            }
            catch (System.Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetExternalRoles Method" + e);
                return Error("");
            }
        }

        //[AuthorizeByRole(Role.SuperAdmin)]
        [HttpGet("internal-roles")]
        public IActionResult GetInternalRoles()
        {
            try
            {
                var roles = RoleModel.InternalRoles();

                var data = roles.Select(a => new DropdownDataModel
                {
                    Id = (int)a.Role,
                    Text = a.Name,
                    TextAr = a.NameAr
                }).ToList();

                return Success("", data);
            }
            catch (System.Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetInternalRoles Method" + e);
                return Error("");
            }
        }

        [HttpGet("user-dropdown/{roleId}")]
        public async Task<IActionResult> GetUserDropdown(Role roleId)
        {
            try
            {
                var users = await this.serviceFactory.userService.GetUsers(roleId);

                var data = users.Select(a => new DropdownDataModel
                {
                    Id = a.UserId,
                    Text = (a.FirstName + " " + a.LastName),
                });

                return Success("", data);
            }
            catch (System.Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetUserDropdown Method" + e);
                return Error("");
            }
        }

        [HttpGet("users-dropdown/{roles}")]
        public async Task<IActionResult> GetUsersDropdown(string roles)
        {
            try
            {
                var users = await this.serviceFactory.userService.GetUsers(roles);

                var data = users.Select(a => new DropdownDataModel
                {
                    Id = a.UserId,
                    Text = (a.FirstName + " " + a.LastName),
                });

                return Success("", data);
            }
            catch (System.Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetUserDropdown Method" + e);
                return Error("");
            }
        }
    }
}