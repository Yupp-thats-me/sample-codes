﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Account.API.DataSource;
using SJP.Account.API.Models;
using SJP.Account.API.Services;
using SJP.Account.API.Services.Interfaces;
using SJP.Core.Api.Controllers;
using SJP.Core.Api.Models.UserManagement;
using SJP.Core.Composition;
using SJP.Core.Model;
using SJP.Core.Models;
using SJP.Core.Utility;
using SJP.Counselling.Api.Services;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace SJP.Account.API.Controllers.Areas.v1
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class UserController : BaseAccountController
    {
        private readonly IUserService service;


        private readonly string PROFILE_DIRECTORY = "user/profile-pic";


        public UserController(ServiceFactory serviceFactory, ILogger<DataController> logger, IUserService service, IConfiguration config, ApplicationDBContext dbContext) : base(logger, serviceFactory, dbContext, config)
        {
            this.service = service;
        }


        [HttpGet("users")]  // DO NOT USE THIS METHOD
        public async Task<IEnumerable<ApplicationUser>> GetUserPersonalDetails(Role? role)
        {
            try
            {


                var data = await this.service.GetUsers(role);

                return data;
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetUserPersonalDetails Method" + e);

                return null;
            }
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [HttpGet("personal-details")]
        public async Task<IActionResult> GetPersonalDetails()
        {
            try
            {
                var data = await this.service.GetUserDetails(long.Parse(this.UserId));

                return Success("", data);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetPersonalDetails Method" + e);
                return Error("");
            }
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [HttpGet("professional-details")]
        public async Task<IActionResult> GetProfessionalDetails()
        {
            try
            {
                var data = await this.service.GetProfessionalDetails(long.Parse(this.UserId));

                return Success("", data);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetProfessionalDetails Method" + e);
                return Error("");
            }
        }
        [Authorize(AuthenticationSchemes = "Bearer")]
        [HttpGet("educational-details")]
        public async Task<IActionResult> GetEducationalDetails()
        {
            try
            {
                var data = await this.service.GetEducationDetails(long.Parse(this.UserId));

                return Success("", data);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetEducationalDetails Method" + e);
                return Error("");
            }
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [HttpPost("profile-pic")]
        public async Task<IActionResult> UploadProfilePic()
        {
            try
            {
                var file = this.HttpContext.Request.Form.Files[0];

                await this.service.SaveProfilePic(long.Parse(this.UserId), file);

                await this.dbContext.SaveChangesAsync();

                var base64Thumbnail = serviceFactory.fileUtility.GetThumbnailBase64String(PROFILE_DIRECTORY, this.UserId, file.FileName);

                return Success("", base64Thumbnail);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in UploadProfilePic Method" + e);
                return Error("");
            }
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [HttpDelete("profile-pic")]
        public async Task<IActionResult> DeleteProfilePic()
        {
            try
            {
                await this.service.DeleteProfilePic(long.Parse(this.UserId));

                await this.dbContext.SaveChangesAsync();

                return Success("");
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in DeleteProfilePic Method" + e);
                return Error("");
            }
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [HttpPut("personal-details")]
        public async Task<IActionResult> UpdatePersonalDetails([FromBody] ApplicationUser model)
        {
            try
            {
                var succeeded = await this.service.UpdatePersonalDetails(long.Parse(this.UserId), model);

                if (succeeded)
                {
                    await dbContext.SaveChangesAsync();
                    return Success("");
                }
                return Error("Failed to save");
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in UpdatePersonalDetails Method" + e);
                return Error("");
            }
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [HttpPost("education-details")]
        public async Task<IActionResult> SaveEducationDetails([FromForm] EducationDetailModel model)
        {
            try
            {
                if (model.EducationLevelId == 0)
                {
                    model.EducationLevelId = null;
                }
                await this.service.SaveEducationDetails(model);

                await dbContext.SaveChangesAsync();

                return Success("");
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SaveEducationDetails Method" + e);
                return Error("");
            }
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [HttpPost("professional-details")]
        public async Task<IActionResult> SaveProfessionalDetails([FromBody] ProfessionalDetailModel model)
        {
            try
            {
                await this.service.SaveProfessionalDetails(model);

                await dbContext.SaveChangesAsync();

                return Success("");
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SaveProfessionalDetails Method" + e);
                return Error("");
            }
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [HttpDelete("professional-details/{id}")]
        public async Task<IActionResult> DeleteProfessionalDetails(long id)
        {
            try
            {
                var existingData = await service.GetProfessionalDetails(long.Parse(this.UserId));

                if (existingData == null || !(existingData.Any(a => a.Id == id)))
                {
                    return Error("Delete Failed! Either the data does not exists or you do not have permission");
                }

                await this.service.DeleteProfessionalDetails(id);

                await dbContext.SaveChangesAsync();

                return Success("Deleted successfully");
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in DeleteProfessionalDetails Method" + e);
                return Error("");
            }
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [HttpDelete("educational-details/{id}")]
        public async Task<IActionResult> DeleteEducationalDetails(long id)
        {
            try
            {
                var existingData = await service.GetEducationDetails(long.Parse(this.UserId));

                if (existingData == null || !(existingData.Any(a => a.Id == id)))
                {
                    return Error("Delete Failed! Either the data does not exists or you do not have permission");
                }

                await this.service.DeleteEducationalDetails(id);

                await dbContext.SaveChangesAsync();

                return Success("Deleted successfully");
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in DeleteEducationalDetails Method" + e);
                return Error("");
            }
        }

        //[Authorize(AuthenticationSchemes = "Bearer")]  DO NOT USE THIS METHOD.
        [HttpGet("{userId}")]
        public async Task<UserDetailsModel> GetUser(long userId)
        {
            try
            {
                var data = await this.service.GetUser(userId);

                return data;
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetUser Method" + e);

                return null;
            }
        }

        //[Authorize(AuthenticationSchemes = "Bearer")]  DO NOT USE THIS METHOD.
        [HttpGet("personal-details/{userId}")]
        public async Task<ApplicationUser> GetPersonalDetails(long userId)
        {
            try
            {
                var data = await this.service.GetUserDetails(userId);

                return data;
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetPersonalDetails Method" + e);
                return null;
            }
        }

        //[Authorize(AuthenticationSchemes = "Bearer")] DO NOT USE THIS METHOD.
        [HttpGet("professional-details/{userId}")]
        public async Task<IEnumerable<ProfessionalDetailModel>> GetProfessionalDetails(long userId)
        {
            try
            {
                var data = await this.service.GetProfessionalDetails(userId);

                return data;
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetProfessionalDetails Method" + e);

                return null;
            }
        }

        //[Authorize(AuthenticationSchemes = "Bearer")] DO NOT USE THIS METHOD.
        [HttpGet("educational-details/{userId}")]
        public async Task<IEnumerable<EducationDetailModel>> GetEducationalDetails(long userId)
        {
            try
            {
                var data = await this.service.GetEducationDetails(userId);

                return data;
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetEducationalDetails Method" + e);

                return null;
            }
        }

        //[Authorize(AuthenticationSchemes = "Bearer")] DO NOT USE THIS METHOD.
        [HttpGet("filtered-users")]
        public async Task<PageResult<ApplicationUser>> GetUsersByFilter([FromQuery] QueryFilter? filter, [FromQuery] int? roleId)
        {
            try
            {
                var query = new List<ApplicationUser>();

                var role = (Role?)roleId;
                var data = this.service.GetUsersAsQueryable(role);


                var list = await (from user in data
                                  where user.ApprovalStatus == (int)Status.Approved && !user.IsDeleted
                                  select new ApplicationUser
                                  {
                                      LastName = user.LastName,
                                      FirstName = user.FirstName,
                                      MiddleName = user.MiddleName,
                                      UserId = user.Id,
                                      CategoryId = user.CategoryId,
                                      ServicesId = user.ServicesId,
                                      ProfilePic = this.serviceFactory.fileUtility.GetThumbnailBase64String(this.PROFILE_DIRECTORY, user.Id.ToString(), user.ProfilePicFileName),

                                  }).ToListAsync();

                if (filter != null && filter.page > 0)
                {
                    var searchCategory = filter.searchCategory.ToIntList();
                    var searchService = filter.searchService.ToIntList();

                    query = list.Where(a => searchCategory.Count == 0 || a.CategoryId.ToIntList().Intersect(searchCategory).Any()
                                          && searchService.Count == 0 || a.ServicesId.ToIntList().Intersect(searchService).Any()
                                          && (String.IsNullOrEmpty(filter.searchText)
                                  || (a.FirstName.StartsWith(filter.searchText) || a.FirstName.Contains(filter.searchText)) || ((a.LastName.StartsWith(filter.searchText) || a.LastName.Contains(filter.searchText))))).ToList(); // VERY EXPENSIVE. TEMPORARY EXECUTION

                    int totalCount = query.Count;
                }
                else
                {
                    query = list;
                }


                PageResult<ApplicationUser> result = new PageResult<ApplicationUser>
                {
                    Count = query.Count,
                    PageIndex = filter?.page ?? 0,
                    PageSize = filter?.pagesize ?? 0,
                    Items = (filter == null || filter.page == 0) ? query : query.Skip((filter.page - 1) * filter.pagesize).Take(filter.serversize).ToList()
                };

                return result;
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetEducationalDetails Method" + e);

                return null;
            }
        }

        [HttpGet("test")]
        public async Task<Email.EmailTemplate> testTemplate()
        {
            var model = new EmailInfoModel()
            {

                EmailId = "test@test.com",
                Token = "dsadsadjsakdsadhsajdsakjd",
                ToAddress = new List<Common.EmailService.EmailAddress>() { new Common.EmailService.EmailAddress { Address = "test@test.com", Name = "Karthik" } }
            };

            var template = await this.serviceFactory.accountEmailService.BuildEmailConfirmation(model);

            return template;
        }
    }
}
