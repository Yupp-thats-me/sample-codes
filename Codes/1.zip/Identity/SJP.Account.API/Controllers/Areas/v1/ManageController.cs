﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Account.API.DataSource;
using SJP.Account.API.Handlers;
using SJP.Account.API.Models;
using SJP.Account.API.Services;
using SJP.Account.API.Services.Interfaces;
using SJP.Core.Api.Controllers;
using SJP.Core.Cache;
using SJP.Core.Composition;
using SJP.Core.Model;
using SJP.Core.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace SJP.Account.API.Controllers.Areas.v1
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]

    public class ManageController : BaseAccountController
    {


        private readonly IAccountService service;

        public ManageController(ILogger<ManageController> logger, IAccountService service, ApplicationDBContext dbContext, ServiceFactory serviceFactory, IConfiguration config) : base(logger, serviceFactory, dbContext, config)
        {
            this.service = service;
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [HttpPost("add-user")]
        [AuthorizeByRole(Role.SuperAdmin)]
        public async Task<IActionResult> AddUser(UserBasicModel user)
        {
            try
            {
                var result = await this.service.AddUser(user);

                if(result.Exists)
                {
                    return Error("Already exists");
                }

                var model = new ApprovalModel();
                model.Status = Status.Approved;
                model.Role = user.RequestedRole;
                model.UserId = result.User.Id;

                await service.UserApproval(model);

                if (result.IdentityResult.Succeeded)
                    return Success("");
                else
                    return Error(String.Join(',', result.IdentityResult.Errors));
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in AddUser Method" + e);
                return Error("");
            }
        }

        [HttpPost("add-users")]
        [Authorize(AuthenticationSchemes = "Bearer")]
        [AuthorizeByRole(Role.SuperAdmin)]
        public async Task<IActionResult> AddUsers(List<UserBasicModel> users)
        {
            try
            {
                var Errors = await this.service.AddUsers(users);

                if (Errors.Count == 0)
                {
                    //this.dbContext.SaveChanges();
                    return Success("");
                }
                else
                    return Error(String.Join(',', Errors.SelectMany(a => a.IdentityResult.Errors)));

            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in AddUsers Method" + e);
                return Error("");
            }
        }

        //[Authorize(AuthenticationSchemes = "Bearer")]
        //[AuthorizeByRole(Role.SuperAdmin)]
        //[HttpPost("update-user")]
        //public async Task<IActionResult> UpdateUser(RegistrationModel user)
        //{
        //    try
        //    {
        //        var result = await this.service.AddUser(user);

        //        if (result.IdentityResult.Succeeded)
        //        {
        //            //this.dbContext.SaveChanges();
        //            return Success("");
        //        }
        //        else
        //            return Error(String.Join(',', result.IdentityResult.Errors));

        //    }
        //    catch (Exception e)
        //    {
        //        return Error("");
        //    }
        //}

        [Authorize(AuthenticationSchemes = "Bearer")]
        [AuthorizeByRole(Role.SuperAdmin)]
        [HttpPut("activate-user/{id}")]
        public async Task<IActionResult> ActivateUser(string id)
        {
            try
            {
                await this.service.UpdateUserStatus(id, true);
                return Success("");
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in ActivateUser Method" + e);
                return Error("");
            }
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [AuthorizeByRole(Role.SuperAdmin)]
        [HttpPut("deactivate-user/{id}")]
        public async Task<IActionResult> DeActivateUser(string id)
        {
            try
            {
                await this.service.UpdateUserStatus(id, false);
                return Success("");
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in DeActivateUser Method" + e);
                return Error("");
            }
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [AuthorizeByRole(Role.SuperAdmin)]
        [HttpGet("professional-details/{userId}")]
        public async Task<IActionResult> GetProfessionalDetails(long userId)
        {
            try
            {
                var data = await this.serviceFactory.userService.GetProfessionalDetails(userId);

                return Success("", data);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetProfessionalDetails Method" + e);
                return Error("");
            }
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [AuthorizeByRole(Role.SuperAdmin)]
        [HttpGet("educational-details/{userId}")]
        public async Task<IActionResult> GetEducationalDetails(long userId)
        {
            try
            {
                var data = await this.serviceFactory.userService.GetEducationDetails(userId);

                return Success("", data);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetEducationalDetails Method" + e);
                return Error("");
            }
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [AuthorizeByRole(Role.SuperAdmin)]
        [HttpGet("user/{userId}")]
        public async Task<IActionResult> GetUser(long userId)
        {
            try
            {
                var data = await this.serviceFactory.userService.GetUser(userId);

                return Success("", data);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetUser Method" + e);
                return Error("");
            }
        }

        [AuthorizeByRole(Role.SuperAdmin)]
        [HttpGet("users-grid")]
        public async Task<IActionResult> GetUsersGrid(Role? role)
        {
            try
            {
                var data = await this.service.GetUsersGrid(role);

                return Success("", data);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetUsersGrid Method" + e);
                return Error("");
            }
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [AuthorizeByRole(Role.SuperAdmin)]
        [HttpGet("users-approval-grid")]
        public async Task<IActionResult> GetUsersInRole(Role? roleId)
        {
            try
            {
                var data = await this.service.GetUsersGrid(roleId);

                return Success("", data);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in UserApproval Method" + e);
                return Error("");
            }
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [AuthorizeByRole(Role.SuperAdmin)]
        [HttpDelete("user/{id}")]
        public IActionResult DeleteUsers(string id)
        {
            try
            {
                this.service.DeleteUser(id);

                return Success("");
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in DeleteUsers Method" + e);
                return Error("");
            }
        }

        [Authorize(AuthenticationSchemes = "Bearer")]
        [AuthorizeByRole(Role.SuperAdmin)]
        [HttpPut("approval-user")]
        public async Task<IActionResult> UserApproval([FromBody] ApprovalModel model)
        {
            try
            {
                await this.service.UserApproval(model);

                return Success("");
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in UserApproval Method" + e);
                return Error("");
            }
        }
    }
}