﻿using AutoMapper;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using SJP.Account.API.DataSource;
using SJP.Account.API.DataSource.Models;
using SJP.Account.API.Handlers;
using SJP.Account.API.Models;
using SJP.Account.API.Services;
using SJP.Account.API.Services.Interfaces;
using SJP.Common.EmailService;
using SJP.Common.JWTConfiguration;
using SJP.Core.Api.Controllers;
using SJP.Core.Api.Models.UserManagement;
using SJP.Core.Cache;
using SJP.Core.Composition;
using SJP.Core.Model;
using SJP.Core.Models;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace SJP.Account.API.Controllers.Areas.v1
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]

    public class AccountController : BaseAccountController
    {
        private readonly IAccountService service;

        private readonly IAccountEmailService emailService;

        private readonly JWTHandler jwtHandler;

        private readonly string PROFILE_DIRECTORY = "user/profile-pic";

        private readonly AuthenticationConfig authenticationConfig = null;

        public AccountController(ILogger<AccountController> logger, IAccountEmailService emailService, ServiceFactory serviceFactory, ApplicationDBContext dbContext, JWTHandler jwtHandler, IConfiguration config) : base(logger, serviceFactory, dbContext, config)
        {
            this.service = this.serviceFactory.accountService;
            this.emailService = emailService;
            this.jwtHandler = jwtHandler;

            this.authenticationConfig = new AuthenticationConfig();

            config.Bind("Authentication", authenticationConfig);
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegistrationModel user)
        {
            try
            {
                if (user == null || !ModelState.IsValid)
                    return BadRequest();


                if (service.EmailExists(user.PersonalDetails.EmailId))
                {
                    ModelState.AddModelError("EmailId", "Duplicate");
                    return Error("EmailId", (int)AccountErrorCode.EmailExists);
                }

                if (service.IdentityIdExists(user.PersonalDetails.IdentityId))
                {
                    ModelState.AddModelError("IdentityId", "Duplicate");
                    return Error("IdentityId", (int)AccountErrorCode.EmirateIdExists);
                }

                var roleName = ((RoleModel)user.PersonalDetails.RequestedRole).Name;

                if (user.RequireEducationalDetails && user.EducationalDetails == null)
                    return BadRequest(new { msg = "EducationalDetails cannot be null for '" + roleName + "'" });

                if (user.RequireProfessionalDetails && user.ProfessionalDetails == null)
                    return BadRequest(new { msg = "ProfessionalDetails cannot be null for '" + roleName + "'" });

                if (IsSuperAdmin)
                {
                    user.PersonalDetails.EntryVia = EntryVia.Admin;
                }
                else if (user.PersonalDetails.EntryVia == EntryVia.Invite)
                {
                    user.PersonalDetails.EntryVia = EntryVia.Invite;
                }
                else
                {
                    user.PersonalDetails.EntryVia = EntryVia.Manual;
                }

                user.PersonalDetails.ApprovalStatus = Status.Pending;

                var result = await this.service.AddUser(user);

                if (result.Exists)
                    return Error("User already exists", (int)AccountErrorCode.AlreadyExists);

                var autoValidate = (IsSuperAdmin || user.PersonalDetails.RequestedRole == Role.General);

                if (user.PersonalDetails.RequestedRole == Role.Student)
                {
                    var hasCHedsAlmanhalData = await this.jwtHandler.HasCHedsAlmanhalData(user.ExternalToken, user.PersonalDetails.IdentityId);

                    if (hasCHedsAlmanhalData)
                    {
                        autoValidate = true;
                    }
                }

                if (autoValidate)
                {
                    var model = new ApprovalModel();
                    model.Status = Status.Approved;
                    model.Role = user.PersonalDetails.RequestedRole;
                    model.UserId = result.User.Id;
                    await service.UserApproval(model, user.Provider == ProviderType.SSO);
                }

                if (result.IdentityResult.Succeeded)
                {
                    if (user.RequireEducationalDetails)
                    {
                        user.EducationalDetails.UserId = result.User.Id;
                        user.EducationalDetails.ApprovalStatus = IsSuperAdmin ? Status.Approved : Status.Pending;
                        await this.serviceFactory.userService.SaveEducationDetails(user.EducationalDetails);
                    }

                    if (user.RequireProfessionalDetails)
                    {
                        user.ProfessionalDetails.UserId = result.User.Id;
                        user.ProfessionalDetails.ApprovalStatus = IsSuperAdmin ? Status.Approved : Status.Pending;
                        await this.serviceFactory.userService.SaveProfessionalDetails(user.ProfessionalDetails);
                    }

                    this.dbContext.SaveChanges();

                    if (user.PersonalDetails.ProviderId == Guid.Parse(ProviderType.SSO))
                    {
                        var payload = await jwtHandler.VerifyGoogleTokenAsync(user.ExternalToken, user.Provider);

                        if (payload == null)
                            return Error("Invalid External Authtentication", Core.Constants.ErrorCode.InvalidAuthentication);

                        var info = new UserLoginInfo(user.Provider, payload.Subject, user.Provider);

                        var externalLoginResult = await this.serviceFactory.externalLoginService.AddLoginAsync(result.User, info);

                        if (externalLoginResult.Succeeded)
                        {
                            if (user.PersonalDetails.RequestedRole == Role.Student)
                            {
                                externalLoginResult.UserDetails.EducationCategoryId = this.dbContext.EducationalDetails.Where(a => a.UserId == result.User.Id).FirstOrDefault().EducationCategoryId;
                            }

                            externalLoginResult = await TokenResponse(externalLoginResult);

                            await dbContext.SaveChangesAsync();

                            return Success("", externalLoginResult);
                        }
                        else
                        {
                            this.Logger.LogError(new Exception("Error Occured"), "Error Occured in External Login Method " + externalLoginResult.Errors.ToString());

                            return Error("FailedToLoginExternalUser");
                        }
                    }

                    var emailInfo = new EmailInfoModel() { ClientURI = user.EmailVerificationURI, EmailId = user.PersonalDetails.EmailId };

                    emailInfo.EmailId = user.PersonalDetails.EmailId;

                    emailInfo.ToAddress = new List<EmailAddress>();

                    emailInfo.ToAddress.Add(new EmailAddress { Address = user.PersonalDetails.EmailId, Name = user.PersonalDetails.FirstName + " " + user.PersonalDetails.LastName });

                    emailInfo.ClientURI = user.EmailVerificationURI;

                    var template = await emailService.BuildEmailConfirmation(emailInfo);

                    var emailAddress = new EmailAddress() { Name = user.PersonalDetails.FirstName + " " + user.PersonalDetails.LastName, Address = user.PersonalDetails.EmailId };

                    this.serviceFactory.emailService.Send(template);

                    return Success("Sent for Approval if not super admin");
                }
                else
                {
                    this.Logger.LogError(new Exception("Error Occured"), "Error Occured in Register Method " + result.IdentityResult.Errors.Select(a => a.Description).ToList());
                    return Error("");
                }
            }
            catch (Exception e)
            {

                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in Register Method" + e);
                return Error("");
            }
        }

        [HttpPost("sjp-signin")]
        public async Task<IActionResult> SJPSignIn([FromBody] LoginModel model)
        {
            try
            {
                var result = await this.service.SignIn(model);
                return await SignIn(model, result);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SJPSignIn Method" + e);
                return Error("");
            }
        }

        private async Task<IActionResult> SignIn(LoginModel model, LoggedInUserModel result)
        {
            if (result.Succeeded)
            {
                if (!result.UserDetails.EmailConfirmed)
                {
                    var email = await this.service.BuildEmailConfirmationEmail(result.UserDetails, model.EmailVerificationURI);

                    this.serviceFactory.emailService.Send(email);

                    return Error("", (int)result.ErrorCode);
                }

                result = await TokenResponse(result);

                await dbContext.SaveChangesAsync();

                return Success("", result);
            }
            else
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SJPSignIn Method " + String.Join(',', result.Errors.Select(a => a).ToList()));
                return Error("", (int)result?.ErrorCode);
            }
        }

        private async Task<LoggedInUserModel> TokenResponse(LoggedInUserModel result)
        {
            var signingCredentials = jwtHandler.GetSigningCredentials();
            var claims = jwtHandler.GetClaims(result.UserDetails, result.Roles);
            var tokenOptions = jwtHandler.GenerateTokenOptions(signingCredentials, claims);
            result.token = new JwtSecurityTokenHandler().WriteToken(tokenOptions);
            result.refreshToken = jwtHandler.GenerateRefreshToken();
            result.UserDetails.ProfilePic = serviceFactory.fileUtility.GetThumbnailBase64String(PROFILE_DIRECTORY, result.UserDetails.UserId.ToString(), result.UserDetails.ProfilePicFileName);

            var user = await service.FindUserByIdAsync(result.UserDetails.UserId.ToString());

            user.Token = result.token;

            user.RefreshTokenExpiryTime = DateTime.Now.AddDays(authenticationConfig.JWTAuthSettings.RefreshExpiryInDays);

            user.RefreshToken = result.refreshToken;

            return result;
        }

        //[HttpPost("sso-signin")]
        //public async Task<IActionResult> SSOSignIn(string ProviderId, string ProviderKey)
        //{
        //    try
        //    {
        //        var result = await this.service.SSOSignIn(ProviderId, ProviderKey);



        //        //return await SignIn(model, result);
        //    }
        //    catch (Exception e)
        //    {
        //        this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SSOSignIn Method" + e);

        //        return Error("");
        //    }
        //}

        [HttpPost("sjp-signout")]
        public async Task<IActionResult> SJPSignOut()
        {
            try
            {
                var Succeeded = await this.service.SignOut();

                if (Succeeded)
                {
                    return Success("");
                }
                else
                    return Error("");
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SJPSignOut Method" + e);
                return Error("");
            }
        }

        [HttpPost("change-password")]
        public IActionResult ChangePassword([FromBody] string oldPassword, string newPassword)
        {
            try
            {
                var succeeded = this.service.ChangePassword(this.UserId, oldPassword, newPassword);

                return Success("");
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in ChangePassword Method" + e);
                return Error("");
            }
        }

        [HttpPost("recover-password")]
        public async Task<IActionResult> RecoverPassword([FromBody] ResetDataModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest();

                var user = await this.service.UserExists(model.Email);

                if (user == null)
                {
                    return Error("User does not exists", (int)AccountErrorCode.DoesNotExists);
                }
                try
                {


                    var emailInfo = new EmailInfoModel();

                    emailInfo.EmailId = model.Email;

                    emailInfo.ToAddress = new List<EmailAddress>();

                    emailInfo.ToAddress.Add(new EmailAddress { Address = model.Email, Name = user.FirstName + " " + user.LastName });

                    emailInfo.ClientURI = model.ClientURI;

                    var emailMessage = await this.emailService.BuildResetPasswordEmail(emailInfo);

                    this.serviceFactory.emailService.Send(emailMessage);

                    return Success("Mail sent");
                }
                catch (Exception e)
                {
                    this.Logger.LogError(new Exception("Error Occured"), " mail sending failed" + e);
                    return Error("Failed to send mail");
                }
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in RecoverPassword Method" + e);
                return Error("");
            }
        }


        [HttpPost("reset-password")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetDataModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest();

                model.Token = model.Token.Replace(' ', '+');

                var user = await this.service.UserExists(model.Email);

                if (user == null)
                {
                    return BadRequest(new { msg = "User does not exists" });
                }

                var result = await this.service.ResetPassword(user, model);

                if (result.Succeeded)
                {
                    return Success("Password reset successfully");
                }
                else
                {
                    this.Logger.LogError(new Exception("Error Occured"), "Error Occured in ResetPassword Method" + String.Join(',', result.Errors));
                    return Error("");
                }
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in ResetPassword Method" + e);
                return Error("");
            }
        }

        [HttpPost("confirm-email")]
        public async Task<IActionResult> ConfirmEmail(string token, string email)
        {
            try
            {
                token = token.Replace(' ', '+');

                var result = await this.service.ConfirmEmail(token, email);

                if (result.Succeeded)
                {
                    return Success("Email Confirmed");
                }
                else
                {
                    this.Logger.LogError(new Exception("Error Occured"), "Error Occured in ConfirmEmail Method" + String.Join(',', result.Errors.Select(a => a.Description).ToList()));

                    return Error("", Core.Constants.ErrorCode.EmailNotConfirmed);
                }
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in ConfirmEmail Method" + e);
                return Error("");
            }
        }

        [HttpPost]
        [Route("refresh-token")]
        public async Task<IActionResult> RefreshToken([FromBody] LoggedInUserModel model)
        {
            try
            {
                if (model is null || (model.token is null))
                {
                    return Error("Invalid client request");
                }

                var principal = jwtHandler.GetPrincipalFromExpiredToken(model.token);

                var userId = principal.Claims.Where(a => a.Type == ClaimTypes.NameIdentifier).Select(a => a.Value).FirstOrDefault(); //this is mapped to the Name claim by default

                var user = await service.FindUserByIdAsync(userId);

                if (user == null || user.RefreshToken != model.refreshToken || user.RefreshTokenExpiryTime < DateTime.Now)
                {
                    return Error("Invalid client request");
                }

                var signingCredentials = jwtHandler.GetSigningCredentials();

                var tokenOptions = jwtHandler.GenerateTokenOptions(signingCredentials, principal.Claims.ToList());

                var token = new JwtSecurityTokenHandler().WriteToken(tokenOptions);

                var refreshToken = jwtHandler.GenerateRefreshToken();

                user.RefreshToken = refreshToken;

                dbContext.SaveChanges();

                return Success("", new { token = token, refreshToken = refreshToken });
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in RefreshToken Method" + e);
                return Error("");
            }
        }

        [HttpPost("send-confirm-mail-link")]
        public async Task<IActionResult> ResendEmailLink([FromBody] EmailInfoModel model)
        {
            
            try
            {
                var emailInfo = new EmailInfoModel();

                emailInfo.EmailId = model.EmailId;

                emailInfo.ToAddress = new List<EmailAddress>();

                emailInfo.ToAddress.Add(new EmailAddress { Address = model.EmailId, Name = model.EmailId });

                emailInfo.ClientURI = model.ClientURI;

                var template = await emailService.BuildEmailConfirmation(emailInfo);

                this.serviceFactory.emailService.Send(template);

                return Success("");
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in ResendEmailLink Method" + e);

                return Error("", Core.Constants.ErrorCode.EmailNotSent);
            }
        }
    }
}
