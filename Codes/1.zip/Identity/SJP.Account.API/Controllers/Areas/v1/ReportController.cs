﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Account.API.DataSource;
using SJP.Account.API.Handlers;
using SJP.Account.API.Models;
using SJP.Account.API.Models.Report;
using SJP.Account.API.Services;
using SJP.Account.API.Services.Interfaces;
using SJP.Common.JWTConfiguration;
using SJP.Core.Models;

namespace SJP.Account.API.Controllers.Areas.v1
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class ReportController : BaseAccountController
    {
        private readonly IReportService service;

        //private readonly string PROFILE_DIRECTORY = "user/profile-pic";

        public ReportController(ILogger<ReportController> logger, ServiceFactory serviceFactory, ApplicationDBContext dbContext, JWTHandler jwtHandler, IConfiguration config) : base(logger, serviceFactory, dbContext, config)
        {
            this.service = this.serviceFactory.reportService;
        }

        [HttpGet("student")]
        public async Task<IActionResult> GetStudentReport([FromQuery] FilterModel filter)
        {
            try
            {

                var data = await this.service.GetUsers(filter, Role.Student);

                return Success("", data);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetUserPersonalDetails Method" + e);

                return Error("");
            }
        }

        [HttpGet("profile-summary")]
        public async Task<IActionResult> GetProfileSummary([FromQuery] FilterModel filter)
        {
            try
            {
                var data = await this.service.GetProfileSummary(filter);

                return Success("", data);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetUserPersonalDetails Method" + e);

                return Error("");
            }
        }

        [HttpGet("student-chart")]
        public IActionResult GetStudentChartData([FromQuery] FilterModel filter)
        {
            try
            {
                var data = this.service.GetStudentChartData(filter);

                return Success("", data);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetUserPersonalDetails Method" + e);

                return Error("");
            }
        }
        [HttpGet("cxo-chart")]
        public IActionResult GetCXOChartData([FromQuery] FilterModel filter)
        {
            try
            {
                var data = this.service.GetCXOChartData(filter);

                return Success("", data);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetCXOChartData Method" + e);

                return Error("");
            }
        }

    }
}