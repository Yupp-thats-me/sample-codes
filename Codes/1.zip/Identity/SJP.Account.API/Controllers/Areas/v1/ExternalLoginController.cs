﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Account.API.DataSource;
using SJP.Account.API.DataSource.Models;
using SJP.Account.API.Handlers;
using SJP.Account.API.Models;
using SJP.Account.API.Services;
using SJP.Account.API.Services.Interfaces;
using SJP.Common.JWTConfiguration;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Controllers.Areas.v1
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class ExternalLoginController : BaseAccountController
    {
        private readonly IExternalLoginService service;

        private readonly JWTHandler jwtHandler;

        private readonly string PROFILE_DIRECTORY = "user/profile-pic";


        private readonly AuthenticationConfig authenticationConfig = null;
        public ExternalLoginController(ILogger<ExternalLoginController> logger, IExternalLoginService service, ServiceFactory serviceFactory, ApplicationDBContext dbContext, JWTHandler jwtHandler, IConfiguration config) : base(logger, serviceFactory, dbContext, config)
        {
            this.jwtHandler = jwtHandler;

            this.service = service;

            this.authenticationConfig = new AuthenticationConfig();

            config.Bind("Authentication", authenticationConfig);
        }

        [HttpGet]
        [Route("validate-user/{provider}")]
        public async Task<IActionResult> ValidateUser(string provider)
        {
            try
            {
                var externalToken = Request.Headers["Authorization"].ToString().Replace("Bearer ", "");

                var payload = await jwtHandler.VerifyGoogleTokenAsync(externalToken, provider);

                if (payload == null)
                    return Error("Invalid External Authtentication", Core.Constants.ErrorCode.InvalidAuthentication);

                var info = new UserLoginInfo(provider, payload.Subject, provider);

                var user = await service.FindByLoginAsync(info.LoginProvider, info.ProviderKey);

                LoggedInUserModel result = new LoggedInUserModel();

                result.Status = Core.Model.Status.UnRegistered;

                if (user != null)
                {
                    result = new LoggedInUserModel()
                    {
                        Email = user.Email,
                        UserDetails = serviceFactory.accountService.CreateModel(user),
                        Succeeded = result.Succeeded,
                        Roles = await service.GetRolesAsync(user),
                        Status = (Core.Model.Status)user.ApprovalStatus
                    };

                    if (user.ApprovalStatus == (int)Core.Model.Status.Approved)
                    {
                        var signingCredentials = jwtHandler.GetSigningCredentials();
                        var claims = jwtHandler.GetClaims(result.UserDetails, result.Roles);
                        var tokenOptions = jwtHandler.GenerateTokenOptions(signingCredentials, claims);
                        result.token = new JwtSecurityTokenHandler().WriteToken(tokenOptions);
                        result.refreshToken = jwtHandler.GenerateRefreshToken();
                        result.UserDetails.ProfilePic = serviceFactory.fileUtility.GetThumbnailBase64String(PROFILE_DIRECTORY, result.UserDetails.UserId.ToString(), result.UserDetails.ProfilePicFileName);

                        user.Token = result.token;

                        user.RefreshTokenExpiryTime = DateTime.Now.AddDays(authenticationConfig.JWTAuthSettings.RefreshExpiryInDays);

                        user.RefreshToken = result.refreshToken;

                        await dbContext.SaveChangesAsync();
                    }
                }

                return Success("", result);
            }
            catch (Exception e)
            {
                return Error("Failed to login");
                throw;
            }
        }


        [HttpPost]
        [Route("update-registration")]
        public async Task<IActionResult> UpdateRegistration([FromBody] RegistrationModel model)
        {
            try
            {
                var payload = await jwtHandler.VerifyGoogleTokenAsync(model.ExternalToken, model.Provider);

                if (payload == null)
                    return Error("Invalid External Authtentication", Core.Constants.ErrorCode.InvalidAuthentication);

                var info = new UserLoginInfo(model.Provider, payload.Subject, model.Provider);

                var user = await service.FindByLoginAsync(info.LoginProvider, info.ProviderKey);

                LoggedInUserModel result = new LoggedInUserModel();

                if (user == null)
                {
                    model.PersonalDetails.ApprovalStatus = Core.Model.Status.Pending;

                    var registration = await this.serviceFactory.accountService.AddUser(model);

                    await dbContext.SaveChangesAsync();

                    user = registration.User;

                    //prepare and send an email for the email confirmation
                }
                else
                {

                    if (result.UserDetails.ApprovalStatus == Core.Model.Status.Approved)
                    {
                        result = new LoggedInUserModel()
                        {
                            Email = user.Email,
                            UserDetails = result.Succeeded ? serviceFactory.accountService.CreateModel(user) : null,
                            Succeeded = result.Succeeded,
                            Roles = await service.GetRolesAsync(user)
                        };

                        var signingCredentials = jwtHandler.GetSigningCredentials();
                        var claims = jwtHandler.GetClaims(model.PersonalDetails, result.Roles);
                        var tokenOptions = jwtHandler.GenerateTokenOptions(signingCredentials, claims);
                        result.token = new JwtSecurityTokenHandler().WriteToken(tokenOptions);
                        result.refreshToken = jwtHandler.GenerateRefreshToken();
                        result.UserDetails.ProfilePic = serviceFactory.fileUtility.GetThumbnailBase64String(PROFILE_DIRECTORY, result.UserDetails.UserId.ToString(), result.UserDetails.ProfilePicFileName);

                        user.Token = result.token;

                        user.RefreshTokenExpiryTime = DateTime.Now.AddDays(authenticationConfig.JWTAuthSettings.RefreshExpiryInDays);

                        user.RefreshToken = result.refreshToken;

                        await dbContext.SaveChangesAsync();
                    }
                }

                result.Status = (Core.Model.Status)user.ApprovalStatus;

                return Success("", result);
            }
            catch (Exception e)
            {
                return Error("");
            }
        }

        //[HttpGet]
        //[Route("CallBack")]
        //public async Task<IActionResult> CallBack(string remoteError = null)
        //{
        //    return Success("", remoteError);
        //    //var returnUrl = Url.Content("~/");
        //    //if (remoteError != null)
        //    //{
        //    //    //ErrorMessage = $"Error from external provider: {remoteError}";
        //    //    return Redirect("/Identity/Account/Login");
        //    //}
        //    //var info = await _signInManager.GetExternalLoginInfoAsync();
        //    //if (info == null)
        //    //{
        //    //    //ErrorMessage = "Error loading external login information.";
        //    //    return Redirect("/Identity/Account/Login");
        //    //}

        //    //// Sign in the user with this external login provider if the user already has a login.
        //    //var result = await _signInManager.ExternalLoginSignInAsync(info.LoginProvider, info.ProviderKey, isPersistent: false, bypassTwoFactor: true);
        //    //if (result.Succeeded)
        //    //{
        //    //    _logger.LogInformation("{Name} logged in with {LoginProvider} provider.", info.Principal.Identity.Name, info.LoginProvider);
        //    //    return Redirect("/");
        //    //}
        //    //if (result.IsLockedOut)
        //    //{
        //    //    return Redirect("/Identity/Account/Login");
        //    //}
        //    //else
        //    //{
        //    //    // If the user does not have an account, then ask the user to create an account.
        //    //    //ReturnUrl = returnUrl;
        //    //    //LoginProvider = info.LoginProvider;
        //    //    var Email = "";
        //    //    var Name = info.Principal.Identity.Name;

        //    //    if (info.Principal.HasClaim(c => c.Type == ClaimTypes.Email))
        //    //    {
        //    //        Email = info.Principal.FindFirstValue(ClaimTypes.Email);
        //    //    }

        //    //    var user = new IdentityUser { UserName = Email, Email = Name };
        //    //    var result2 = await _userManager.CreateAsync(user);
        //    //    if (result2.Succeeded)
        //    //    {
        //    //        result2 = await _userManager.AddLoginAsync(user, info);
        //    //        if (result2.Succeeded)
        //    //        {
        //    //            await _signInManager.SignInAsync(user, isPersistent: false);
        //    //            _logger.LogInformation("User created an account using {Name} provider.", info.LoginProvider);

        //    //            var userId = await _userManager.GetUserIdAsync(user);
        //    //            var code = await _userManager.GenerateEmailConfirmationTokenAsync(user);
        //    //            code = WebEncoders.Base64UrlEncode(Encoding.UTF8.GetBytes(code));
        //    //            var callbackUrl = Url.Page(
        //    //                "/Account/ConfirmEmail",
        //    //                pageHandler: null,
        //    //                values: new { area = "Identity", userId = userId, code = code },
        //    //                protocol: Request.Scheme);

        //    //            await _emailSender.SendEmailAsync(Email, "Confirm your email",
        //    //                $"Please confirm your account by <a href='{HtmlEncoder.Default.Encode(callbackUrl)}'>clicking here</a>.");

        //    //            return Redirect("/");
        //    //        }
        //    //    }
        //    //    foreach (var error in result2.Errors)
        //    //    {
        //    //        ModelState.AddModelError(string.Empty, error.Description);
        //    //    }

        //    //    return Redirect("/");
        //    //}
        //}
    }
}
