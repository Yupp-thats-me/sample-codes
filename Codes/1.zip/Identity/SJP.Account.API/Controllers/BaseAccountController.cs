﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Account.API.DataSource;
using SJP.Account.API.Services;
using SJP.Common.EmailService;
using SJP.Core.Api.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BaseAccountController : BaseApiController
    {
        protected ServiceFactory serviceFactory;

        protected readonly IConfiguration config;
        protected readonly ApplicationDBContext dbContext;
        protected readonly IEmailService emailService;

        public BaseAccountController(ILogger logger, ServiceFactory serviceFactory, ApplicationDBContext dbContext, IConfiguration config) : base(logger)
        {
            this.dbContext = dbContext;
            this.serviceFactory = serviceFactory;
            this.serviceFactory.Init(dbContext, HttpContext);
            this.serviceFactory.userService.Init(dbContext, HttpContext);
            this.config = config;
        }

        [HttpGet]
        public string ping()
        {
            return "Activated";
        }
    }
}
