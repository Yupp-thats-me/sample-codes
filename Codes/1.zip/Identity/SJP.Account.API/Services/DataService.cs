﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Account.API.DataSource;
using SJP.Account.API.DataSource.DataAccess.Interfaces;
using SJP.Account.API.DataSource.Models;
using SJP.Account.API.Services.Interfaces;
using SJP.Core.Model;
using SJP.Core.Models;
using SJP.Core.Services;
using SJP.DataAccess.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Services
{
    public class DataService : ServiceBase, IDataService
    {
        private readonly ILogger logger;
        protected ILogger Logger => logger;

        private HttpContext httpContext;

        private readonly UserManager<Users> userManager;
        private readonly SignInManager<Users> signInManager;
        private ApplicationDBContext dbContext;

        public DataService(ILogger<AccountService> logger, UserManager<Users> userManager, SignInManager<Users> signInManager, IConfiguration configuration) : base(configuration)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
        }

        public void Init(ApplicationDBContext dbContext, HttpContext httpContext)
        {
            this.dbContext = dbContext;
            this.httpContext = httpContext;
        }

        public override void Dispose()
        {
            //throw new System.NotImplementedException();
        }

        public async Task<IEnumerable<DropdownDataModel>> GetElements(string elementTypeId)
        {
            IEnumerable<DropdownDataModel> elements;

            var elementTypes = String.IsNullOrEmpty(elementTypeId) ? new List<int>() : elementTypeId.Split(',').Select(a => int.Parse(a)).ToList();

            var result = await this.dbContext.Elements.Where(a => elementTypes.Contains(a.ElementType)).ToListAsync();

            if (result != null)
            {
                elements = result.Select(CreateModel());
            }
            else
                elements = new List<DropdownDataModel>();

            return elements;
        }

        public async Task<IEnumerable<DropdownDataModel>> GetServices(string categoryId)
        {
            var categories = String.IsNullOrEmpty(categoryId) ? null : categoryId.Split(',').Select(a => long.Parse(a)).ToList();

            var result = await (from service in dbContext.ServiceMaster
                                where (categories == null || categories.Contains(service.CategoryId))
                                select new DropdownDataModel
                                {
                                    Id = service.Id,
                                    Text = service.NameEn,
                                    data = service
                                }).ToListAsync();

            return result;
        }

        public async Task<IEnumerable<DropdownDataModel>> GetCategories()
        {
            var result = await (from category in dbContext.CategoryMaster

                                select new DropdownDataModel
                                {
                                    Id = category.Id,
                                    Text = category.NameEn,
                                    data = category
                                }).ToListAsync();

            return result;
        }

        private DropdownDataModel CreateModel(Elements element)
        {
            var model = new DropdownDataModel()
            {
                Id = (int)element.Id,
                NameAr = element.ElementNameAr,
                NameEn = element.ElementNameEn,
                ElementType = element.ElementType
            };

            return model;
        }

        private Func<Elements, DropdownDataModel> CreateModel()
        {
            return a => CreateModel(a);
        }

        public async Task<IEnumerable<DropdownDataModel>> GetInstituteMaster(Role? instituteType)
        {
            IEnumerable<DropdownDataModel> elements;

            int? instituteTypeId = (int?)instituteType;

            var result = this.dbContext.InstituteMasters;

            if (result != null)
            {
                elements = await result.Where(a => (instituteTypeId == null) || a.EducationCategoryId == instituteTypeId).Select(a => new DropdownDataModel()
                {
                    Id = a.Id,
                    NameAr = a.InstituteNameAr,
                    NameEn = a.InstituteNameEn
                }).ToListAsync();
            }
            else
                elements = new List<DropdownDataModel>();

            return elements;
        }
    }
}
