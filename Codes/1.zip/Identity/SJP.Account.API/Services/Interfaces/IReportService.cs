﻿using SJP.Account.API.DataSource;
using SJP.Account.API.Models;
using SJP.Account.API.Models.Report;
using SJP.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Services.Interfaces
{
    public interface IReportService
    {
        public void Init(ApplicationDBContext dbContext);

        /// <summary>
        /// Dependencies : InstituteMasters, Elements
        /// </summary>
        /// <param name="role"></param>
        /// <returns></returns>
        public Task<IEnumerable<UserReportModel>> GetUsers(FilterModel filter, Role? role);

        public Task<ProfileSummaryReportModel> GetProfileSummary(FilterModel filter);
        public IEnumerable<StudentChartModel> GetStudentChartData(FilterModel filter);
        public IEnumerable<CXOChartModel> GetCXOChartData(FilterModel filter);

    }
}
