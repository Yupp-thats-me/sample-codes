﻿using SJP.Account.API.Email;
using SJP.Account.API.Models;
using SJP.Common.EmailService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Services.Interfaces
{
    public interface IAccountEmailService
    {
        public Task<EmailTemplate> BuildEmailConfirmation(EmailInfoModel model);

        public Task<EmailTemplate> BuildResetPasswordEmail(EmailInfoModel model);
    }
}