﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using SJP.Account.API.DataSource;
using SJP.Account.API.DataSource.Models;
using SJP.Account.API.Models;
using SJP.Common.EmailService;
using SJP.Core.Api.Models.UserManagement;
using SJP.Core.Model;
using SJP.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Services.Interfaces
{
    public interface IAccountService
    {
        public Task<UserIdentityResult> AddUser(RegistrationModel user);

        public Task<UserIdentityResult> AddExternalUser(RegistrationModel user);


        public Task<UserIdentityResult> AddUser(UserBasicModel user);


        public Task<List<UserIdentityResult>> AddUsers(IEnumerable<UserBasicModel> users);

        public Task<bool> DeleteUser(string userId);

        /// <summary>
        /// Comma separated ids.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>

        public Task<IEnumerable<ApplicationUser>> GetUsersGrid(Role? role);

        public Task<LoggedInUserModel> SignIn(LoginModel model);

        public Task<LoggedInUserModel> SSOSignIn(string Provider, string ProviderKey);


        public Task<bool> SignOut();

        public void Init(ApplicationDBContext dbContext, HttpContext httpContext);

        public Task<bool> ChangePassword(string userId, string oldPassword, string newPassword);

        public Task<IdentityResult> ResetPassword(Users user, ResetDataModel model);

        public Task<bool> UpdateUserStatus(string userId, bool status);

        public Task UserApproval(ApprovalModel model, bool isExternalLogin = false);


        public Task<EmailMessage> BuildEmailConfirmationEmail(ApplicationUser user, string EmailVerificationURI);

        public EmailMessage BuildPasswordRecoveryEmail(Users user, ResetDataModel model);

        public Task<Users> UserExists(string email);

        public bool EmailExists(string EmailId);
        public bool IdentityIdExists(string IdentityId);    // EmirateId/LicenseNumber

        public Task<string> ForgotPassword(Users user);

        public Task<IdentityResult> ConfirmEmail(string token, string email);

        public Task<string> GeneratePasswordResetToken(Users user);

        public Task<string> GetRole(string userId);

        public Task<Users> FindUserByIdAsync(string userId);

        public ApplicationUser CreateModel(Users user);

    }
}