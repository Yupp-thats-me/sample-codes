﻿using Microsoft.AspNetCore.Http;
using SJP.Account.API.DataSource;
using SJP.Core.Model;
using SJP.Core.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SJP.Account.API.Services.Interfaces
{
    public interface IDataService
    {
        /// <summary>
        /// comma separated elementTypeId accepted for multiple element types
        /// </summary>
        /// <param name="elementTypeId"></param>
        /// <returns>IEnumerable<DropdownDataModel></returns>
        public Task<IEnumerable<DropdownDataModel>> GetElements(string elementTypeId);

        public void Init(ApplicationDBContext dbContext, HttpContext httpContext);
        public Task<IEnumerable<DropdownDataModel>> GetCategories();

        public Task<IEnumerable<DropdownDataModel>> GetServices(string id);


        public Task<IEnumerable<DropdownDataModel>> GetInstituteMaster(Role? instituteType);

    }
}
