﻿using Microsoft.AspNetCore.Identity;
using SJP.Account.API.DataSource.Models;
using SJP.Account.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Services.Interfaces
{
    public interface IExternalLoginService
    {
        public Microsoft.AspNetCore.Authentication.AuthenticationProperties GetExternalAuthenticationProperties(string provider, string redirectURL);

        public Task<Users> FindByLoginAsync(string provider, string providerKey);

        public Task<LoggedInUserModel> AddLoginAsync(Users user, UserLoginInfo info);

        public Task<IList<string>> GetRolesAsync(Users user);
    }
}
