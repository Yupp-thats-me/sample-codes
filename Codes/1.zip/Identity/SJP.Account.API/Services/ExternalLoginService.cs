﻿using Google.Apis.Auth;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Account.API.DataSource.Models;
using SJP.Account.API.Models;
using SJP.Account.API.Services.Interfaces;
using SJP.Core.Api.Models.UserManagement;
using SJP.Core.Model;
using SJP.Core.Models;
using SJP.Core.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Account.API.Services
{
    public class ExternalLoginService : ServiceBase, IExternalLoginService
    {

        private readonly SignInManager<Users> signInManager;
        private readonly UserManager<Users> userManager;

        private readonly ILogger logger;
        protected ILogger Logger => logger;

        public ExternalLoginService(ILogger<ExternalLoginService> logger, UserManager<Users> userManager, SignInManager<Users> signInManager, IConfiguration configuration) : base(configuration)
        {
            this.signInManager = signInManager;
            this.userManager = userManager;
        }
        public Microsoft.AspNetCore.Authentication.AuthenticationProperties GetExternalAuthenticationProperties(string provider, string redirectURL)
        {
            try
            {
                var properties = signInManager.ConfigureExternalAuthenticationProperties(provider, redirectURL);

                return properties;
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public async Task<Users> FindByLoginAsync(string provider, string providerKey)
        {
            try
            {
                return await this.userManager.FindByLoginAsync(provider, providerKey);
            }
            catch (Exception e)
            {
                // log 
                throw;
            }
        }

        public async Task<LoggedInUserModel> AddLoginAsync(Users user, UserLoginInfo info)
        {
            try
            {
                var loginResult = await userManager.AddLoginAsync(user, info);

                var result = new LoggedInUserModel()
                {
                    Email = user.Email,
                    UserDetails = loginResult.Succeeded ? CreateModel(user) : null,
                    Succeeded = loginResult.Succeeded,
                    Roles = await userManager.GetRolesAsync(user)
                };

                return result;

            }
            catch (Exception e)
            {
                //log
                throw;
            }
        }
        public async Task<IList<string>> GetRolesAsync(Users user)
        {
            try
            {
                return await userManager.GetRolesAsync(user);
            }
            catch (Exception e)
            {

                throw;
            }
        }

        private ApplicationUser CreateModel(Users user)
        {
            var model = new ApplicationUser()
            {
                UserId = user.Id,
                CurrentAddress = user.CurrentAddress,
                DOB = user.DOB,
                EmailId = user.Email,
                Gender = (Gender)user.Gender,
                LastName = user.LastName,
                PermanentAddress = user.PermanentAddress,
                Phone = user.PhoneNumber,
                ProviderId = user.ProviderId,
                RequestedRole = (Role)user.RequestedRole,
                ShortBio = user.ShortBio,
                UserCode = user.UserCode,   // StudentId/EmployeeId
                ApprovalStatus = (Status)user.ApprovalStatus,
                ServicesId = user.ServicesId,
                FirstName = user.FirstName,
                IdentityId = user.IdentityId,   // Emirate/License
                IsActive = user.IsActive,
                CategoryId = user.CategoryId,
                Language = user.Language,
                DepartmentId = user.DepartmentId,
                Reason = user.Reason,
                POBox = user.POBox,
                EmailConfirmed = user.EmailConfirmed,
                ProfilePicFileName = user.ProfilePicFileName,
                OrganizationName = user.OrganizationName,
                OrganizationType = (int?)user.OrganizationType,
                InstituteId = user.InstituteId
            };
            return model;
        }

        public override void Dispose()
        {
            //throw new NotImplementedException();
        }
    }
}
