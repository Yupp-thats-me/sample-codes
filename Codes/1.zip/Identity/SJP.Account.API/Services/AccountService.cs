﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Account.API.DataSource;
using SJP.Account.API.DataSource.DataAccess.Interfaces;
using SJP.Account.API.DataSource.Models;
using SJP.Account.API.Email;
using SJP.Account.API.Models;
using SJP.Account.API.Services.Interfaces;
using SJP.Common.EmailService;
using SJP.Core.Api.Models.UserManagement;
using SJP.Core.Model;
using SJP.Core.Models;
using SJP.Core.Services;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace SJP.Account.API.Services
{
    public class AccountService : ServiceBase, IAccountService
    {
        private readonly UserManager<Users> userManager;
        private readonly SignInManager<Users> signInManager;
        private readonly IAccountDataAccess dataAccess;
        private ApplicationDBContext dbContext;
        private readonly ILogger logger;
        protected ILogger Logger => logger;
        private HttpContext httpContext;

        public AccountService(ILogger<AccountService> logger, UserManager<Users> userManager, IAccountDataAccess dataAccess, SignInManager<Users> signInManager, IConfiguration configuration, IHttpContextAccessor _contextAccessor) : base(configuration)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
            this.dataAccess = dataAccess;
            this.httpContext = _contextAccessor.HttpContext;
            EmailContent.InitConfiguration(configuration);
        }

        public void Init(ApplicationDBContext dbContext, HttpContext httpContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<UserIdentityResult> AddUser(RegistrationModel user)
        {
            try
            {
                var exists = dbContext.Users.Any(a => a.Email == user.PersonalDetails.EmailId || (a.IdentityId == user.PersonalDetails.IdentityId));

                if (exists)
                {
                    return new UserIdentityResult() { Exists = true };
                }

                Users table = CreateModel(user.PersonalDetails);

                if (user.PersonalDetails.ProviderId == Guid.Parse(ProviderType.SSO))
                {
                    table.EmailConfirmed = false;
                }

                UserIdentityResult result = new UserIdentityResult();

                table.ApprovalStatus = (int)user.PersonalDetails.ApprovalStatus;
                table.Reason = null;
                table.IsActive = true;
                table.UserName = Guid.NewGuid().ToString();
                table.CreatedBy = this.httpContext.User.Identity.Name;
                table.CreatedDate = DateTime.Now;
                // table.EntryVia = (int?)user.PersonalDetails.EntryVia;

                if (user.ProfessionalDetails != null)
                {
                    table.OrganizationName = user.ProfessionalDetails.OrganizationName;
                    table.OrganizationType = (int?)user.ProfessionalDetails.OrganizationType;
                }

                if (user.PersonalDetails.ProviderId == Guid.Parse(ProviderType.SSO))
                {
                    result.IdentityResult = await userManager.CreateAsync(table);
                }
                else
                {
                    result.IdentityResult = await userManager.CreateAsync(table, user.Password);
                }

                result.User = table;

                return result;
            }
            catch (Exception e)
            {
                throw;
            }
        }

        public async Task<EmailMessage> BuildEmailConfirmationEmail(ApplicationUser user, string EmailVerificationURI)
        {
            try
            {
                var model = CreateModel(user);

                EmailMessage email = new EmailMessage();

                model.Email = "karthikmuni@sightspectrum.com";

                EmailAddress toAddress = new EmailAddress() { Address = model.Email, Name = (model.FirstName + model.LastName) };
                email.ToAddress = new List<EmailAddress> { toAddress };

                email.FromAddress = EmailContent.GetSystemEmailAddress();

                email.Subject = "Email Confirmation | " + (model.FirstName + model.LastName);

                var resetModel = new ResetDataModel();

                var userTable = await userManager.FindByIdAsync(user.UserId.ToString());

                var token = await this.userManager.GenerateEmailConfirmationTokenAsync(userTable);

                resetModel.Token = HttpUtility.UrlEncode(token);

                resetModel.ClientURI = EmailVerificationURI;

                resetModel.Email = user.EmailId;

                email.Content = EmailContent.BuildEmailConfirmationContent(resetModel);

                return email;
            }
            catch (Exception e)
            {
                throw;
            }
        }

        // Used only Super Admin
        public async Task<List<UserIdentityResult>> AddUsers(IEnumerable<UserBasicModel> users)
        {
            try
            {
                var result = new List<UserIdentityResult>();

                foreach (var user in users)
                {
                    var model = new RegistrationModel();

                    model.UserName = Guid.NewGuid().ToString();
                    model.Password = user.Password;
                    model.PersonalDetails = new ApplicationUser();
                    model.PersonalDetails.IdentityId = user.IdentityId;
                    model.PersonalDetails.IsActive = true;
                    model.PersonalDetails.Phone = user.Phone;
                    model.PersonalDetails.EntryVia = EntryVia.Import;
                    model.PersonalDetails.ApprovalStatus = Status.Approved;
                    var data = await AddUser(model);

                    if (!data.IdentityResult.Succeeded)
                    {
                        result.Add(data);
                    }
                }

                return result;
            }
            catch (Exception e)
            {
                throw;
            }
        }

        private Users CreateModel(ApplicationUser user)
        {
            var table = new Users()
            {
                FirstName = user.FirstName,
                //POBox = user.POBox,
                IdentityId = user.IdentityId,
                CurrentAddress = user.CurrentAddress,
                DepartmentId = user.DepartmentId,
                DOB = user.DOB,
                Email = user.EmailId,
                Gender = (int)user.Gender,
                LastName = user.LastName,
                PermanentAddress = user.PermanentAddress,
                PhoneNumber = user.Phone,
                ProviderId = user.ProviderId,
                ShortBio = user.ShortBio,
                UserCode = user.UserCode,
                ApprovalStatus = (int)user.ApprovalStatus,
                CategoryId = user.CategoryId,
                ServicesId = user.ServicesId,
                IsActive = user.IsActive,
                Id = user.UserId,
                Reason = user.Reason,
                RequestedRole = (int)user.RequestedRole,
                Language = user.Language,
                OrganizationName = user.OrganizationName,
                OrganizationType = (int?)user.OrganizationType,
                CityId = user.CityId,
                InstituteId = user.InstituteId,
                EntryVia = (int?)user.EntryVia
            };

            return table;
        }
        public ApplicationUser CreateModel(Users user)
        {
            var model = new ApplicationUser()
            {
                UserId = user.Id,
                CurrentAddress = user.CurrentAddress,
                DOB = user.DOB,
                EmailId = user.Email,
                Gender = (Gender)user.Gender,
                LastName = user.LastName,
                PermanentAddress = user.PermanentAddress,
                Phone = user.PhoneNumber,
                ProviderId = user.ProviderId,
                RequestedRole = (Role)user.RequestedRole,
                ShortBio = user.ShortBio,
                UserCode = user.UserCode,   // StudentId/EmployeeId
                ApprovalStatus = (Status)user.ApprovalStatus,
                ServicesId = user.ServicesId,
                FirstName = user.FirstName,
                IdentityId = user.IdentityId,   // Emirate/License
                IsActive = user.IsActive,
                CategoryId = user.CategoryId,
                Language = user.Language,
                DepartmentId = user.DepartmentId,
                Reason = user.Reason,
                POBox = user.POBox,
                EmailConfirmed = user.EmailConfirmed,
                ProfilePicFileName = user.ProfilePicFileName,
                OrganizationName = user.OrganizationName,
                OrganizationType = (int?)user.OrganizationType,
                InstituteId = user.InstituteId,
                EntryVia = (EntryVia?)user.EntryVia
            };
            return model;
        }

        async Task<LoggedInUserModel> IAccountService.SignIn(LoginModel model)
        {
            Users table = null;

            if (model.Provider.Equals(ProviderType.SJP))
            {
                table = await userManager.FindByEmailAsync(model.Username);
            }
            else if (model.Provider.Equals(ProviderType.SSO))
            {
                var data = userManager.Users.Where(a => a.IsActive && a.IdentityId == model.EmirateId);

                table = data.FirstOrDefault();
            }
            else if (model.Provider.Equals(ProviderType.EmirateId))
            {
                var data = userManager.Users.Where(a => a.IsActive && a.IdentityId == model.Username);

                table = data.FirstOrDefault();
            }

            if (table == null)
            {
                return new LoggedInUserModel() { Succeeded = false, ErrorCode = AccountErrorCode.DoesNotExists, Errors = new List<string> { "Account does not exists" } };
            }
            else
            {
                if (table.ApprovalStatus == (int)Status.Pending)
                {
                    return new LoggedInUserModel() { UserDetails = CreateModel(table), ErrorCode = AccountErrorCode.NotApproved, Succeeded = false, Errors = new List<string> { "Account is not verified yet. Please contact the Administrator." } };
                }
                else if (!table.IsActive)
                {
                    return new LoggedInUserModel() { UserDetails = CreateModel(table), ErrorCode = AccountErrorCode.Deactivated, Succeeded = false, Errors = new List<string> { "Account is deactivated. Please contact the Administrator." } };
                }
                else if (!table.EmailConfirmed)
                {
                    return new LoggedInUserModel() { UserDetails = CreateModel(table), ErrorCode = AccountErrorCode.EmailNotVerified, Succeeded = false, Errors = new List<string> { "Please check your mail and confirm email address." } };
                }
                else
                {
                    var result = await signInManager.PasswordSignInAsync(table, model.Password, model.RememberMe, false);

                    var user = new LoggedInUserModel()
                    {
                        Email = table.Email,
                        UserDetails = result.Succeeded ? CreateModel(table) : null,
                        Succeeded = result.Succeeded,
                        Roles = await userManager.GetRolesAsync(table)
                    };

                    if (table.RequestedRole == (int?)Role.Student && result.Succeeded)
                    {
                        user.UserDetails.EducationCategoryId = this.dbContext.EducationalDetails.Where(a => a.UserId == table.Id).FirstOrDefault().EducationCategoryId;
                    }

                    var identity = new GenericIdentity(table.UserName);
                    SetPrincipal(new GenericPrincipal(identity, user.Roles.ToArray()));

                    return user;
                }
            }
        }

        public async Task<LoggedInUserModel> SSOSignIn(string Provider, string ProviderKey)
        {
            try
            {
                var result = await signInManager.ExternalLoginSignInAsync(Provider, ProviderKey, true);

                return null;
            }
            catch (Exception e)
            {
                throw;
            }
        }

        private void SetPrincipal(IPrincipal principal)
        {
            Thread.CurrentPrincipal = principal;
            if (httpContext != null)
            {
                httpContext.User = (System.Security.Claims.ClaimsPrincipal)principal;
            }
        }

        public async Task<bool> ChangePassword(string userId, string oldPassword, string newPassword)
        {
            var user = await userManager.FindByIdAsync(userId);

            var result = await userManager.ChangePasswordAsync(user, oldPassword, newPassword);

            return result.Succeeded;
        }

        public async Task<bool> DeleteUser(string userId)
        {
            try
            {
                var user = await userManager.FindByIdAsync(userId);

                if (user != null)
                {
                    user.IsDeleted = true;
                }
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private Func<Users, ApplicationUser> CreateModel()
        {
            return a => CreateModel(a);
        }

        public Task<bool> DeleteUser(long id)
        {
            throw new NotImplementedException();
        }

        public async Task<bool> UpdateUserStatus(string userId, bool IsActive)
        {
            try
            {

                var user = await userManager.FindByIdAsync(userId);

                user.IsActive = IsActive;

                await userManager.UpdateAsync(user);

                return true;
            }
            catch (Exception e)
            {
                throw;
            }
        }

        public async Task<bool> SignOut()
        {
            await signInManager.SignOutAsync();

            return true;
        }

        public override void Dispose()
        {
            /*throw new NotImplementedException();*/
        }



        public async Task UserApproval(ApprovalModel model, bool isExternalLogin = false)
        {
            try
            {
                var user = await userManager.FindByIdAsync(model.UserId.ToString());

                user.ApprovalStatus = (int)model.Status;

                if (model.Status == Status.Rejected)
                {
                    user.Reason = model.Reason;
                }

                await userManager.UpdateAsync(user);

                if (!isExternalLogin && user.ApprovalStatus == (int)Status.Approved)
                {
                    var roles = await userManager.GetRolesAsync(user);

                    await userManager.RemoveFromRolesAsync(user, roles);

                    Role role = (Role)user.RequestedRole;

                    RoleModel roleModel = ((RoleModel)role);

                    var roleResult = await userManager.AddToRoleAsync(user, roleModel.Name);
                }
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public async Task<string> GeneratePasswordResetToken(Users user)
        {
            var token = await userManager.GeneratePasswordResetTokenAsync(user);

            return token;
        }

        public async Task<IdentityResult> ResetPassword(Users user, ResetDataModel model)
        {
            try
            {
                var result = await userManager.ResetPasswordAsync(user, model.Token, model.Password);

                return result;
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public async Task<Users> UserExists(string email)
        {
            try
            {
                Users user = await userManager.FindByEmailAsync(email);
                return user;
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public EmailMessage BuildPasswordRecoveryEmail(Users user, ResetDataModel model)
        {
            try
            {
                var userModel = CreateModel(user);

                EmailMessage email = new EmailMessage();

                //EmailAddress toAddress = new EmailAddress() { Address = userModel.EmailId, Name = userModel.DisplayName };
                EmailAddress toAddress1 = new EmailAddress() { Address = "karthikmuni@sightspectrum.com", Name = (userModel.FirstName + userModel.LastName) };
                EmailAddress toAddress2 = new EmailAddress() { Address = "ashika@sightspectrum.com", Name = (userModel.FirstName + userModel.LastName) };

                email.ToAddress = new List<EmailAddress> { toAddress1, toAddress2 };

                email.FromAddress = EmailContent.GetSystemEmailAddress();

                email.Subject = "Password Recovery | " + (userModel.FirstName + userModel.LastName);

                email.Content = EmailContent.BuildPasswordRecoveryContent(model);

                return email;
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public async Task<string> ForgotPassword(Users user)
        {
            var token = await userManager.GeneratePasswordResetTokenAsync(user);

            return token;
        }

        public async Task<IEnumerable<ApplicationUser>> GetUsersGrid(Role? role)
        {
            try
            {
                var roleId = (int?)role;

                var users = await (from a in userManager.Users
                                   where (((a.RequestedRole == (int)Role.Student) || (a.RequestedRole == (int)Role.General))
                                   || a.EmailConfirmed)
                                   && (!role.HasValue || (a.RequestedRole == (int)role))
                                   orderby (a.ModifiedDate != null ? a.ModifiedDate : a.CreatedDate) descending
                                   select new ApplicationUser()
                                   {
                                       UserId = a.Id,
                                       CurrentAddress = a.CurrentAddress,
                                       DOB = a.DOB,
                                       EmailId = a.Email,
                                       Gender = (Gender)a.Gender,
                                       LastName = a.LastName,
                                       PermanentAddress = a.PermanentAddress,
                                       Phone = a.PhoneNumber,
                                       ProviderId = a.ProviderId,
                                       RequestedRole = (Role)a.RequestedRole,
                                       ShortBio = a.ShortBio,
                                       UserCode = a.UserCode,   // StudentId/EmployeeId
                                       ApprovalStatus = (Status)a.ApprovalStatus,
                                       ServicesId = a.ServicesId,
                                       FirstName = a.FirstName,
                                       IdentityId = a.IdentityId,   // Emirate/License
                                       IsActive = a.IsActive,
                                       CategoryId = a.CategoryId,
                                       Language = a.Language,
                                       DepartmentId = a.DepartmentId,
                                       Reason = a.Reason,
                                       POBox = a.POBox,
                                       CityId = a.CityId,
                                       OrganizationName = a.OrganizationName,
                                       OrganizationType = (int?)a.OrganizationType,
                                       InstituteId = a.InstituteId,
                                       EntryVia = (EntryVia)a.EntryVia
                                   }).ToListAsync();

                return users;
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public async Task<string> GetRole(string userId)
        {
            try
            {
                var user = await userManager.FindByIdAsync(userId);

                var roles = await userManager.GetRolesAsync(user);

                return roles.ToString();
            }
            catch (Exception e)
            {
                throw;
            }
        }

        public async Task<IdentityResult> ConfirmEmail(string token, string email)
        {
            try
            {
                var user = await this.userManager.FindByEmailAsync(email);

                var result = await userManager.ConfirmEmailAsync(user, token);

                return result;
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public Task<UserIdentityResult> AddUser(UserBasicModel user)
        {

            try
            {
                var model = new RegistrationModel();

                model.Password = user.Password;
                model.EmailVerificationURI = user.EmailVerificationURI;
                model.PersonalDetails = new ApplicationUser
                {
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    Gender = user.Gender,
                    ApprovalStatus = Status.Approved,
                    CurrentAddress = user.Address,
                    EmailId = user.EmailId,
                    DOB = user.DOB,
                    POBox = user.POBox ?? 0,
                    RequestedRole = user.RequestedRole,
                    UserCode = user.UserCode ?? 0,
                    OrganizationName = user.OrganizationName,
                    IdentityId = user.IdentityId,
                    EntryVia = (EntryVia)user.EntryVia

                };

                return AddUser(model);
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public async Task<Users> FindUserByIdAsync(string userId)
        {
            try
            {
                return await userManager.FindByIdAsync(userId);
            }
            catch (Exception e)
            {
                throw;
            }
        }

        public bool EmailExists(string EmailId)
        {
            try
            {
                return dbContext.Users.Any(a => !(a.IsDeleted) && a.Email.ToLower() == EmailId.ToLower());
            }
            catch (Exception e)
            {
                throw;
            }
        }

        public bool IdentityIdExists(string IdentityId)
        {
            try
            {
                return dbContext.Users.Any(a => !(a.IsDeleted) && a.IdentityId.ToLower() == IdentityId.ToLower());
            }
            catch (Exception e)
            {
                throw;
            }
        }

        public Task<UserIdentityResult> AddExternalUser(RegistrationModel user)
        {
            try
            {
                return null;
            }
            catch (Exception e)
            {

                throw;
            }
        }
    }
}