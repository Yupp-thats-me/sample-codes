﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.WebUtilities;
using SJP.Account.API.DataSource.Models;
using SJP.Account.API.Email;
using SJP.Account.API.Models;
using SJP.Account.API.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace SJP.Account.API.Services
{
    public class AccountEmailService : IAccountEmailService
    {
        private readonly UserManager<Users> userManager;
        public AccountEmailService(UserManager<Users> userManager)
        {
            this.userManager = userManager;
        }
        public async Task<EmailTemplate> BuildEmailConfirmation(EmailInfoModel model)
        {
            try
            {
                var template = EmailContent.Read(EmailCategory.Registration);

                if (template != null)
                {
                    string toNames = String.Join(',', model.ToAddress.Select(a => a.Name).ToList());
                    string fromNames = String.Join(',', template.FromAddress.Select(a => a.Name).ToList());

                    template.ToAddress = model.ToAddress;

                    template.Body = String.Join(' ', template.BodyHTML);

                    template.Body = template.Body.ToString().Replace("{toName}", toNames);
                    template.Body = template.Body.ToString().Replace("{fromName}", fromNames);

                    var token = await GetEmailConfirmationToken(model.EmailId);

                    var user = await userManager.FindByEmailAsync(model.EmailId);

                    var link = model.ClientURI + "?token=" + token + "&email=" + model.EmailId;

                    template.Body = template.Body.Replace("{link}", link);

                    template.ToAddress = model.ToAddress;

                    return template;
                }
                else
                {
                    // log error saying no template found.
                    throw new Exception("No RegistrationConfirmation Email Template Found!");
                }
            }
            catch (Exception e)
            {
                // log error.
                throw;
            }
        }

        public async Task<EmailTemplate> BuildResetPasswordEmail(EmailInfoModel model)
        {
            try
            {
                var template = EmailContent.Read(EmailCategory.ResetPassword);

                if (template != null)
                {
                    string toNames = String.Join(',', model.ToAddress.Select(a => a.Name).ToList());
                    string fromNames = String.Join(',', template.FromAddress.Select(a => a.Name).ToList());

                    template.ToAddress = model.ToAddress;

                    template.Body = String.Join(' ', template.BodyHTML);

                    template.Body = template.Body.ToString().Replace("{toName}", toNames);
                    template.Body = template.Body.ToString().Replace("{fromName}", fromNames);

                    var user = await userManager.FindByEmailAsync(model.EmailId);

                    var token = await userManager.GeneratePasswordResetTokenAsync(user);

                    var link = model.ClientURI + "?token=" + token + "&email=" + model.EmailId;

                    template.Body = template.Body.Replace("{link}", link);

                    template.ToAddress = model.ToAddress;

                    return template;
                }
                else
                {
                    // log error saying no template found.
                    throw new Exception("No RegistrationConfirmation Email Template Found!");
                }
            }
            catch (Exception e)
            {
                // log error.
                throw;
            }
        }

        private async Task<string> GetEmailConfirmationToken(string email)
        {
            try
            {
                var userTable = await userManager.FindByEmailAsync(email);

                var token = await this.userManager.GenerateEmailConfirmationTokenAsync(userTable);

                return token;
            }
            catch (Exception e)
            {
                throw;
            }

        }
    }
}
