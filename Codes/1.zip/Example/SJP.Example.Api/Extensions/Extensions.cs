﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using SJP.Communication.Http;
using SJP.Core.Api.Extensions;
using SJP.Logger.Extensions;
using SJP.Example.Api.DataAccess;
using SJP.Example.Api.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Example.Api.Extensions
{
    /// <summary>
    /// This class contains utility methods
    /// </summary>
    public static class Extensions
    {
        public static IServiceCollection AddServices(this IServiceCollection services)
        {
            services.AddDatabaseLogger();
            services.AddDistributedMemCache();

            /// Use AddHttpCommunicatorWithOAuth only if the oauth is enabled otherwise use simple form 
            ///services.AddHttpCommunicatorWithOAuth();
            ///

            services.AddHttpCommunicator();

            services.AddScoped<IStudentDataAccess, StudentDataAccess>();
            services.AddScoped<IStudentService, StudentService>();
           
            return services;
        }

        public static IApplicationBuilder UseServices(this IApplicationBuilder app)
        {
            app.UseDatabaseLogger();
            return app;
        }
    }

}
