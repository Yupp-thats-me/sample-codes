﻿using Microsoft.Extensions.Configuration;
using SJP.Core.Services;
using SJP.Example.Api.DataAccess;
using SJP.Example.Api.Model;
using SJP.Example.Api.Model.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Example.Api.Services
{
    public class StudentService : ServiceBase, IStudentService
    {
        private readonly IStudentDataAccess studentDataAccess;
        public StudentService(IStudentDataAccess studentDataAccess, IConfiguration configuration) : base(configuration)
        {
            this.studentDataAccess = studentDataAccess;
        }

        public async Task<IEnumerable<StudentDto>> GetStudents()
        {
            var student = await this.studentDataAccess.GetStudentsAsync();
            if(student!=null)
            {
                var res =  student.Select(student => new StudentDto
                {
                    StudentID = student.Id,
                    StudentName = student.StudentName,
                    Height = student.Height,
                    Weight = student.Weight,
                    Active = student.Active,
                    DateOfBirth = student.DateOfBirth,
                    RecordVersion = student.RecordVersion,
                    CreatedBy = student.CreatedBy,
                    UpdatedBy = student.UpdatedBy,
                    CreatedDate = student.CreatedDate,
                    UpdatedDate = student.UpdatedDate
                });
                return res;
            }

            return null;

        }
        public async Task<StudentDto> GetStudent(int studentid)
        {
            var student = await this.studentDataAccess.GetStudentAsync(studentid);
            if (student != null)
            {
                return new StudentDto
                {
                    StudentID = student.Id,
                    StudentName = student.StudentName,
                    Height = student.Height,
                    Weight = student.Weight,
                    Active = student.Active,
                    DateOfBirth = student.DateOfBirth,
                    RecordVersion = student.RecordVersion,
                    CreatedBy = student.CreatedBy,
                    UpdatedBy = student.UpdatedBy,
                    CreatedDate = student.CreatedDate,
                    UpdatedDate = student.UpdatedDate
                };
            }
            return null;
        }

        public async Task<StudentDto> SaveStudent(StudentDto student)
        {

            /// Do Validaion 
            /// 
            var studentToBeSubmitted = new Student
            {
                Id = student.StudentID,
                StudentName = student.StudentName,
                Height = student.Height,
                Weight = student.Weight,
                Active = student.Active,
                DateOfBirth = student.DateOfBirth,
                RecordVersion = student.RecordVersion,
                CreatedBy = student.CreatedBy,
                UpdatedBy = student.UpdatedBy

            };

            var dataSaved = await this.studentDataAccess.SaveStudentAsync(studentToBeSubmitted);

            student.StudentID = dataSaved.Id;
            return student;
        }


        public Task<bool> DeleteStudent(int studentid)
        {
            throw new NotImplementedException();
        }

        public override void Dispose()
        {
            
        }

      
    }
}
