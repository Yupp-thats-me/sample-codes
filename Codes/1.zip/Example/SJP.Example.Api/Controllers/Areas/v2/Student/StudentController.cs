﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SJP.Communication.Http;
using SJP.Core.Api.Controllers;
using SJP.Core.Cache;
using SJP.Example.Api.Model.Dto;
using SJP.Example.Api.Services;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SJP.Example.Api.Controllers.Areas.v2.Student
{
    [Route("v{version:apiVersion}/[controller]")]
    [ApiController]
    public class StudentController : BaseApiController
    {
        private readonly IStudentService studentService;
        private readonly ICacheHelper cacheHelper;
        private readonly IHttpCommunicator httpCommunicator;


        public StudentController(ILogger<StudentController> logger, ICacheHelper cacheHelper, IStudentService studentService, IHttpCommunicator httpCommunicator) : base(logger)
        {
            this.studentService = studentService;
            this.cacheHelper = cacheHelper;
            this.httpCommunicator = httpCommunicator;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            this.Logger.LogInformation("Loading Student Info");
            this.Logger.LogError(new Exception("Error Occured"),"An Error Occured");

            // Caching simple value
            await cacheHelper.AddAsync("samplekey", "my value");
            var samplevalue = await cacheHelper.GetAsync<string>("samplekey");

            var students = await this.studentService.GetStudents();

            // Caching complex object
            await cacheHelper.AddAsync("students", students);
            var  cachedstudent = await cacheHelper.GetAsync<IEnumerable<StudentDto>>("students");

            var result = await httpCommunicator.GetAsync("https://google.com");

            return Collection(students);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            return Single(await this.studentService.GetStudent(id));
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] StudentDto student)
        {
            if (student.StudentID > 0)
            {
                return BadRequest("Invalid Student Id");
            }

            await this.studentService.SaveStudent(student);

            return Single(new { StudentId = student.StudentID, StudentName = student.StudentName, RecordVersion = student.RecordVersion });
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] StudentDto student)
        {
            if (id == 0)
            {
                return BadRequest("Invalid Student Id");
            }
            student.StudentID = id;
            await this.studentService.SaveStudent(student);
            return Single(new { StudentId = student.StudentID, StudentName = student.StudentName, RecordVersion = student.RecordVersion });
        }

        // DELETE api/<ValuesController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
