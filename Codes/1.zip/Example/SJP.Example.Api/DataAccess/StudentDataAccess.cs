﻿using Microsoft.Extensions.Configuration;
using SJP.DataAccess;
using SJP.Example.Api.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using SJP.DataAccess.Extensions;

namespace SJP.Example.Api.DataAccess
{
    public class StudentDataAccess : DataAccessBase, IStudentDataAccess
    {
        public StudentDataAccess(IConfiguration configuration) : base(configuration)
        {

        }

        public async Task<IEnumerable<Student>> GetStudentsAsync()
        {
            IList<Student> students = new List<Student>(); ;

            using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
            {
                using (var reader = await ExecuteReaderAsync(
                                            connection,
                                            CommandType.StoredProcedure,
                                            "dbo.Get_Student_List").ConfigureAwait(false))
                {
                    if (reader.HasRows)
                    {
                        while (await reader.ReadAsync().ConfigureAwait(false))
                        {
                            students.Add(new Student
                            {
                                Id = reader.To<int>("StudentId"),
                                StudentName = reader.ToStringValue("Name"),
                                DateOfBirth = reader.To<DateTime>("DateOfBirth"),
                                Height = reader.ToNullable<decimal>("Height"),
                                Weight = reader.ToNullable<decimal>("Weight"),
                                Active = reader.To<bool>("Active"),
                                RecordVersion = reader.To<int>("RecordVersion"),
                                CreatedBy = reader.ToStringValue("CreatedBy"),
                                CreatedDate = reader.To<DateTime>("CreatedDate"),
                                UpdatedBy = reader.ToStringValue("UpdatedBy"),
                                UpdatedDate = reader.To<DateTime>("UpdatedDate")
                            });
                        }
                    }
                }
            }

            return students;
        }
        public async Task<Student> GetStudentAsync(int studentid)
        {
            Student student = null;
            var paramstudentid = new SqlParameter("@studentid", SqlDbType.BigInt) { Value = studentid };

            using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
            {
                using (var reader = await ExecuteReaderAsync(
                                            connection,
                                            CommandType.StoredProcedure,
                                            "dbo.Get_Student",
                                            paramstudentid).ConfigureAwait(false))
                {
                    if (reader.HasRows)
                    {
                        while (await reader.ReadAsync().ConfigureAwait(false))
                        {
                            student = new Student
                            {
                                Id = reader.To<int>("StudentId"),
                                StudentName = reader.ToStringValue("Name"),
                                DateOfBirth = reader.To<DateTime>("DateOfBirth"),
                                Height = reader.ToNullable<decimal>("Height"),
                                Weight = reader.ToNullable<decimal>("Weight"),
                                Active = reader.To<bool>("Active"),
                                RecordVersion = reader.To<int>("RecordVersion"),
                                CreatedBy = reader.ToStringValue("CreatedBy"),
                                CreatedDate = reader.To<DateTime>("CreatedDate"),
                                UpdatedBy = reader.ToStringValue("UpdatedBy"),
                                UpdatedDate = reader.To<DateTime>("UpdatedDate"),
                            };
                        }
                    }
                }
            }

            return student;
        }
        public Task<bool> DeleteStudent(int studentid)
        {
            throw new NotImplementedException();
        }

        public async Task<Student> SaveStudentAsync(Student student)
        {
            var paramId = new SqlParameter("@StudentId", SqlDbType.BigInt) { Value = student.Id, Direction = ParameterDirection.Output };
            var paramName = new SqlParameter("@Name", SqlDbType.NVarChar) { Value = student.StudentName };
            var paramDOB = new SqlParameter("@DateOfBirth", SqlDbType.Date) { Value = student.DateOfBirth };
            var paramHeight = new SqlParameter("@Height", SqlDbType.Decimal) { Value = student.Height };
            var paramWeight = new SqlParameter("@Weight", SqlDbType.Decimal) { Value = student.Weight };
            var paramCreatedBy = new SqlParameter("@Created_By", SqlDbType.NVarChar) { Value = student.CreatedBy };
            var paramUpdatedBy = new SqlParameter("@Updated_By", SqlDbType.NVarChar) { Value = student.UpdatedBy };

            using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
            {
                SqlTransaction transaction = null;
                try
                {
                    transaction = connection.BeginTransaction();
                    await ExecuteNonQueryAsync(
                            connection,
                            transaction,
                            CommandType.StoredProcedure,
                            "dbo.Student_Save",
                            paramId,
                            paramName,
                            paramDOB,
                            paramHeight,
                            paramWeight,
                            paramCreatedBy,
                            paramUpdatedBy
                            ).ConfigureAwait(false);
                    transaction.Commit();
                }
                catch
                {
                    if (transaction != null)
                        transaction.Rollback();
                    throw;
                }
            }
            student.Id = (long)paramId.Value;
            return student;

        }
    }
}
