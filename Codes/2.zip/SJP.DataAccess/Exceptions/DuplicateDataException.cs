﻿using System;
using System.Data.SqlClient;

namespace SJP.DataAccess.Exceptions
{
    [Serializable]
    public class DuplicateDataException : GenericSqlException
    {
        public DuplicateDataException()
            : base(String.Format("Duplicate Record found"))
        {

        }
        public DuplicateDataException(SqlException ex)
          : base(String.Format("Duplicate Record found"))
        {
            Number = ex.Number;
            Errors = ex.Errors;
            Number = ex.Number;
        }
       
       
    }

    [Serializable]
    public class DateValidationException : GenericSqlException
    {
        public DateValidationException(SqlException ex)
          : base(String.Format("Invalid Date"))
        {
            Number = ex.Number;
            Errors = ex.Errors;
            Number = ex.Number;
        }
    }
}
