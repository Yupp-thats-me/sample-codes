﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Text;

namespace SJP.DataAccess.Exceptions
{
    /// <summary>
    /// Class for CustomSqlException
    /// </summary>
    [Serializable]
    public class GenericException : Exception 
    {
        /// <summary>
        /// inner exception
        /// </summary>
        private Exception innerException;

        /// <summary>
        /// exception id
        /// </summary>
        private int exceptionId;

        /// <summary>
        /// exception description
        /// </summary>
        private string exceptionDescription;

        /// <summary>
        /// exception stackTrace
        /// </summary>
        private string stackTrace;

        /// <summary>
        /// exception message
        /// </summary>
        private string message;

        /// <summary>
        /// paramerers of the exception
        /// </summary>
        private IList<string> paramerers;

        /// <summary>
        /// The number
        /// </summary>
        private int number;

        /// <summary>
        /// Initializes a new instance of the <see cref="GenericException"/> class.
        /// </summary>
        public GenericException()
            : base()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GenericException"/> class.
        /// </summary>
        /// <param name="message">This is the description of the exception</param>
        public GenericException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GenericException"/> class.
        /// </summary>
        /// <param name="message">This is the description of the exception</param>
        /// <param name="innerException">Inner exception</param>
        public GenericException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GenericException"/> class.+6
        /// </summary>
        /// <param name="info">Instance of SerializationInfo</param>
        /// <param name="context">Instance of StreamingContext</param>
        protected GenericException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        /// <summary>
        /// Gets or sets InnerException.
        /// </summary>
        /// <value>
        /// InnerException.
        /// </value>
        public new Exception InnerException
        {
            get
            {
                return this.innerException;
            }

            set
            {
                this.innerException = value;
            }
        }

        /// <summary>
        /// Gets or sets ExceptionId.
        /// </summary>
        /// <value>
        /// ExceptionId.
        /// </value>
        public int ExceptionId
        {
            get
            {
                return this.exceptionId;
            }

            set
            {
                this.exceptionId = value;
            }
        }

        /// <summary>
        /// Gets or sets ExceptionDescription.
        /// </summary>
        /// <value>
        /// ExceptionDescription.
        /// </value>
        public string ExceptionDescription
        {
            get
            {
                return this.exceptionDescription;
            }

            set
            {
                this.exceptionDescription = value;
            }
        }

        /// <summary>
        /// Gets or sets StackTrace.
        /// </summary>
        /// <value>
        /// StackTrace.
        /// </value>
        public new string StackTrace
        {
            get
            {
                return this.stackTrace;
            }

            set
            {
                this.stackTrace = value;
            }
        }

        /// <summary>
        /// Gets or sets Message.
        /// </summary>
        /// <value>
        /// Message.
        /// </value>
        public new string Message
        {
            get
            {
                return this.message;
            }

            set
            {
                this.message = value;
            }
        }

        /// <summary>
        /// Gets or sets parameters of the exception.
        /// </summary>
        /// <value>
        /// Parameters of the exception.
        /// </value>
        public IList<string> Paramerers
        {
            get
            {
                return this.paramerers;
            }

            set
            {
                this.paramerers = value;
            }
        }

        /// <summary>
        /// Gets or sets the number of sqlexception.
        /// </summary>
        /// <value>
        /// The number of sqlexception.
        /// </value>
        public int Number
        {
            get
            {
                return this.number;
            }

            set
            {
                this.number = value;
            }
        }

        /// <summary>
        /// sets the System.Runtime.Serialization.SerializationInfo with information about the exception
        /// </summary>
        /// <param name="info">Instance of SerializationInfo</param>
        /// <param name="context">Instance of StreamingContext</param>
        [SecurityPermissionAttribute(SecurityAction.Demand, SerializationFormatter = true)]
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            if (info == null)
            {
                throw new ArgumentNullException("info");
            }

            base.GetObjectData(info, context);
        }
    }
}
