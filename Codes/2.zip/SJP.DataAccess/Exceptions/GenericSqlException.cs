﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Text;

namespace SJP.DataAccess.Exceptions
{
    /// <summary>
    /// Class for CustomSqlException
    /// </summary>
    [Serializable]
    public class GenericSqlException : GenericException
    {
        /// <summary>
        /// SP name
        /// </summary>
        private SqlErrorCollection errors;

        /// <summary>
        /// Sql parameters
        /// </summary>
        private SqlParameter[] sqlparams;

        /// <summary>
        /// Command text string
        /// </summary>
        private string commandText;

        /// <summary>
        /// Initializes a new instance of the <see cref="GenericSqlException"/> class.
        /// </summary>
        public GenericSqlException()
            : base()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GenericSqlException"/> class.
        /// </summary>
        /// <param name="message">This is the description of the exception</param>
        public GenericSqlException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GenericSqlException"/> class.
        /// </summary>
        /// <param name="message">This is the description of the exception</param>
        /// <param name="innerException">Inner exception</param>
        public GenericSqlException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="GenericSqlException"/> class.+6
        /// </summary>
        /// <param name="info">Instance of SerializationInfo</param>
        /// <param name="context">Instance of StreamingContext</param>
        protected GenericSqlException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        /// <summary>
        /// Gets or sets Errors.
        /// </summary>
        /// <value>
        /// Errors.
        /// </value>
        public SqlErrorCollection Errors
        {
            get
            {
                return this.errors;
            }

            set
            {
                this.errors = value;
            }
        }

        /// <summary>
        /// Gets or sets sql parameters
        /// </summary>
        /// <value>
        /// Sql parameters
        /// </value>
        public SqlParameter[] SqlParams
        {
            get
            {
                return this.sqlparams;
            }

            set
            {
                this.sqlparams = value;
            }
        }

        /// <summary>
        /// Gets or sets Command text
        /// </summary>
        /// <value>
        /// Command text
        /// </value>
        public string CommandText
        {
            get
            {
                return this.commandText;
            }

            set
            {
                this.commandText = value;
            }
        }

        /// <summary>
        /// sets the System.Runtime.Serialization.SerializationInfo with information about the exception
        /// </summary>
        /// <param name="info">Instance of SerializationInfo</param>
        /// <param name="context">Instance of StreamingContext</param>
        [SecurityPermissionAttribute(SecurityAction.Demand, SerializationFormatter = true)]
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            if (info == null)
            {
                throw new ArgumentNullException(nameof(info));
            }

            base.GetObjectData(info, context);
        }
    }
}
