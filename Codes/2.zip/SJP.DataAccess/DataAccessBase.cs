﻿using Microsoft.Extensions.Configuration;
using SJP.DataAccess.Exceptions;
using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace SJP.DataAccess
{
    /// <summary>
    /// Base class for the data access classes which initiates the Database connections
    /// </summary>
    public class DataAccessBase : IDisposable
    {

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="DataAccessBase"/> class.
        /// </summary>
        /// <param name="connectionString">Connection string</param>
        public DataAccessBase(IConfiguration configuration)
        {
            this.Configuration = configuration;
            this.ConnectionString = configuration.GetConnectionString("SJP");
        }

        #endregion

        #region Protected Properties

        /// <summary>
        /// Gets the connection string.
        /// </summary>
        /// <value>
        /// The connection string.
        /// </value>
        protected virtual string ConnectionString { get; }

        /// <summary>
        /// Gets the instance of configuration
        /// </summary>
        /// <value>
        /// The instance of configuration
        /// </value>
        protected IConfiguration Configuration { get; }

        #endregion

        #region IDisposable

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion

        /// <summary>
        /// Method which executes the SQL command to retrieve data from database
        /// </summary>
        /// <param name="conn">Connection to database</param>
        /// <param name="type">Command type</param>
        /// <param name="cmdText">Command text</param>
        /// <param name="parameters">Parameters passed to function</param>
        /// <returns>
        /// return the SQL Data Reader object
        /// </returns>
        protected static SqlDataReader ExecuteReader(SqlConnection conn, CommandType type, string cmdText, params SqlParameter[] parameters)
        {
            if (parameters == null)
            {
                throw new ArgumentNullException(nameof(parameters));
            }

            SqlCommand command = null;
            SqlDataReader reader = null;

            try
            {
                command = new SqlCommand(cmdText, conn);
                command.CommandType = type;
                foreach (SqlParameter param in parameters)
                {
                    if ((param.Direction == (ParameterDirection)3 || param.Direction == (ParameterDirection)1) && param.Value == null)
                    {
                        param.Value = DBNull.Value;
                    }

                    command.Parameters.Add(param);
                }

                reader = command.ExecuteReader();
            }
            catch (Exception ex)
            {
                if (ex is SqlException sqlException)
                {
                    HandleException(sqlException, command.CommandText, parameters);
                }
                else
                {
                    throw;
                }
            }
            finally
            {
                command.Dispose();
            }

            return reader;
        }

        /// <summary>
        /// Method which executes the SQL command to retrieve data from database
        /// </summary>
        /// <param name="conn">Connection to database</param>
        /// <param name="type">Command type</param>
        /// <param name="cmdText">Command text</param>
        /// <param name="parameters">Parameters passed to function</param>
        /// <returns>
        /// return the SQL Data Reader object
        /// </returns>
        protected static async Task<SqlDataReader> ExecuteReaderAsync(SqlConnection conn, CommandType type, string cmdText, params SqlParameter[] parameters)
        {
            if (parameters == null)
            {
                throw new ArgumentNullException(nameof(parameters));
            }

            SqlCommand command = null;
            SqlDataReader reader = null;

            try
            {
                command = new SqlCommand(cmdText, conn);
                command.CommandType = type;
                foreach (SqlParameter param in parameters)
                {
                    if ((param.Direction == (ParameterDirection)3 || param.Direction == (ParameterDirection)1) && param.Value == null)
                    {
                        param.Value = DBNull.Value;
                    }

                    command.Parameters.Add(param);
                }   

                reader = await command.ExecuteReaderAsync().ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                if (ex is SqlException sqlException)
                {
                    HandleException(sqlException, command.CommandText, parameters);
                }
                else
                {
                    throw;
                }
            }
            finally
            {
                command.Dispose();
            }

            return reader;
        }

        /// <summary>
        /// Method which executes the SQL command to retrieve data from database
        /// </summary>
        /// <param name="conn">Connection to database</param>
        /// <param name="type">Command type</param>
        /// <param name="cmdText">Command text</param>
        /// <returns>
        /// return the SQL Data Reader object
        /// </returns>
        protected static SqlDataReader ExecuteReader(SqlConnection conn, CommandType type, string cmdText)
        {
            SqlCommand command = new SqlCommand(cmdText, conn);
            command.CommandType = type;
            SqlDataReader reader = null;

            try
            {
                reader = command.ExecuteReader();
            }
            catch (Exception ex)
            {
                if (ex is SqlException sqlException)
                {
                    HandleException(sqlException, null);
                }
                else
                {
                    throw;
                }
            }
            finally
            {
                command.Dispose();
            }

            return reader;
        }

        /// <summary>
        /// Method which executes the SQL command to retrieve data from database
        /// </summary>
        /// <param name="conn">Connection to database</param>
        /// <param name="type">Command type</param>
        /// <param name="cmdText">Command text</param>
        /// <returns>
        /// return the SQL Data Reader object
        /// </returns>
        protected static async Task<SqlDataReader> ExecuteReaderAsync(SqlConnection conn, CommandType type, string cmdText)
        {
            SqlCommand command = new SqlCommand(cmdText, conn);
            command.CommandType = type;
            SqlDataReader reader = null;

            try
            {
                reader = await command.ExecuteReaderAsync().ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                if (ex is SqlException sqlException)
                {
                    HandleException(sqlException, null);
                }
                else
                {
                    throw;
                }
            }
            finally
            {
                command.Dispose();
            }

            return reader;
        }

        /// <summary>
        /// Executes a Transact-SQL statement against the connection and returns the number of rows affected.
        /// </summary>
        /// <param name="conn">Connection to database</param>
        /// <param name="type">Command type</param>
        /// <param name="cmdText">Command text</param>
        /// <param name="parameters">Parameters passed to the query</param>
        /// <returns>
        /// Number of rows affected
        /// </returns>
        protected static int ExecuteNonQuery(SqlConnection conn, CommandType type, string cmdText, params SqlParameter[] parameters)
        {
            return ExecuteNonQuery(conn, null, type, cmdText, parameters);
        }

        /// <summary>
        /// Executes a Transact-SQL statement against the connection and returns the number of rows affected.
        /// </summary>
        /// <param name="conn">Connection to database</param>
        /// <param name="transaction">Transaction associated with connection</param>
        /// <param name="type">Command type</param>
        /// <param name="cmdText">Command text</param>
        /// <param name="parameters">Parameters passed to the query</param>
        /// <returns>
        /// Number of rows affected
        /// </returns>
        protected static int ExecuteNonQuery(SqlConnection conn, SqlTransaction transaction, CommandType type, string cmdText, params SqlParameter[] parameters)
        {
            if (parameters == null)
            {
                throw new ArgumentNullException(nameof(parameters));
            }

            SqlCommand command = null;
            int rowsAffected = 0;

            try
            {
                command = new SqlCommand(cmdText, conn);
                command.CommandType = type;
                foreach (SqlParameter param in parameters)
                {
                    command.Parameters.Add(param);
                }

                if (transaction != null)
                {
                    command.Transaction = transaction;
                }

                rowsAffected = command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                if (ex is SqlException sqlException)
                {
                    HandleException(sqlException, command.CommandText, parameters);
                }
                else
                {
                    throw;
                }
            }
            finally
            {
                command.Dispose();
            }

            return rowsAffected;
        }

        /// <summary>
        /// Executes a Transact-SQL statement against the connection and returns the number of rows affected.
        /// </summary>
        /// <param name="conn">Connection to database</param>
        /// <param name="type">Command type</param>
        /// <param name="cmdText">Command text</param>
        /// <param name="parameters">Parameters passed to the query</param>
        /// <returns>
        /// Number of rows affected
        /// </returns>
        protected static async Task<int> ExecuteNonQueryAsync(SqlConnection conn, CommandType type, string cmdText, params SqlParameter[] parameters)
        {
            return await ExecuteNonQueryAsync(conn, null, type, cmdText, parameters);
        }
        /// <summary>
        /// Executes a Transact-SQL statement against the connection and returns the number of rows affected.
        /// </summary>
        /// <param name="conn">Connection to database</param>
        /// <param name="transaction">Transaction associated with connection</param>
        /// <param name="type">Command type</param>
        /// <param name="cmdText">Command text</param>
        /// <param name="parameters">Parameters passed to the query</param>
        /// <returns>
        /// Number of rows affected
        /// </returns>
        protected static async Task<int> ExecuteNonQueryAsync(SqlConnection conn, SqlTransaction transaction, CommandType type, string cmdText, params SqlParameter[] parameters)
        {
            if (parameters == null)
            {
                throw new ArgumentNullException(nameof(parameters));
            }

            SqlCommand command = null;
            int rowsAffected = 0;

            try
            {

                command = new SqlCommand(cmdText, conn);
                command.CommandType = type;
                foreach (SqlParameter param in parameters)
                {
                    command.Parameters.Add(param);
                }

                if (transaction != null)
                {
                    command.Transaction = transaction;
                }

                rowsAffected = await command.ExecuteNonQueryAsync().ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                if (ex is SqlException sqlException)
                {
                    HandleException(sqlException, command.CommandText, parameters);
                }
                else
                {
                    throw;
                }
            }
            finally
            {
                command.Dispose();
            }

            return rowsAffected;
        }

        /// <summary>
        /// Executes a Transact-SQL statement against the connection and returns the scalar value.
        /// </summary>
        /// <param name="conn">Connection to database</param>
        /// <param name="type">Command type</param>
        /// <param name="cmdText">Command text</param>
        /// <returns>
        /// The scalar value
        /// </returns>
        protected static object ExecuteScalar(SqlConnection conn, CommandType type, string cmdText)
        {
            SqlCommand command = null;
            object returnValue = null;

            try
            {
                command = new SqlCommand(cmdText, conn);
                command.CommandType = type;

                returnValue = command.ExecuteScalar();
            }
            catch (Exception ex)
            {
                if (ex is SqlException sqlException)
                {
                    HandleException(sqlException, command.CommandText);
                }
                else
                {
                    throw;
                }
            }
            finally
            {
                command.Dispose();
            }

            return returnValue;
        }

        /// <summary>
        /// Executes a Transact-SQL statement against the connection and returns the scalar value.
        /// </summary>
        /// <param name="conn">Connection to database</param>
        /// <param name="type">Command type</param>
        /// <param name="cmdText">Command text</param>
        /// <returns>
        /// The scalar value
        /// </returns>
        protected static async Task<object> ExecuteScalarAsync(SqlConnection conn, CommandType type, string cmdText)
        {
            SqlCommand command = null;
            object returnValue = null;

            try
            {
                command = new SqlCommand(cmdText, conn);
                command.CommandType = type;

                returnValue = await command.ExecuteScalarAsync().ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                if (ex is SqlException sqlException)
                {
                    HandleException(sqlException, command.CommandText);
                }
                else
                {
                    throw;
                }
            }
            finally
            {
                command.Dispose();
            }

            return returnValue;
        }

        /// <summary>
        /// Executes a Transact-SQL statement against the connection and returns the scalar value.
        /// </summary>
        /// <param name="conn">Connection to database</param>
        /// <param name="type">Command type</param>
        /// <param name="cmdText">Command text</param>
        /// <param name="parameters">Parameters passed to the query</param>
        /// <returns>
        /// The scalar value
        /// </returns>
        protected static object ExecuteScalar(SqlConnection conn, CommandType type, string cmdText, params SqlParameter[] parameters)
        {
            if (parameters == null)
            {
                throw new ArgumentNullException(nameof(parameters));
            }

            SqlCommand command = null;
            object returnValue = null;

            try
            {
                command = new SqlCommand(cmdText, conn);
                command.CommandType = type;
                foreach (SqlParameter param in parameters)
                {
                    command.Parameters.Add(param);
                }

                returnValue = command.ExecuteScalar();
            }
            catch (Exception ex)
            {
                if (ex is SqlException sqlException)
                {
                    HandleException(sqlException, command.CommandText, parameters);
                }
                else
                {
                    throw;
                }
            }
            finally
            {
                command.Dispose();
            }

            return returnValue;
        }

        /// <summary>
        /// Executes a Transact-SQL statement against the connection and returns the scalar value.
        /// </summary>
        /// <param name="conn">Connection to database</param>
        /// <param name="type">Command type</param>
        /// <param name="cmdText">Command text</param>
        /// <param name="parameters">Parameters passed to the query</param>
        /// <returns>
        /// The scalar value
        /// </returns>
        protected static async Task<object> ExecuteScalarAsync(SqlConnection conn, CommandType type, string cmdText, params SqlParameter[] parameters)
        {
            if (parameters == null)
            {
                throw new ArgumentNullException(nameof(parameters));
            }

            SqlCommand command = null;
            object returnValue = null;

            try
            {
                command = new SqlCommand(cmdText, conn);
                command.CommandType = type;
                foreach (SqlParameter param in parameters)
                {
                    command.Parameters.Add(param);
                }

                returnValue = await command.ExecuteScalarAsync().ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                if (ex is SqlException sqlException)
                {
                    HandleException(sqlException, command.CommandText, parameters);
                }
                else
                {
                    throw;
                }
            }
            finally
            {
                command.Dispose();
            }

            return returnValue;
        }

        /// <summary>
        /// Creates a comma delimited string from the supplied list containing items of type T
        /// </summary>
        /// <typeparam name="T">The type of items in the list</typeparam>
        /// <param name="items">The list of items</param>
        /// <returns>
        /// A comma delimited string of values
        /// </returns>
        protected static string GetDelimitedString<T>(Collection<T> items)
        {
            if (items == null)
            {
                throw new ArgumentNullException(nameof(items));
            }

            StringBuilder stringBuilder = new StringBuilder();
            foreach (T item in items)
            {
                stringBuilder.Append(stringBuilder.Length > 0 ? "," : string.Empty);
                stringBuilder.Append(item.ToString());
            }

            return stringBuilder.ToString();
        }

        /// <summary>
        /// Creates a database connection
        /// </summary>
        /// <returns>
        /// Connection to database
        /// </returns>
        protected SqlConnection OpenConnection()
        {
            return this.OpenConnection(this.ConnectionString);
        }

        /// <summary>
        /// Creates a database connection
        /// </summary>
        /// <param name="connectionString">The connection string.</param>
        /// <returns>
        /// Connection to database
        /// </returns>
        protected SqlConnection OpenConnection(string connectionString)
        {
            var connection = new SqlConnection(connectionString);
            connection.Open();
            return connection;
        }

        /// <summary>
        /// Creates a database connection
        /// </summary>
        /// <returns>
        /// Connection to database
        /// </returns>
        protected async Task<SqlConnection> OpenConnectionAsync()
        {
            return await this.OpenConnectionAsync(this.ConnectionString).ConfigureAwait(false);
        }

        /// <summary>
        /// Creates a database connection
        /// </summary>
        /// <param name="connectionString">The connection string.</param>
        /// <returns>
        /// Connection to database
        /// </returns>
        protected async Task<SqlConnection> OpenConnectionAsync(string connectionString)
        {
            var connection = new SqlConnection(connectionString);
            await connection.OpenAsync().ConfigureAwait(false);
            return connection;
        }

        #region Dispose

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources
        /// </summary>
        /// <param name="disposing">if true, releases both managed and unmanaged resources; otherwise releases only unmanaged resources.</param>
        protected virtual void Dispose(bool disposing)
        {
            try
            {
                if (disposing)
                {

                }
            }
            catch (SqlException)
            {
            }
            finally
            {

            }
        }

        #endregion //Dispose

        #region Private methods

        /// <summary>
        /// Creating custom exception for SqlExceptions
        /// </summary>
        /// <param name="sqlException">sql exception</param>
        /// <param name="commandText">Command text</param>
        /// <param name="parameters">parameters of sp</param>
        /// <returns>custom sql exception</returns>
        private static GenericSqlException CreateGenericSqlException(SqlException sqlException, string commandText, params SqlParameter[] parameters)
        {
            GenericSqlException genericSqlException = null;
            genericSqlException = new GenericSqlException(sqlException.Message)
            {
                Errors = sqlException.Errors,
                InnerException = sqlException.InnerException,
                StackTrace = sqlException.StackTrace,
                Number = sqlException.Number,
                SqlParams = parameters,
                CommandText = commandText
            };
            return genericSqlException;
        }

        private static void HandleException(SqlException ex, string commandText, params SqlParameter[] parameters)
        {
            if (ex.Number == 50001)
            {
                throw new DuplicateDataException(ex);
            }
            else if (ex.Number == 50002)
            {
                throw new DateValidationException(ex);
            }
            else
            {
                throw CreateGenericSqlException(ex, commandText, parameters);
            }
        }

        #endregion
    }
}
