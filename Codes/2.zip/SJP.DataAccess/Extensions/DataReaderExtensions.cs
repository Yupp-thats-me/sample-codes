﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace SJP.DataAccess.Extensions
{
    /// <summary>
    /// Extending data reader to support reading values from stream to the POCO members
    /// </summary>
    public static class DataReaderExtensions
    {
        /// <summary>
        /// Read a string value
        /// </summary>
        /// <param name="reader">Data reader to be used</param>
        /// <param name="index">ordinal of the field in list</param>
        /// <returns>string or null</returns>
        public static string ToStringValue(this IDataRecord reader, int index)
        {
            object tmp = reader.GetValue(index);
            if (tmp != DBNull.Value)
            {
                return (string)tmp;
            }

            return null;
        }

        /// <summary>
        /// Read any nullable value type
        /// </summary>
        /// <typeparam name="T">Required underlying value type</typeparam>
        /// <param name="reader">Data reader to be used</param>
        /// <param name="index">ordinal of the field in list</param>
        /// <returns>object of type T or null</returns>
        public static T? ToNullable<T>(this IDataRecord reader, int index)
            where T : struct
        {
            object tmp = reader.GetValue(index);
            if (tmp != DBNull.Value)
            {
                return (T)Convert.ChangeType(tmp, typeof(T));
            }

            return null;
        }

        /// <summary>
        /// Read any non nullable value type
        /// </summary>
        /// <typeparam name="T">Required value type</typeparam>
        /// <param name="reader">Data reader to be used</param>
        /// <param name="index">ordinal of the field in list</param>
        /// <returns>object of type T</returns>
        public static T To<T>(this IDataRecord reader, int index)
            where T : struct
        {
            T defValue = default(T);
            object tmp = reader.GetValue(index);
            if (tmp != DBNull.Value)
            {
                return (T)Convert.ChangeType(tmp, typeof(T));
            }

            return defValue;
        }

        /// <summary>
        /// Read a string value
        /// </summary>
        /// <param name="reader">Data reader to be used</param>
        /// <param name="name">field name</param>
        /// <returns>string or null</returns>
        public static string ToStringValue(this IDataRecord reader, string name)
        {
            var index = reader.GetOrdinal(name);
            object tmp = reader.GetValue(index);
            if (tmp != DBNull.Value)
            {
                return (string)tmp;
            }

            return null;
        }

        /// <summary>
        /// To the string value.
        /// </summary>
        /// <param name="reader">The reader.</param>
        /// <param name="name">The name.</param>
        /// <returns>Byte Array or null</returns>
        public static byte[] ToByteArray(this IDataRecord reader, string name)
        {
            var index = reader.GetOrdinal(name);
            object tmp = reader.GetValue(index);
            if (tmp != DBNull.Value)
            {
                return (byte[])tmp;
            }

            return null;
        }

        /// <summary>
        /// Read a rowversion (timestamp) value
        /// </summary>
        /// <param name="reader">Data reader to be used</param>
        /// <param name="name">field name</param>
        /// <returns>rowversion or zero</returns>
        public static ulong ToRowVersion(this IDataRecord reader, string name)
        {
            var index = reader.GetOrdinal(name);
            object tmp = reader.GetValue(index);
            if (tmp != DBNull.Value)
            {
                return BitConverter.ToUInt64((byte[])tmp, 0);
            }

            return 0;
        }

        /// <summary>
        /// Read any non nullable value type
        /// </summary>
        /// <typeparam name="T">Required underlying value type</typeparam>
        /// <param name="reader">Data reader to be used</param>
        /// <param name="name">field name</param>
        /// <returns>object of type T or null</returns>
        public static T? ToNullable<T>(this IDataRecord reader, string name)
            where T : struct
        {
            var index = reader.GetOrdinal(name);
            object tmp = reader.GetValue(index);
            if (tmp != DBNull.Value)
            {
                return (T)Convert.ChangeType(tmp, typeof(T));
            }

            return null;
        }

        /// <summary>
        /// Read any non nullable value type
        /// </summary>
        /// <typeparam name="T">Required value type</typeparam>
        /// <param name="reader">Data reader to be used</param>
        /// <param name="name">field name</param>
        /// <returns>object of type T</returns>
        public static T To<T>(this IDataRecord reader, string name)
            where T : struct
        {
            T defValue = default(T);
            var index = reader.GetOrdinal(name);
            object tmp = reader.GetValue(index);
            if (tmp != DBNull.Value)
            {
                return (T)Convert.ChangeType(tmp, typeof(T));
            }

            return defValue;
        }

        /// <summary>
        /// Read any non nullable value type
        /// </summary>
        /// <typeparam name="T">Required value type</typeparam>
        /// <param name="reader">Data reader to be used</param>
        /// <param name="name">field name</param>
        /// <returns>object of type T</returns>
        public static T TryTo<T>(this IDataRecord reader, string name)
            where T : struct
        {
            T defValue = default(T);
            try
            {
                defValue = default(T);
                if (reader != null)
                {
                    var index = reader.GetOrdinal(name);
                    object tmp = reader.GetValue(index);
                    if (tmp != DBNull.Value)
                    {
                        return (T)Convert.ChangeType(tmp, typeof(T));
                    }
                }
            }
            catch
            {
                return defValue;
            }

            return defValue;
        }
    }
}
