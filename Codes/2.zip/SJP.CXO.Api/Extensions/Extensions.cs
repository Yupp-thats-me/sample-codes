﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using SJP.Communication.Http;
using SJP.Core.Api.Extensions;
using SJP.Core.Utility;
using SJP.CXO.Api.Context;
using SJP.CXO.Api.Datasource.DataAccess;
using SJP.CXO.Api.Datasource.Services;
using SJP.CXO.Api.Services;
using SJP.Logger.Extensions;

namespace SJP.CXO.Api.Extensions
{
    public static class Extensions
    {
        public static IServiceCollection AddServices(this IServiceCollection services)
        {
            services.AddDatabaseLogger();
            services.AddDistributedMemCache();

            /// Use AddHttpCommunicatorWithOAuth only if the oauth is enabled otherwise use simple form 
            ///services.AddHttpCommunicatorWithOAuth();
            ///

            services.AddHttpCommunicator();
            services.AddScoped<IProfileDataAccess, ProfileDataAccess>();
            services.AddScoped<IEventDataAccess, EventDataAccess>();

            services.AddScoped<IProfileService, ProfileService>();
            services.AddScoped<IEventService, EventService>();

            services.AddScoped<IPublicationService, PublicationService>();
            services.AddScoped<IPublicationDataAccess, PublicationDataAccess>();

            services.AddScoped<IReportService, ReportService>();
            services.AddScoped<IReportDataAccess, ReportDataAccess>();

            //services.AddScoped<IFileUtility, FileUtility>();

            services.AddScoped<ICXODataAccess, CXODataAccess>();
            services.AddScoped<IContextContainer, ContextContainer>();

            return services;
        }

        public static IApplicationBuilder UseServices(this IApplicationBuilder app)
        {
            app.UseDatabaseLogger();
            return app;
        }
    }
}
