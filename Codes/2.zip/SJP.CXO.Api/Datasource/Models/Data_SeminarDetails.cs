﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Datasource.Models
{
    public class Data_SeminarDetails
    {
        public int PublicationTypeId { get; set; }

        public string SeminarTypeName { get; set; }

    }
}
