﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Datasource.Models
{
    public class Data_ElementDetails
    {
        public int ElementId { get; set; }

        public int ElementTypeId { get; set; }

        public string ElementTypeName { get; set; }

        public string ElementValue { get; set; }

        public string ElementValueAr { get; set; }



    }
}
