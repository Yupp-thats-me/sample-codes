﻿using SJP.CXO.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Datasource.Models
{
    public class Data_Event
    {
        public long Id { get; set; }

        public int EntryTypeId { get; set; }

        public string Title { get; set; }

        public string PostedBy { get; set; }
        public string Url { get; set; }

        public string Description { get; set; }

        public string ImageName { get; set; }

        public string VideoName { get; set; }

        public string VideoTitle { get; set; }

        public string Venue { get; set; }

        public DateTime EventDate { get; set; }

        public DateTime? ExpiryDate { get; set; }

        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
        public int Status { get; set; }

        public long CXOId { get; set; }

        public bool Active { get; set; }
        public EntryType EntryType { get; set; }

        public string Remarks { get; set; }
    }
}
