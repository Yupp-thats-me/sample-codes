﻿using SJP.CXO.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Datasource.Models
{
    public class Data_ProfileDetails
    {
        public long Id { get; set; }
        public long CXOId { get; set; }
        public int CXOTypeId { get; set; }
        public string OnlineProfile { get; set; }

        public string ShortBio { get; set; }
        public EntryType EntryType { get; set; }
        public int EntryTypeId { get; set; }
        public string ProfileVideo { get; set; }
        public int? IndustryId { get; set; }
        public int? CompanyId { get; set; }
        public int? DesignationId { get; set; }
        public int? CompanyZoneId { get; set; }
        public string CreatedBy { get; set; }
        public string VideoTitle { get; set; }
        public int Status { get; set; }
        public DateTime CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public string Designation { get; set; }
        public string Industry { get; set; }
        public string Company { get; set; }
        public string CompanyZone { get; set; }
        public string Remarks { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}
