﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Core.Api.Services;
using SJP.CXO.Api.Datasource.Models;
using SJP.CXO.Api.Models;
using SJP.DataAccess;
using SJP.DataAccess.Extensions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using static SJP.CXO.Api.Models.EventModel;

namespace SJP.CXO.Api.Datasource.Services
{
    public class EventDataAccess : DataAccessBase, IEventDataAccess
    {
        private readonly ILogger logger;
        protected ILogger Logger => logger;

        private UserManager userManager;

        public EventDataAccess(ILogger<EventDataAccess> logger, IConfiguration configuration, UserManager userManager) : base(configuration)
        {
            this.logger = logger;
            this.userManager = userManager;
        }

        public async Task<Data_Event> SaveEvent(Data_Event data)
        {
            try
            {
                var paramReferenceId = new SqlParameter("@ReferenceId", SqlDbType.BigInt) { Value = data.Id, Direction = ParameterDirection.Output };
                var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = data.Id };
                var paramEntryTypeId = new SqlParameter("@EntryTypeId", SqlDbType.BigInt) { Value = (int)data.EntryType };
                var paramActive = new SqlParameter("@Active", SqlDbType.Bit) { Value = data.Active };
                var paramTitle = new SqlParameter("@Title", SqlDbType.NVarChar) { Value = data.Title ?? "", IsNullable = true };
                var paramDescription = new SqlParameter("@Description", SqlDbType.NVarChar) { Value = data.Description ?? "", IsNullable = true };
                var paramUrl = new SqlParameter("@Url", SqlDbType.NVarChar) { Value = data.Url ?? "", IsNullable = true };
                var paramVideoTitle = new SqlParameter("@VideoTitle", SqlDbType.NVarChar) { Value = data.VideoTitle ?? "", IsNullable = true };
                var paramEventVideos = new SqlParameter("@EventVideos", SqlDbType.NVarChar) { Value = data.VideoName ?? "", IsNullable = true };
                var paramStatus = new SqlParameter("@Status", SqlDbType.TinyInt) { Value = data.Status };
                var paramEventPic = new SqlParameter("@EventPic", SqlDbType.NVarChar) { Value = data.ImageName ?? "", IsNullable = true };
                var paramVenue = new SqlParameter("@Venue", SqlDbType.NVarChar) { Value = data.Venue ?? "", IsNullable = true };
                var paramEventDate = new SqlParameter("@EventDate", SqlDbType.DateTime) { Value = data.EventDate, IsNullable = true };
                var paramExpiryDate = new SqlParameter("@ExpiryDate", SqlDbType.DateTime) { Value = data.ExpiryDate, IsNullable = true };
                var paramCXOId = new SqlParameter("@CXOId", SqlDbType.BigInt) { Value = data.CXOId };
                var paramCreatedBy = new SqlParameter("@CreatedBy", SqlDbType.NVarChar) { Value = data.CreatedBy, IsNullable = true };
                var paramUpdatedBy = new SqlParameter("@UpdatedBy", SqlDbType.NVarChar) { Value = data.UpdatedBy ?? "", IsNullable = true };

                this.Logger.LogInformation(string.Format(" Details received for rowId:{0}", paramId));

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();

                        await ExecuteNonQueryAsync(
                                connection,
                                transaction,
                                CommandType.StoredProcedure,
                                "dbo.SaveEvent",
                                paramReferenceId,
                                paramId,
                                paramEntryTypeId,
                                paramActive,
                                paramTitle,
                                paramUrl,
                                paramDescription,
                                paramEventPic,
                                paramEventVideos,
                                paramStatus,
                                paramCXOId,
                                paramVenue,
                                paramVideoTitle,
                                paramEventDate,
                                paramExpiryDate,
                                paramCreatedBy,
                                paramUpdatedBy
                                ).ConfigureAwait(false);

                        transaction.Commit();
                    }
                    catch (Exception e)
                    {
                        Debug.WriteLine("Error is :" + e);
                        if (transaction != null)
                            transaction.Rollback();
                        throw;
                    }

                    data.Id = (long)paramReferenceId.Value;

                    this.Logger.LogInformation("Exiting from CXO SaveEvent method");

                    return data;
                }
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public async Task<IEnumerable<Data_Event>> GetEventsAsync(FilterModel filter)
        {
            this.Logger.LogInformation("Entering into GetEventsAsync Method");

            IList<Data_Event> result = new List<Data_Event>();

            var filterParams = GetFilterParams(filter);



            using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
            {
                using (var reader = await ExecuteReaderAsync(
                                connection,
                                CommandType.StoredProcedure,
                                "GetEventDetails",
                                filterParams
                                ).ConfigureAwait(false))
                {
                    if (reader.HasRows)
                    {
                        while (await reader.ReadAsync().ConfigureAwait(false))
                        {
                            result.Add(new Data_Event
                            {
                                Id = reader.To<int>("Id"),
                                //EntryTypeId = reader.To<int>("EntryTypeId"),
                                Active = reader.To<bool>("Active"),
                                Title = reader.ToStringValue("Title"),
                                CXOId = reader.To<int>("CXOId"),
                                // PostedBy = reader.ToStringValue("PostedBy"),
                                Url = reader.ToStringValue("Url"),
                                Status = reader.To<int>("Status"),
                                Description = reader.ToStringValue("Description"),
                                ImageName = reader.ToStringValue("EventPic"),
                                VideoTitle = reader.ToStringValue("VideoTitle"),
                                VideoName = reader.ToStringValue("EventVideos"),
                                Venue = reader.ToStringValue("Venue"),
                                EventDate = reader.To<DateTime>("EventDate"),
                                ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                CreatedBy = reader.ToStringValue("CreatedBy"),
                                UpdatedBy = reader.ToStringValue("UpdatedBy"),
                                Remarks = reader.ToStringValue("Remarks"),

                            });
                        }
                    }
                }
            }

            this.Logger.LogInformation("Exiting from GetEventsAsync Method");
            return result;
        }

        public async Task<IEnumerable<Data_Event>> GetEventsGridAsync(FilterModel filter)
        {
            this.Logger.LogInformation("Entering into GetEventsGridAsync Method");

            IList<Data_Event> result = new List<Data_Event>();

            var filterParams = GetFilterParams(filter);

            using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
            {
                using (var reader = await ExecuteReaderAsync(
                                connection,
                                CommandType.StoredProcedure,
                                "GetEventsGrid",
                                filterParams
                                ).ConfigureAwait(false))
                {
                    if (reader.HasRows)
                    {
                        while (await reader.ReadAsync().ConfigureAwait(false))
                        {
                            result.Add(new Data_Event
                            {
                                Id = reader.To<int>("Id"),
                                Title = reader.ToStringValue("Title"),
                                // PostedBy = reader.ToStringValue("PostedBy"),
                                Url = reader.ToStringValue("Url"),
                                Status = reader.To<int>("Status"),
                                Venue = reader.ToStringValue("Venue"),
                                EventDate = reader.To<DateTime>("EventDate"),
                                ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                Remarks = reader.ToStringValue("Remarks"),
                                PostedBy = reader.ToStringValue("PostedBy"),

                            });
                        }
                    }
                }
            }

            this.Logger.LogInformation("Exiting from GetEventsGridAsync Method");
            return result;
        }


        public async Task<bool> DeleteEventAsync(long Id)
        {
            try
            {
                this.Logger.LogInformation("Entering into DeleteEventAsync Method");

                var paramid = new SqlParameter("@Id", SqlDbType.BigInt) { Value = Id };

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "DeleteEventDetails",
                            paramid
                            ).ConfigureAwait(false);
                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from DeleteEventAsync Method");
                return true;
            }

            catch (Exception Ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in DeleteEventAsync Method :" + Ex.ToString());
                throw Ex;
            }
        }

        public async Task<bool> UpdateApproval(ApprovalModel model)
        {
            this.Logger.LogInformation("Entering into ApproveEvent Method");

            var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = model.Id };
            var paramStatusId = new SqlParameter("@Status", SqlDbType.TinyInt) { Value = model.Status };
            var paramRemarks = new SqlParameter("@Remarks", SqlDbType.NVarChar) { Value = model.Remarks };
            var paramUpdatedBy = new SqlParameter("@UpdatedBy", SqlDbType.NVarChar) { Value = model.UpdatedBy };


            using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
            {
                SqlTransaction transaction = null;
                try
                {
                    transaction = connection.BeginTransaction();
                    await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "UpdateEventApproval",

                        paramId,
                        paramStatusId,
                        paramRemarks,
                        paramUpdatedBy
                        ).ConfigureAwait(false);
                    transaction.Commit();
                }
                catch (Exception e)
                {
                    this.Logger.LogError("Error Occured", "ERROR in UpdateApproval Method, rollback... :" + e.ToString());
                    if (transaction != null)
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
            return true;
        }

        private SqlParameter[] GetFilterParams(FilterModel filter)
        {
            var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = filter.Id, IsNullable = true };

            var paramFromDate = new SqlParameter("@FromDate", SqlDbType.DateTime) { Value = filter.FromDate, IsNullable = true };
            var paramToDate = new SqlParameter("@ToDate", SqlDbType.DateTime) { Value = filter.FromDate, IsNullable = true };
            var paramCXOId = new SqlParameter("@CXOId", SqlDbType.BigInt) { Value = filter.CXOId, IsNullable = true };
            var paramExcludeExpired = new SqlParameter("@ExcludeExpired", SqlDbType.Bit) { Value = filter.ExcludeExpired, IsNullable = true };
            var paramStatusList = new SqlParameter("@StatusList", SqlDbType.NVarChar) { Value = filter.Status, IsNullable = true };

            return new SqlParameter[] { paramId, paramFromDate, paramToDate, paramCXOId, paramExcludeExpired, paramStatusList };
        }

        public async Task<bool> UpdateView(long id, string UserId)
        {
            this.Logger.LogInformation("Entering into UpdateView Method");

            var paramUserId = new SqlParameter("@UserId", SqlDbType.NVarChar) { Value = UserId };
            var paramId = new SqlParameter("@Id", SqlDbType.NVarChar) { Value = id };


            using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
            {
                SqlTransaction transaction = null;
                try
                {
                    transaction = connection.BeginTransaction();
                    await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "UpdateView",
                        paramId,
                        paramUserId
                        ).ConfigureAwait(false);
                    transaction.Commit();
                }
                catch (Exception e)
                {
                    this.Logger.LogError("Error Occured", "ERROR in UpdateView Method, rollback... :" + e.ToString());
                    if (transaction != null)
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
            return true;

        }
    }
}
