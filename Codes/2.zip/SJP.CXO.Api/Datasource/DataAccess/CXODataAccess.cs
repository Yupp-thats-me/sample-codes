﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.CXO.Api.Models;
using SJP.DataAccess;
using System;
using SJP.DataAccess.Extensions;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Datasource.DataAccess
{
    public class CXODataAccess : DataAccessBase, ICXODataAccess
    {
        private readonly ILogger logger;
        protected ILogger Logger => logger;
        public CXODataAccess(ILogger<CXODataAccess> logger, IConfiguration configuration) : base(configuration)
        {
            this.logger = logger;
        }

        public async Task<IList<ElementModel>> GetElementsAsync(int? ElementTypeId = null)
        {
            IList<ElementModel> result = new List<ElementModel>();

            try
            {
                this.Logger.LogInformation("Entering into GetElementsAsync Method");

                var paramElementTypeId = new SqlParameter("@ElementTypeId", SqlDbType.NVarChar) { Value = ElementTypeId, IsNullable = true };

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                    connection,
                                    CommandType.StoredProcedure,
                                    "GetElements",
                                    paramElementTypeId
                                    ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                result.Add(new ElementModel
                                {
                                    ElementId = reader.To<int>("ElementId"),
                                    ElementTypeId = reader.To<int>("ElementTypeId"),
                                    ElementTypeName = reader.ToStringValue("ElementTypeName"),
                                    ElementValue = reader.ToStringValue("ElementValue"),
                                    ElementValueAr = reader.ToStringValue("ElementValueAr"),
                                });
                            }
                        }
                    }
                }

                this.Logger.LogInformation("Exiting from GetElementsAsync Method");

                return result;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetElementsAsync mrthod : " + ex.ToString());

                return result;

            }
        }
    }
}
