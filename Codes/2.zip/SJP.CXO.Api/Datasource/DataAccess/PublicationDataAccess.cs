﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.CXO.Api.Datasource.Models;
using SJP.CXO.Api.Models;
using SJP.DataAccess;
using SJP.DataAccess.Extensions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Datasource.DataAccess
{
    public class PublicationDataAccess : DataAccessBase, IPublicationDataAccess
    {
        private readonly ILogger logger;
        protected ILogger Logger => logger;

        public PublicationDataAccess(ILogger<PublicationDataAccess> logger, IConfiguration configuration) : base(configuration)
        {
            this.logger = logger;
        }

        public async Task<Data_Publication> SavePublication(Data_Publication data)
        {
            try
            {
                var paramReferenceId = new SqlParameter("@ReferenceId", SqlDbType.BigInt) { Value = data.Id, Direction = ParameterDirection.Output };
                var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = data.Id };
                var paramEntryTypeId = new SqlParameter("@EntryTypeId", SqlDbType.BigInt) { Value = (int)data.EntryType };
                var paramCXOId = new SqlParameter("@CXOId", SqlDbType.BigInt) { Value = data.CXOId };
                var paramIndustryId = new SqlParameter("@IndustryId", SqlDbType.BigInt) { Value = data.IndustryId };
                var paramImageFile = new SqlParameter("@ImageFile", SqlDbType.NVarChar) { Value = data.ImageFiles ?? "", IsNullable = true };
                var paramPostedDate = new SqlParameter("@PostedDate", SqlDbType.DateTime) { Value = data.PostedDate, IsNullable = true };
                var paramTitleEn = new SqlParameter("@TitleEn", SqlDbType.NVarChar) { Value = data.TitleEn ?? "", IsNullable = true };
                var paramPublicationTypeId = new SqlParameter("@PublicationTypeId", SqlDbType.TinyInt) { Value = data.PublicationTypeId };
                var paramTitleAr = new SqlParameter("@TitleAr", SqlDbType.NVarChar) { Value = data.TitleAr ?? "", IsNullable = true };
                var paramAuthorEn = new SqlParameter("@AuthorEn", SqlDbType.NVarChar) { Value = data.AuthorEn ?? "", IsNullable = true };
                var paramAuthorAr = new SqlParameter("@AuthorAr", SqlDbType.NVarChar) { Value = data.AuthorAr ?? "", IsNullable = true };
                var paramExpiryDate = new SqlParameter("@ExpiryDate", SqlDbType.DateTime) { Value = data.ExpiryDate, IsNullable = true };
                var paramAbstractEn = new SqlParameter("@AbstractEn", SqlDbType.NVarChar) { Value = data.AbstractEn, IsNullable = true };
                var paramAbstractAr = new SqlParameter("@AbstractAr", SqlDbType.NVarChar) { Value = data.AbstractEn, IsNullable = true };
                var paramVideoTitle = new SqlParameter("@VideoTitle", SqlDbType.NVarChar) { Value = data.VideoTitle, IsNullable = true };
                var paramVideoFile = new SqlParameter("@VideoFile", SqlDbType.NVarChar) { Value = data.VideoFiles, IsNullable = true };
                var paramDocumentFile = new SqlParameter("@DocumentFile", SqlDbType.NVarChar) { Value = data.DocumentFiles ?? "", IsNullable = true };
                var paramStatus = new SqlParameter("@Status", SqlDbType.TinyInt) { Value = data.Status };
                var paramActive = new SqlParameter("@Active", SqlDbType.Bit) { Value = data.Active };
                var paramCreatedBy = new SqlParameter("@CreatedBy", SqlDbType.NVarChar) { Value = data.CreatedBy };
                var paramUpdatedBy = new SqlParameter("@UpdatedBy", SqlDbType.NVarChar) { Value = data.UpdatedBy ?? "", IsNullable = true };

                this.Logger.LogInformation(string.Format(" Details received for rowId:{0}", paramId));

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();

                        await ExecuteNonQueryAsync(
                                connection,
                                transaction,
                                CommandType.StoredProcedure,
                                "dbo.SavePublication",
                                paramReferenceId,
                                paramId,
                                paramEntryTypeId,
                                paramCXOId,
                                paramIndustryId,
                                paramImageFile,
                                paramPostedDate,
                                paramTitleEn,
                                paramTitleAr,
                                paramAuthorEn,
                                paramAuthorAr,
                                paramAbstractEn,
                                paramAbstractAr,
                                paramVideoTitle,
                                paramVideoFile,
                                paramDocumentFile,
                                paramPublicationTypeId,
                                paramExpiryDate,
                                paramStatus,
                                paramActive,
                                paramCreatedBy,
                                paramUpdatedBy
                                ).ConfigureAwait(false);

                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                            transaction.Rollback();
                        throw;
                    }

                    data.Id = (long)paramReferenceId.Value;

                    this.Logger.LogInformation("Exiting from CXO SavePublication method");

                    return data;
                }
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public async Task<IEnumerable<Data_Publication>> GetPublicationDataAsync(FilterModel filter)
        {
            this.Logger.LogInformation("Entering into GetPublicationDataAsync Method");

            IList<Data_Publication> result = new List<Data_Publication>();

            var paramId = new SqlParameter("@id", SqlDbType.BigInt) { Value = filter.Id, IsNullable = true };


            var paramCXOId = new SqlParameter("@CXOId", SqlDbType.BigInt) { Value = filter.CXOId, IsNullable = true};

            var paramPublicationTypeId = new SqlParameter("@PublicationTypeId", SqlDbType.Int) { Value = filter.PublicationTypeId, IsNullable = true };

            var paramStatus = new SqlParameter("@Status", SqlDbType.TinyInt) { Value = filter.Status, IsNullable = true };

            using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
            {
                using (var reader = await ExecuteReaderAsync(
                                connection,
                                CommandType.StoredProcedure,
                                "GetPublicationDetails",
                                paramId,
                                paramCXOId,
                                paramPublicationTypeId,
                                paramStatus
                                ).ConfigureAwait(false))
                {
                    if (reader.HasRows)
                    {
                        while (await reader.ReadAsync().ConfigureAwait(false))
                        {
                            result.Add(new Data_Publication
                            {
                                Id = reader.To<int>("Id"),
                                //EntryTypeId = reader.To<int>("EntryTypeId"),
                                CXOId = reader.To<int>("CXOId"),
                                IndustryId = reader.To<int>("IndustryId"),
                                Status = reader.To<int>("Status"),
                                Active = reader.To<bool>("Active"),
                                ApproverId = reader.To<int>("ApproverId"),
                                TitleEn = reader.ToStringValue("TitleEn"),
                                ImageFiles = reader.ToStringValue("ImageFile"),
                                PostedDate = reader.To<DateTime>("PostedDate"),
                                AuthorEn = reader.ToStringValue("AuthorEn"),
                                AbstractEn = reader.ToStringValue("AbstractEn"),
                                VideoTitle = reader.ToStringValue("VideoTitle"),
                                VideoFiles = reader.ToStringValue("VideoFiles"),
                                DocumentFiles = reader.ToStringValue("DocumentFiles"),
                                PublicationTypeId = reader.To<int>("PublicationTypeId"),
                                PublicationTypeName = reader.ToStringValue("PublicationTypeName"),
                                IndustryName = reader.ToStringValue("IndustryName"),
                                ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                CreatedBy = reader.ToStringValue("CreatedBy"),
                                UpdatedBy = reader.ToStringValue("UpdatedBy"),
                                Remarks = reader.ToStringValue("Remarks"),
                            });
                        }
                    }
                }
                return result;
            }
        }

        public async Task<IEnumerable<Data_Publication>> GetPublicationsGridAsync(FilterModel filter)
        {

            IList<Data_Publication > result = new List<Data_Publication>();

            var filterParams = GetFilterParams(filter);

            using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
            {
                using (var reader = await ExecuteReaderAsync(
                                connection,
                                CommandType.StoredProcedure,
                                "GetPublicationsGrid",
                                filterParams
                                ).ConfigureAwait(false))
                {
                    if (reader.HasRows)
                    {
                        while (await reader.ReadAsync().ConfigureAwait(false))
                        {
                            result.Add(new Data_Publication
                            {
                                Id = reader.To<int>("Id"),
                                TitleEn = reader.ToStringValue("TitleEn"),
                                AuthorEn = reader.ToStringValue("AuthorEn"),
                                Status = reader.To<int>("Status"),
                                PublicationTypeId = reader.To<int>("PublicationTypeId"),
                                PostedDate = reader.To<DateTime>("PostedDate"),
                                ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                Remarks = reader.ToStringValue("Remarks"),
                            });
                        }
                    }
                }
            }

            this.Logger.LogInformation("Exiting from GetEventsGridAsync Method");
            return result;
        }

        public async Task<bool> DeletePublicationAsync(long Id)
        {
            try
            {
                this.Logger.LogInformation("Entering into DeletePublicationAsync Method");

                var paramid = new SqlParameter("@Id", SqlDbType.BigInt) { Value = Id };

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "dbo.DeletePublicationDetails",
                            paramid
                            ).ConfigureAwait(false);
                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from DeletePublicationAsync Method");
                return true;
            }

            catch (Exception Ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in DeletePublicationAsync Method :" + Ex.ToString());
                throw Ex;
            }
        }

        public async Task<bool> UpdatePublicationStatus(ApprovalModel model)
        {

            this.Logger.LogInformation("Entering into ApprovePublication Method");

            var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = model.Id }; 
            var paramStatusId = new SqlParameter("@Status", SqlDbType.BigInt) { Value = model.Status };
            var paramRemarks = new SqlParameter("@Remarks", SqlDbType.NVarChar) { Value = model.Remarks, IsNullable = true };
            var paramUpdatedBy = new SqlParameter("@UpdatedBy", SqlDbType.NVarChar) { Value = model.UpdatedBy };

            using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
            {
                SqlTransaction transaction = null;
                try
                {
                    transaction = connection.BeginTransaction();
                    await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "[ApprovePublication]",
                        paramId,
                        paramStatusId,
                        paramRemarks,
                        paramUpdatedBy
                        ).ConfigureAwait(false);
                    transaction.Commit();
                }
                catch (Exception e)
                {
                    this.Logger.LogError("Error Occured", "ERROR in UpdateApproval Method, rollback... :" + e.ToString());
                    if (transaction != null)
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
            return true;
        }

        public async Task<IEnumerable<Data_SeminarDetails>> GetSeminarAsync(int? PublicationTypeId = null)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetElementsAsync Method");

                IList<Data_SeminarDetails> result = new List<Data_SeminarDetails>();

                var paramPublicationTypeId = new SqlParameter("@PublicationTypeId", SqlDbType.NVarChar) { Value = PublicationTypeId, IsNullable = true };

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                    connection,
                                    CommandType.StoredProcedure,
                                    "GetSeminarDetails",
                                    paramPublicationTypeId
                                    ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                result.Add(new Data_SeminarDetails
                                {
                                    PublicationTypeId = reader.To<int>("PublicationTypeId"),
                                    SeminarTypeName = reader.ToStringValue("SeminarTypeName"),
                                });
                            }
                        }
                    }
                }

                this.Logger.LogInformation("Exiting from GetSeminarAsync Method");

                return result;
            }
            catch (Exception es)
            {

                throw;
            }
        }
        public async Task<Feedback> SaveFeedbackDetails(Feedback feedback)

        {
            try
            {
                this.Logger.LogInformation("Entering into SaveFeedbackDetails method");
                var paramid = new SqlParameter("@Id", SqlDbType.BigInt) { Value = feedback.Id };
                var paramreferenceid = new SqlParameter("@ReferenceId", SqlDbType.BigInt) { Value = feedback.Id, Direction = ParameterDirection.Output };
                var parampublicationtypeid = new SqlParameter("@PublicationtypeID", SqlDbType.BigInt) { Value = feedback.PublicationtypeID };
                var paramuserid = new SqlParameter("@UserId", SqlDbType.BigInt) { Value = feedback.UserId };
                //var paramfeedbackType = new SqlParameter("@FeedbackType", SqlDbType.Int) { Value = feedback.FeedbackType };
                var paramContent = new SqlParameter("@Content", SqlDbType.Int) { Value = feedback.Content };
                var paramdesign = new SqlParameter("@Design", SqlDbType.Int) { Value = feedback.Design };
                var parampersonalization = new SqlParameter("@Personalization", SqlDbType.Int) { Value = feedback.Personalization };
                var paramfunctionality = new SqlParameter("@Functionality", SqlDbType.Int) { Value = feedback.Functionality };
                var paramCreatedBy = new SqlParameter("@CreatedBy", SqlDbType.NVarChar) { Value = feedback.CreatedBy };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveFeedbackDetails",
                        paramid,
                        paramreferenceid,
                        parampublicationtypeid,
                        paramuserid,
                        //paramfeedbackType,
                        paramContent,
                        paramdesign,
                        parampersonalization,
                        paramfunctionality,
                        paramCreatedBy
                        ).ConfigureAwait(false);
                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }

                }
                feedback.Id = (long)paramreferenceid.Value;
                this.Logger.LogInformation("Exiting from SaveFeedbackDetails Method");
                return feedback;
            }

            catch (Exception Ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in SaveFeedbackDetails Method : " + Ex.ToString());
                throw Ex;
            }

        }

        private SqlParameter[] GetFilterParams(FilterModel filter)
        {
            var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = filter.Id, IsNullable = true };
            var paramPublicationTypeId = new SqlParameter("@PublicationTypeId", SqlDbType.BigInt) { Value = filter.PublicationTypeId, IsNullable = true };

            var paramFromDate = new SqlParameter("@FromDate", SqlDbType.DateTime) { Value = filter.FromDate, IsNullable = true };
            var paramToDate = new SqlParameter("@ToDate", SqlDbType.DateTime) { Value = filter.FromDate, IsNullable = true };
            var paramCXOId = new SqlParameter("@CXOId", SqlDbType.BigInt) { Value = filter.CXOId, IsNullable = true };
            var paramExcludeExpired = new SqlParameter("@ExcludeExpired", SqlDbType.Bit) { Value = filter.ExcludeExpired, IsNullable = true };
            var paramStatusList = new SqlParameter("@StatusList", SqlDbType.NVarChar) { Value = filter.Status, IsNullable = true };

            return new SqlParameter[] { paramId, paramPublicationTypeId, paramFromDate, paramToDate, paramCXOId, paramExcludeExpired, paramStatusList };
        }
    }
}


