﻿using SJP.CXO.Api.Datasource.Models;
using SJP.CXO.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Datasource.DataAccess
{
    public interface IPublicationDataAccess
    {
        Task<Data_Publication> SavePublication(Data_Publication data);
        Task<IEnumerable<Data_Publication>> GetPublicationDataAsync(FilterModel filter);
        Task<IEnumerable<Data_Publication>> GetPublicationsGridAsync(FilterModel filter);
        Task<bool> DeletePublicationAsync(long id);
        Task<bool> UpdatePublicationStatus(ApprovalModel model);
        Task<IEnumerable<Data_SeminarDetails>> GetSeminarAsync(int? PublicationTypeId = null);
        Task<Feedback> SaveFeedbackDetails(Feedback feedback);

    }
}
