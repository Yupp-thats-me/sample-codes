﻿using SJP.CXO.Api.Datasource.Models;
using SJP.CXO.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Datasource.Services
{
    public interface IProfileDataAccess
    {
        Task<Data_ProfileDetails> SaveProfile(Data_ProfileDetails data);

        Task<IEnumerable<Data_ProfileDetails>> GetProfilesAsync(ProfileFilterModel filter);

        Task<IEnumerable<Data_ProfileDetails>> GetProfilesGridAsync(); 

        Task<IEnumerable<Data_ElementDetails>> GetElementsAsync(int? ElementTypeId = null);

        Task<bool> UpdateProfileStatus(ApprovalModel model);

    }
}
