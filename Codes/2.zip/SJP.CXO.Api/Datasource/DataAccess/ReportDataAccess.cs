﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.CXO.Api.Models;
using SJP.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Extensions;
using System.Linq;
using System.Threading.Tasks;
using SJP.DataAccess.Extensions;
using SJP.CXO.Api.Datasource.Models;
using System.Data.SqlClient;
using SJP.CXO.Api.Models.Report;
using SJP.Core.Model;

namespace SJP.CXO.Api.Datasource.DataAccess
{
    public class ReportDataAccess : DataAccessBase, IReportDataAccess
    {
        private readonly ILogger logger;
        protected ILogger Logger => logger;

        public ReportDataAccess(ILogger<ReportDataAccess> logger, IConfiguration configuration) : base(configuration)
        {
            this.logger = logger;
        }

        public async Task<IEnumerable<Data_Profiles>> GetCXOProfilesAsync(FilterModel filter)
        {
            try
            {
                IList<Data_Profiles> result = new List<Data_Profiles>();

                var paramStartDate = new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = filter.FromDate, IsNullable = true };
                var paramEndDate = new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = filter.ToDate, IsNullable = true };
                var paramOrganizationType = new SqlParameter("@OrganizationType", SqlDbType.Int) { Value = filter.OrganizationType, IsNullable = true };
                var paramEmirate = new SqlParameter("@CityId", SqlDbType.Int) { Value = filter.CityId, IsNullable = true };


                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                    connection,
                                    CommandType.StoredProcedure,
                                    "[dbo].[report.getProfiles]",
                                    paramStartDate,
                                    paramEndDate,
                                    paramOrganizationType,
                                    paramEmirate

                                    ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                result.Add(new Data_Profiles
                                {
                                    ShortBio = reader.ToStringValue("Bio"),
                                    OnlineProfile = reader.ToStringValue("OnlineProfile"),
                                    Designation = reader.ToStringValue("Designation"),
                                    Name = reader.ToStringValue("Name"),
                                    //LastName = reader.ToStringValue("LastName"),
                                    OrganizationName = reader.ToStringValue("OrganizationName"),
                                    Email = reader.ToStringValue("Email"),
                                    EmirateEn = reader.ToStringValue("EmirateEn"),
                                    EmirateAr = reader.ToStringValue("EmirateAr"),
                                    OrganizationTypeCXO = reader.To<int>("OrganizationTypeCXO"),
                                    Industry = reader.ToStringValue("Industry"),
                                    TotalCXOPublic = reader.To<long>("TotalCXOPublic"),
                                    TotalCXOPrivate = reader.To<long>("TotalCXOPrivate"),
                                    TotalCXO = reader.To<long>("TotalCXO"),



                                }); ;
                            }
                        }
                    }
                }

                this.Logger.LogInformation("Exiting from GetCXOProfilesAsync Method");

                return result;
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public async Task<IEnumerable<EventReportModel>> GetEventDetails(FilterModel filter)
        {
            try
            {
                IList<EventReportModel> result = new List<EventReportModel>();

                var paramStartDate = new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = filter.FromDate, IsNullable = true };
                var paramEndDate = new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = filter.ToDate, IsNullable = true };
                var paramPostType = new SqlParameter("@PostType", SqlDbType.Int) { Value = filter.PostType, IsNullable = true };
                var paramOrganizationType = new SqlParameter("@OrganizationType", SqlDbType.Int) { Value = filter.OrganizationType, IsNullable = true };


                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                    connection,
                                    CommandType.StoredProcedure,
                                    "[dbo].[report.getEventsView]",
                                    paramStartDate,
                                    paramEndDate,
                                    paramPostType,
                                    paramOrganizationType
                                    ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                result.Add(new EventReportModel
                                {
                                    PostedBy = reader.ToStringValue("PostedBy"),
                                    Title = reader.ToStringValue("Title"),
                                    PostedDate = reader.To<DateTime>("CreatedDate"),
                                    Industry = reader.ToStringValue("Industry"),
                                    ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                    Venue = reader.ToStringValue("Venue"),
                                    URL = reader.ToStringValue("URL"),
                                    TotalViews=reader.To<long>("TotalViews"),
                                    StudentViews=reader.To<long>("StudentViews"),
                                    PostTitle = reader.ToStringValue("PostTitle"),
                                    TotalEvent = reader.To<long>("TotalEvent"),
                                    TOTALPUBLICATION = reader.To<long>("TOTALPUBLICATION"),
                                    Totalseminars = reader.To<long>("Totalseminars"),

                                });
                            }
                        }
                    }
                }

                this.Logger.LogInformation("Exiting from GetEventDetails Method");

                return result;
            }
            catch (Exception e)
            {

                throw;
            }
        }


        public async Task<IEnumerable<PublicationReportModel>> GetpublicationDetails(FilterModel filter)
        {
            try
            {
                IList<PublicationReportModel> result = new List<PublicationReportModel>();

                var paramStartDate = new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = filter.FromDate, IsNullable = true };
                var paramEndDate = new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = filter.ToDate, IsNullable = true };
                var paramPostType = new SqlParameter("@PostType", SqlDbType.Int) { Value = filter.PostType, IsNullable = true };
                var paramOrganizationType = new SqlParameter("@OrganizationType", SqlDbType.Int) { Value = filter.OrganizationType, IsNullable = true };


                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                    connection,
                                    CommandType.StoredProcedure,
                                    "[dbo].[report.getPublicationView]",
                                    paramStartDate,
                                    paramEndDate,
                                    paramPostType,
                                    paramOrganizationType
                                    ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                result.Add(new PublicationReportModel
                                {
                                    PostedBy = reader.ToStringValue("PostedBy"),
                                    Title = reader.ToStringValue("TitleEN"),
                                    PostedDate = reader.To<DateTime>("CreatedDate"),
                                    Industry = reader.ToStringValue("Industry"),
                                    ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                    Authors=reader.ToStringValue("Authors"),
                                    TotalViews = reader.To<long>("TotalViews"),
                                    StudentViews = reader.To<long>("StudentViews"),
                                    PostTitle = reader.ToStringValue("PostTitle"),
                                    TotalEvent = reader.To<long>("TotalEvent"),
                                    TOTALPUBLICATION = reader.To<long>("TOTALPUBLICATION"),
  


                                });
                            }
                        }
                    }
                }

                this.Logger.LogInformation("Exiting from GetEventDetails Method");

                return result;
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public async Task<IEnumerable<EventModel>> GetCXOListing(FilterModel filter)
        {
            try
            {
                IList<EventModel> result = new List<EventModel>();

                var paramStartDate = new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = filter.FromDate, IsNullable = true };
                var paramEndDate = new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = filter.ToDate, IsNullable = true };
                var paramOrganizationType = new SqlParameter("@OrganizationType", SqlDbType.Int) { Value = filter.OrganizationType, IsNullable = true };
                var paramPostType = new SqlParameter("@PostType", SqlDbType.Int) { Value = filter.PostType, IsNullable = true };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                    connection,
                                    CommandType.StoredProcedure,
                                    "[dbo].[report.getCxoListingStatistics]",
                                    paramStartDate,
                                    paramEndDate,
                                    paramOrganizationType,
                                    paramPostType

                                    ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                result.Add(new EventModel
                                {

                                    AdminName = reader.ToStringValue("AdminName"),
                                    TotalCXOPosted = reader.To<long>("TotalCXOPosted"),
                                    TotalCXOPending = reader.To<long>("TotalCXOPending"),
                                    TotalCXOApproved = reader.To<long>("TotalCXOApproved"),
                                    TotalCXORejected = reader.To<long>("TotalCXORejected"),
                                });
                            }
                        }
                    }
                }

                this.Logger.LogInformation("Exiting from GetCXOProfilesAsync Method");

                return result;
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public async Task<IEnumerable<Feedback>> GetCXOFeedBack(FilterModel filter)
        {
            try
            {
                IList<Feedback> result = new List<Feedback>();

                var paramStartDate = new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = filter.FromDate, IsNullable = true };
                var paramEndDate = new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = filter.ToDate, IsNullable = true };
                //var paramEducaionLevel = new SqlParameter("@EducationLevel", SqlDbType.Int) { Value = filter.EducationLevelId, IsNullable = true };
                //var paramEducationCategory = new SqlParameter("@EducationCategory", SqlDbType.Int) { Value = filter.EducationCategoryId, IsNullable = true };

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                    connection,
                                    CommandType.StoredProcedure,
                                    "[dbo].[report.getCXOFeedback]",
                                    paramStartDate,
                                    paramEndDate
                                    //paramEducaionLevel,
                                    //paramEducationCategory

                                    ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                result.Add(new Feedback
                                {

                                   // UserId = reader.To<long>("UserId"),
                                    AdminName = reader.ToStringValue("AdminName"),
                                    Institute = reader.ToStringValue("Institute"),
                                    MajorId = reader.ToStringValue("MajorId"),
                                    IdentityId = reader.ToStringValue("IdentityId"),
                                    Content = reader.To<int>("Content"),
                                    Personalization = reader.To<int>("Personalization"),
                                    Design = reader.To<int>("Design"),                                    
                                    Functionality = reader.To<int>("Functionality"),
                                    Emirate=reader.ToStringValue("Emirate"),

                                });
                            }
                        }
                    }
                }

                this.Logger.LogInformation("Exiting from GetCXOProfilesAsync Method");

                return result;
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public async Task<IList<ChartModel>> GetChartData(ReportFilterModel filter)
        {
            this.Logger.LogInformation("Entering into GetChartData Method");

            IList<ChartModel> result = new List<ChartModel>();

            var paramStartDate = new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = filter.StartDate, IsNullable = true };
            var paramEndDate = new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = filter.EndDate, IsNullable = true };
            var paramOrganizationType = new SqlParameter("@OrganizationType", SqlDbType.Int) { Value = filter.OrganizationType, IsNullable = true };
            var paramPeriodTypeType = new SqlParameter("@PeriodType", SqlDbType.Int) { Value = (int?)filter.PeriodType, IsNullable = true };

            using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
            {
                using (var reader = await ExecuteReaderAsync(
                                connection,
                                CommandType.StoredProcedure,
                                "report.getChartData",
                                paramStartDate,
                                paramEndDate,
                                paramOrganizationType,
                                paramPeriodTypeType
                                ).ConfigureAwait(false))
                {
                    if (reader.HasRows)
                    {
                        while (await reader.ReadAsync().ConfigureAwait(false))
                        {
                            result.Add(new ChartModel
                            {
                                Period = reader.ToStringValue("Period"),
                                TotalEvents = reader.To<int>("TotalEvents"),
                                TotalLeaderships = reader.To<int>("TotalLeaderships"),
                                TotalLecturers = reader.To<int>("TotalLecturers"),
                                TotalPrivateCXO = reader.To<int>("TotalPrivateCXO"),
                                TotalPublicCXO = reader.To<int>("TotalPublicCXO"),
                                TotalRegistered = reader.To<int>("TotalRegistered"),
                                TotalSeminars = reader.To<int>("TotalSeminars"),
                                TotalWorkshops = reader.To<int>("TotalWorkshops"),
                            });
                        }
                    }
                }
                return result;
            }
        }
    }
}
