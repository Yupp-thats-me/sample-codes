﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.CXO.Api.Datasource.Models;
using SJP.CXO.Api.Models;
using SJP.DataAccess;
using SJP.DataAccess.Extensions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Datasource.Services
{
    public class ProfileDataAccess : DataAccessBase, IProfileDataAccess
    {
        private readonly ILogger logger;
        protected ILogger Logger => logger;

        public ProfileDataAccess(ILogger<ProfileDataAccess> logger, IConfiguration configuration) : base(configuration)
        {
            this.logger = logger;
        }
        public async Task<Data_ProfileDetails> SaveProfile(Data_ProfileDetails data)
        {
            this.Logger.LogInformation("Entering into SaveProfile method in DataService");

            try
            {
                var paramReferenceId = new SqlParameter("@ReferenceId", SqlDbType.BigInt) { Value = data.Id, Direction = ParameterDirection.Output };
                var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = data.Id };
                var paramEntryTypeId = new SqlParameter("@EntryTypeId", SqlDbType.BigInt) { Value = (int)data.EntryType };
                var paramCXOId = new SqlParameter("@CXOId", SqlDbType.BigInt) { Value = data.CXOId };
                var paramCXOTypeId = new SqlParameter("@CXOTypeId ", SqlDbType.TinyInt) { Value = data.CXOTypeId };
                var paramindustryId = new SqlParameter("@IndustryId", SqlDbType.SmallInt) { Value = data.IndustryId, IsNullable = true };
                var paramdesignationId = new SqlParameter("@designationId", SqlDbType.SmallInt) { Value = data.DesignationId, IsNullable = true };
                var paramcompanyId = new SqlParameter("@CompanyId", SqlDbType.SmallInt) { Value = data.CompanyId, IsNullable = true };
                var paramcompanyZoneId = new SqlParameter("@CompanyZoneId", SqlDbType.SmallInt) { Value = data.CompanyZoneId, IsNullable = true };
                var paramOnlineProfile = new SqlParameter("@OnlineProfile", SqlDbType.NVarChar) { Value = data.OnlineProfile ?? "", IsNullable = true };
                var paramVideoTitle = new SqlParameter("@VideoTitle", SqlDbType.NVarChar) { Value = data.VideoTitle ?? "", IsNullable = true };
                var paramStatus = new SqlParameter("@Status", SqlDbType.TinyInt) { Value = data.Status };
                var paramProfileVideo = new SqlParameter("@ProfileVideo", SqlDbType.NVarChar) { Value = data.ProfileVideo ?? "", IsNullable = true };
                var paramCreatedBy = new SqlParameter("@CreatedBy", SqlDbType.NVarChar) { Value = data.CreatedBy };
                var paramUpdatedBy = new SqlParameter("@UpdatedBy", SqlDbType.NVarChar) { Value = data.UpdatedBy ?? "", };
                var paramBio = new SqlParameter("@Bio", SqlDbType.NVarChar) { Value = data.ShortBio ?? "", };
                
                this.Logger.LogInformation(string.Format(" Details received for CXOId: {0}, rowId:{1}", paramCXOId, paramId));

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();

                        await ExecuteNonQueryAsync(
                                connection,
                                transaction,
                                CommandType.StoredProcedure,
                                "dbo.SaveProfile",
                                paramReferenceId,
                                paramId,
                                paramCXOId,
                                paramCXOTypeId,
                                paramBio,
                                paramOnlineProfile,
                                paramVideoTitle,
                                paramStatus,
                                paramindustryId,
                                paramcompanyId,
                                paramcompanyZoneId,
                                paramdesignationId,
                                
                                //paramProfilePic,
                                paramProfileVideo,
                                paramEntryTypeId,
                                paramCreatedBy,
                                paramUpdatedBy
                                ).ConfigureAwait(false);

                        transaction.Commit();
                    }
                    catch (Exception e)
                    {
                        if (transaction != null)
                            transaction.Rollback();
                        throw;
                    }

                    data.Id = (long)paramReferenceId.Value;

                    this.Logger.LogInformation("Exiting from CXO SaveProfile method");

                    return data;
                }
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public async Task<IEnumerable<Data_ProfileDetails>> GetProfilesAsync(ProfileFilterModel filter)
        {
            this.Logger.LogInformation("Entering into GetProfilesAsync Method");

            var paramCXOId = new SqlParameter("@CXOId", SqlDbType.BigInt) { Value = filter.CXOId, IsNullable = true };
            var paramStatusList = new SqlParameter("@StatusList", SqlDbType.NVarChar) { Value = filter.Status, IsNullable = true };

            IList<Data_ProfileDetails> result = new List<Data_ProfileDetails>();

            using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
            {
                using (var reader = await ExecuteReaderAsync(
                                connection,
                                CommandType.StoredProcedure,
                                "GetProfileDetails",
                                paramCXOId,
                                paramStatusList
                                ).ConfigureAwait(false))
                {
                    if (reader.HasRows)
                    {
                        while (await reader.ReadAsync().ConfigureAwait(false))
                        {
                            result.Add(new Data_ProfileDetails
                            {
                                Id = reader.To<int>("Id"),
                                //EntryTypeId = reader.To<int>("EntryTypeId"),
                                ShortBio = reader.ToStringValue("Bio"),
                                OnlineProfile = reader.ToStringValue("OnlineProfile"),
                                VideoTitle = reader.ToStringValue("VideoTitle"),
                                Status = reader.To<int>("Status"),
                                ProfileVideo = reader.ToStringValue("ProfileVideo"),
                                CreatedDate = reader.To<DateTime>("CreatedDate"),
                                UpdatedDate = reader.To<DateTime>("UpdatedDate"),
                                UpdatedBy = reader.ToStringValue("UpdatedBy"),
                                CXOId = reader.To<long>("CXOId"),
                                CXOTypeId = reader.To<int>("CXOTypeId"),
                                CreatedBy = reader.ToStringValue("CreatedBy"),
                                IndustryId = reader.To<int>("IndustryId"),
                                CompanyId = reader.To<int>("CompanyId"),
                                CompanyZoneId = reader.To<int>("CompanyZoneId"),
                                DesignationId = reader.To<int>("DesignationId"),
                                Designation = reader.ToStringValue("Designations"),
                                Industry = reader.ToStringValue("Industrys"),
                                Company = reader.ToStringValue("Companys"),
                                CompanyZone = reader.ToStringValue("CompanyZones"),
                                Remarks = reader.ToStringValue("Remarks")
                            });
                        }
                    }
                }
            }

            this.Logger.LogInformation("Exiting from GetProfilesAsync Method");

            return result;
        }
        public async Task<IEnumerable<Data_ProfileDetails>> GetProfilesGridAsync()
        {
            this.Logger.LogInformation("Entering into GetProfilesAsync Method");

            IList<Data_ProfileDetails> result = new List<Data_ProfileDetails>();

            using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
            {
                using (var reader = await ExecuteReaderAsync(
                                connection,
                                CommandType.StoredProcedure,
                                "GetProfileGrid"
                                ).ConfigureAwait(false))
                {
                    if (reader.HasRows)
                    {
                        while (await reader.ReadAsync().ConfigureAwait(false))
                        {
                            result.Add(new Data_ProfileDetails
                            {
                                Id = reader.To<int>("Id"),
                                //EntryTypeId = reader.To<int>("EntryTypeId"),
                                Status = reader.To<int>("Status"),
                                CXOId = reader.To<long>("CXOId"),
                                CreatedDate = reader.To<DateTime>("CreatedDate"),
                                UpdatedDate = reader.To<DateTime>("UpdatedDate"),
                                UpdatedBy = reader.ToStringValue("UpdatedBy"),
                                CreatedBy = reader.ToStringValue("CreatedBy"),
                                CompanyId = reader.To<int>("CompanyId"),
                                CompanyZoneId = reader.To<int>("CompanyZoneId"),
                                DesignationId = reader.To<int>("DesignationId"),
                                Designation = reader.ToStringValue("Designations"),
                                Company = reader.ToStringValue("Companys"),
                                Remarks = reader.ToStringValue("Remarks")
                            });
                        }
                    }
                }
            }

            this.Logger.LogInformation("Exiting from GetProfilesAsync Method");

            return result;
        }

        public async Task<IEnumerable<Data_ElementDetails>> GetElementsAsync(int? ElementTypeId = null)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetElementsAsync Method");

                IList<Data_ElementDetails> result = new List<Data_ElementDetails>();

                var paramElementTypeId = new SqlParameter("@ElementTypeId", SqlDbType.NVarChar) { Value = ElementTypeId, IsNullable = true };

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                    connection,
                                    CommandType.StoredProcedure,
                                    "GetElements",
                                    paramElementTypeId
                                    ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                result.Add(new Data_ElementDetails
                                {
                                    ElementId = reader.To<int>("ElementId"),
                                    ElementTypeId = reader.To<int>("ElementTypeId"),
                                    ElementTypeName = reader.ToStringValue("ElementTypeName"),
                                    ElementValue = reader.ToStringValue("ElementValue"),
                                    ElementValueAr = reader.ToStringValue("ElementValueAr"),
                                });
                            }
                        }
                    }
                }

                this.Logger.LogInformation("Exiting from GetElementsAsync Method");

                return result;
            }
            catch (Exception es)
            {

                throw;
            }
        }

        public async Task<bool> UpdateProfileStatus(ApprovalModel model)
        {
            try
            {
                this.Logger.LogInformation("Entering into ApproveProfile Method");

                var paramProfileId = new SqlParameter("@ProfileId", SqlDbType.BigInt) { Value = model.Id };    // EventId
                var paramStatusId = new SqlParameter("@Status", SqlDbType.BigInt) { Value = model.Status };
                var paramRemarks = new SqlParameter("@Remarks", SqlDbType.NVarChar) { Value = model.Remarks, IsNullable = true };
                var paramUpdatedBy = new SqlParameter("@UpdatedBy", SqlDbType.NVarChar) { Value = model.UpdatedBy };

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "[ApproveProfile]",
                            paramProfileId,
                            paramStatusId,
                            paramRemarks,
                            paramUpdatedBy
                            ).ConfigureAwait(false);
                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from ApproveProfile Method");
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

    }
}
