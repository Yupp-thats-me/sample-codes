﻿using SJP.CXO.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Datasource.DataAccess
{
    public interface ICXODataAccess
    {
        public Task<IList<ElementModel>> GetElementsAsync(int? ElementTypeId = null);
    }
}
