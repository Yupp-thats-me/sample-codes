﻿using SJP.CXO.Api.Datasource.Models;
using SJP.CXO.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static SJP.CXO.Api.Models.EventModel;

namespace SJP.CXO.Api.Datasource.Services
{
    public interface IEventDataAccess
    {
        Task<Data_Event> SaveEvent(Data_Event data);

        Task<IEnumerable<Data_Event>> GetEventsAsync(FilterModel filter);

        Task<IEnumerable<Data_Event>> GetEventsGridAsync(FilterModel filter);

        Task<bool> DeleteEventAsync(long id);

        Task<bool> UpdateApproval(ApprovalModel model);

        Task<bool> UpdateView(long id, string UserId);
    }
}
