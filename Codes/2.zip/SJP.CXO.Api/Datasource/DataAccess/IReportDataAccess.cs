﻿using SJP.Core.Model;
using SJP.CXO.Api.Datasource.Models;
using SJP.CXO.Api.Models;
using SJP.CXO.Api.Models.Report;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Datasource.DataAccess
{
    public interface IReportDataAccess
    {
        public Task<IEnumerable<Data_Profiles>> GetCXOProfilesAsync(FilterModel filter);
        public Task<IEnumerable<EventReportModel>> GetEventDetails(FilterModel filter);
        public Task<IEnumerable<PublicationReportModel>> GetpublicationDetails(FilterModel filter);

        public Task<IEnumerable<EventModel>> GetCXOListing(FilterModel filter);

        public Task<IEnumerable<Feedback>> GetCXOFeedBack(FilterModel filter);
        public Task<IList<ChartModel>> GetChartData(ReportFilterModel filter);



    }
}
