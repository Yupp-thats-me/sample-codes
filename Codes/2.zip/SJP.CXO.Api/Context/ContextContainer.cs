﻿using Microsoft.AspNetCore.Http;
using SJP.Communication.Http;
using SJP.Core.Cache;
using SJP.Core.Utility;
using SJP.CXO.Api.Datasource.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Context
{
    public class ContextContainer : IContextContainer
    {
        public readonly ICacheHelper cacheHelper;
        public readonly IHttpCommunicator httpCommunicator;
        public readonly IFileUtility fileUtility;

        public ICXODataAccess DataAccess;
        public IFileUtility FileUtility;

        ICXODataAccess IContextContainer.DataAccess => this.DataAccess;
        IFileUtility IContextContainer.FileUtility => this.FileUtility;

        //  HttpContext IContextContainer.HttpContext { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public ContextContainer(ICacheHelper cacheHelper, ICXODataAccess dataAccess, IHttpCommunicator httpCommunicator, IFileUtility fileUtility)
        {
            this.cacheHelper = cacheHelper;
            this.httpCommunicator = httpCommunicator;
            this.FileUtility = fileUtility;
            this.DataAccess = dataAccess;
        }
    }
}
