﻿using Microsoft.AspNetCore.Http;
using SJP.Core.Utility;
using SJP.CXO.Api.Datasource.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Context
{
    public interface IContextContainer
    {
        public ICXODataAccess DataAccess { get; }
        public IFileUtility FileUtility { get; }
    }
}
