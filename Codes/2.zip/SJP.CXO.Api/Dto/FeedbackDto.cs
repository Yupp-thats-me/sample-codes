﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Models.Dto
{
    public class FeedbackDto
    {
        public long Id { get; set; }

        public long PublicationtypeID { get; set; }
        public long UserId { get; set; }

        //public int FeedbackType { get; set; }
        public int Content { get; set; }
        public int Design { get; set; }
        public int Personalization { get; set; }
        public int Functionality { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }

        public string? AdminName { get; set; }
        public string? Institute { get; set; }
        public string? MajorId { get; set; }
        public string? IdentityId { get; set; }
        public string HigherEducationId { get; set; }
        public long? SatisfiedContent { get; set; }
        public long? NotContent { get; set; }
        public long? SatisfiedPersonalization { get; set; }
        public long? NotPersonalization { get; set; }
        public long? SatisfiedDesign { get; set; }
        public long? NotDesign { get; set; }
        public long? SatisfiedFunctionality { get; set; }
        public long? NotFunctionality { get; set; }

        public string? Emirate { get; set; }

        public string? Name { get; set; }

    }
}
