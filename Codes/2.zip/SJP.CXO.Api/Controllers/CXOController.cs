﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SJP.Core.Api.Controllers;
using SJP.CXO.Api.Context;
using SJP.CXO.Api.Datasource.DataAccess;
using SJP.CXO.Api.Models;
using SJP.CXO.Api.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class CXOController : BaseApiController
    {
        protected IContextContainer context;

        private ICXODataAccess dataAccess;

        public CXOController(IContextContainer context, ILogger logger) : base(logger)
        {
            this.context = context;
            this.dataAccess = context.DataAccess;
        }

        protected async Task<IList<ElementModel>> GetElements(ElementType? ElementType)
        {
            try
            {
                var elements = await this.dataAccess.GetElementsAsync((int?)ElementType);

                return elements;
            }
            catch (Exception e)
            {
                return new List<ElementModel>();
            }
        }

        protected async Task<IList<ElementModel>> GetElements()
        {
            return await GetElements(null);
        }
    }
}
