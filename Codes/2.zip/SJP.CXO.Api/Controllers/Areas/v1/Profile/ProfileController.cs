﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SJP.Communication.Http;
using SJP.Core.Api.Controllers;
using SJP.Core.Api.Services;
using SJP.Core.Cache;
using SJP.Core.Composition;
using SJP.Core.Model;
using SJP.Core.Models;
using SJP.Core.Services;
using SJP.Core.Utility;
using SJP.CXO.Api.Context;
using SJP.CXO.Api.Models;
using SJP.CXO.Api.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Controllers.Areas.v1.Profile
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class ProfileController : CXOController
    {

        private readonly IProfileService profileService;
        private readonly string PROFILE_SUBDIRECTORY = "profile";
        private readonly UserManager userManager;

        public ProfileController(IContextContainer context, ILogger<ProfileController> logger, UserManager userManager, IProfileService profileService) : base(context, logger)
        {
            this.profileService = profileService;
            this.userManager = userManager;
        }
        /// <summary>
        /// to fetch the profile details of the  user
        /// </summary>
        /// <returns></returns>
        [AuthorizeByRole(Role.CXO)]
        [Route("my-profile")]
        [HttpGet]
        public async Task<IActionResult> GetMyProfile()
        {
            try
            {
                var userId = long.Parse(this.UserId);

                this.Logger.LogInformation("Retrieving CXO Profile for ID:" + userId);

                var data = await this.profileService.GetMyProfile(userId);

                if (data != null)
                {
                    data.ProfileVideoFileName = data.ProfileVideo;

                    data.ProfileVideo = context.FileUtility.GetThumbnailBase64String(PROFILE_SUBDIRECTORY, data.Id.ToString(), data.ProfileVideo);
                }
                else
                    data = new ProfileModel();

                var elements = await this.profileService.GetElements();

                var result = new { profile = data, elements = elements };

                return Success("", result);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetProfile Method" + e);

                return Error("");
            }
        }
        /// <summary>
        /// to fetch the profile details of the particular user
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>

        [Authorize]
        [Route("{id}")]
        [HttpGet]
        public async Task<IActionResult> GetProfile(long id)
        {
            try
            {
                this.Logger.LogInformation("Retrieving CXO Profile for ID:" + id);

                var data = await this.profileService.GetProfile(id);

                if (data != null)
                {
                    data.ProfileVideoFileName = data.ProfileVideo;

                    data.ProfileVideo = context.FileUtility.GetThumbnailBase64String(PROFILE_SUBDIRECTORY, data.Id.ToString(), data.ProfileVideo);
                }
                else
                    data = new ProfileModel();

                var elements = await this.profileService.GetElements();

                var result = new { profile = data, elements = elements };

                return Success("", result);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetProfile Method" + e);

                return Error("");
            }
        }
        /// <summary>
        /// to get the profile details of the cxos in the grid
        /// </summary>
        /// <returns></returns>

        [AuthorizeByRole(Role.CXO, Role.ContentApprover)]
        [Route("GetProfilesGrid")]
        [HttpGet]
        public async Task<IActionResult> GetProfilesGrid()
        {
            try
            {
                this.Logger.LogInformation("Retrieving All CXO Profiles...");

                var data = await this.profileService.GetProfileGrid();

                return Success("", data);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetProfilesGrid Method" + e);

                return Error("");
            }
        }
        /// <summary>
        /// to fetch the profile details of the cxos
        /// </summary>
        /// <returns></returns>
        [Route("GetProfiles")]
        [HttpGet]
        public async Task<IActionResult> GetProfiles()
        {
            try
            {
                this.Logger.LogInformation("Retrieving All CXO Profiles...");

                var filter = new ProfileFilterModel() { Status = ((int)Status.Approved).ToString() };

                var data = await this.profileService.GetProfiles(filter);

                var elements = await this.profileService.GetElements();

                var result = new { profile = data, elements = elements };

                return Success("", result);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetProfiles Method" + e);

                return Error("");
            }
        }
        /// <summary>
        /// to fetch the profiles based on the filter
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>

        [Route("GetFilteredProfiles")]
        [HttpGet]
        public async Task<IActionResult> GetFilteredProfiles(ProfileFilterModel filter)
        {
            try
            {
                this.Logger.LogInformation("Retrieving All CXO Profiles...");

                var data = await this.profileService.GetProfiles(filter);

                var filteredData = this.profileService.FilterProfiles(data, filter);

                return Success("", filteredData);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetFilteredProfiles Method" + e);

                return Error("");
            }
        }

        /// <summary>
        /// to save the profile  details of the cxos
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.CXO)]
        [HttpPost]
        public async Task<IActionResult> SaveProfile([FromForm] ProfileModel model)
        {
            try
            {
                this.Logger.LogInformation("Saving CXO Profile");

                var files = HttpContext.Request.Form.Files;

                model.ProfileVideo = context.FileUtility.GetFileNames(context.FileUtility.FileType_Videos, files);

                var data = await this.profileService.SaveProfile(model);

                context.FileUtility.Save(files, PROFILE_SUBDIRECTORY, data.Id.ToString()); // file is saved after DB changes to get the rowId.

                return Success("Success", data);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SaveProfile Method" + e);
                return Error("Failed to save");
            }
        }
        /// <summary>
        /// to update or edit the profile datas 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.CXO)]
        [HttpPut]
        public async Task<IActionResult> UpdateProfile([FromForm] ProfileModel model)
        {

            if (model.Id == 0 || model.Id == null)
            {
                return BadRequest("Invalid Bad request");
            }

            return await this.SaveProfile(model);
        }

        /// <summary>
        /// to fetch the profile element details
        /// </summary>
        /// <returns></returns>
        [Authorize]
        [Route("GetElements")]
        [HttpGet]
        public async Task<IActionResult> GetElement()
        {
            try
            {
                this.Logger.LogInformation("Retrieving Elements....");

                var elements = await this.GetElements();

                this.Logger.LogInformation("Exiting GetElements....");

                return Success("", elements);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetElements Method" + e);

                return Error("");
            }
        }
        /// <summary>
        /// to update or edit the profile status of the users
        /// </summary>
        /// <param name="approval"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.ContentApprover)]
        [Route("UpdateProfileStatus")]
        [HttpPost]

        public async Task<IActionResult> UpdateProfileStatus(ApprovalModel approval)
        {
            this.Logger.LogInformation("Executing UpdateProfileStatus method...");

            try
            {
                await this.profileService.UpdateProfileStatus(approval);

                return Success("");
            }
            catch (Exception e)
            {
                return Error("");
            }
        }
    }
}
