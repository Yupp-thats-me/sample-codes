﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SJP.Core.Composition;
using SJP.Core.Constants;
using SJP.Core.Model;
using SJP.Core.Models;
using SJP.CXO.Api.Context;
using SJP.CXO.Api.Models;
using SJP.CXO.Api.Services;
using SJP.DataAccess.Exceptions;
using System;
using System.Threading.Tasks;
using static SJP.CXO.Api.Models.EventModel;

namespace SJP.CXO.Api.Controllers.Areas.v1.Event
{
    [Route("api/v{version:apiVersion}/[controller]")]

    [ApiController]

    public class EventController : CXOController
    {
        private IEventService eventService;

        private readonly string EVENT_SUBDIRECTORY = "events";

        public EventController(IContextContainer context, ILogger<EventController> logger, IEventService eventService) : base(context, logger)
        {
            this.eventService = eventService;
        }
        /// <summary>
        /// to save the given event details 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.CXO)]
        [HttpPost]
        public async Task<IActionResult> SaveEvent([FromForm] EventModel model)
        {
            try
            {

                #region Bind Files
                var files = HttpContext.Request.Form.Files;
                try
                {


                    model.ImageName = this.context.FileUtility.GetFileNames(this.context.FileUtility.FileType_Images, files);
                    model.VideoName = this.context.FileUtility.GetFileNames(this.context.FileUtility.FileType_Videos, files);
                }
                catch (Exception e)
                {
                    // Do not throw/return any error here for smoother User experience. Just log it.
                    this.Logger.LogError(new Exception("Error Occured"), "Failed to save files" + e);
                }

                #endregion

                var savedData = await this.eventService.SaveEvent(model);

                this.context.FileUtility.Save(files, EVENT_SUBDIRECTORY, savedData.Id.ToString());

                return Success("");
            }
            catch (DuplicateDataException e)
            {
                return Error("", ErrorCode.Duplicate);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SaveEvent Method" + e);

                return Error("Failed to save", System.Net.HttpStatusCode.InternalServerError);
            }
        }
        /// <summary>
        /// to edit or update the event 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.CXO)]
        [HttpPut]
        public async Task<IActionResult> UpdateEvent([FromForm] EventModel model)
        {
            if (model.Id == 0 && model.Id == null)
            {
                return BadRequest("Invalid request");
            }

            return await this.SaveEvent(model);
        }
        /// <summary>
        /// to update the approval of events
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.ContentApprover)]
        [Route("approval")]
        [HttpPut]
        public async Task<IActionResult> UpdateApproval([FromBody] ApprovalModel model)
        {
            try
            {
                if (model.Id == 0)
                {
                    return BadRequest("Invalid request");
                }

                await this.eventService.UpdateApproval(model);

                return Success("");
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in UpdateApproval Method" + e);

                return Error("Failed to update approval status");
            }
        }
        /// <summary>
        /// to fetch the event datas
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Get([FromQuery] FilterModel filter = null)
        {
            try
            {
                filter.ExcludeExpired = true;
                filter.Status = ((int)Status.Approved).ToString();

                var data = await this.eventService.GetEvents(filter);

                #region Fetch files

                try
                {
                    foreach (var item in data)
                    {
                        item.ImageFile = this.context.FileUtility.GetThumbnailBase64String(EVENT_SUBDIRECTORY, item.Id.ToString(), item.ImageName);

                        item.VideoFile = this.context.FileUtility.GetThumbnailBase64String(EVENT_SUBDIRECTORY, item.Id.ToString(), item.VideoName);
                    }
                }
                catch (Exception e)
                {
                    // Do not throw/return any error here for smoother User experience. Just log it.
                    this.Logger.LogError(new Exception("Error Occured"), "Failed to fetch files" + e);
                }

                #endregion

                return Success(data);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetEventGrid Method" + e);

                return Error("Failed to retrieve events");
            }
        }
        /// <summary>
        /// to fetch the events data for the grid based on the filter
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.CXO)]
        [Route("grid")]
        [HttpGet]
        public async Task<IActionResult> GetEventsGrid([FromQuery] FilterModel filter)
        {
            try
            {
                var data = await this.eventService.GetEventGrid(filter);

                return Success(data);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetEventGrid Method" + e);

                return Error("Failed to retrieve data for grid");
            }
        }
        /// <summary>
        /// to fetch the approved events for the grid
        /// </summary>
        /// <returns></returns>

        [AuthorizeByRole(Role.ContentApprover)]
        [Route("approval-grid")]
        [HttpGet]
        public async Task<IActionResult> GetEventsApprovalGrid()
        {
            try
            {
                var filter = new FilterModel() { ExcludeExpired = true };

                var data = await this.eventService.GetEventGrid(filter);

                return Success(data);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetEventGrid Method" + e);

                return Error("Failed to retrieve data for approval-grid");
            }
        }

        /// <summary>
        /// to fetch the event data for the particular user
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Authorize]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetEventRow(long id)
        {
            try
            {
                var data = await this.eventService.GetEventRow(id);

                #region Fetch Files
                try
                {
                    data.ImageFile = this.context.FileUtility.GetThumbnailBase64String(EVENT_SUBDIRECTORY, data.Id.ToString(), data.ImageName);

                    data.VideoFile = this.context.FileUtility.GetThumbnailBase64String(EVENT_SUBDIRECTORY, data.Id.ToString(), data.VideoName);
                }
                catch (Exception e)
                {
                    // Do not throw/return any error here for smoother User experience. Just log it.
                    this.Logger.LogError(new Exception("Error Occured"), "Failed to load files" + e);
                }
                #endregion

                return Success(data);
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetEventGrid Method" + e);

                return Error("Failed to retrieve");
            }
        }

        /// <summary>
        /// to delete or remove the particular data from the list of events
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.CXO)]
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEvent(long id)
        {
            try
            {
                if (id == 0)
                {
                    return BadRequest("Invalid Data");
                }

                await this.eventService.DeleteEvent(id);

                #region Delete files

                try
                {
                    var data = await this.eventService.GetEventRow(id);

                    this.context.FileUtility.Delete(data.ImageName, EVENT_SUBDIRECTORY, data.Id.ToString());
                    this.context.FileUtility.Delete(data.VideoName, EVENT_SUBDIRECTORY, data.Id.ToString());
                }
                catch (Exception e)
                {
                    // Do not throw/return any error here for smoother User experience. Just log it.
                    this.Logger.LogError(new Exception("Error Occured"), "Failed to deltet files" + e);
                }

                #endregion

                return Success("Deleted successfully");
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in DeleteEvent Method" + Ex);

                return Error("Failed to Delete event");
            }
        }
        /// <summary>
        /// to update the view count based on the particulae user view
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>

        [HttpPut("update-view/{id}")]
        public async Task<IActionResult> UpdateView(long id)
        {
            try
            {
                await eventService.UpdateView(id, "test");

                return Success("");
            }
            catch (Exception e)
            {
                return Error("");
            }
        }
    }
}