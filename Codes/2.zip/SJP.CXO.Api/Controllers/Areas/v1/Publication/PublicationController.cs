﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SJP.Communication.Http;
using SJP.Core.Api.Controllers;
using SJP.Core.Cache;
using SJP.Core.Composition;
using SJP.Core.Constants;
using SJP.Core.Model;
using SJP.Core.Models;
using SJP.Core.Utility;
using SJP.CXO.Api.Context;
using SJP.CXO.Api.Models;
using SJP.CXO.Api.Models.Dto;
using SJP.CXO.Api.Services;
using SJP.DataAccess.Exceptions;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Controllers.Areas.v1.Publication
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [Authorize]


    public class PublicationController : CXOController
    {

        private readonly IPublicationService publicationService;

        private readonly string PUBLICATION_SUBDIRECTORY = "publication";


        public PublicationController(IContextContainer context, ILogger<PublicationController> logger, IPublicationService publicationService) : base(context, logger)
        {
            this.publicationService = publicationService;
        }
        /// <summary>
        /// to save the publication details of the cxos
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.CXO)]
        [HttpPost]
        public async Task<IActionResult> Save([FromForm] PublicationModel model)
        {
            try
            {
                this.Logger.LogInformation("Executing SavePublication method...");

                var files = HttpContext.Request.Form.Files;

                model.ImageFiles = this.context.FileUtility.GetFileNames(this.context.FileUtility.FileType_Images, files);
                model.VideoFiles = this.context.FileUtility.GetFileNames(this.context.FileUtility.FileType_Videos, files);
                model.DocumentFiles = this.context.FileUtility.GetFileNames(this.context.FileUtility.FileType_Documents, files);

                var savedData = await this.publicationService.SavePublication(model);

                this.context.FileUtility.Save(files, PUBLICATION_SUBDIRECTORY, model.Id.ToString()); //need to check document also pdf

                this.Logger.LogInformation("Exiting SavePublication method...");

                return Success("success");
            }
            catch (DuplicateDataException e)
            {
                return Error("", ErrorCode.Duplicate);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SavePublication Method" + ex);
                return Error("Failed to save");
            }
        }
        /// <summary>
        /// to fetch the publications data for the grid based on filter
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.CXO)]
        [Route("grid")]
        [HttpGet]
        public async Task<IActionResult> GetPublicationsGrid([FromQuery] FilterModel filter)
        {
            try
            {
                this.Logger.LogInformation("Executing GetApprovedPublicationData method...");

                var data = await this.publicationService.GetPublicationsGrid(filter);

                var industryList = await this.GetElements(ElementType.Industry);

                var result = new { data = data, industryList = industryList };

                return Success("", result);
            }
            catch (Exception e)
            {

                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetApprovedPublicationData Method" + e);
                return Error("Failed to get");
            }
        }
        /// <summary>
        /// to fetch the publications approval status in the grid
        /// </summary>
        /// <returns></returns>

        [AuthorizeByRole(Role.ContentApprover)]
        [Route("approval-grid")]
        [HttpGet]
        public async Task<IActionResult> GetPublicationsApprovalGrid()
        {
            try
            {
                var filter = new FilterModel { ExcludeExpired = true };

                this.Logger.LogInformation("Executing GetPublicationsApprovalGrid method...");

                var data = await this.publicationService.GetPublicationsGrid(filter);

                var industryList = await this.GetElements(ElementType.Industry);

                var result = new { data = data, industryList = industryList };

                return Success("", result);
            }
            catch (Exception e)
            {

                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetApprovedPublicationData Method" + e);
                return Error("Failed to get");
            }
        }
        /// <summary>
        /// to fetch the publication data based on the filter
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> GetPublicationData([FromQuery] FilterModel filter)
        {
            try
            {
                this.Logger.LogInformation("Executing GetPublicationData method...");

                var data = await this.publicationService.GetPublications(filter);

                foreach (var item in data)
                {
                    item.ImageName = item.ImageFiles;
                    item.ImageFiles = this.context.FileUtility.GetThumbnailBase64String(PUBLICATION_SUBDIRECTORY, item.Id.ToString(), item.ImageName);

                    item.DocumentName = item.DocumentFiles;
                    item.DocumentFiles = this.context.FileUtility.GetThumbnailBase64String(PUBLICATION_SUBDIRECTORY, item.Id.ToString(), item.DocumentName);

                    var videos = String.IsNullOrEmpty(item.VideoFiles) ? new List<string>() : item.VideoFiles.Split(new char[] { ',' }).ToList();

                    item.PublicationVideoList = videos.Select(fileName => new FileDataModel
                    {
                        FileName = fileName,
                        Data = this.context.FileUtility.GetThumbnailBase64String(PUBLICATION_SUBDIRECTORY, item.Id.ToString(), fileName) ?? ""
                    }).ToList();
                }

                var industryList = await this.GetElements(ElementType.Industry);

                var result = new { data = data, industryList = industryList };

                return Success("", result);
            }
            catch (Exception e)
            {

                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetPublicationData Method" + e);
                return Error("Failed to get");
            }
        }
        /// <summary>
        /// to fetch the users publication data based on the particular publicationtypeid
        /// </summary>
        /// <param name="publicationTypeId"></param>
        /// <returns></returns>

        [Authorize]
        [HttpGet("user-publications/{publicationTypeId}")]
        public async Task<IActionResult> GetUserPublicationData(int publicationTypeId)
        {
            try
            {
                this.Logger.LogInformation("Executing GetPublicationData method...");

                var filter = new FilterModel();
                filter.ExcludeExpired = true;
                filter.PublicationTypeId = publicationTypeId;
                filter.Status = ((int)Status.Approved).ToString();

                var data = await this.publicationService.GetPublications(filter);

                foreach (var item in data)
                {
                    item.ImageName = item.ImageFiles;
                    item.ImageFiles = this.context.FileUtility.GetThumbnailBase64String(PUBLICATION_SUBDIRECTORY, item.Id.ToString(), item.ImageName);

                    item.DocumentName = item.DocumentFiles;
                    item.DocumentFiles = this.context.FileUtility.GetThumbnailBase64String(PUBLICATION_SUBDIRECTORY, item.Id.ToString(), item.DocumentName);

                    var videos = String.IsNullOrEmpty(item.VideoFiles) ? new List<string>() : item.VideoFiles.Split(new char[] { ',' }).ToList();

                    item.PublicationVideoList = videos.Select(fileName => new FileDataModel
                    {
                        FileName = fileName,
                        Data = this.context.FileUtility.GetThumbnailBase64String(PUBLICATION_SUBDIRECTORY, item.Id.ToString(), fileName) ?? ""
                    }).ToList();
                }

                var industryList = await this.GetElements(ElementType.Industry);

                var result = new { data = data, industryList = industryList };

                return Success("", result);
            }
            catch (Exception e)
            {

                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetPublicationData Method" + e);
                return Error("Failed to get");
            }
        }
        /// <summary>
        /// to fetch the publication data of the particular cxo
        /// </summary>
        /// <param name="cxoId"></param>
        /// <returns></returns>
        [Authorize]
        [HttpGet("cxo-publications/{cxoId}")]
        public async Task<IActionResult> GetCXOPublicationData(int cxoId)
        {
            try
            {
                this.Logger.LogInformation("Executing GetPublicationData method...");

                var filter = new FilterModel();
                filter.ExcludeExpired = true;
                filter.CXOId = cxoId;
                filter.Status = ((int)Status.Approved).ToString();

                var data = await this.publicationService.GetPublications(filter);

                foreach (var item in data)
                {
                    item.ImageName = item.ImageFiles;
                    item.ImageFiles = this.context.FileUtility.GetThumbnailBase64String(PUBLICATION_SUBDIRECTORY, item.Id.ToString(), item.ImageName);

                    item.DocumentName = item.DocumentFiles;
                    item.DocumentFiles = this.context.FileUtility.GetThumbnailBase64String(PUBLICATION_SUBDIRECTORY, item.Id.ToString(), item.DocumentName);

                    var videos = String.IsNullOrEmpty(item.VideoFiles) ? new List<string>() : item.VideoFiles.Split(new char[] { ',' }).ToList();

                    item.PublicationVideoList = videos.Select(fileName => new FileDataModel
                    {
                        FileName = fileName,
                        Data = this.context.FileUtility.GetThumbnailBase64String(PUBLICATION_SUBDIRECTORY, item.Id.ToString(), fileName) ?? ""
                    }).ToList();
                }

                var industryList = await this.GetElements(ElementType.Industry);

                var result = new { data = data, industryList = industryList };

                return Success("", result);
            }
            catch (Exception e)
            {

                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetPublicationData Method" + e);
                return Error("Failed to get");
            }
        }

        /// <summary>
        /// to fetch the publication data row based on particular  user
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>

        [Authorize]
        [HttpGet("{id}")]

        public async Task<IActionResult> GetPublicationRow(long id)
        {
            try
            {
                var filter = new FilterModel() { Id = id };

                var data = await this.publicationService.GetPublications(filter);

                var row = data.FirstOrDefault();

                if (row != null)
                {
                    row.ImageName = row.ImageFiles;
                    row.ImageFiles = context.FileUtility.GetThumbnailBase64String(PUBLICATION_SUBDIRECTORY, row.Id.ToString(), row.ImageName);

                    row.DocumentName = row.DocumentFiles;
                    row.DocumentFiles = context.FileUtility.GetThumbnailBase64String(PUBLICATION_SUBDIRECTORY, row.Id.ToString(), row.DocumentName);

                    var videos = String.IsNullOrEmpty(row.VideoFiles) ? new List<string>() : row.VideoFiles.Split(new char[] { ',' }).ToList();

                    row.PublicationVideoList = videos.Select(fileName => new FileDataModel
                    {
                        FileName = fileName,
                        Data = this.context.FileUtility.GetThumbnailBase64String(PUBLICATION_SUBDIRECTORY, row.Id.ToString(), fileName) ?? ""
                    }).ToList();

                }

                return Success(row);
            }
            catch (Exception e)
            {

                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetPublicationRow Method" + e);
                return Error("Failed to retrieve");
            }
        }
        /// <summary>
        /// to delete the publications deatil of the particular user
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.CXO)]
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePublication(long id)
        {
            try
            {
                if (id == 0)
                {
                    return BadRequest("Invalid Data");
                }

                await this.publicationService.DeletePublication(id);

                return Success("Deleted successfully");
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in DeletePublication Method" + Ex);
                return Error("Failed to Delete Publication Details ");
            }
        }
        /// <summary>
        /// to update the approval status 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.ContentApprover)]
        [Route("approval")]
        [HttpPut]

        public async Task<IActionResult> UpdateApprovalStatus([FromBody] ApprovalModel model)
        {
            this.Logger.LogInformation("Executing UpdatePublicationStatus method...");

            try
            {
                await this.publicationService.UpdatePublicationStatus(model);

                return Success("");
            }
            catch (Exception e)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in UpdatePublicationStatus Method" + e);

                return Error("");
            }
        }
        /// <summary>
        /// to save the feedback details 
        /// </summary>
        /// <param name="feedback"></param>
        /// <returns></returns>
        [Authorize]
        [HttpPost("SaveFeedback")]
        public async Task<IActionResult> SaveFeedbackDetails(FeedbackDto feedback)
        {
            try
            {
                if (feedback.Id > 0)
                {
                    return BadRequest("Invalid Data");
                }
                await this.publicationService.SaveFeedbackDetails(feedback);
                var feedbackid = new { Id = feedback.Id };
                return Success("Data Saved Successfully", feedbackid);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SaveFeedbackDetails Method" + Ex);
                return Error("Failed toSaveFeedbackDetails ");
            }
        }
    }
}
