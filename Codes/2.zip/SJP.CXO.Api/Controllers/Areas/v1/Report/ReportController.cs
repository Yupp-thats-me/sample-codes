﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SJP.Core.Composition;
using SJP.Core.Models;
using SJP.CXO.Api.Context;
using SJP.CXO.Api.Models;
using SJP.CXO.Api.Models.Report;
using SJP.CXO.Api.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Controllers.Areas.v1.Report
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class ReportController : CXOController
    {
        private readonly IReportService reportService;

        public ReportController(IContextContainer context, ILogger<ReportController> logger, IReportService reportService) : base(context, logger)
        {
            this.reportService = reportService;
        }
        /// <summary>
        /// to fetch the profile based on the filter
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.SuperAdmin)]
        [Route("profiles")]
        [HttpGet]
        public async Task<IActionResult> GetProfiles([FromQuery] FilterModel filter)
            {
            try
            {
                this.Logger.LogInformation("Executing GetProfiles method...");

                var data = await this.reportService.GetCXOProfiles(filter);

                return Success("", data);
            }
            catch (Exception e)
            {

                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetProfiles Method" + e);
                return Error("Failed to get");
            }
        }

        /// <summary>
        /// to fetch the event details based on the filter
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>
        
        [AuthorizeByRole(Role.SuperAdmin)]
        [Route("viewCount")]
        [HttpGet]
        public async Task<IActionResult> GetEventDetails([FromQuery] FilterModel filter)
        {
            try
            {
                this.Logger.LogInformation("Executing GetEventDetails method...");

                dynamic data;
                if (filter.PostType==5)
                {
                    data = await this.reportService.GetEventDetails(filter);
                }
               else
                {
                    data = await this.reportService.GetpublicationDetails(filter);
                }

               

                return Success("", data);
            }
            catch (Exception e)
            {

                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetEventDetails Method" + e);
                return Error("Failed to get");
            }
        }
        /// <summary>
        /// to fetch the cxo user list in the grid based on the filter 
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.SuperAdmin)]
        [Route("listing")]
        [HttpGet]
        public async Task<IActionResult> GetCXOListing([FromQuery] FilterModel filter)
        {
            try
            {
                this.Logger.LogInformation("Executing GetProfiles method...");

                var data = await this.reportService.GetCXOListing(filter);

                return Success("", data);
            }
            catch (Exception e)
            {

                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetProfiles Method" + e);
                return Error("Failed to get");
            }
        }
        /// <summary>
        /// to fetch the feedback given based on filter
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.SuperAdmin)]
        [Route("feedback")]
        [HttpGet]
        public async Task<IActionResult> GetCXOFeedback([FromQuery] FilterModel filter)
        {
            try
            {
                this.Logger.LogInformation("Executing GetProfiles method...");

                var data = await this.reportService.GetCXOFeedBack(filter);

                return Success("", data);
            }
            catch (Exception e)
            {

                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetProfiles Method" + e);
                return Error("Failed to get");
            }
        }
        /// <summary>
        /// to fetch the data for the chart based on filter
        /// </summary>
        /// <param name="filter"></param>
        /// <returns></returns>

       // [AuthorizeByRole(Role.SuperAdmin)]
        [Route("chart")]
        [HttpGet]
        public async Task<IActionResult> GetChartData([FromQuery] ReportFilterModel filter)
        {
            try
            {
                this.Logger.LogInformation("Executing GetChartData method...");

                var data = await this.reportService.GetChartData(filter);

                return Success("", data);
            }
            catch (Exception e)
            {

                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetChartData Method" + e);
                return Error("Failed to get");
            }
        }
    }
}
