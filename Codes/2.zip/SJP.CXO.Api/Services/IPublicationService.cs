﻿using SJP.CXO.Api.Models;
using SJP.CXO.Api.Models.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Services
{
    public interface IPublicationService
    {
        Task<PublicationModel> SavePublication(PublicationModel data);

        Task<List<PublicationModel>> GetPublications(FilterModel filter);

        Task<IEnumerable<PublicationModel>> GetPublicationsGrid(FilterModel filter);

        Task<bool> DeletePublication(long id);

        Task<bool> UpdatePublicationStatus(ApprovalModel model);

        Task<FeedbackDto> SaveFeedbackDetails(FeedbackDto feedback);

    }
}
