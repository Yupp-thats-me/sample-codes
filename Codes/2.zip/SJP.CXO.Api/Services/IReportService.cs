﻿using SJP.Core.Model;
using SJP.CXO.Api.Models;
using SJP.CXO.Api.Models.Report;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Services
{
    public interface IReportService
    {
        public Task<IEnumerable<CXOProfileModel>> GetCXOProfiles(FilterModel filter);

        public Task<IEnumerable<PublicationReportModel>> GetpublicationDetails(FilterModel filter);

        public Task<IEnumerable<EventReportModel>> GetEventDetails(FilterModel filter);

        public Task<IEnumerable<EventModel>> GetCXOListing(FilterModel filter);

        public Task<IEnumerable<Feedback>> GetCXOFeedBack(FilterModel filter);
        public Task<IList<ChartModel>> GetChartData(ReportFilterModel filter);
    }
}