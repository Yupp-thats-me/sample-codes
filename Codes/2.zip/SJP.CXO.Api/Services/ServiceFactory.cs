﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Services
{
    public class ServiceFactory : IServiceFactory
    {
        private readonly IEventService eventService;
        private readonly IProfileService profileService;

        public ServiceFactory(IEventService eventService, IProfileService profileService)
        {
            this.eventService = eventService;
            this.profileService = profileService;
        }

        public IServiceFactory GetService<IServiceFactory>()
        {
            throw new NotImplementedException();
        }

        public void Init()
        {

        }

        Task<IServiceFactory> IServiceFactory.GetService<IServiceFactory>()
        {
            throw new NotImplementedException();
        }

        public IEventService EventService
        {
            get
            {
                return this.eventService;
            }
        }

        //public IServiceFactory GetService<IServiceFactory>()
        //{
        //    switch (typeof(IServiceFactory))
        //    {
        //        case (typeof(IEventService)):return this.eventService

        //    }

        //}
    }
}
