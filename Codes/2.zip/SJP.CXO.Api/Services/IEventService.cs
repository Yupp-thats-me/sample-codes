﻿using SJP.CXO.Api.Datasource.Models;
using SJP.CXO.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static SJP.CXO.Api.Models.EventModel;

namespace SJP.CXO.Api.Services
{
    public interface IEventService
    {
        /// <summary>
        /// Save an event.
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        Task<EventModel> SaveEvent(EventModel data);
        Task<bool> UpdateApproval(ApprovalModel model);


        /// <summary>
        /// Gets all the events.
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        Task<List<EventModel>> GetEvents(FilterModel filter);

        Task<IEnumerable<EventModel>> GetEventGrid(FilterModel filter);

        Task<EventModel> GetEventRow(long id);

        Task<bool> DeleteEvent(long id);

       // public
            Task<bool> UpdateView(long id, string UserId);
    }
}
