﻿using SJP.CXO.Api.Datasource.Models;
using SJP.CXO.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Services
{
    public interface IProfileService
    {
        Task<ProfileModel> SaveProfile(ProfileModel model);

        //Task<ProfileModel> GetProfile(long id);

        Task<List<ProfileModel>> GetProfiles(ProfileFilterModel filter); // Expensive and need to be called only when all data required.

        Task<IEnumerable<ProfileModel>> GetProfileGrid();

        Task<ProfileModel> GetProfile(long CXOId);

        Task<ProfileModel> GetMyProfile(long CXOId);


        Task<bool> UpdateProfileStatus(ApprovalModel model);


        IEnumerable<ProfileModel> FilterProfiles(IEnumerable<ProfileModel> data, ProfileFilterModel filter);


        Task<IEnumerable<ElementModel>> GetElements();
    }
}
