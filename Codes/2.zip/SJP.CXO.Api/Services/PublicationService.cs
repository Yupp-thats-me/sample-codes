﻿using Microsoft.Extensions.Logging;
using SJP.CXO.Api.Datasource.DataAccess;
using SJP.CXO.Api.Datasource.Models;
using SJP.CXO.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SJP.CXO.Api.Models.Dto;

namespace SJP.CXO.Api.Services
{
    public class PublicationService : IPublicationService
    {
        private readonly IPublicationDataAccess dataAccess;

        private readonly ILogger logger;
        protected ILogger Logger => logger;

        public PublicationService(IPublicationDataAccess dataAccess, ILogger<PublicationService> logger)
        {
            this.dataAccess = dataAccess;
            this.logger = logger;
        }

        public virtual async Task<PublicationModel> SavePublication(PublicationModel model)
        {
            var data = new Data_Publication()
            {
                Id = model.Id ?? 0,
                CXOId=model.CXOId,
                IndustryId=model.IndustryId,
                ImageFiles = model.ImageFiles,
                PostedDate = model.PostedDate,
                TitleEn = model.TitleEn,
                TitleAr = model.TitleAr,
                AuthorEn = model.AuthorEn,
                AuthorAr = model.AuthorAr,
                AbstractEn = model.AbstractEn,
                AbstractAr = model.AbstractAr,
                VideoTitle = model.VideoTitle,
                ExpiryDate = model.ExpiryDate,
                DocumentFiles = model.DocumentFiles,
                Status = (int)ApprovalStatus.Pending,
                Active = model.Active,
                PublicationTypeId = model.PublicationTypeId,
                VideoFiles = model.VideoFiles,
                EntryType = model.EntryType,
                CreatedBy = model.CreatedBy,
                UpdatedBy = model.UpdatedBy
            };

            var dataSaved = await this.dataAccess.SavePublication(data);

            model.Id = dataSaved.Id;

            return model;
        }



        public virtual async Task<List<PublicationModel>> GetPublications(FilterModel filter)
        {

            try
            {
                this.Logger.LogInformation("Entering into GetPublications Method");

                var data = await this.dataAccess.GetPublicationDataAsync(filter);

                var result = data.Select(CreateModel());

                return result.ToList();
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Exiting from GetPublications Method", ex);
                throw;
            }
        }

        public virtual async Task<IEnumerable<PublicationModel>> GetPublicationsGrid(FilterModel filter)
        {
            var data = await this.dataAccess.GetPublicationsGridAsync(filter);

            var result = data.Select(CreateModel());

            return result;
        }


        public virtual async Task<bool> DeletePublication(long id)
        {
            try
            {
                this.Logger.LogError("Entering into Publication Service DeletePublication Method");

                await this.dataAccess.DeletePublicationAsync(id);

                return true;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Exiting from Document Service DeleteDocumentData Method", ex);
                throw;
            }


        }

        private static Func<Data_Publication, PublicationModel> CreateModel()
        {
            return a => new PublicationModel
            {

                AbstractAr = a.AbstractAr,
                AbstractEn = a.AbstractEn,
                AuthorAr = a.AuthorAr,
                AuthorEn = a.AuthorEn,
                DocumentFiles = a.DocumentFiles,
                PublicationTypeId = a.PublicationTypeId,
                IndustryId =a.IndustryId,
                ImageFiles = a.ImageFiles,
                ExpiryDate = a.ExpiryDate,
                Id = a.Id,
                //UserId =,
                VideoFiles = a.VideoFiles,
                VideoTitle = a.VideoTitle,
                TitleAr = a.TitleAr,
                TitleEn = a.TitleEn,
                PostedDate = a.PostedDate,
                UpdatedBy = a.UpdatedBy,
                Status = (ApprovalStatus)a.Status,
                Active =a.Active,
                ApproverId = a.ApproverId,
                PublicationTypeName =a.PublicationTypeName,
                IndustryName=a.IndustryName,
                Remarks = a.Remarks

            };
        }

        public virtual async Task<bool> UpdatePublicationStatus(ApprovalModel model)
        {
            try
            {
                this.logger.LogError("In ApprovePublication method");

                var data = await this.dataAccess.UpdatePublicationStatus(model);

                return true;

            }
            catch (Exception e)
            {
                this.logger.LogError("Exiting ApproveEvent method", e);
                return false;
            }
        }

        public virtual async Task<IEnumerable<SeminarModel>> GetSeminar()
        {
            try
            {
                var data = await this.dataAccess.GetSeminarAsync();

                return data.Select(a => new SeminarModel
                {
                    PublicationTypeId = a.PublicationTypeId,
                    SeminarTypeName = a.SeminarTypeName,
                });
            }
            catch (Exception e)
            {
                this.logger.LogError("Exiting GetSeminar method", e);
                throw;
            }
        }
        public async Task<FeedbackDto> SaveFeedbackDetails(FeedbackDto feedback)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveFeedbackDetails ");

                var saveFeedback = new Feedback
                {
                    Id = feedback.Id,
                    PublicationtypeID = feedback.PublicationtypeID,
                    UserId = feedback.UserId,
                    //FeedbackType = feedback.FeedbackType,
                    Content = feedback.Content,
                    Design = feedback.Design,
                    Personalization = feedback.Personalization,
                    Functionality = feedback.Functionality,
                    CreatedBy = feedback.CreatedBy
                };

                var dataSaved = await this.dataAccess.SaveFeedbackDetails(saveFeedback);
                feedback.Id = dataSaved.Id;
                this.Logger.LogInformation("Exiting from SaveFeedbackDetails");
                return feedback;

            }
            catch (Exception Ex)
            {
                this.Logger.LogInformation("Error Occured in SaveFeedbackDetails" + Ex);
                throw Ex;
            }
        }

    }

}
