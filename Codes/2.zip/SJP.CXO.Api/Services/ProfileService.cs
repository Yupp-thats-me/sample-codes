﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Core.Api.Services;
using SJP.Core.Services;
using SJP.CXO.Api.Datasource.Models;
using SJP.CXO.Api.Datasource.Services;
using SJP.CXO.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Services
{
    public class ProfileService : ServiceBase, IProfileService
    {
        private readonly IProfileDataAccess dataAccess;

        private readonly ILogger logger;
        protected ILogger Logger => logger;

        private readonly UserManager userManager;

        public ProfileService(IProfileDataAccess dataService, ILogger<ProfileService> logger, IConfiguration config, UserManager userManager) : base(config)
        {
            this.dataAccess = dataService;
            this.logger = logger;
            this.userManager = userManager;
        }
        public virtual async Task<ProfileModel> SaveProfile(ProfileModel model)
        {
            var table = new Data_ProfileDetails()
            {
                Id = model.Id ?? 0,
                CXOId = model.CXOId,
                CXOTypeId = model.CXOTypeId,
                OnlineProfile = model.OnlineProfile,
                VideoTitle = model.VideoTitle,
                Status = (int)ApprovalStatus.Pending,
                ProfileVideo = model.ProfileVideo,
                CreatedBy = model.CreatedBy,
                UpdatedBy = model.UpdatedBy,
                IndustryId = model.IndustryId,
                CompanyId = model.CompanyId,
                CompanyZoneId = model.CompanyZoneId,
                DesignationId = model.DesignationId,
                EntryType = model.EntryType,
                ShortBio = model.ShortBio,
            };

            var dataSaved = await this.dataAccess.SaveProfile(table);

            model.Id = dataSaved.Id;

            return model;
        }
        public virtual async Task<List<ProfileModel>> GetProfiles(ProfileFilterModel filter)
        {
            this.logger.LogError("Entering into GetProfiles Method");

            var list = new List<ProfileModel>();

            var personalDetailsAsync = await userManager.GetUsersAsync(Core.Models.Role.CXO);

            //temp. remove it.
            var personalData = personalDetailsAsync.Where(a => a.RequestedRole == Core.Models.Role.CXO).ToDictionary(a => a.UserId);

            var data = await this.dataAccess.GetProfilesAsync(filter);

            var result = data.Select(a => new ProfileModel
            {
                CXOId = a.CXOId,
                FirstName = personalData[a.CXOId].FirstName,
                Phone = personalData[a.CXOId].Phone,
                LastName = personalData[a.CXOId].LastName,
                EmailId = personalData[a.CXOId].EmailId,
                ProfilePic = personalData[a.CXOId].ProfilePic,
                DOB = personalData[a.CXOId].DOB,
                Id = a.Id,
                OnlineProfile = a.OnlineProfile,
                ProfileVideo = a.ProfileVideo,
                VideoTitle = a.VideoTitle,
                Status = a.Status,
                CreatedBy = a.CreatedBy,
                UpdatedBy = a.UpdatedBy,
                IndustryId = a.IndustryId,
                CompanyId = a.CompanyId,
                CompanyZoneId = a.CompanyZoneId,
                DesignationId = a.DesignationId,
                CXOTypeId = a.CXOTypeId,
                Company = a.Company,
                Industry = a.Industry,
                Designation = a.Designation,
                CompanyZone = a.CompanyZone,

            }).ToList();

            this.logger.LogError("Exiting from GetProfiles Method");

            return result;
        }

        public virtual async Task<IEnumerable<ProfileModel>> GetProfileGrid()
        {
            var personalDetailsAsync = await userManager.GetUsersAsync(Core.Models.Role.CXO);

            //temp. remove it.
            var personalData = personalDetailsAsync.Where(a => a.RequestedRole == Core.Models.Role.CXO).ToDictionary(a => a.UserId);


            var data = await this.dataAccess.GetProfilesGridAsync();

            var result = data.Select(a => new ProfileModel
            {
                CXOId = a.CXOId,
                FirstName = personalData[a.CXOId].FirstName,
                Phone = personalData[a.CXOId].Phone,
                LastName = personalData[a.CXOId].LastName,
                Id = a.Id,
                OnlineProfile = a.OnlineProfile,
                ProfileVideo = a.ProfileVideo,
                VideoTitle = a.VideoTitle,
                CreatedBy = a.CreatedBy,
                UpdatedBy = a.UpdatedBy,
                IndustryId = a.IndustryId,
                CompanyId = a.CompanyId,
                CompanyZoneId = a.CompanyZoneId,
                DesignationId = a.DesignationId,
                CXOTypeId = a.CXOTypeId,
                Company = a.Company,
                Industry = a.Industry,
                Designation = a.Designation,
                CompanyZone = a.CompanyZone,
                Status = a.Status,
                Remarks = a.Remarks
            });

            this.logger.LogInformation("Exiting into GetProfileGrid Method");

            return result;
        }

        public override void Dispose()
        {
            //  throw new NotImplementedException();
        }

        public virtual async Task<ProfileModel> GetMyProfile(long CXOId)
        {
            try
            {
                var filter = new ProfileFilterModel() { CXOId = CXOId };
                var data = await this.dataAccess.GetProfilesAsync(filter);

                if (data == null)
                    return new ProfileModel();

                var profile = data.Select(a => new ProfileModel
                {
                    Id = a.Id,
                    OnlineProfile = a.OnlineProfile,
                    ShortBio = a.ShortBio,
                    CXOId = a.CXOId,
                    CompanyId = a.CompanyId,
                    CompanyZoneId = a.CompanyZoneId,
                    DesignationId = a.DesignationId,
                    IndustryId = a.IndustryId,
                    ProfileVideo = a.ProfileVideo,
                    VideoTitle = a.VideoTitle,
                    CreatedBy = a.CreatedBy,
                    UpdatedBy = a.UpdatedBy,
                    CXOTypeId = a.CXOTypeId,
                    Company = a.Company,
                    Industry = a.Industry,
                    Designation = a.Designation,
                    CompanyZone = a.CompanyZone,
                    Status = a.Status,
                    Remarks = a.Remarks

                }).FirstOrDefault();

                return profile;
            }
            catch (Exception e)
            {
                this.Logger.LogError("Exiting from GetProfile Method", e);
                throw;
            }
        }

        public virtual IEnumerable<ProfileModel> FilterProfiles(IEnumerable<ProfileModel> data, ProfileFilterModel filter)
        {
            return data.Where(a =>
                 (
                     filter.IndustryId == null || ((int?)a.IndustryId == filter.IndustryId))
                     && (filter.DesignationId == null || a.DesignationId == filter.DesignationId)
                     && (filter.CompanyId == null || a.CompanyId == filter.CompanyId)
                 );
        }

        public virtual async Task<IEnumerable<ElementModel>> GetElements()
        {
            try
            {
                var data = await this.dataAccess.GetElementsAsync();

                return data.Select(a => new ElementModel
                {
                    ElementId = a.ElementId,
                    ElementTypeId = a.ElementTypeId,
                    ElementTypeName = a.ElementTypeName,
                    ElementValue = a.ElementValue,
                    ElementValueAr = a.ElementValueAr
                });
            }
            catch (Exception e)
            {
                this.logger.LogError("Entering into GetProfileGrid Method", e);
                throw;
            }
        }

        public virtual async Task<bool> UpdateProfileStatus(ApprovalModel model)
        {
            try
            {
                this.logger.LogInformation("In ApproveProfile method");

                var data = await this.dataAccess.UpdateProfileStatus(model);

                this.logger.LogInformation("Exiting ApproveProfile method");

                return true;

            }
            catch (Exception e)
            {
                return false;
            }
        }

        public async Task<ProfileModel> GetProfile(long CXOId)
        {
            try
            {
                var filter = new ProfileFilterModel() { CXOId = CXOId };
                var data = await this.dataAccess.GetProfilesAsync(filter);

                if (data == null)
                    return new ProfileModel();

                var personalDetailsAsync = await userManager.GetPersonalDetailsAsync(CXOId);

                var profile = data.Select(a => new ProfileModel
                {
                    Id = a.Id,
                    OnlineProfile = a.OnlineProfile,
                    FirstName = personalDetailsAsync.FirstName,
                    LastName = personalDetailsAsync.LastName,
                    DOB = personalDetailsAsync.DOB,
                    Gender = personalDetailsAsync.Gender,
                    EmailId = personalDetailsAsync.EmailId,
                    Phone = personalDetailsAsync.Phone,
                    ProfilePic = personalDetailsAsync.ProfilePic,
                    ShortBio = a.ShortBio,
                    CXOId = a.CXOId,
                    CompanyId = a.CompanyId,
                    CompanyZoneId = a.CompanyZoneId,
                    DesignationId = a.DesignationId,
                    IndustryId = a.IndustryId,
                    ProfileVideo = a.ProfileVideo,
                    VideoTitle = a.VideoTitle,
                    CreatedBy = a.CreatedBy,
                    UpdatedBy = a.UpdatedBy,
                    CXOTypeId = a.CXOTypeId,
                    Company = a.Company,
                    Industry = a.Industry,
                    Designation = a.Designation,
                    CompanyZone = a.CompanyZone,
                    Status = a.Status,
                    Remarks = a.Remarks

                }).FirstOrDefault();

                return profile;
            }
            catch (Exception e)
            {
                this.Logger.LogError("Exiting from GetProfile Method", e);
                throw;
            }
        }
    }
}