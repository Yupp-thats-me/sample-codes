﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Core.Model;
using SJP.Core.Services;
using SJP.CXO.Api.Datasource.DataAccess;
using SJP.CXO.Api.Models;
using SJP.CXO.Api.Models.Report;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Services
{
    public class ReportService : ServiceBase, IReportService
    {
        private readonly IReportDataAccess dataAccess;

        private readonly ILogger logger;
        protected ILogger Logger => logger;


        public ReportService(IReportDataAccess dataAccess, ILogger<ReportService> logger, IConfiguration config) : base(config)
        {
            this.dataAccess = dataAccess;
            this.logger = logger;
        }
        public override void Dispose()
        {
            // throw new NotImplementedException();
        }

        public async Task<IEnumerable<CXOProfileModel>> GetCXOProfiles(FilterModel filter)
        {
            try
            {
                var data = await this.dataAccess.GetCXOProfilesAsync(filter);

                var result = data.Select(a => new CXOProfileModel
                {
                    Designation = a.Designation,
                    EmirateEn = a.EmirateEn,
                    EmirateAr = a.EmirateAr,
                    Email = a.Email,
                    Name = a.Name,
                    //LastName = a.LastName,
                    OnlineProfile = a.OnlineProfile,
                    OrganizationName = a.OrganizationName,
                    ShortBio = a.ShortBio,
                    TotalCXOPublic = a.TotalCXOPublic,
                    TotalCXOPrivate = a.TotalCXOPrivate,
                    TotalCXO = a.TotalCXO,
                    Industry = a.Industry,
                    OrganizationTypeCXO = a.OrganizationTypeCXO,
                });

                return result;
            }
            catch (Exception e)
            {

                throw;
            }
        }

        //public Task<IEnumerable<CXOProfileModel>> GetProfileSummary(FilterModel filter)
        //{
        //    try
        //    {

        //    }
        //    catch (Exception e)
        //    {
        //        throw;
        //    }
        //}

        public Task<IEnumerable<CXOProfileModel>> GetProfileSummary(FilterModel filter)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<EventReportModel>> GetEventDetails(FilterModel filter)
        {
            try
            {
                var data = await this.dataAccess.GetEventDetails(filter);
                var result = data.Select(a => new EventReportModel
                {
                    PostedBy = a.PostedBy,
                    Title = a.Title,
                    PostedDate = a.PostedDate,
                    Industry = a.Industry,
                    ExpiryDate = a.ExpiryDate,
                    Venue = a.Venue,
                    URL =a.URL,
                    TotalViews=a.TotalViews,
                    StudentViews=a.StudentViews,
                    TotalEvent = a.TotalEvent,
                    TOTALPUBLICATION= a.TOTALPUBLICATION,
                    PostTitle=a.PostTitle,
                    Totalseminars=a.Totalseminars,  

                });

                return result;
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public async Task<IEnumerable<PublicationReportModel>> GetpublicationDetails(FilterModel filter)
        {
            try
            {
                var data = await this.dataAccess.GetpublicationDetails(filter);
                var result = data.Select(a => new PublicationReportModel
                {   
                    PostedBy = a.PostedBy,
                    Title = a.Title,
                    PostedDate = a.PostedDate,
                    Industry = a.Industry,
                    ExpiryDate = a.ExpiryDate,
                    Authors = a.Authors,
                    TotalViews = a.TotalViews,
                    StudentViews = a.StudentViews,
                    TotalEvent = a.TotalEvent,
                    TOTALPUBLICATION = a.TOTALPUBLICATION,
                    PostTitle = a.PostTitle,
                });

                return result;
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public async Task<IEnumerable<EventModel>> GetCXOListing(FilterModel filter)
        {
            try
            {
                var data = await this.dataAccess.GetCXOListing(filter);

                var result = data.Select(a => new EventModel
                {
                    AdminName = a.AdminName,
                    TotalCXOPosted = a.TotalCXOPosted,
                    TotalCXOPending = a.TotalCXOPending,
                    TotalCXOApproved = a.TotalCXOApproved,
                    TotalCXORejected = a.TotalCXORejected,
                });

                return result;
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public async Task<IEnumerable<Feedback>> GetCXOFeedBack(FilterModel filter)
        {
            try
            {
                var data = await this.dataAccess.GetCXOFeedBack(filter);

                var result = data.Select(a => new Feedback
                {
                   // UserId = a.UserId,
                    AdminName = a.AdminName,
                    Content = a.Content,
                    Design = a.Design,
                    Personalization = a.Personalization,
                    Functionality = a.Functionality,
                    Institute = a.Institute,
                    MajorId = a.MajorId,    
                    Emirate = a.Emirate
                   

                });

                return result;
            }
            catch (Exception e)
            {

                throw;
            }
        }

        public async Task<IList<ChartModel>> GetChartData(ReportFilterModel filter)
        {
            try
            {
                var series = await this.dataAccess.GetChartData(filter);

                return series;
            }
            catch (Exception e)
            {

                throw;
            }
        }
    }
}
