﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Core.Services;
using SJP.CXO.Api.Datasource.Models;
using SJP.CXO.Api.Datasource.Services;
using SJP.CXO.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static SJP.CXO.Api.Models.EventModel;

namespace SJP.CXO.Api.Services
{
    public class EventService : ServiceBase, IEventService
    {
        private readonly IEventDataAccess dataAccess;

        private readonly ILogger logger;
        protected ILogger Logger => logger;

        public EventService(IEventDataAccess dataAccess, ILogger<EventService> logger, IConfiguration config) : base(config)
        {
            this.dataAccess = dataAccess;
            this.logger = logger;
        }

        public virtual async Task<EventModel> SaveEvent(EventModel model)
        {
            var data = new Data_Event()
            {
                Id = model.Id ?? 0,
                Title = model.Title,
                VideoTitle = model.VideoTitle,
                Description = model.Description,
                Url = model.Url,
                EventDate = model.EventDate,
                ExpiryDate = model.ExpiryDate,
                ImageName = model.ImageName,
                VideoName = model.VideoName,
                Venue = model.Venue,
                Status = (int)ApprovalStatus.Pending,
                //Status = (int)ApprovalStatus.Approved,
                Active = model.IsActive,
                CXOId = model.CXOId,
                EntryType = model.EntryType,
                CreatedBy = model.CreatedBy,
                UpdatedBy = model.UpdatedBy
            };

            var dataSaved = await this.dataAccess.SaveEvent(data);

            model.Id = dataSaved.Id;

            return model;
        }

        public virtual async Task<IEnumerable<EventModel>> GetEventGrid(FilterModel filter)
        {
            this.Logger.LogInformation("Entering into Event Service GetEventGrid Method");

            var data = await this.dataAccess.GetEventsGridAsync(filter);

            var result = data.Select(CreateModel());

            this.Logger.LogError("Exiting from Event Service GetEventGrid Method");

            return result;
        }

        public virtual async Task<List<EventModel>> GetEvents(FilterModel filter)
        {
            this.Logger.LogInformation("Entering into Event Service GetEvents Method");

            var data = await this.dataAccess.GetEventsAsync(filter);

            var result = data.Select(CreateModel()).ToList();

            this.Logger.LogError("Exiting from Event Service GetEvents Method");

            return result;
        }

        public virtual async Task<EventModel> GetEventRow(long id)
        {
            var filter = new FilterModel() { Id = id };

            var data = await this.dataAccess.GetEventsAsync(filter);

            var result = new EventModel();

            if (data != null)
            {
                result = data.Select(CreateModel()).FirstOrDefault();
            }

            return result;
        }

        public virtual async Task<bool> DeleteEvent(long id)
        {
            try
            {
                this.Logger.LogInformation("Entering into Event Service DeleteEvent Method");

                await this.dataAccess.DeleteEventAsync(id);

                return true;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Exiting from Document Service DeleteDocumentData Method", ex);
                throw;
            }
        }

        private static Func<Data_Event, EventModel> CreateModel()
        {
            return a => new EventModel
            {
                Id = a.Id,
                Description = a.Description,
                Url = a.Url,
                Title = a.Title,
                Venue = a.Venue,
                Status = (ApprovalStatus)a.Status,
                Remarks = a.Remarks,
                IsActive = a.Active,
                PostedBy = a.PostedBy,
                EventDate = a.EventDate,
                ExpiryDate = a.ExpiryDate,
                ImageName = a.ImageName,
                VideoName = a.VideoName,
                VideoTitle = a.VideoTitle,
                CXOId = a.CXOId,
                UpdatedBy = a.UpdatedBy
            };
        }

        public virtual async Task<bool> UpdateApproval(ApprovalModel model)
        {
            try
            {
                this.logger.LogInformation("In UpdateEventStatus method");

                var data = await this.dataAccess.UpdateApproval(model);

                this.logger.LogInformation("Exiting UpdateEventStatus method");

                return true;

            }
            catch (Exception e)
            {
                this.Logger.LogError("Exiting from Document Service UpdateEventStatus Method", e);
                return false;
            }
        }

        public override void Dispose()
        {
            //
        }

        public async Task<bool> UpdateView(long id, string UserId)
        {
            try
            {
                await this.dataAccess.UpdateView(id, UserId);

                return true;
            }

            catch (Exception e)
            {
                throw;

            }
            
        }
    }
}