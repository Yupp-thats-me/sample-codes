﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Models
{
    public class ProfileFilterModel
    {
        public long? CXOId { get; set; }
        public string Status { get; set; }
        public string Keyword { get; set; }   // For keyword search
        public int? IndustryId { get; set; }
        public int? DesignationId { get; set; }
        public int? CompanyId { get; set; }

        public long CXOTypeId { get; set; }
    }
}
