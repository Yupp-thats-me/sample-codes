﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Models
{
    public class EventModel
    {
        public long? Id { get; set; }

        public long CXOId { get; set; }

        public string Title { get; set; }

        public string PostedBy { get; set; }

        public string Url { get; set; }

        public string Description { get; set; }

        public string VideoName { get; set; }
        public string VideoFile { get; set; }

        public string ImageName { get; set; }

        public string ImageFile { get; set; }

        public string VideoTitle { get; set; }

        public string Venue { get; set; }

        public DateTime EventDate { get; set; }

        public DateTime? ExpiryDate { get; set; }

        public ApprovalStatus Status { get; set; }

        public bool IsActive { get; set; }

        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }

        public EntryType EntryType { get; set; }

        public string Remarks { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Author { get; set; }

        public DateTime CreatedDate { get; set; }

        public string Industry { get; set; }

        public long TotalCXOPosted { get; set; }

        public long TotalCXOPending { get; set; }

        public long TotalCXOApproved { get; set; }

        public long TotalCXORejected { get; set; }

        public int? OrganizationType { get; set; }
        public int? PostType { get; set; }
        public string AdminName { get; set; }
    }
}
