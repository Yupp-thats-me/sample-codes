﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Models
{
    public class PublicationModel
    {
        public long? Id { get; set; }

        public long CXOId { get; set; }
        public DateTime PostedDate { get; set; }
        public string TitleEn { get; set; }
        public string TitleAr { get; set; }
        public string AuthorEn { get; set; }
        public string AuthorAr { get; set; }
        public string AbstractEn { get; set; }
        public string AbstractAr { get; set; }
        public string VideoTitle { get; set; }
        public int PublicationTypeId { get; set; }

        public long IndustryId { get; set; }
       
        public DateTime? ExpiryDate { get; set; }
        public long? UserId { get; set; }

        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }

        public ApprovalStatus Status { get; set; }

        public long ApproverId { get; set; }

        public string VideoFiles { get; set; }

        public string ImageFiles { get; set; }

        public string DocumentFiles { get; set; }

        public string ImageName { get; set; }

        public string DocumentName { get; set; }
        public string PublicationTypeName { get; set; }

        public string IndustryName { get; set; }

        public EntryType EntryType { get; set; }

        public bool Active { get; set; }
        public List<FileDataModel> PublicationVideoList { get; set; }

        public string Remarks { get; set; }
    }
}
