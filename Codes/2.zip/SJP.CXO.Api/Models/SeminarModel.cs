﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Models
{
    public class SeminarModel
    {
        public int PublicationTypeId { get; set; }

        public string SeminarTypeName { get; set; }
    }
}
