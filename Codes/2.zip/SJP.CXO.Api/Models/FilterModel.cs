﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Models
{

    public class FilterModel
    {
        [FromQuery]
        public long? Id { get; set; }

        [FromQuery]
        public DateTime? FromDate { get; set; }

        [FromQuery]
        public DateTime? ToDate { get; set; }

        [FromQuery]
        public bool? ExcludeExpired { get; set; }

        [FromQuery]
        public long? CXOId { get; set; }

        [FromQuery]
        public string Status { get; set; }

        public int PublicationTypeId { get; set; }

        public string PublicationTypeIds { get; set; }

        public int? OrganizationType { get; set; }

        public int? PostType { get; set; }

        public int? CityId { get; set; }
        public int? EducationLevelId { get; set; }
        public int? EducationCategoryId { get; set; }
        public string? Institute { get; set; }
        public string? EMIRATE { get; set; }
        public string? MajorId { get; set; }
        public long? SatisfiedContent { get; set; }
        public long? NotContent { get; set; }
        public long? SatisfiedPersonalization { get; set; }
        public long? NotPersonalization { get; set; }
        public long? SatisfiedDesign { get; set; }
        public long? NotDesign { get; set; }
        public long? SatisfiedFunctionality { get; set; }
        public long? NotFunctionality { get; set; }

        public string? AdminName { get; set; }


    }
}
