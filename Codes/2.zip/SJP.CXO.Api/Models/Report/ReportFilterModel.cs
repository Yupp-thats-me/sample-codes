﻿using SJP.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Models.Report
{
    public class ReportFilterModel
    {
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        private PeriodType? _PeriodType;
        public PeriodType PeriodType
        {
            get
            {
                return _PeriodType ?? PeriodType.Monthly;
            }
            set
            {
                _PeriodType = value;
            }
        }

        public long OrganizationType { get; set; }

        public long Emirate { get; set; }
    }
}
