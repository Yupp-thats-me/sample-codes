﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Models.Report
{
    public class PublicationReportModel
    {

        public string PostedBy { get; set; }
        public string Title { get; set; }

        public DateTime PostedDate { get; set; }

        public string Industry { get; set; }

        public DateTime? ExpiryDate { get; set; }       

        public string Authors { get; set; }
        public long TotalViews { get; set; }

        public long StudentViews { get; set; }
        public string PostTitle { get; set; }
        public long TotalEvent { get; set; }
        public long TOTALPUBLICATION { get; set; }
      
    }
}
