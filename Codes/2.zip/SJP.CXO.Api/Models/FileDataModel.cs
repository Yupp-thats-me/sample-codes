﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Models
{
    public class FileDataModel
    {
        public string FileName { get; set; }
        public string Data { get; set; }
    }
}
