﻿using SJP.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Models
{
    public class ProfileModel
    {
        public long? Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public string ProfilePic { get; set; }

        public long CXOId { get; set; }

        public int CXOTypeId { get; set; }

        public string OnlineProfile { get; set; }

        public string ShortBio { get; set; }
        public string VideoTitle { get; set; }
        public int Status { get; set; }

        public string ProfileVideo { get; set; }

        public string ProfileVideoFileName { get; set; }

        public DateTime DOB { get; set; }

        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }

        public int? IndustryId { get; set; }

        public int? DesignationId { get; set; }

        public int? CompanyZoneId { get; set; }

        public EntryType EntryType { get; set; }

        public string Designation { get; set; }
        public string Industry { get; set; }
        public string Company { get; set; }
        public string CompanyZone { get; set; }

        public int? CompanyId { get; set; }
        public string Remarks { get; set; }
        public string EmailId { get; set; }
        public Gender Gender { get; set; }
        public string Phone { get; set; }
    }
}
