﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Models
{
    public class CXOProfileModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public string DisplayName
        {
            get
            {
                return FirstName + " " + LastName;
            }
        }

        public string Designation { get; set; }
        public string OrganizationName { get; set; }
        public string EmirateEn { get; set; }
        public string EmirateAr { get; set; }
        public string ShortBio { get; set; }
        public string Email { get; set; }
        public string OnlineProfile { get; set; }
        public long TotalCXOPublic { get; set; }
        public long TotalCXOPrivate { get; set; }
        public long TotalCXO { get; set; }

        public string OrganizationType { get; set; }


        public int OrganizationTypeCXO { get; set; }

        public string Industry { get; set; }

        public string Name { get; set; }
    }
}
