﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CXO.Api.Models
{
    public enum PublicationType
    {
        Publication=1,
        Seminar=2,
        }
}
