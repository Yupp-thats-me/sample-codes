﻿using SJP.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Sponsorship.Api.Model
{
    public class FeedbackDetails :DomainObject
    {
        public long StudentId { get; set; }
        public int FeedbackType { get; set; }
        public int Content { get; set; }
        public int Design { get; set; }
        public int Personalization { get; set; }
        public int Functionality { get; set; }
    }
}
