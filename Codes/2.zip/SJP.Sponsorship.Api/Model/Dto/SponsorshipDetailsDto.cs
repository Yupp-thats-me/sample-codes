﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Sponsorship.Api.Model.Dto
{
    public class SponsorshipDetailsDto
    {
        public long Id { get; set; }
        public string TitleEn { get; set; }
        public string TitleAr { get; set; }
        public string DescriptionEn { get; set; }
        public string DescriptionAr { get; set; }
        public string BenefitsEn { get; set; }
        public string BenefitsAr { get; set; }
        public int NationalityId { get; set; }
        public int HigherEducationId { get; set; }
        public int MajorId { get; set; }
        public int YearId { get; set; }
        public string EligibilityEn { get; set; }
        public string EligibilityAr { get; set; }
        public string HowToApplyEn { get; set; }
        public string HowToApplyAr { get; set; }
        public DateTime ExpiryDate { get; set; }
        public string UploadImage { get; set; }
        public int StatusId { get; set; }
        public int OnBehalfOf { get; set; }
        public int SponsorshipTypeId { get; set; }
        public string ApplicationUrl { get; set; }
        public string ContactEmail { get; set; }
        public bool Active { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string NationalityValue { get; set; }
        public string HigherEducationValue { get; set; }
        public string MajorValue { get; set; }
        public string YearValue { get; set; }
        public string SponsorshipType { get; set; }

    }
}
