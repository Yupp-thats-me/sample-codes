﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Sponsorship.Api.Model.Dto
{
    public class FeedbackDto
    {
        public long Id { get; set; }
        public long StudentId { get; set; }
        public int FeedbackType { get; set; }
        public int Content { get; set; }
        public int Design { get; set; }
        public int Personalization { get; set; }
        public int Functionality { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
