﻿using Microsoft.AspNetCore.Mvc;
using SJP.Communication.Http;
using SJP.Core.Api.Controllers;
using SJP.Core.Cache;
using SJP.Sponsorship.Api.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace SJP.Sponsorship.Api.Controllers.Areas.v1.SponsorshipDropdown
{
    [Route("v{version:apiVersion}/[controller]")]
    [ApiController]
    public class SponsorshipDropdownController : BaseApiController
    {
        private readonly ISponsorshipDropdownService sponsorshipDropdownService;
        private readonly ICacheHelper cacheHelper;
        private readonly IHttpCommunicator httpCommunicator;


       public SponsorshipDropdownController(ILogger<SponsorshipDropdownController> logger,ICacheHelper cacheHelper,
           ISponsorshipDropdownService sponsorshipDropdownService,IHttpCommunicator httpCommunicator) : base(logger)
        {
            this.sponsorshipDropdownService = sponsorshipDropdownService;
            this.httpCommunicator = httpCommunicator;
            this.cacheHelper = cacheHelper;
        }

        [HttpGet]
        public async Task<IActionResult> GetDropdownDetailsAsyn()
        {
            try
            {
                this.Logger.LogInformation("Loading SponsorshipDrodown Details for Category" );
                var sponsor = await this.sponsorshipDropdownService.GetDropdownDetailsAsyn();
                return Success("Get SponsorshipDrodown Details by Category", sponsor);
            }
            catch (Exception ex )
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetDropdownDetailsAsyn Method for Category"+ ex);
                return Error("Failed to Get SponsorshipDrodown Details ");

            }
        }
     
    }
}
