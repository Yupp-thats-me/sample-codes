﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SJP.Communication.Http;
using SJP.Core.Api.Controllers;
using SJP.Core.Cache;
using SJP.Sponsorship.Api.Model.Dto;
using SJP.Sponsorship.Api.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Sponsorship.Api.Controllers.Areas.v1.Sponsorship
{
    [Route("v{version:apiVersion}/[controller]")]
    [ApiController]
    // [Authorize]
    public class SponsorshipController : BaseApiController
    {
        private readonly ISponsorshipService sponsorshipService;
        private readonly ICacheHelper cacheHelper;
        private readonly IHttpCommunicator httpCommunicator;


        public SponsorshipController(ILogger<SponsorshipController> logger, ICacheHelper cacheHelper,
           ISponsorshipService sponsorshipService, IHttpCommunicator httpCommunicator) : base(logger)
        {
            this.sponsorshipService = sponsorshipService;
            this.httpCommunicator = httpCommunicator;
            this.cacheHelper = cacheHelper;
        }

        //Get Sponsorship Details
        
        [HttpGet]
        public async Task<IActionResult> GetSponsorshipDetails()
        {
            try
            {
                this.Logger.LogInformation("Loading Sponsorship Details");
                var sponsor = await this.sponsorshipService.GetSponsorshipDetails();
                this.Logger.LogInformation("Exiting from GetSponsorshipDetails Method");
                return Success("Get Sponsorship Details", sponsor);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetSponsorshipDetails Method" + Ex);
                return Error("Failed to Get Sponsorship Details");
            }
        }

        //Get Sponsorship Details based on Id

        [HttpGet("{Id}")]
        public async Task<IActionResult> GetSponsorshipDetails(int Id)
        {
            try
            {
                this.Logger.LogInformation("Loading Sponsorship Details for Id" + Id.ToString());
                var sponsor = await this.sponsorshipService.GetSponsorshipDetails(Id);
                return Success("Get Sponsorship Details by Id", sponsor);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetSponsorshipDetails Method for Id" + Id.ToString(), Ex.ToString());
                return Error("Failed to Get Sponsorship Details ");
            }
        }

        //Save Sponsorship Details

        [HttpPost]
        public async Task<IActionResult> SaveSponsorshipDetails(SponsorshipDetailsDto sponsorshipDetail)
        {
            try
            {
                if (sponsorshipDetail.Id > 0)
                {
                    return BadRequest("Invalid Data");
                }

                await this.sponsorshipService.SaveSponsorshipDetails(sponsorshipDetail);
                var sponsor = new { Id = sponsorshipDetail.Id };
                return Success("Data Saved Successfully", sponsor);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in Save Sponsor Details Method" + Ex);
                return Error("Failed to Save Sponsor Details ");
            }
        }

        //Update Sponsorship Details

        [HttpPut("{Id}")]
        public async Task<IActionResult> UpdateSponsorshipDetails(int Id, SponsorshipDetailsDto sponsorshipDetail)
        {
            try
            {
                if (Id == 0)
                {
                    return BadRequest("Invalid Details");
                }

                sponsorshipDetail.Id = Id;
                await this.sponsorshipService.SaveSponsorshipDetails(sponsorshipDetail);
                var sponsor = new { Id = sponsorshipDetail.Id};
                return Success("Data Updated and saved Successfully", sponsor);
            }

            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in Update Sponsorship Details Method" + Ex);
                return Error("Failed to Update Sponsorship Details ");
            }
        }

        [HttpGet("GetSponsorshipDetailsUser")]
        public async Task<IActionResult> GetSponsorshipDetailsForUsers()
        {
            try
            {
                this.Logger.LogInformation("Loading Sponsorship Details");
                var sponsor = await this.sponsorshipService.GetSponsorshipDetailsForUsers();
                this.Logger.LogInformation("Exiting from GetSponsorshipDetailsForUsers Method");
                return Success("Get Sponsorship Details For Users", sponsor);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetSponsorshipDetailsForUsers Method" + Ex);
                return Error("Failed to Get Sponsorship Details For Users");
            }
        }

        [HttpGet("GetFullSponsorshipDetailsUser")]
        public async Task<IActionResult> GetFullSponsorshipDetailsForUsers()
        {
            try
            {
                this.Logger.LogInformation("Loading Full Sponsorship Details");
                var sponsor = await this.sponsorshipService.GetFullSponsorshipDetailsForUsers();
                this.Logger.LogInformation("Exiting from GetFullSponsorshipDetailsForUsers Method");
                return Success("Get Full Sponsorship Details For Users", sponsor);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetFullSponsorshipDetailsForUsers Method" + Ex);
                return Error("Failed to Get Full Sponsorship Details For Users");
            }
        }

        [HttpGet("GetFullSponsorshipDetailsUser/{Id}")]
        public async Task<IActionResult> GetSponsorshipDetailsForUserId(long Id)
        {
            try
            {
                this.Logger.LogInformation("Loading Full GetSponsorshipDetailsForUserId ");
                var sponsor = await this.sponsorshipService.GetSponsorshipDetailsForUserId(Id);
                this.Logger.LogInformation("Exiting from GetSponsorshipDetailsForUserId Method");
                return Success("Get Full GetSponsorshipDetailsForUserId", sponsor);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetSponsorshipDetailsForUserId Method" + Ex);
                return Error("Failed to GetFullSponsorshipDetailsMainPageforUser");
            }
        }

        //Save Feedback Details

        [HttpPost("SaveFeedback")]
        public async Task<IActionResult> SaveFeedbackDetails(FeedbackDto feedback)
        {
            try
            {
                if (feedback.Id > 0)
                {
                    return BadRequest("Invalid Data");
                }

                await this.sponsorshipService.SaveFeedbackDetails(feedback);
                var feedbackid = new { Id = feedback.Id };
                return Success("Data Saved Successfully", feedbackid);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SaveFeedbackDetails Method" + Ex);
                return Error("Failed toSaveFeedbackDetails ");
            }
        }
    }
}
