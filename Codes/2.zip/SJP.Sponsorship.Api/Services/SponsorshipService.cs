﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Core.Services;
using SJP.Sponsorship.Api.DataAccess;
using SJP.Sponsorship.Api.Model;
using SJP.Sponsorship.Api.Model.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Sponsorship.Api.Services
{
    public class SponsorshipService : ServiceBase, ISponsorshipService
    {

            private readonly ISponsorshipDataAccess sponsorshipDataAccess;

            private readonly ILogger logger;
            protected ILogger Logger => logger;

        public SponsorshipService(ILogger<SponsorshipService> logger, ISponsorshipDataAccess sponsorshipDataAccess, IConfiguration configuration) : base(configuration)
            {
                this.sponsorshipDataAccess = sponsorshipDataAccess;
                this.logger = logger;
            }

            public override void Dispose()
            {
                //  throw new NotImplementedException();
            }

        public async Task<IEnumerable<SponsorshipDetailsDto>> GetSponsorshipDetails()
        {
            try
            {
                this.logger.LogInformation("Loading GetSponsorshipDetails Method");
                var sponsorRecord = await this.sponsorshipDataAccess.GetSponsorshipDetailsAsync();

                if (sponsorRecord != null)
                {
                    this.Logger.LogInformation("Exiting from GetSponsershipDetails Method with" + sponsorRecord.Count().ToString());
                    return sponsorRecord.Select(sponsor => new SponsorshipDetailsDto
                    {
                        Id = sponsor.Id,
                        TitleEn = sponsor.TitleEn,
                        TitleAr = sponsor.TitleAr,
                        DescriptionEn = sponsor.DescriptionEn,
                        DescriptionAr = sponsor.DescriptionAr,
                        BenefitsEn = sponsor.BenefitsEn,
                        BenefitsAr = sponsor.BenefitsAr,
                        NationalityId = sponsor.NationalityId,
                        HigherEducationId = sponsor.HigherEducationId,
                        MajorId = sponsor.MajorId,
                        Active=sponsor.Active,
                        YearId = sponsor.YearId,
                        EligibilityEn = sponsor.EligibilityEn,
                        EligibilityAr = sponsor.EligibilityAr,
                        HowToApplyEn = sponsor.HowToApplyEn,
                        HowToApplyAr = sponsor.HowToApplyAr,
                        ExpiryDate = sponsor.ExpiryDate,
                        UploadImage = sponsor.UploadImage,
                        StatusId = sponsor.StatusId,
                        OnBehalfOf = sponsor.OnBehalfOf,
                        SponsorshipTypeId = sponsor.SponsorshipTypeId,
                        ApplicationUrl = sponsor.ApplicationUrl,
                        ContactEmail = sponsor.ContactEmail,
                        CreatedBy=sponsor.CreatedBy,
                        UpdatedBy=sponsor.UpdatedBy


                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetSponsorshipDetails Method with 0 records");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SponsorshipDetailsService at SponsorshipDetailsAsync Method" + Ex);
                throw Ex;
            }
        }

        // get Sponsorship by ID

        public async Task<SponsorshipDetailsDto> GetSponsorshipDetails(long Id)
        {
            try
            {
                this.logger.LogInformation("Loading GetSponsorshipDetails Method");
                var sponsorRecord = await this.sponsorshipDataAccess.GetSponsorshipDetailsAsync(Id);

                if (sponsorRecord != null)
                {
                    this.Logger.LogInformation("Exiting from GetSponsorshipDetails Method with" + sponsorRecord.ToString());
                    return new SponsorshipDetailsDto
                     {
                        Id = sponsorRecord.Id,
                        TitleEn = sponsorRecord.TitleEn,
                        TitleAr = sponsorRecord.TitleAr,
                        DescriptionEn = sponsorRecord.DescriptionEn,
                        DescriptionAr = sponsorRecord.DescriptionAr,
                        BenefitsEn = sponsorRecord.BenefitsEn,
                        BenefitsAr = sponsorRecord.BenefitsAr,
                        NationalityId = sponsorRecord.NationalityId,
                        HigherEducationId = sponsorRecord.HigherEducationId,
                        MajorId = sponsorRecord.MajorId,
                        Active = sponsorRecord.Active,
                        YearId = sponsorRecord.YearId,
                        EligibilityEn = sponsorRecord.EligibilityEn,
                        EligibilityAr = sponsorRecord.EligibilityAr,
                        HowToApplyEn = sponsorRecord.HowToApplyEn,
                        HowToApplyAr = sponsorRecord.HowToApplyAr,
                        ExpiryDate = sponsorRecord.ExpiryDate,
                        UploadImage = sponsorRecord.UploadImage,
                        StatusId = sponsorRecord.StatusId,
                        OnBehalfOf = sponsorRecord.OnBehalfOf,
                        SponsorshipTypeId = sponsorRecord.SponsorshipTypeId,
                        ApplicationUrl = sponsorRecord.ApplicationUrl,
                        ContactEmail = sponsorRecord.ContactEmail,
                        CreatedBy=sponsorRecord.CreatedBy,
                        UpdatedBy=sponsorRecord.UpdatedBy



                    };
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetSponsorshipDetails Method with 0 records");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SponsorshipDetailsService at SponsorshipDetailsAsync Method" + Ex);
                throw Ex;
            }
        }

        // Save Sponsorship Details

        public async Task<SponsorshipDetailsDto> SaveSponsorshipDetails(SponsorshipDetailsDto sponsershipDetail)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveSponsorshipDetails ");

                var saveSponsorship = new SponsorshipDetails
                {
                    Id = sponsershipDetail.Id,
                    TitleEn = sponsershipDetail.TitleEn,
                    TitleAr = sponsershipDetail.TitleAr,
                    DescriptionEn = sponsershipDetail.DescriptionEn,
                    DescriptionAr = sponsershipDetail.DescriptionAr,
                    BenefitsEn = sponsershipDetail.BenefitsEn,
                    BenefitsAr = sponsershipDetail.BenefitsAr,
                    NationalityId = sponsershipDetail.NationalityId,
                    HigherEducationId = sponsershipDetail.HigherEducationId,
                    MajorId = sponsershipDetail.MajorId,
                    Active=sponsershipDetail.Active,
                    YearId = sponsershipDetail.YearId,
                    EligibilityEn = sponsershipDetail.EligibilityEn,
                    EligibilityAr = sponsershipDetail.EligibilityAr,
                    HowToApplyEn = sponsershipDetail.HowToApplyEn,
                    HowToApplyAr = sponsershipDetail.HowToApplyAr,
                    ExpiryDate = sponsershipDetail.ExpiryDate,
                    UploadImage = sponsershipDetail.UploadImage,
                    StatusId = sponsershipDetail.StatusId,
                    OnBehalfOf = sponsershipDetail.OnBehalfOf,
                    SponsorshipTypeId = sponsershipDetail.SponsorshipTypeId,
                    ApplicationUrl = sponsershipDetail.ApplicationUrl,
                    ContactEmail = sponsershipDetail.ContactEmail,
                    CreatedBy=sponsershipDetail.CreatedBy,
                    UpdatedBy=sponsershipDetail.UpdatedBy



                };

                var dataSaved = await this.sponsorshipDataAccess.SaveSponsorshipDetailsAsync(saveSponsorship);
                sponsershipDetail.Id = dataSaved.Id;
                this.Logger.LogInformation("Exiting from SaveSponsorshipDetails");
                return sponsershipDetail;

            }
            catch (Exception Ex)
            {
                this.Logger.LogInformation("Error Occured in SaveSponsorshipDetails" + Ex);
                throw Ex;
            }
        }

        public async Task<IEnumerable<SponsorshipDetailsDto>> GetSponsorshipDetailsForUsers()
        {
            try
            {
                this.logger.LogInformation("Loading GetSponsorshipDetailsForUsers Method");
                var sponsorRecord = await this.sponsorshipDataAccess.GetSponsorshipDetailsForUsersAsync();

                if (sponsorRecord != null)
                {
                    this.Logger.LogInformation("Exiting from GetSponsorshipDetailsForUsers Method with" + sponsorRecord.Count().ToString());
                    return sponsorRecord.Select(sponsor => new SponsorshipDetailsDto
                    {
                        Id = sponsor.Id,
                        TitleEn = sponsor.TitleEn,
                        TitleAr = sponsor.TitleAr,
                        DescriptionEn = sponsor.DescriptionEn,
                        DescriptionAr = sponsor.DescriptionAr,
                        BenefitsEn = sponsor.BenefitsEn,
                        BenefitsAr = sponsor.BenefitsAr,
                        NationalityId = sponsor.NationalityId,
                        HigherEducationId = sponsor.HigherEducationId,
                        MajorId = sponsor.MajorId,
                        Active = sponsor.Active,
                        YearId = sponsor.YearId,
                        EligibilityEn = sponsor.EligibilityEn,
                        EligibilityAr = sponsor.EligibilityAr,
                        HowToApplyEn = sponsor.HowToApplyEn,
                        HowToApplyAr = sponsor.HowToApplyAr,
                        ExpiryDate = sponsor.ExpiryDate,
                        //UploadImage = sponsor.UploadImage,
                        StatusId = sponsor.StatusId,
                        OnBehalfOf = sponsor.OnBehalfOf,
                        SponsorshipTypeId = sponsor.SponsorshipTypeId,
                        ApplicationUrl = sponsor.ApplicationUrl,
                        ContactEmail = sponsor.ContactEmail,
                        //CreatedBy = sponsor.CreatedBy,
                        //UpdatedBy = sponsor.UpdatedBy


                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetSponsorshipDetailsForUsers Method with 0 records");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SponsorshipDetailsService at SponsorshipDetailsForUsersAsync Method" + Ex);
                throw Ex;
            }
        }

        public async Task<IEnumerable<SponsorshipDetailsDto>> GetFullSponsorshipDetailsForUsers()
        {
            try
            {
                this.logger.LogInformation("Loading GetFullSponsorshipDetailsForUsers Method");
                var sponsorRecord = await this.sponsorshipDataAccess.GetFullSponsorshipDetailsForUsersAsync();

                if (sponsorRecord != null)
                {
                    this.Logger.LogInformation("Exiting from GetFullSponsorshipDetailsForUsers Method with" + sponsorRecord.Count().ToString());
                    return sponsorRecord.Select(sponsor => new SponsorshipDetailsDto
                    {
                        Id = sponsor.Id,
                        TitleEn = sponsor.TitleEn,
                        TitleAr = sponsor.TitleAr,
                        DescriptionEn = sponsor.DescriptionEn,
                        DescriptionAr = sponsor.DescriptionAr,
                        BenefitsEn = sponsor.BenefitsEn,
                        BenefitsAr = sponsor.BenefitsAr,
                        NationalityId = sponsor.NationalityId,
                        HigherEducationId = sponsor.HigherEducationId,
                        MajorId = sponsor.MajorId,
                        Active = sponsor.Active,
                        YearId = sponsor.YearId,
                        EligibilityEn = sponsor.EligibilityEn,
                        EligibilityAr = sponsor.EligibilityAr,
                        HowToApplyEn = sponsor.HowToApplyEn,
                        HowToApplyAr = sponsor.HowToApplyAr,
                        ExpiryDate = sponsor.ExpiryDate,
                        //UploadImage = sponsor.UploadImage,
                        StatusId = sponsor.StatusId,
                        OnBehalfOf = sponsor.OnBehalfOf,
                        SponsorshipTypeId = sponsor.SponsorshipTypeId,
                        ApplicationUrl = sponsor.ApplicationUrl,
                        ContactEmail = sponsor.ContactEmail,
                        //CreatedBy = sponsor.CreatedBy,
                        //UpdatedBy = sponsor.UpdatedBy


                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetFullSponsorshipDetailsForUsers Method with 0 records");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SponsorshipDetailsService at FullSponsorshipDetailsForUsersAsync Method" + Ex);
                throw Ex;
            }
        }

        public async Task<IEnumerable<SponsorshipDetailsDto>> GetSponsorshipDetailsForUserId(long Id)
        {
            try
            {
                this.logger.LogInformation("Loading GetSponsorshipDetailsForUserId Method");
                var sponsorRecord = await this.sponsorshipDataAccess.GetSponsorshipDetailsForUserId(Id);

                if (sponsorRecord != null)
                {
                    this.Logger.LogInformation("Exiting from GetSponsorshipDetailsForUserId Method with" + sponsorRecord.Count().ToString());
                    return sponsorRecord.Select(sponsor => new SponsorshipDetailsDto
                    {
                        Id = sponsor.Id,
                        TitleEn = sponsor.TitleEn,
                        TitleAr = sponsor.TitleAr,
                        DescriptionEn = sponsor.DescriptionEn,
                        DescriptionAr = sponsor.DescriptionAr,
                        BenefitsEn = sponsor.BenefitsEn,
                        BenefitsAr = sponsor.BenefitsAr,
                        EligibilityEn = sponsor.EligibilityEn,
                        EligibilityAr = sponsor.EligibilityAr,
                        HowToApplyEn = sponsor.HowToApplyEn,
                        HowToApplyAr = sponsor.HowToApplyAr,
                        ExpiryDate = sponsor.ExpiryDate,
                        //UploadImage = sponsor.UploadImage,
                        ApplicationUrl = sponsor.ApplicationUrl,
                        SponsorshipType=sponsor.SponsorshipType,
                        NationalityValue=sponsor.NationalityValue,
                        HigherEducationValue=sponsor.HigherEducationValue,
                        MajorValue=sponsor.MajorValue,
                        YearValue=sponsor.YearValue
                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetSponsorshipDetailsForUserId Method with 0 records");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetSponsorshipDetailsForUserId at FullSponsorshipDetailsForUsersAsync Method" + Ex);
                throw Ex;
            }
        }

        public async Task<FeedbackDto> SaveFeedbackDetails(FeedbackDto feedback) 
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveFeedbackDetails ");

                var saveFeedback = new FeedbackDetails
                {
                    Id = feedback.Id,
                    StudentId = feedback.StudentId,
                    FeedbackType=feedback.FeedbackType,
                    Content=feedback.Content,
                    Design=feedback.Design,
                    Personalization=feedback.Personalization,
                    Functionality=feedback.Functionality,
                    CreatedBy = feedback.CreatedBy,
                    //UpdatedBy = feedback.UpdatedBy,

                };

                var dataSaved = await this.sponsorshipDataAccess.SaveFeedbackDetails(saveFeedback);
                feedback.Id = dataSaved.Id;
                this.Logger.LogInformation("Exiting from SaveFeedbackDetails");
                return feedback;

            }
            catch (Exception Ex)
            {
                this.Logger.LogInformation("Error Occured in SaveFeedbackDetails" + Ex);
                throw Ex;
            }
        }


    }
}
