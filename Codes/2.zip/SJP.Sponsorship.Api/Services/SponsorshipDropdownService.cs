﻿using Microsoft.Extensions.Logging;
using SJP.Core.Services;
using System;
using SJP.Sponsorship.Api.Model;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SJP.Sponsorship.Api.Model.Dto;
using Microsoft.Extensions.Configuration;
using SJP.Sponsorship.Api.DataAccess;

namespace SJP.Sponsorship.Api.Services
{
    public class SponsorshipDropdownService : ServiceBase , ISponsorshipDropdownService
    {

        private readonly ISponsorshipDropdownDataAccess SponsorshipDropdownDataAccess;

        private readonly ILogger logger;
        protected ILogger Logger => logger;

        public SponsorshipDropdownService(ILogger<SponsorshipDropdownService> logger, ISponsorshipDropdownDataAccess SponsorshipDropdownDataAccess, IConfiguration configuration) : base(configuration)
        {
            this.SponsorshipDropdownDataAccess = SponsorshipDropdownDataAccess;

            this.logger = logger;
        }

        public override void Dispose()
        {
            //  throw new NotImplementedException();
        }

        public async Task<IEnumerable<DropdownDetailsDto>> GetDropdownDetailsAsyn ()
        {
            try
            {
                this.logger.LogInformation("Loading GetDropdownDetailsAsyn Method");
                var sponsorRecord = await this.SponsorshipDropdownDataAccess.GetDropdownDetailsAsyn();

                if (sponsorRecord != null)
                {
                    this.Logger.LogInformation("Exiting from GetDropdownDetailsAsyn Method with" + sponsorRecord.ToString());
                    return  sponsorRecord.Select(sponsor => new DropdownDetailsDto
                    {
                        DropdownId = sponsor.DropdownId,
                        DropdownValueEn = sponsor.DropdownValueEn,
                        DropdownValueAr = sponsor.DropdownValueAr,
                        Category = sponsor.Category,
                        IsActive = sponsor.IsActive

                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetDropdownDetailsAsyn Method with 0 records");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SponsorshipDropdownService at SponsorshipDetailsAsync Method" + Ex);
                throw Ex;
            }
        }
    }
}
