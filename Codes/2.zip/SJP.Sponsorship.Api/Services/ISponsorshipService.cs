﻿using SJP.Sponsorship.Api.Model.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Sponsorship.Api.Services
{
    public interface ISponsorshipService
    {
        Task<IEnumerable<SponsorshipDetailsDto>> GetSponsorshipDetails();
        Task<SponsorshipDetailsDto> GetSponsorshipDetails(long Id);
        Task<SponsorshipDetailsDto> SaveSponsorshipDetails(SponsorshipDetailsDto sponsorshipDetail);

        //GetSponsorshipDetailsUser Service
        Task<IEnumerable<SponsorshipDetailsDto>> GetSponsorshipDetailsForUsers();
        Task<IEnumerable<SponsorshipDetailsDto>> GetFullSponsorshipDetailsForUsers();
        Task<IEnumerable<SponsorshipDetailsDto>> GetSponsorshipDetailsForUserId(long Id);

        Task<FeedbackDto> SaveFeedbackDetails(FeedbackDto feedback);

    }
}
