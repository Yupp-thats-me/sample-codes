﻿using SJP.Sponsorship.Api.Model.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Sponsorship.Api.Services
{
    public interface ISponsorshipDropdownService
    {
        Task<IEnumerable<DropdownDetailsDto>> GetDropdownDetailsAsyn();
    }
}
