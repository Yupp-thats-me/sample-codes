﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.DataAccess;
using SJP.Sponsorship.Api.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using SJP.DataAccess.Extensions;

namespace SJP.Sponsorship.Api.DataAccess
{
    public class SponsorshipDropdownDataAccess : DataAccessBase,  ISponsorshipDropdownDataAccess

    {
        private readonly ILogger logger;
        protected ILogger Logger => logger;
        public SponsorshipDropdownDataAccess(ILogger<SponsorshipDropdownDataAccess> logger, IConfiguration configuration) : base(configuration)
        {
            this.logger = logger;
        }

        public async Task<IEnumerable<DropdownDetails>> GetDropdownDetailsAsyn()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetDropdownDetailsAsyn Method");

                IList<DropdownDetails> dropdowndetails = new List<DropdownDetails>();
                //var OnBehalfOf = new SqlParameter("@Category", SqlDbType.NVarChar) { Value = Category };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                    connection,
                                    CommandType.StoredProcedure,
                                    "GetSponsorshipDropdownDetails" 
                                    ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                dropdowndetails.Add(new DropdownDetails
                                {
                                    DropdownId = reader.To<long>("DropdownId"),
                                    DropdownValueEn = reader.ToStringValue("DropdownValueEn"),
                                    DropdownValueAr = reader.ToStringValue("DropdownValueAr"),
                                    Category = reader.ToStringValue("Category"),
                                    IsActive = reader.To<bool>("IsActive")

                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetDropdownDetailsAsyn Method");
                return dropdowndetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occurred", "ERROR in GetDropdownDetailsAsyn : " + ex.ToString());
                throw ex;
            }
        }
    }
}
