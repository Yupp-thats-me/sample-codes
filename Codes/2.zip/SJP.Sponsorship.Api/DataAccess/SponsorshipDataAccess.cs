﻿using SJP.DataAccess;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using SJP.Sponsorship.Api.Model;
using System.Data;
using System.Data.SqlClient;
using SJP.DataAccess.Extensions;

namespace SJP.Sponsorship.Api.DataAccess
{
    public class SponsorshipDataAccess : DataAccessBase, ISponsorshipDataAccess
    {
        private readonly ILogger logger;
        protected ILogger Logger => logger;

        public SponsorshipDataAccess(ILogger<SponsorshipDataAccess> logger, IConfiguration configuration) : base(configuration)
        {
            this.logger = logger;
        }

        public async Task<IEnumerable<SponsorshipDetails>> GetSponsorshipDetailsAsync()
        {
            try
            {
                //this.Logger.LogInformation("Entering into GetSponsorshipDetailsAsync method");
                IList<SponsorshipDetails> sponsorshipDetail = new List<SponsorshipDetails>();

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {

                    using (var reader = await ExecuteReaderAsync(
                                                connection,
                                                CommandType.StoredProcedure,
                                                "GetSponsorshipDetails").ConfigureAwait(false))
                    {

                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                sponsorshipDetail.Add(new SponsorshipDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    TitleEn = reader.ToStringValue("TitleEn"),
                                    TitleAr = reader.ToStringValue("TitleAr"),
                                    DescriptionEn = reader.ToStringValue("DescriptionEn"),
                                    DescriptionAr = reader.ToStringValue("DescriptionAr"),
                                    BenefitsEn = reader.ToStringValue("BenefitsEn"),
                                    BenefitsAr = reader.ToStringValue("BenefitsAr"),
                                    NationalityId = reader.To<int>("NationalityId"),
                                    HigherEducationId = reader.To<int>("HigherEducationId"),
                                    MajorId = reader.To<int>("MajorId"),
                                    Active = reader.To<bool>("Active"),
                                    YearId = reader.To<int>("YearId"),
                                    EligibilityEn = reader.ToStringValue("EligibilityEn"),
                                    EligibilityAr = reader.ToStringValue("EligibilityAr"),
                                    HowToApplyEn = reader.ToStringValue("HowToApplyEn"),
                                    HowToApplyAr = reader.ToStringValue("HowToApplyAr"),
                                    ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                    UploadImage = reader.ToStringValue("UploadImage"),
                                    StatusId = reader.To<int>("StatusId"),
                                    OnBehalfOf = reader.To<int>("OnBehalfOf"),
                                    SponsorshipTypeId = reader.To<int>("SponsorshipTypeId"),
                                    ApplicationUrl = reader.ToStringValue("ApplicationUrl"),
                                    ContactEmail = reader.ToStringValue("ContactEmail"),
                                    CreatedBy = reader.ToStringValue("CreatedBy"),
                                    UpdatedBy = reader.ToStringValue("UpdatedBy"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    UpdatedDate = reader.To<DateTime>("UpdatedDate")



                                });

                            }

                        }
                    }
                }

                return sponsorshipDetail;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<SponsorshipDetails> GetSponsorshipDetailsAsync(long Id)
        {
            try
            {
                //this.Logger.LogInformation("Entering into GetSponsorshipDetailsAsync method");
                 //IList<SponsorshipDetails> sponsorshipDetail = new List<SponsorshipDetails>();
                SponsorshipDetails sponsorshipDetails = null;
                var paramid = new SqlParameter("@Id", SqlDbType.BigInt) { Value = Id };

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {

                    using (var reader = await ExecuteReaderAsync(
                                                connection,
                                                CommandType.StoredProcedure,
                                                "GetSponsorshipDetails",paramid).ConfigureAwait(false))
                    {
                        

                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                sponsorshipDetails = new SponsorshipDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    TitleEn = reader.ToStringValue("TitleEn"),
                                    TitleAr = reader.ToStringValue("TitleAr"),
                                    DescriptionEn = reader.ToStringValue("DescriptionEn"),
                                    DescriptionAr = reader.ToStringValue("DescriptionAr"),
                                    BenefitsEn = reader.ToStringValue("BenefitsEn"),
                                    BenefitsAr = reader.ToStringValue("BenefitsAr"),
                                    NationalityId = reader.To<int>("NationalityId"),
                                    HigherEducationId = reader.To<int>("HigherEducationId"),
                                    MajorId = reader.To<int>("MajorId"),
                                    Active=reader.To<bool>("Active"),
                                    YearId = reader.To<int>("YearId"),
                                    EligibilityEn = reader.ToStringValue("EligibilityEn"),
                                    EligibilityAr = reader.ToStringValue("EligibilityAr"),
                                    HowToApplyEn = reader.ToStringValue("HowToApplyEn"),
                                    HowToApplyAr = reader.ToStringValue("HowToApplyAr"),
                                    ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                    UploadImage = reader.ToStringValue("UploadImage"),
                                    StatusId = reader.To<int>("StatusId"),
                                    OnBehalfOf = reader.To<int>("OnBehalfOf"),
                                    SponsorshipTypeId = reader.To<int>("SponsorshipTypeId"),
                                    ApplicationUrl = reader.ToStringValue("ApplicationUrl"),
                                    ContactEmail = reader.ToStringValue("ContactEmail"),
                                    CreatedBy = reader.ToStringValue("CreatedBy"),
                                    UpdatedBy= reader.ToStringValue("UpdatedBy"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    UpdatedDate = reader.To<DateTime>("UpdatedDate"),


                                };

                            }

                        }
                    }
                }

                return sponsorshipDetails;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<SponsorshipDetails> SaveSponsorshipDetailsAsync(SponsorshipDetails sponsorshipDetail)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveSponsorshipAsync method");
                var paramid = new SqlParameter("@Id", SqlDbType.BigInt) { Value = sponsorshipDetail.Id };
                var paramreferenceid = new SqlParameter("@ReferenceId", SqlDbType.BigInt) { Value = sponsorshipDetail.Id, Direction = ParameterDirection.Output };
                var paramTitleEn = new SqlParameter("@TitleEn", SqlDbType.NVarChar) { Value = sponsorshipDetail.TitleEn };
                var paramTitleAr = new SqlParameter("@TitleAr", SqlDbType.NVarChar) { Value = sponsorshipDetail.TitleAr };
                var paramDescriptionEn = new SqlParameter("@DescriptionEn", SqlDbType.NVarChar) { Value = sponsorshipDetail.DescriptionEn };
                var paramDescriptionAr = new SqlParameter("@DescriptionAr", SqlDbType.NVarChar) { Value = sponsorshipDetail.DescriptionAr };
                var paramBenefitsEn = new SqlParameter("@BenefitsEn", SqlDbType.NVarChar) { Value = sponsorshipDetail.BenefitsEn };
                var paramBenefitsAr = new SqlParameter("@BenefitsAr", SqlDbType.NVarChar) { Value = sponsorshipDetail.BenefitsAr };
                var paramNationalityId = new SqlParameter("@NationalityId", SqlDbType.BigInt) { Value = sponsorshipDetail.NationalityId };
                var paramHigherEducationId = new SqlParameter("@HigherEducationId", SqlDbType.BigInt) { Value = sponsorshipDetail.HigherEducationId };
                var paramMajorId = new SqlParameter("@MajorId", SqlDbType.BigInt) { Value = sponsorshipDetail.MajorId };
                var paramActive = new SqlParameter("@Active", SqlDbType.Bit) { Value = sponsorshipDetail.Active };
                var paramYearId = new SqlParameter("@YearId", SqlDbType.BigInt) { Value = sponsorshipDetail.YearId };
                var paramEligibilityEn = new SqlParameter("@EligibilityEn", SqlDbType.NVarChar) { Value = sponsorshipDetail.EligibilityEn };
                var paramEligibilityAr = new SqlParameter("@EligibilityAr", SqlDbType.NVarChar) { Value = sponsorshipDetail.EligibilityAr };
                var paramHowToApplyEn = new SqlParameter("@HowToApplyEn", SqlDbType.NVarChar) { Value = sponsorshipDetail.HowToApplyEn };
                var paramHowToApplyAr = new SqlParameter("@HowToApplyAr", SqlDbType.NVarChar) { Value = sponsorshipDetail.HowToApplyAr };
                var paramExpiryDate = new SqlParameter("@ExpiryDate", SqlDbType.DateTime) { Value = sponsorshipDetail.ExpiryDate };
                var paramUploadImage = new SqlParameter("@UploadImage", SqlDbType.NVarChar) { Value = sponsorshipDetail.UploadImage };
                var paramStatusId = new SqlParameter("@StatusId", SqlDbType.BigInt) { Value = sponsorshipDetail.StatusId };
                var paramOnBehalfOf = new SqlParameter("@OnBehalfOf", SqlDbType.BigInt) { Value = sponsorshipDetail.OnBehalfOf };
                var paramSponsorshipTypeId = new SqlParameter("@SponsorshipTypeId", SqlDbType.BigInt) { Value = sponsorshipDetail.SponsorshipTypeId };
                var paramApplicationUrl = new SqlParameter("@ApplicationUrl", SqlDbType.NVarChar) { Value = sponsorshipDetail.ApplicationUrl };
                var paramContactEmail = new SqlParameter("@ContactEmail", SqlDbType.NVarChar) { Value = sponsorshipDetail.ContactEmail };
                var paramCreatedBy = new SqlParameter("@CreatedBy", SqlDbType.NVarChar) { Value = sponsorshipDetail.CreatedBy };
                var paramUpdatedBy = new SqlParameter("@UpdatedBy", SqlDbType.NVarChar) { Value = sponsorshipDetail.UpdatedBy };

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveSponsorshipDetails",
                        paramid,
                        paramreferenceid,
                        paramTitleEn,
                        paramTitleAr,
                        paramDescriptionEn,
                        paramDescriptionAr,
                        paramBenefitsEn,
                        paramBenefitsAr,
                        paramNationalityId,
                        paramHigherEducationId,
                        paramMajorId,
                        paramActive,
                        paramYearId,
                        paramEligibilityEn,
                        paramEligibilityAr,
                        paramHowToApplyEn,
                        paramHowToApplyAr,
                        paramExpiryDate,
                        paramUploadImage,
                        paramStatusId,
                        paramOnBehalfOf,
                        paramSponsorshipTypeId,
                        paramApplicationUrl,
                        paramContactEmail,
                        paramCreatedBy,
                        paramUpdatedBy


                        ).ConfigureAwait(false);
                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }

                }
                sponsorshipDetail.Id = (long)paramreferenceid.Value;
                this.Logger.LogInformation("Exiting from SaveSponsorshipDetails Method");
                return sponsorshipDetail;
            }

            catch (Exception Ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in SaveSponsorshipDetails Method : " + Ex.ToString());
                throw Ex;
            }
        }

        public async Task<IEnumerable<SponsorshipDetails>> GetSponsorshipDetailsForUsersAsync()
        {
            try
            {
                //this.Logger.LogInformation("Entering into GetSponsorshipDetailsForUsersAsync method");
                IList<SponsorshipDetails> SponsorshipDetailsForUsers = new List<SponsorshipDetails>();

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {

                    using (var reader = await ExecuteReaderAsync(
                                                connection,
                                                CommandType.StoredProcedure,
                                                "GetSponsorshipDetailsForUsers").ConfigureAwait(false))
                    {

                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                SponsorshipDetailsForUsers.Add(new SponsorshipDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    TitleEn = reader.ToStringValue("TitleEn"),
                                    TitleAr = reader.ToStringValue("TitleAr"),
                                    DescriptionEn = reader.ToStringValue("DescriptionEn"),
                                    DescriptionAr = reader.ToStringValue("DescriptionAr"),
                                    BenefitsEn = reader.ToStringValue("BenefitsEn"),
                                    BenefitsAr = reader.ToStringValue("BenefitsAr"),
                                    NationalityId = reader.To<int>("NationalityId"),
                                    HigherEducationId = reader.To<int>("HigherEducationId"),
                                    MajorId = reader.To<int>("MajorId"),
                                    Active = reader.To<bool>("Active"),
                                    YearId = reader.To<int>("YearId"),
                                    EligibilityEn = reader.ToStringValue("EligibilityEn"),
                                    EligibilityAr = reader.ToStringValue("EligibilityAr"),
                                    HowToApplyEn = reader.ToStringValue("HowToApplyEn"),
                                    HowToApplyAr = reader.ToStringValue("HowToApplyAr"),
                                    ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                    //UploadImage = reader.ToStringValue("UploadImage"),
                                    StatusId = reader.To<int>("StatusId"),
                                    OnBehalfOf = reader.To<int>("OnBehalfOf"),
                                    SponsorshipTypeId = reader.To<int>("SponsorshipTypeId"),
                                    ApplicationUrl = reader.ToStringValue("ApplicationUrl"),
                                    ContactEmail = reader.ToStringValue("ContactEmail"),
                                    //CreatedBy = reader.ToStringValue("CreatedBy"),
                                    //UpdatedBy = reader.ToStringValue("UpdatedBy"),
                                    //CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    //UpdatedDate = reader.To<DateTime>("UpdatedDate")



                                });

                            }

                        }
                    }
                }

                return SponsorshipDetailsForUsers;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<IEnumerable<SponsorshipDetails>> GetFullSponsorshipDetailsForUsersAsync()
        {
            try
            {
                //this.Logger.LogInformation("Entering into GetSponsorshipDetailsForUsersAsync method");
                IList<SponsorshipDetails> SponsorshipDetailsForUsers = new List<SponsorshipDetails>();

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {

                    using (var reader = await ExecuteReaderAsync(
                                                connection,
                                                CommandType.StoredProcedure,
                                                "GetFullSponsorshipDetailsForUsers").ConfigureAwait(false))
                    {

                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                SponsorshipDetailsForUsers.Add(new SponsorshipDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    TitleEn = reader.ToStringValue("TitleEn"),
                                    TitleAr = reader.ToStringValue("TitleAr"),
                                    DescriptionEn = reader.ToStringValue("DescriptionEn"),
                                    DescriptionAr = reader.ToStringValue("DescriptionAr"),
                                    BenefitsEn = reader.ToStringValue("BenefitsEn"),
                                    BenefitsAr = reader.ToStringValue("BenefitsAr"),
                                    NationalityId = reader.To<int>("NationalityId"),
                                    HigherEducationId = reader.To<int>("HigherEducationId"),
                                    MajorId = reader.To<int>("MajorId"),
                                    Active = reader.To<bool>("Active"),
                                    YearId = reader.To<int>("YearId"),
                                    EligibilityEn = reader.ToStringValue("EligibilityEn"),
                                    EligibilityAr = reader.ToStringValue("EligibilityAr"),
                                    HowToApplyEn = reader.ToStringValue("HowToApplyEn"),
                                    HowToApplyAr = reader.ToStringValue("HowToApplyAr"),
                                    ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                    //UploadImage = reader.ToStringValue("UploadImage"),
                                    StatusId = reader.To<int>("StatusId"),
                                    OnBehalfOf = reader.To<int>("OnBehalfOf"),
                                    SponsorshipTypeId = reader.To<int>("SponsorshipTypeId"),
                                    ApplicationUrl = reader.ToStringValue("ApplicationUrl"),
                                    ContactEmail = reader.ToStringValue("ContactEmail"),
                                    //CreatedBy = reader.ToStringValue("CreatedBy"),
                                    //UpdatedBy = reader.ToStringValue("UpdatedBy"),
                                    //CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    //UpdatedDate = reader.To<DateTime>("UpdatedDate")



                                });

                            }

                        }
                    }
                }

                return SponsorshipDetailsForUsers;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<IEnumerable<SponsorshipDetails>> GetSponsorshipDetailsForUserId(long Id)
        {
            try
            {
                //this.Logger.LogInformation("Entering into GetSponsorshipDetailsId method");
                IList<SponsorshipDetails> SponsorshipDetailsForUsers = new List<SponsorshipDetails>();
                var paramid = new SqlParameter("@Id", SqlDbType.BigInt) { Value = Id };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {

                    using (var reader = await ExecuteReaderAsync(
                                                connection,
                                                CommandType.StoredProcedure,
                                                "GetSponsorshipDetailId",paramid).ConfigureAwait(false))
                    {

                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                SponsorshipDetailsForUsers.Add(new SponsorshipDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    TitleEn = reader.ToStringValue("TitleEn"),
                                    TitleAr = reader.ToStringValue("TitleAr"),
                                    DescriptionEn = reader.ToStringValue("DescriptionEn"),
                                    DescriptionAr = reader.ToStringValue("DescriptionAr"),
                                    BenefitsEn = reader.ToStringValue("BenefitsEn"),
                                    BenefitsAr = reader.ToStringValue("BenefitsAr"),
                                    EligibilityEn = reader.ToStringValue("EligibilityEn"),
                                    EligibilityAr = reader.ToStringValue("EligibilityAr"),
                                    HowToApplyEn = reader.ToStringValue("HowToApplyEn"),
                                    HowToApplyAr = reader.ToStringValue("HowToApplyAr"),
                                    ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                    //UploadImage = reader.ToStringValue("UploadImage"),
                                    ApplicationUrl = reader.ToStringValue("ApplicationUrl"),
                                    NationalityValue=reader.ToStringValue("Nationality"),
                                    HigherEducationValue=reader.ToStringValue("Education"),
                                    MajorValue=reader.ToStringValue("Major"),
                                    YearValue=reader.ToStringValue("Year"),
                                    SponsorshipType = reader.ToStringValue("SponsorshipType")
                                });

                            }

                        }
                    }
                }

                return SponsorshipDetailsForUsers;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<FeedbackDetails> SaveFeedbackDetails(FeedbackDetails feedbackDetails)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveFeedbackDetails method");
                var paramid = new SqlParameter("@Id", SqlDbType.BigInt) { Value = feedbackDetails.Id };
                var paramreferenceid = new SqlParameter("@ReferenceId", SqlDbType.BigInt) { Value = feedbackDetails.Id, Direction = ParameterDirection.Output };
                var paramstudentid = new SqlParameter("@StudentId", SqlDbType.Int) { Value = feedbackDetails.StudentId };
                var paramfeedbackType = new SqlParameter("@FeedbackType", SqlDbType.Int) { Value=feedbackDetails.FeedbackType};
                var paramContent = new SqlParameter("@Content", SqlDbType.Int) { Value = feedbackDetails.Content };
                var paramdesign = new SqlParameter("@Design", SqlDbType.Int) { Value = feedbackDetails.Design };
                var parampersonalization = new SqlParameter("@Personalization", SqlDbType.Int) { Value = feedbackDetails.Personalization };
                var paramfunctionality = new SqlParameter("@Functionality", SqlDbType.Int) { Value = feedbackDetails.Functionality };
                var paramCreatedBy = new SqlParameter("@CreatedBy", SqlDbType.NVarChar) { Value = feedbackDetails.CreatedBy };
                //var paramUpdatedBy = new SqlParameter("@UpdatedBy", SqlDbType.NVarChar) { Value = feedbackDetails.UpdatedBy };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveFeedbackDetails",
                        paramid,
                        paramreferenceid,
                        paramstudentid,
                        paramfeedbackType,
                        paramContent,
                        paramdesign,
                        parampersonalization,
                        paramfunctionality,
                        paramCreatedBy
                       // paramUpdatedBy


                        ).ConfigureAwait(false);
                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }

                }
                feedbackDetails.Id = (long)paramreferenceid.Value;
                this.Logger.LogInformation("Exiting from SaveFeedbackDetails Method");
                return feedbackDetails;
            }

            catch (Exception Ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in SaveFeedbackDetails Method : " + Ex.ToString());
                throw Ex;
            }
        
        }
    }
}