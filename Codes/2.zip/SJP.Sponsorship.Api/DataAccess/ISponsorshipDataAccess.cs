﻿using SJP.Sponsorship.Api.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Sponsorship.Api.DataAccess
{
    public interface ISponsorshipDataAccess
    {
        Task<IEnumerable <SponsorshipDetails>> GetSponsorshipDetailsAsync();
        Task<SponsorshipDetails> GetSponsorshipDetailsAsync(long Id);
        Task<SponsorshipDetails> SaveSponsorshipDetailsAsync(SponsorshipDetails sponsorshipDetail);

        //GetSponsorshipDetailsUser
        Task<IEnumerable<SponsorshipDetails>> GetSponsorshipDetailsForUsersAsync();
        Task<IEnumerable<SponsorshipDetails>> GetFullSponsorshipDetailsForUsersAsync();
        Task<IEnumerable<SponsorshipDetails>> GetSponsorshipDetailsForUserId(long Id);

        Task<FeedbackDetails> SaveFeedbackDetails(FeedbackDetails feedbackDetails);
    }
}
