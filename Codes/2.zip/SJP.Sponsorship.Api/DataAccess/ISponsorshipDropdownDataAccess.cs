﻿using SJP.Sponsorship.Api.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Sponsorship.Api.DataAccess
{
    public interface ISponsorshipDropdownDataAccess
    {
        Task<IEnumerable<DropdownDetails>> GetDropdownDetailsAsyn();
    }
}
