﻿using Microsoft.AspNetCore.Http;
using Serilog.Context;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace SJP.Logger.Middleware
{
    public class SeriLogContextExtensionMiddleware
    {
        /// <summary>
        /// The request delegate.
        /// </summary>
        private readonly RequestDelegate next;

        /// <summary>
        /// Initializes a new instance of the <see cref="SeriLogContextExtensionMiddleware"/> class.
        /// </summary>
        /// <param name="next">The request delegate.</param>
        /// <param name="configurationService">The configuration.</param>
        public SeriLogContextExtensionMiddleware(RequestDelegate next)
        {
            this.next = next;
        }

        /// <summary>
        /// Invoke
        /// </summary>
        /// <param name="context">Context object</param>
        /// <returns>Retuns task</returns>
        public async Task Invoke(HttpContext context)
        {
            try
            {
                if (context.User.Identity.IsAuthenticated)
                {
                    LogContext.PushProperty("User", context.User.Identity.Name);
                }
            }
            catch
            {
            }

            await this.next.Invoke(context);
        }
    }
}
