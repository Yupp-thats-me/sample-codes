﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Core;
using SJP.Logger.Middleware;
using System;
using System.Collections.Generic;
using System.Text;

namespace SJP.Logger.Extensions
{
    public static class Extension
    {

        public static IServiceCollection AddDatabaseLogger(this IServiceCollection services)
        {
            var configuration = services.BuildServiceProvider().GetService<IConfiguration>();
            services.AddLogging(config =>
            {
                // clear out default configuration
                config.ClearProviders();
                Serilog.ILogger logger = new DatabaseLogger(configuration).Configure();
                config.AddSerilog(logger);
            });
            return services;
        }


        public static IApplicationBuilder UseDatabaseLogger(this IApplicationBuilder app)
        {
            app.UseMiddleware<SeriLogContextExtensionMiddleware>();
            return app;
        }

        /// <summary>
        /// Looks up a switch in the declared LoggingLevelSwitches
        /// </summary>
        /// <param name="namedLevelSwitches">the dictionary of switches to look up by name</param>
        /// <param name="switchName">the name of a switch to look up</param>
        /// <returns>the LoggingLevelSwitch registered with the name</returns>
        /// <exception cref="InvalidOperationException">if no switch has been registered with <paramref name="switchName"/></exception>
        public static LoggingLevelSwitch LookUpSwitchByName(this IReadOnlyDictionary<string, LoggingLevelSwitch> namedLevelSwitches, string switchName)
        {
            if (namedLevelSwitches == null)
            {
                throw new ArgumentNullException(nameof(namedLevelSwitches));
            }

            if (namedLevelSwitches.TryGetValue(switchName, out var levelSwitch))
            {
                return levelSwitch;
            }

            throw new InvalidOperationException($"No LoggingLevelSwitch has been declared with name \"{switchName}\". You might be missing a section \"LevelSwitches\":{{\"{switchName}\":\"InitialLevel\"}}");
        }
    }
}
