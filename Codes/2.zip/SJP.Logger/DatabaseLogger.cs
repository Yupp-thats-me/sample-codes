﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;
using Serilog;
using Serilog.Configuration;
using Serilog.Core;
using Serilog.Debugging;
using Serilog.Events;
using Serilog.Sinks.MSSqlServer;
using Serilog.Sinks.MSSqlServer.Sinks.MSSqlServer.Options;
using SJP.Logger.Extensions;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace SJP.Logger
{

    /// <summary>
    /// This class is used to implement database logging using serilog.
    /// </summary>
    public class DatabaseLogger
    {
        private const string LevelSwitchNameRegex = @"^\$[A-Za-z]+[A-Za-z0-9]*$";
        private static IConfiguration configuration;

        private readonly IConfigurationSection section;

        /// <summary>
        /// Initializes a new instance of the <see cref="SeriLogConfigurationReader"/> class.
        /// </summary>
        /// <param name="configuration">Configuration object</param>
        public DatabaseLogger(IConfiguration configuration)
        {
            DatabaseLogger.configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
            this.section = configuration.GetSection("SeriLog");
        }

        /// <summary>
        /// Method used to configure Serilog from the config
        /// </summary>
        /// <returns>Instance of ILogger</returns>
        public ILogger Configure()
        {
            var loggerconfig = new LoggerConfiguration();
            var declaredLevelSwitches = this.ProcessLevelSwitchDeclarations();
            this.ApplyMinimumLevel(loggerconfig, declaredLevelSwitches);

            var sqlSection = this.section.GetSection("WriteTo").GetChildren().FirstOrDefault().GetSection("Args");

            var columnOptions = new ColumnOptions
            {
                AdditionalColumns = new Collection<SqlColumn>
                {
                        new SqlColumn { DataType = SqlDbType.NVarChar, ColumnName = "User" },
                }
            };

            columnOptions.Store.Add(StandardColumn.LogEvent);
            columnOptions.Store.Remove(StandardColumn.MessageTemplate);
            columnOptions.Store.Remove(StandardColumn.Properties);


            loggerconfig.Enrich.FromLogContext()
               .WriteTo.MSSqlServer(
                sqlSection.GetSection("connectionString").Value,
                sinkOptions: new SinkOptions
                {
                    TableName = sqlSection.GetSection("tableName").Value
                },
                columnOptions: columnOptions
               );



            return loggerconfig.CreateLogger();
        }

        /// <summary>
        /// This method is used to get the detaols of logging level switches
        /// </summary>
        /// <returns>List of logging level</returns>
        private IReadOnlyDictionary<string, LoggingLevelSwitch> ProcessLevelSwitchDeclarations()
        {
            var levelSwitchesDirective = this.section.GetSection("LevelSwitches");
            var namedSwitches = new Dictionary<string, LoggingLevelSwitch>();
            foreach (var levelSwitchDeclaration in levelSwitchesDirective.GetChildren())
            {
                var switchName = levelSwitchDeclaration.Key;
                var switchInitialLevel = levelSwitchDeclaration.Value;

                // switchName must be something like $switch to avoid ambiguities
                if (!this.IsValidSwitchName(switchName))
                {
                    throw new FormatException($"\"{switchName}\" is not a valid name for a Level Switch declaration. Level switch must be declared with a '$' sign, like \"LevelSwitches\" : {{\"$switchName\" : \"InitialLevel\"}}");
                }

                LoggingLevelSwitch newSwitch;
                if (string.IsNullOrEmpty(switchInitialLevel))
                {
                    newSwitch = new LoggingLevelSwitch();
                }
                else
                {
                    var initialLevel = this.ParseLogEventLevel(switchInitialLevel);
                    newSwitch = new LoggingLevelSwitch(initialLevel);
                }

                namedSwitches.Add(switchName, newSwitch);
            }

            return namedSwitches;
        }

        /// <summary>
        /// This method is used to apply the minimum loglevel
        /// </summary>
        /// <param name="loggerConfiguration">LoggerConfiguration instance</param>
        /// <param name="declaredLevelSwitches">Lits of logging level switches</param>
        private void ApplyMinimumLevel(LoggerConfiguration loggerConfiguration, IReadOnlyDictionary<string, LoggingLevelSwitch> declaredLevelSwitches)
        {
            var minimumLevelDirective = this.section.GetSection("MinimumLevel");

            var defaultMinLevelDirective = minimumLevelDirective.Value != null ? minimumLevelDirective : minimumLevelDirective.GetSection("Default");
            if (defaultMinLevelDirective.Value != null)
            {
                ApplyMinimumLevel(defaultMinLevelDirective, (configuration, levelSwitch) => configuration.ControlledBy(levelSwitch));
            }

            var minLevelControlledByDirective = minimumLevelDirective.GetSection("ControlledBy");
            if (minLevelControlledByDirective.Value != null)
            {
                var globalMinimumLevelSwitch = declaredLevelSwitches.LookUpSwitchByName(minLevelControlledByDirective.Value);

                // not calling ApplyMinimumLevel local function because here we have a reference to a LogLevelSwitch already
                loggerConfiguration.MinimumLevel.ControlledBy(globalMinimumLevelSwitch);
            }

            foreach (var overrideDirective in minimumLevelDirective.GetSection("Override").GetChildren())
            {
                var overridePrefix = overrideDirective.Key;
                var overridenLevelOrSwitch = overrideDirective.Value;
                if (Enum.TryParse(overridenLevelOrSwitch, out LogEventLevel _))
                {
                    ApplyMinimumLevel(overrideDirective, (configuration, levelSwitch) => configuration.Override(overridePrefix, levelSwitch));
                }
                else
                {
                    var overrideSwitch = declaredLevelSwitches.LookUpSwitchByName(overridenLevelOrSwitch);

                    // not calling ApplyMinimumLevel local function because here we have a reference to a LogLevelSwitch already
                    loggerConfiguration.MinimumLevel.Override(overridePrefix, overrideSwitch);
                }
            }

            /// <summary>
            /// This method is used to apply the minimum loglevel
            /// </summary>
            /// <param name="loggerConfiguration">LoggerConfiguration instance</param>
            /// <param name="declaredLevelSwitches">Lits of logging level switches</param>
            void ApplyMinimumLevel(IConfigurationSection directive, Action<LoggerMinimumLevelConfiguration, LoggingLevelSwitch> applyConfigAction)
            {
                var minimumLevel = this.ParseLogEventLevel(directive.Value);

                var levelSwitch = new LoggingLevelSwitch(minimumLevel);
                applyConfigAction(loggerConfiguration.MinimumLevel, levelSwitch);

                ChangeToken.OnChange(
                    directive.GetReloadToken,
                    () =>
                    {
                        if (Enum.TryParse(directive.Value, out minimumLevel))
                        {
                            levelSwitch.MinimumLevel = minimumLevel;
                        }
                        else
                        {
                            SelfLog.WriteLine($"The value {directive.Value} is not a valid Serilog level.");
                        }
                    });
            }
        }

        /// <summary>
        /// This methed is to check whether the input is valid switch name
        /// </summary>
        /// <param name="input">input string</param>
        /// <returns>True of the input is valid switch type</returns>
        private bool IsValidSwitchName(string input)
        {
            return Regex.IsMatch(input, LevelSwitchNameRegex);
        }

        /// <summary>
        /// This method is used to parse log level event
        /// </summary>
        /// <param name="value">log level string</param>
        /// <returns>LogEventLevel </returns>
        private LogEventLevel ParseLogEventLevel(string value)
        {
            if (!Enum.TryParse(value, out LogEventLevel parsedLevel))
            {
                throw new InvalidOperationException($"The value {value} is not a valid Serilog level.");
            }

            return parsedLevel;
        }
    }
}
