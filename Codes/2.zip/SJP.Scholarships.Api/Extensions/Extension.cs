﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using SJP.Communication.Http;
using SJP.Core.Api.Extensions;
using SJP.Core.Utility;
using SJP.Logger.Extensions;
using SJP.Scholarships.Api.DataAccess;
using SJP.Scholarships.Api.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Scholarships.Api.Extensions
{
    public static class Extension
    {
        public static IServiceCollection AddServices(this IServiceCollection services)
        {
            services.AddDatabaseLogger();
            services.AddDistributedMemCache();
            services.AddHttpCommunicator();
            services.AddScoped<IScholarshipDataAccess, ScholarshipDataAccess>();
            services.AddScoped<IScholarshipServices, ScholarshipServices>();
            services.AddScoped<IDropdownDataAccess, DropdownDataAccess>();
            services.AddScoped<IDropdownServices, DropdownServices>();
            
            return services;
        }
        public static IApplicationBuilder UseServices(this IApplicationBuilder app)
        {
            app.UseDatabaseLogger();
            return app;
        }
    }
}
