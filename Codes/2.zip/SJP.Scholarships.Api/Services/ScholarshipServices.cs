﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Core.Services;
using SJP.Scholarships.Api.DataAccess;
using SJP.Scholarships.Api.Model;
using SJP.Scholarships.Api.Model.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Scholarships.Api.Services
{
    public class ScholarshipServices : ServiceBase, IScholarshipServices
    {
        private readonly IScholarshipDataAccess scholarshipDataAcess;

        private readonly ILogger logger;
        protected ILogger Logger => logger;
        public ScholarshipServices(ILogger<ScholarshipServices> logger, IScholarshipDataAccess scholarshipDataAcess, IConfiguration configuration) : base(configuration)
        {
            this.scholarshipDataAcess = scholarshipDataAcess;
            this.logger = logger;
        }
        public override void Dispose()
        {
            //throw new NotImplementedException();
        }

        public async Task<ScholarshipDto> SaveScholarshipDetails(ScholarshipDto scholarshipDto)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveScholarshipDetails Method");
                var saveScholarship = new ScholarshipDetails
                {
                    Id = scholarshipDto.Id ??0 ,
                    TitleEn = scholarshipDto.TitleEn,
                    TitleAr = scholarshipDto.TitleAr,
                    DescriptionEn = scholarshipDto.DescriptionEn,
                    DescriptionAr = scholarshipDto.DescriptionAr,
                    BenefitsEn = scholarshipDto.BenefitsEn,
                    BenefitsAr = scholarshipDto.BenefitsAr,
                    NationalityId = scholarshipDto.NationalityId,
                    HigherEducationId = scholarshipDto.HigherEducationId,
                    MajorId = scholarshipDto.MajorId,
                    Active = scholarshipDto.Active,
                    YearId = scholarshipDto.YearId,
                    EligibilityEn = scholarshipDto.EligibilityEn,
                    EligibilityAr = scholarshipDto.EligibilityAr,
                    HowToApplyEn = scholarshipDto.HowToApplyEn,
                    HowToApplyAr = scholarshipDto.HowToApplyAr,
                    ExpiryDate = scholarshipDto.ExpiryDate,
                    UploadImage = scholarshipDto.UploadImage,
                    StatusId = scholarshipDto.StatusId,
                    OnBehalfOf = scholarshipDto.OnBehalfOf,
                    ApplicationUrl = scholarshipDto.ApplicationUrl,
                    ContactEmail = scholarshipDto.ContactEmail,
                    CreatedBy = scholarshipDto.CreatedBy,
                    UpdatedBy = scholarshipDto.UpdatedBy,
                    Reason = scholarshipDto.Reason,
                    Scholarshipfeature = scholarshipDto.Scholarshipfeature,
                    Scholarshiptype = scholarshipDto.Scholarshiptype,
                    TotalViews=scholarshipDto.TotalViews
                    
                };
                var save = await this.scholarshipDataAcess.SaveScholarshipDetailsAsync(saveScholarship);
                scholarshipDto.Id = save.Id;
                this.Logger.LogInformation("Exiting from SaveScholarshipDetails");
                return scholarshipDto;
            }
            catch (Exception Ex)
            {
                this.Logger.LogInformation("Error Occured in SaveScholarshipDetailsAsync" + Ex);
                throw Ex;
            }
        }

        public async Task<ScholarshipDto> UpdatedApprovalDetails(ScholarshipDto scholarshipDto) 
        {
            try
            {
                this.Logger.LogInformation("Entering into UpdatedApprovalDetails Method");
                var approvalScholarship = new ScholarshipDetails
                {
                    Id = scholarshipDto.Id ??0,
                    Reason = scholarshipDto.Reason,
                    StatusId = scholarshipDto.StatusId,
                    UpdatedBy = scholarshipDto.UpdatedBy
                };
                var save = await this.scholarshipDataAcess.SaveApprovalDetailsAsync(approvalScholarship);
                scholarshipDto.Id = save.Id;
                this.Logger.LogInformation("Exiting from UpdatedApprovalDetails");
                return scholarshipDto;
            }
            catch (Exception Ex)
            {
                this.Logger.LogInformation("Error Occured in UpdatedApprovalDetails" + Ex);
                throw Ex;
            }
        }


        public async Task<IEnumerable<ScholarshipDto>> GetScholarshipDetails()
        {
            try
            {
                this.logger.LogInformation("Loading GetScholarshipDetails Method");
                var scholarshipRecords = await this.scholarshipDataAcess.GetScholarshipDetailsAsync();
                if (scholarshipRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetScholarshipDetails Method with" + scholarshipRecords.Count().ToString());
                    return scholarshipRecords.Select(scholarship => new ScholarshipDto
                    {
                        Id = scholarship.Id,
                        TitleEn = scholarship.TitleEn,
                        TitleAr = scholarship.TitleAr,
                        DescriptionEn = scholarship.DescriptionEn,
                        DescriptionAr = scholarship.DescriptionAr,
                        BenefitsEn = scholarship.BenefitsEn,
                        BenefitsAr = scholarship.BenefitsAr,
                        NationalityId = scholarship.NationalityId,
                        HigherEducationId = scholarship.HigherEducationId,
                        MajorId = scholarship.MajorId,
                        Active = scholarship.Active,
                        YearId = scholarship.YearId,
                        EligibilityEn = scholarship.EligibilityEn,
                        EligibilityAr = scholarship.EligibilityAr,
                        HowToApplyEn = scholarship.HowToApplyEn,
                        HowToApplyAr = scholarship.HowToApplyAr,
                        ExpiryDate = scholarship.ExpiryDate,
                        UploadImage = scholarship.UploadImage,
                        StatusId = scholarship.StatusId,
                        OnBehalfOf = scholarship.OnBehalfOf,
                        ApplicationUrl = scholarship.ApplicationUrl,
                        ContactEmail = scholarship.ContactEmail,
                        CreatedBy = scholarship.CreatedBy,
                        UpdatedBy = scholarship.UpdatedBy,
                        CreatedDate = scholarship.CreatedDate,
                        Reason = scholarship.Reason,
                        Scholarshipfeature = scholarship.Scholarshipfeature,
                        Scholarshiptype = scholarship.Scholarshiptype,
                        PreviewImage = scholarship.PreviewImage
                    });
                }
                this.Logger.LogInformation( "Exiting from GetScholarshipDetails Method");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in ScholarshipServices at GetScholarshipDetails Method" + Ex);
                throw Ex;
            }
        }

        public async Task<ScholarshipDto> GetScholarshipDetails(long Id)
        {
            try
            {
                this.logger.LogInformation("Loading GetScholarshipDetails Method for Id" + Id.ToString());
                var scholarshipRecords = await this.scholarshipDataAcess.GetScholarshipDetailsAsync(Id);
                if (scholarshipRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetScholarshipDetails Method with" + scholarshipRecords.ToString());
                    return new ScholarshipDto
                    {
                        Id = scholarshipRecords.Id,
                        TitleEn = scholarshipRecords.TitleEn,
                        TitleAr = scholarshipRecords.TitleAr,
                        DescriptionEn = scholarshipRecords.DescriptionEn,
                        DescriptionAr = scholarshipRecords.DescriptionAr,
                        BenefitsEn = scholarshipRecords.BenefitsEn,
                        BenefitsAr = scholarshipRecords.BenefitsAr,
                        NationalityId = scholarshipRecords.NationalityId,
                        HigherEducationId = scholarshipRecords.HigherEducationId,
                        MajorId = scholarshipRecords.MajorId,
                        Active = scholarshipRecords.Active,
                        YearId = scholarshipRecords.YearId,
                        EligibilityEn = scholarshipRecords.EligibilityEn,
                        EligibilityAr = scholarshipRecords.EligibilityAr,
                        HowToApplyEn = scholarshipRecords.HowToApplyEn,
                        HowToApplyAr = scholarshipRecords.HowToApplyAr,
                        ExpiryDate = scholarshipRecords.ExpiryDate,
                        UploadImage = scholarshipRecords.UploadImage,
                        StatusId = scholarshipRecords.StatusId,
                        OnBehalfOf = scholarshipRecords.OnBehalfOf,
                        ApplicationUrl = scholarshipRecords.ApplicationUrl,
                        ContactEmail = scholarshipRecords.ContactEmail,
                        CreatedBy = scholarshipRecords.CreatedBy,
                        UpdatedBy = scholarshipRecords.UpdatedBy,
                        Reason = scholarshipRecords.Reason,
                        Scholarshipfeature = scholarshipRecords.Scholarshipfeature,
                        Scholarshiptype = scholarshipRecords.Scholarshiptype,
                        PreviewImage = scholarshipRecords.PreviewImage,
                        TotalViews= scholarshipRecords.TotalViews

                    };
                }

                this.Logger.LogInformation("Exiting from GetScholarshipDetails Method with" + Id.ToString());
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError("Error Occured", "Error Occured in ScholarshipServices at GetScholarshipDetails Method" + Ex);
                throw Ex;
            }
        }

        public async Task<bool> InActiveScholarship(long Id)
        {
            try
            {
                this.Logger.LogInformation("Entering into DeleteScholarshipDetail method");
                await this.scholarshipDataAcess.InActiveScholarship(Id);
                this.Logger.LogInformation("Exiting from DeleteScholarshipDetail method");
                return true;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError("Error Occured", "Error in DeleteScholarshipDetail method :" + Ex);
                throw Ex;
            }

        }
        public async Task<IEnumerable<ScholarshipDto>> GetScholarshipDetailsForUser()
        {
            try
            {
                this.logger.LogInformation("Loading GetScholarshipDetails Method");
                var scholarshipRecords = await this.scholarshipDataAcess.GetScholarshipDetailsForUser();

                if (scholarshipRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetScholarshipDetails Method with" + scholarshipRecords.Count().ToString());
                    return scholarshipRecords.Select(scholarship => new ScholarshipDto
                    {
                        Id = scholarship.Id,
                        TitleEn = scholarship.TitleEn,
                        TitleAr = scholarship.TitleAr,
                        DescriptionEn = scholarship.DescriptionEn,
                        DescriptionAr = scholarship.DescriptionAr,
                        HowToApplyEn = scholarship.HowToApplyEn,
                        HowToApplyAr = scholarship.HowToApplyAr,
                        BenefitsEn = scholarship.BenefitsEn,
                        BenefitsAr = scholarship.BenefitsAr,
                        HigherEducationId = scholarship.HigherEducationId,
                        Active = scholarship.Active,
                        NationalityId = scholarship.NationalityId,
                        MajorId = scholarship.MajorId,
                        //SpecializationId = scholarship.SpecializationId,
                        YearId = scholarship.YearId,
                        EligibilityEn = scholarship.EligibilityEn,
                        EligibilityAr = scholarship.EligibilityAr,
                        ExpiryDate = scholarship.ExpiryDate,
                        UploadImage = scholarship.UploadImage
                    });
                }

                this.Logger.LogInformation("Exiting from GetScholarshipDetails Method");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in ScholarshipServices at GetScholarshipDetails Method" + Ex);
                throw Ex;
            }
        }

        public async Task<IEnumerable<ScholarshipDto>> GetUserScholarshipDetailsList()
        {
            try
            {
                this.logger.LogInformation("Loading GetUserScholarshipDetailsList Method");
                var scholarshipRecord = await this.scholarshipDataAcess.GetUserScholarshipDetailsList();

                if (scholarshipRecord != null)
                {
                    this.Logger.LogInformation("Exiting from GetUserScholarshipDetailsList Method with" + scholarshipRecord.Count().ToString());
                    return scholarshipRecord.Select(sponsor => new ScholarshipDto
                    {
                        Id = sponsor.Id,
                        TitleEn = sponsor.TitleEn,
                        TitleAr = sponsor.TitleAr,
                        DescriptionEn = sponsor.DescriptionEn,
                        DescriptionAr = sponsor.DescriptionAr,
                        BenefitsEn = sponsor.BenefitsEn,
                        BenefitsAr = sponsor.BenefitsAr,
                        NationalityId = sponsor.NationalityId,
                        HigherEducationId = sponsor.HigherEducationId,
                        MajorId = sponsor.MajorId,
                        Active = sponsor.Active,
                        YearId = sponsor.YearId,
                        EligibilityEn = sponsor.EligibilityEn,
                        EligibilityAr = sponsor.EligibilityAr,
                        HowToApplyEn = sponsor.HowToApplyEn,
                        HowToApplyAr = sponsor.HowToApplyAr,
                        ExpiryDate = sponsor.ExpiryDate,
                        UploadImage = sponsor.UploadImage,
                        StatusId = sponsor.StatusId,
                        OnBehalfOf = sponsor.OnBehalfOf,
                        ApplicationUrl = sponsor.ApplicationUrl,
                        ContactEmail = sponsor.ContactEmail
                    });
                }
                this.Logger.LogInformation( "Exiting from GetUserScholarshipDetailsList Method");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetUserScholarshipDetailsList Method" + Ex);
                throw Ex;
            }
        }

        public async Task<ScholarshipDto> GetScholarshipDetailsForUserId(long Id)
        {
            try
            {
                this.logger.LogInformation("Loading GetScholarshipDetailsForUserId Method");
                var sponsorRecord = await this.scholarshipDataAcess.GetScholarshipDetailsForUserId(Id);

                if (sponsorRecord != null)
                {
                    this.Logger.LogInformation("Exiting from GetSponsorshipDetailsForUserId Method with" + sponsorRecord.ToString());
                    return new ScholarshipDto
                    {
                        Id = sponsorRecord.Id,
                        TitleEn = sponsorRecord.TitleEn,
                        TitleAr = sponsorRecord.TitleAr,
                        DescriptionEn = sponsorRecord.DescriptionEn,
                        DescriptionAr = sponsorRecord.DescriptionAr,
                        BenefitsEn = sponsorRecord.BenefitsEn,
                        BenefitsAr = sponsorRecord.BenefitsAr,
                        EligibilityEn = sponsorRecord.EligibilityEn,
                        EligibilityAr = sponsorRecord.EligibilityAr,
                        HowToApplyEn = sponsorRecord.HowToApplyEn,
                        HowToApplyAr = sponsorRecord.HowToApplyAr,
                        ExpiryDate = sponsorRecord.ExpiryDate,
                        UploadImage = sponsorRecord.UploadImage,
                        ApplicationUrl = sponsorRecord.ApplicationUrl,
                        NationalityValueEn = sponsorRecord.NationalityValueEn,
                        HigherEducationValueEn = sponsorRecord.HigherEducationValueEn,
                        MajorValueEn = sponsorRecord.MajorValueEn,
                        YearValueEn = sponsorRecord.YearValueEn,
                        NationalityValueAr = sponsorRecord.NationalityValueAr,
                        HigherEducationValueAr = sponsorRecord.HigherEducationValueAr,
                        MajorValueAr = sponsorRecord.MajorValueAr,
                        YearValueAr = sponsorRecord.YearValueAr,
                        TotalViews=sponsorRecord.TotalViews
                    
                    };
                }
                this.Logger.LogInformation( "Exiting from GetScholarshipDetailsForUserId Method");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetScholarshipDetailsForUserId at FullSponsorshipDetailsForUsersAsync Method" + Ex);
                throw Ex;
            }
        }

        public async Task<FeedbackDto> SaveFeedbackDetails(FeedbackDto feedback)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveFeedbackDetails ");

                var saveFeedback = new Feedback
                {
                    Id = feedback.Id,
                    ScholarshipId= feedback.ScholarshipId,
                    StudentId = feedback.StudentId,
                    //FeedbackType = feedback.FeedbackType,
                    Content = feedback.Content,
                    Design = feedback.Design,
                    Personalization = feedback.Personalization,
                    Functionality = feedback.Functionality,
                    CreatedBy = feedback.CreatedBy
                };

                var dataSaved = await this.scholarshipDataAcess.SaveFeedbackDetails(saveFeedback);
                feedback.Id = dataSaved.Id;
                this.Logger.LogInformation("Exiting from SaveFeedbackDetails");
                return feedback;

            }
            catch (Exception Ex)
            {
                this.Logger.LogInformation("Error Occured in SaveFeedbackDetails" + Ex);
                throw Ex;
            }
        }

        public async Task<IEnumerable<ScholarshipDto>> Getscholarshipgrid()
        {
            try
            {
                this.logger.LogInformation("Loading Getscholarshipgrid Method");
                var scholarshipRecords = await this.scholarshipDataAcess.Getscholarshipgrid();

                if (scholarshipRecords != null)
                {
                    this.Logger.LogInformation("Exiting from Getscholarshipgrid Method with" + scholarshipRecords.Count().ToString());
                    return scholarshipRecords.Select(scholarship => new ScholarshipDto
                    {
                        Id = scholarship.Id,
                        TitleEn = scholarship.TitleEn,
                        TitleAr = scholarship.TitleAr,
                        ExpiryDate = scholarship.ExpiryDate,
                        StatusId = scholarship.StatusId,
                        OnBehalfOf = scholarship.OnBehalfOf,
                        CreatedBy = scholarship.CreatedBy,
                        CreatedDate = scholarship.CreatedDate,
                        UpdatedDate = scholarship.UpdatedDate,
                        Reason = scholarship.Reason,
                    });
                }

                this.Logger.LogInformation("Exiting from GetScholarshipDetails Method ");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in ScholarshipServices at GetScholarshipDetails Method" + Ex);
                throw Ex;
            }
        }

        public Task<int> SaveScholarshipDetails(ScholarshipDetails sDto)
        {
            throw new NotImplementedException();
        }
        public async Task<ScholarshipDto> UpdateTotalViews(ScholarshipDto viewsUpdate)
        {
            try
            {
                this.Logger.LogInformation("Entering into UpdateTotalViews Method");
                var views = new ScholarshipDetails
                {
                    Id = viewsUpdate.Id ?? 0,
                    TotalViews = viewsUpdate.TotalViews
                    
                };
                var save = await this.scholarshipDataAcess.UpdateTotalViews(views);
                viewsUpdate.Id = save.Id;
                this.Logger.LogInformation("Exiting from UpdateTotalViews");
                return viewsUpdate;
            }
            catch (Exception ex)
            {
                this.Logger.LogInformation("Error Occured in UpdateTotalViews" + ex);
                throw ex;
            }
        }

        // Report 1 DataTable
        public async Task<IEnumerable<ScholarshipDto>> GetScholarViewCountStatisticsGrid(ScholarshipParam scholarshipParam)
        {
            try
            {
                this.logger.LogInformation("Loading Getscholarshipgrid Method");
                var scholarshipRecords = await this.scholarshipDataAcess.GetScholarViewCountStatisticsGrid(scholarshipParam);

                if (scholarshipRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetScholarViewCountStatisticsGrid Method with" + scholarshipRecords.Count().ToString());
                    return scholarshipRecords.Select(scholarship => new ScholarshipDto
                    {
                        Id = scholarship.Id,
                        TotalScholarshipInPortal=scholarship.TotalScholarshipInPortal,
                        AdminName=scholarship.AdminName,
                        CreatedDate=scholarship.CreatedDate,
                        TitleEn = scholarship.TitleEn,
                        TitleAr = scholarship.TitleAr,
                        YearId = scholarship.YearId,
                        Scholarshiptype = scholarship.Scholarshiptype,
                        Scholarshipfeature = scholarship.Scholarshipfeature,
                        Nationality=scholarship.Nationality,
                        HigherEducationId=scholarship.HigherEducationId,
                        MajorId = scholarship.MajorId,
                        ApplicationUrl = scholarship.ApplicationUrl,
                        ContactEmail = scholarship.ContactEmail,
                        ExpiryDate = scholarship.ExpiryDate,
                        TotalViews = scholarship.TotalViews,
                        TotalStudentsLoggedIn=scholarship.TotalStudentsLoggedIn,
                        EmployerAdmin=scholarship.EmployerAdmin,
                        HeiAdmin=scholarship.HeiAdmin,
                        GeneralAdmin=scholarship.GeneralAdmin,
                        MoeAdmin=scholarship.MoeAdmin,
                        RequestedRole=scholarship.RequestedRole
                    });
                }

                this.Logger.LogInformation("Exiting from GetScholarViewCountStatisticsGrid Method ");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in ScholarshipServices at GetScholarViewCountStatisticsGrid Method" + Ex);
                throw Ex;
            }
        }
        //Report 2 DataTable
        public async Task<IEnumerable<ScholarshipCountDto>> GetScholarshipListingStatisticsGrid(ScholarshipParam scholarshipParam)
        {
            try
            {
                this.logger.LogInformation("Loading Getscholarshipgrid Method");
                var scholarshipRecords = await this.scholarshipDataAcess.GetScholarshipListingStatisticsGrid(scholarshipParam);

                if (scholarshipRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetScholarshipListingStatisticsGrid Method with" + scholarshipRecords.Count().ToString());
                    return scholarshipRecords.Select(scholarship => new ScholarshipCountDto
                    {
                        //Id = scholarship.Id,
                        AdminName = scholarship.AdminName,
                        //CreatedDate=scholarship.CreatedDate,
                        //ExpiryDate=scholarship.ExpiryDate,
                        TotalScholarshipPosted=scholarship.TotalScholarshipPosted,
                        TotalScholarshipPending=scholarship.TotalScholarshipPending,
                        TotalScholarshipApproved=scholarship.TotalScholarshipApproved,
                        TotalScholarshipRejected=scholarship.TotalScholarshipRejected,
                        RequestedRole=scholarship.RequestedRole
                    });
                }

                this.Logger.LogInformation("Exiting from GetScholarshipListingStatisticsGrid Method ");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in ScholarshipServices at GetScholarshipListingStatisticsGrid Method" + Ex);
                throw Ex;
            }
        }

        //Report 3 DataTable
        public async Task<IEnumerable<FeedbackDto>> GetScholarSubModuleFeedbackGrid(FeedbackParam feedbackParam)
        {
            try
            {
                this.logger.LogInformation("Loading Getscholarshipgrid Method");
                var scholarshipRecords = await this.scholarshipDataAcess.GetScholarSubModuleFeedbackGrid(feedbackParam);

                if (scholarshipRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetScholarSubModuleFeedbackGrid Method with" + scholarshipRecords.Count().ToString());
                    return scholarshipRecords.Select(scholarship => new FeedbackDto
                    {
                        //ScholarshipId = scholarship.ScholarshipId,
                        //StudentId=scholarship.StudentId,
                        AdminName = scholarship.AdminName,
                        Institute=scholarship.Institute,
                        MajorId=scholarship.MajorId,
                        Content=scholarship.Content,
                        Personalization=scholarship.Personalization,
                        Design=scholarship.Design,
                        Functionality=scholarship.Functionality,
                        //HigherEducationId=scholarship.HigherEducationId,
                        //SatisfiedContent=scholarship.SatisfiedContent,
                        //NotContent=scholarship.NotContent,
                        //SatisfiedPersonalization=scholarship.SatisfiedPersonalization,
                        //NotPersonalization=scholarship.NotPersonalization,
                        //SatisfiedDesign=scholarship.SatisfiedDesign,
                        //NotDesign=scholarship.NotDesign,
                       // SatisfiedFunctionality=scholarship.SatisfiedFunctionality,
                        //NotFunctionality=scholarship.NotFunctionality,
                        RequestedRole = scholarship.RequestedRole,
                        EmirateEn=scholarship.EmirateEn,
                        EmirateAr=scholarship.EmirateAr
                    });
                }

                this.Logger.LogInformation("Exiting from GetScholarSubModuleFeedbackGrid Method ");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in ScholarshipServices at GetScholarSubModuleFeedbackGrid Method" + Ex);
                throw Ex;
            }
        }

        // CHART COUNT

        public async Task<IEnumerable<ScholarshipCountDto>> GetScholarshipReportCountDetails()
        {
            try
            {
                this.logger.LogInformation("Entering into GetScholarshipReportCountDetails Method");
                var counts = await this.scholarshipDataAcess.GetScholarshipReportCountDetails();
                if (counts != null)
                {
                    this.Logger.LogInformation("Exiting from GetScholarshipReportCountDetails Method with" + counts.Count().ToString());
                    return counts.Select(count => new ScholarshipCountDto
                    {
                        PostedDate = count.PostedDate,
                        TotalScholarshipInPortal=count.TotalScholarshipInPortal,
                        TotalScholarshipBachelor=count.TotalScholarshipBachelor,
                        TotalScholarshipMaster=count.TotalScholarshipMaster,
                        TotalStudentsLoggedIn=count.TotalStudentsLoggedIn
                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetScholarshipReportCountDetails Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetMediaReportCountDetails Method" + ex);
                throw ex;
            }
        }


    }
}
