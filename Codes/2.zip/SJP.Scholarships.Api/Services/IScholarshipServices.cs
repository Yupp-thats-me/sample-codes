﻿using SJP.Scholarships.Api.Model.Dto;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SJP.Scholarships.Api.Services
{
    public interface IScholarshipServices
    {
        Task<ScholarshipDto> SaveScholarshipDetails(ScholarshipDto scholarship);
        Task<ScholarshipDto> UpdatedApprovalDetails(ScholarshipDto scholarship);
        Task<IEnumerable<ScholarshipDto>> GetScholarshipDetails();
        Task<ScholarshipDto> GetScholarshipDetails(long Id);
        Task<bool> InActiveScholarship(long id);
        Task<IEnumerable<ScholarshipDto>> GetScholarshipDetailsForUser();
        Task<IEnumerable<ScholarshipDto>> GetUserScholarshipDetailsList();
        Task<ScholarshipDto> GetScholarshipDetailsForUserId(long Id);
        Task<FeedbackDto> SaveFeedbackDetails(FeedbackDto feedback);
        Task<IEnumerable<ScholarshipDto>> Getscholarshipgrid();
        Task<ScholarshipDto> UpdateTotalViews(ScholarshipDto viewsUpdate);
        Task<IEnumerable<ScholarshipDto>> GetScholarViewCountStatisticsGrid(ScholarshipParam scholarshipParam);
        Task<IEnumerable<ScholarshipCountDto>> GetScholarshipListingStatisticsGrid(ScholarshipParam scholarshipParam);
        Task<IEnumerable<FeedbackDto>> GetScholarSubModuleFeedbackGrid(FeedbackParam feedbackParam);
        Task<IEnumerable<ScholarshipCountDto>> GetScholarshipReportCountDetails();
    }
}
