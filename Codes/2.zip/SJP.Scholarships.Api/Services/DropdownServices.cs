﻿using Microsoft.Extensions.Logging;
using SJP.Core.Services;
using System;
using SJP.Sponsorship.Api.Model;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using SJP.Scholarships.Api.DataAccess;
using SJP.Sponsorship.Api.Model.Dto;

namespace SJP.Scholarships.Api.Services
{
    public class DropdownServices : ServiceBase, IDropdownServices
    {

        private readonly IDropdownDataAccess dropdownDataAccess;

        private readonly ILogger logger;
        protected ILogger Logger => logger;
        public DropdownServices(ILogger<DropdownServices> logger, IDropdownDataAccess dropdownDataAccess, IConfiguration configuration) : base(configuration)
        {
            this.dropdownDataAccess = dropdownDataAccess;

            this.logger = logger;
        }
        public override void Dispose()
        {
            //  throw new NotImplementedException();
        }

        public async Task<IEnumerable<DropdownDetailsDto>> GetDropdownDetailsAsyn()
        {
            try
            {
                this.logger.LogInformation("Loading GetDropdownDetailsAsyn Method");
                var sponsorRecord = await this.dropdownDataAccess.GetDropdownDetailsAsyn();

                if (sponsorRecord != null)
                {
                    this.Logger.LogInformation("Exiting from GetDropdownDetailsAsyn Method with" + sponsorRecord.ToString());
                    return sponsorRecord.Select(sponsor => new DropdownDetailsDto
                    {
                        DropdownId = sponsor.DropdownId,
                        DropdownValueEn = sponsor.DropdownValueEn,
                        DropdownValueAr = sponsor.DropdownValueAr,
                        Category = sponsor.Category,
                        IsActive = sponsor.IsActive
                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetDropdownDetailsAsyn Method with 0 records");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetDropdownDetailsAsyn at ScholarshipDetailsAsync Method" + Ex);
                throw Ex;
            }
        }
    }
}
