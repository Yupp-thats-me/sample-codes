﻿using SJP.Sponsorship.Api.Model.Dto;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SJP.Scholarships.Api.Services
{
    public interface IDropdownServices
    {
        Task<IEnumerable<DropdownDetailsDto>> GetDropdownDetailsAsyn();
    }
}
