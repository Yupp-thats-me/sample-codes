﻿
namespace SJP.Sponsorship.Api.Model.Dto
{
    public class DropdownDetailsDto
    {
        public long DropdownId { get; set; }
        public string DropdownValueEn { get; set; }
        public string DropdownValueAr { get; set; }
        public string Category { get; set; }
        public bool IsActive { get; set; }

 
    }
}
