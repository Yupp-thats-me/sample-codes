﻿using System;

namespace SJP.Scholarships.Api.Model.Dto
{
    public class ScholarshipDto
    {
        public long? Id { get; set; }
        public string TitleEn { get; set; }
        public string TitleAr { get; set; }
        public string DescriptionEn { get; set; }
        public string DescriptionAr { get; set; }
        public string BenefitsEn { get; set; }
        public string BenefitsAr { get; set; }
        public int NationalityId { get; set; }
        public string HigherEducationId { get; set; }
        public string MajorId { get; set; }
        public string YearId { get; set; }
        public string EligibilityEn { get; set; }
        public string EligibilityAr { get; set; }
        public string HowToApplyEn { get; set; }
        public string HowToApplyAr { get; set; }
        public DateTime ExpiryDate { get; set; }
        public string UploadImage { get; set; }
        public int StatusId { get; set; }
        public int OnBehalfOf { get; set; }
        public string ApplicationUrl { get; set; }
        public string ContactEmail { get; set; }
        public bool Active { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string Reason { get; set; }
        public int Scholarshiptype { get; set; }
        public int Scholarshipfeature { get; set; }
        public string NationalityValueEn { get; set; }
        public string HigherEducationValueEn { get; set; }
        public string MajorValueEn { get; set; }
        public string YearValueEn { get; set; }
        public bool IsFileDelete { get; set; }
        public string DeleteFilename { get; set; }
        public string NationalityValueAr { get; set; }
        public string HigherEducationValueAr { get; set; }
        public string MajorValueAr { get; set; }
        public string YearValueAr { get; set; }
        public string PreviewImage { get; set; }
        public long? TotalViews { get; set; }
        public string? AdminName { get; set; }
        public string? Nationality { get; set; }
        public long? TotalScholarshipInPortal { get; set; }
        public long? TotalStudentsLoggedIn { get; set; }
        //public int? RequestedRole { get; set; }
        public long? EmployerAdmin { get; set; }
        public long? HeiAdmin { get; set; }
        public long? GeneralAdmin { get; set; }
        public long? MoeAdmin { get; set; }
        public int? RequestedRole { get; set; }
    }
}
