﻿using SJP.Core.Model;

namespace SJP.Sponsorship.Api.Model
{
    public class DropdownDetails : DomainObject
    {
        public long DropdownId { get; set; }
        public string DropdownValueEn { get; set; }
        public string DropdownValueAr { get; set; }
        public string Category { get; set; }
        public bool IsActive { get; set; }
    }
}
