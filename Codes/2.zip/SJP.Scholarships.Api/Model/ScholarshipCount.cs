﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Scholarships.Api.Model
{
    public class ScholarshipCount
    {
        public long TotalScholarshipPosted { get; set; }
        public long TotalScholarshipPending { get; set; }
        public long TotalScholarshipApproved { get; set; }
        public long TotalScholarshipRejected { get; set; }
        public string? AdminName { get; set; }
        public long? Id { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public long TotalScholarshipInPortal { get; set; }
        public long TotalScholarshipBachelor { get; set; }
        public long TotalScholarshipMaster { get; set; }
        public long TotalStudentsLoggedIn { get; set; }
        public string? PostedDate { get; set; }
        public int? RequestedRole { get; set; }

    }
}
