﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Communication.Http;
using SJP.Core.Api.Controllers;
using SJP.Core.Cache;
using SJP.Core.Utility;
using SJP.Core.Constants;
using SJP.Scholarships.Api.Model.Dto;
using SJP.Scholarships.Api.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using SJP.DataAccess.Exceptions;
using SJP.Core.Composition;
using SJP.Core.Models;
using Microsoft.AspNetCore.Authorization;

namespace SJP.Scholarships.Api.Controllers.Areas.v1.Scholarship
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]

    public class ScholarshipController : BaseApiController
    {
        private readonly IScholarshipServices scholarshipServices;
        private readonly ICacheHelper cacheHelper;
        private readonly IHttpCommunicator httpCommunicator;
        private readonly IConfiguration Configuration;
        private readonly IFileUtility FileUtility;
        private readonly string SUB_Directory = "Scholarship";

        public ScholarshipController(ILogger<ScholarshipController> logger, ICacheHelper cacheHelper, IScholarshipServices scholarshipServices,
            IHttpCommunicator httpCommunicator, IConfiguration _configuration, IFileUtility FileUtility) : base(logger)
        {
            this.scholarshipServices = scholarshipServices;
            this.cacheHelper = cacheHelper;
            this.httpCommunicator = httpCommunicator;
            this.Configuration = _configuration;
            this.FileUtility = FileUtility;
        }
        /// <summary>
        /// To Save The Scholarship Details
        /// </summary>
        /// <param name="scholarshipDto"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.HEI, Role.GEI, Role.Employer, Role.ContentCreator)]
        //Save Scholarship Details
        [HttpPost]
        public async Task<IActionResult> SaveScholarshipDetails([FromForm] ScholarshipDto scholarshipDto)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveScholarshipDetails Method");
                var files = HttpContext.Request.Form.Files;
                if (files != null)
                {
                    scholarshipDto.UploadImage = this.FileUtility.GetFileNames(this.FileUtility.FileType_Images, files);
                }
                var savedData = await this.scholarshipServices.SaveScholarshipDetails(scholarshipDto);
                #region Save files
                try
                {
                    this.FileUtility.Save(files, SUB_Directory, savedData.Id.ToString());
                }
                catch (Exception ex)
                {
                    this.Logger.LogError(new Exception("Error Occured"), "Failed to save the file" + ex);
                }
                #endregion
                this.Logger.LogInformation("Loading UploadDocuments Info");
                var scholar = new { Id = scholarshipDto.Id };
                return Success("Data Saved Successfully", scholar);
            }
            catch (DuplicateDataException e)
            {
                return Error("", ErrorCode.Duplicate);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in Save Scholarship Details Method" + Ex);
                return Error("Failed to Save Scholarship Details ");
            }
        }

        /// <summary>
        /// To Fetch The Scholarship Details
        /// </summary>
        /// <returns></returns>

        [HttpGet]

        public async Task<IActionResult> Get()
        {
            try
            {
                this.Logger.LogInformation("Loading Scholarship Details");
                var data = await this.scholarshipServices.GetScholarshipDetails();
                foreach (var item in data.ToList())
                {
                    item.PreviewImage = FileUtility.GetThumbnailBase64String(SUB_Directory, item.Id.ToString(), item.PreviewImage ?? "");
                }
                this.Logger.LogInformation("Exiting from Scholarship Details Method");
                return Success("Get Scholarship Details successfully", data);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "ERROR Occured in GetScholarship  method " + ex);
                return Error("Failed to Get Scholarship Details");
            }
        }

        /// <summary>
        /// To Fetch The Scholarship Details For Grid
        /// </summary>
        /// <returns></returns>

        [AuthorizeByRole(Role.HEI, Role.GEI, Role.Employer, Role.ContentCreator, Role.ContentApprover)]
        [HttpGet("grid")]

        public async Task<IActionResult> Getscholarshipgrid()
        {
            try
            {
                this.Logger.LogInformation("Entering into Getscholarshipgrid Method");
                var scholar = await this.scholarshipServices.Getscholarshipgrid();
                this.Logger.LogInformation("Exiting from GetScholarshipgrid Details Method");
                return Success("Getscholarshipgrid Details", scholar);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in Getscholarshipgrid Method" + Ex);
                return Error("Failed to Get Scholarship Details ");
            }
        }

        /// <summary>
        /// To Fetch Scholarship Id Based on ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>

        [Authorize]
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(long id)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetScholarshipDetails Method by Id" + id.ToString());
                var scholarshipdata = await this.scholarshipServices.GetScholarshipDetails(id);
                if (scholarshipdata != null)
                {
                    scholarshipdata.UploadImage = FileUtility.GetThumbnailBase64String(SUB_Directory, scholarshipdata.Id.ToString(), scholarshipdata.UploadImage ?? "");
                }
                this.Logger.LogInformation("Exiting from GetScholarshipDetails  Method");
                return Success("GetScholarshipDetails by Id", scholarshipdata);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetScholarshipDetails Method for Id" + id.ToString(), ex.ToString());
                return Error("Failed to GetScholarshipDetails by Id ");
            }
        }

        /// <summary>
        /// To Put Scholarship Details Based On ID
        /// </summary>
        /// <param name="id"></param>
        /// <param name="scholarshipDto"></param>
        /// <returns></returns>

        //For Approval
        [HttpPut("{id}")]
        [AuthorizeByRole(Role.ContentApprover)]
        public async Task<IActionResult> put(long id, [FromBody] ScholarshipDto scholarshipDto)
        {
            try
            {
                if (id == 0)
                {
                    return BadRequest("Invalid Data");
                }
                scholarshipDto.Id = id;
                await this.scholarshipServices.UpdatedApprovalDetails(scholarshipDto);
                var scholar = new { Id = scholarshipDto.Id };
                return Success("Data Updated and saved Successfully", scholar);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Failed to Update the Data" + ex);
                return Error("Failed to Update Scholarship Details");
            }
        }

        /// <summary>
        /// To Put Scholarship Based On InActiveScholarship ID
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.HEI, Role.GEI, Role.Employer, Role.ContentCreator)]

        [HttpPut("InActiveScholarship/{id}")]
        public async Task<IActionResult> InActiveScholarship(long Id)
        {
            this.Logger.LogInformation("Entering into InActiveScholarship Method");
            try
            {
                await scholarshipServices.InActiveScholarship(Id);
                return Success("Scholarship deleted successfully");
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Failed to Update InActiveScholarship" + ex);
                return Error("Failed to Update InActiveScholarship Method");
            }
        }

        /// <summary>
        /// To Fetch Scholarship User Details
        /// </summary>
        /// <returns></returns>

        [HttpGet("GetScholarshipDetailsUser")]

        public async Task<IActionResult> GetScholarshipDetailsUser()
        {
            try
            {
                this.Logger.LogInformation("Loading GetScholarshipDetailsUser Details");
                IEnumerable<ScholarshipDto> scholarship = new List<ScholarshipDto>();
                List<ScholarshipDto> s = new List<ScholarshipDto>();
                scholarship = await this.scholarshipServices.GetScholarshipDetailsForUser();
                s = scholarship.ToList();

                foreach (var item in s)
                {
                    item.UploadImage = FileUtility.GetThumbnailBase64String(SUB_Directory, item.Id.ToString(), item.UploadImage ?? "");
                }

                return Success("Get Scholarship Details successfully for User", s);

            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "ERROR Occured in GetScholarshipDetailsUser method " + ex);
                return Error("Failed to Get Scholarship");
            }


        }

        /// <summary>
        /// To Fetch Scholarship Users List
        /// </summary>
        /// <returns></returns>

        [HttpGet("GetUserScholarshipDetailsList")]
        public async Task<IActionResult> GetUserScholarshipDetailsList()
        {
            try
            {
                this.Logger.LogInformation("Loading GetUserScholarshipDetailsList Method");
                IEnumerable<ScholarshipDto> scholarship = new List<ScholarshipDto>();
                List<ScholarshipDto> s = new List<ScholarshipDto>();
                scholarship = await this.scholarshipServices.GetUserScholarshipDetailsList();
                s = scholarship.ToList();

                foreach (var item in s)
                {
                    item.UploadImage = FileUtility.GetThumbnailBase64String(SUB_Directory, item.Id.ToString(), item.UploadImage ?? "");
                }

                return Success("Get Scholarship Details successfully for User", s);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetUserScholarshipDetailsList Method" + Ex);
                return Error("Failed to GetUserScholarshipDetailsList For Users");
            }
        }

        /// <summary>
        /// To Fetch Scholarship Details By ID
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>

        [Authorize]
        [HttpGet("GetScholarshipsDetailId/{Id}")]
        public async Task<IActionResult> GetScholarshipDetailsForUserId(long Id)
        {
            try
            {
                this.Logger.LogInformation("Loading Full GetScholarshipDetailsForUserId ");
                ScholarshipDto scholarship = new ScholarshipDto();
                scholarship = await this.scholarshipServices.GetScholarshipDetailsForUserId(Id);
                if (scholarship != null)
                {
                    scholarship.UploadImage = FileUtility.GetThumbnailBase64String(new string[] { SUB_Directory, scholarship.Id.ToString(), scholarship.UploadImage ?? "" });
                }

                this.Logger.LogInformation("Exiting from GetScholarshipDetailsForUserId Method");
                return Success("Get Full GetScholarshipDetailsForUserId", scholarship);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetScholarshipDetailsForUserId Method" + Ex);
                return Error("Failed to GetScholarshipDetailsForUserId");
            }
        }

        /// <summary>
        /// To Save Feedback Details Of Scholarship
        /// </summary>
        /// <param name="feedback"></param>
        /// <returns></returns>

        //Save Feedback Details
        [Authorize]
        [HttpPost("SaveFeedback")]
        public async Task<IActionResult> SaveFeedbackDetails(FeedbackDto feedback)
        {
            try
            {
                if (feedback.Id > 0)
                {
                    return BadRequest("Invalid Data");
                }
                await this.scholarshipServices.SaveFeedbackDetails(feedback);
                var feedbackid = new { Id = feedback.Id };
                return Success("Data Saved Successfully", feedbackid);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SaveFeedbackDetails Method" + Ex);
                return Error("Failed toSaveFeedbackDetails ");
            }
        }

        /// <summary>
        /// To Update Scholarship By ID
        /// </summary>
        /// <param name="id"></param>
        /// <param name="viewDetails"></param>
        /// <returns></returns>

        [HttpPut("update/{id}")]
        public async Task<IActionResult> Put(long id, [FromBody] ScholarshipDto viewDetails)
        {
            try
            {
                if (id == 0)
                {
                    return BadRequest("Invalid Data");
                }
                viewDetails.Id = id;
                await this.scholarshipServices.UpdateTotalViews(viewDetails);
                var status = new { Id = viewDetails.Id };
                return Success("TotalViews Updated Successfully", status);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Failed to Update the Data" + ex);
                return Error("Failed to Update TotalViews");
            }
        }

        /// <summary>
        /// To Fetch Scholarship View Count Statistics
        /// </summary>
        /// <param name="scholarshipParam"></param>
        /// <returns></returns>

        // Report 1 DataTable
        [HttpGet("GetScholarViewCountStatisticsGrid")]
        public async Task<IActionResult> GetScholarViewCountStatisticsGrid([FromQuery] ScholarshipParam scholarshipParam)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetScholarViewCountStatisticsGrid Method");
                var scholar = await this.scholarshipServices.GetScholarViewCountStatisticsGrid(scholarshipParam);
                this.Logger.LogInformation("Exiting from GetScholarViewCountStatisticsGrid  Method");
                return Success("GetScholarViewCountStatisticsGrid Details", scholar);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetScholarViewCountStatisticsGrid Method" + Ex);
                return Error("Failed to Get ScholarViewCountStatisticsGrid Details ");
            }
        }

        /// <summary>
        /// To Fetch Scholarship Listing Statistics
        /// </summary>
        /// <param name="scholarshipParam"></param>
        /// <returns></returns>

        // Report 2 DataTable
        [HttpGet("GetScholarshipListingStatisticsGrid")]
        public async Task<IActionResult> GetScholarshipListingStatisticsGrid([FromQuery] ScholarshipParam scholarshipParam)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetScholarshipListingStatisticsGrid Method");
                var scholar = await this.scholarshipServices.GetScholarshipListingStatisticsGrid(scholarshipParam);
                this.Logger.LogInformation("Exiting from GetScholarshipListingStatisticsGrid  Method");
                return Success("GetScholarshipListingStatisticsGrid Details", scholar);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetScholarshipListingStatisticsGrid Method" + Ex);
                return Error("Failed to Get GetScholarshipListingStatisticsGrid Details ");
            }
        }

        /// <summary>
        /// To Fetch Scholarship SubModule Feedback
        /// </summary>
        /// <param name="feedbackParam"></param>
        /// <returns></returns>

        // Report 3 DataTable
        [HttpGet("GetScholarSubModuleFeedbackGrid")]
        public async Task<IActionResult> GetScholarSubModuleFeedbackGrid([FromQuery] FeedbackParam feedbackParam)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetScholarSubModuleFeedbackGrid Method");
                var scholar = await this.scholarshipServices.GetScholarSubModuleFeedbackGrid(feedbackParam);
                this.Logger.LogInformation("Exiting from GetScholarSubModuleFeedbackGrid  Method");
                return Success("GetScholarSubModuleFeedbackGrid Details", scholar);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetScholarSubModuleFeedbackGrid Method" + Ex);
                return Error("Failed to Get GetScholarSubModuleFeedbackGrid Details ");
            }
        }

        /// <summary>
        /// To Fetch Scholarship Report Count Details
        /// </summary>
        /// <returns></returns>

        // Chart Count 

        [HttpGet("GetScholarshipReportCountDetails")]
        public async Task<IActionResult> GetScholarshipReportCountDetails()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetScholarshipReportCountDetails Method");
                var count = await this.scholarshipServices.GetScholarshipReportCountDetails();

                this.Logger.LogInformation("Exiting from GetScholarshipReportCountDetails Method");
                return Success("GetScholarshipReportCountDetails successfully", count);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "ERROR Occured in GetScholarshipReportCountDetails  method " + ex);
                return Error("Failed to GetScholarshipReportCountDetails");
            }
        }

    }
}
