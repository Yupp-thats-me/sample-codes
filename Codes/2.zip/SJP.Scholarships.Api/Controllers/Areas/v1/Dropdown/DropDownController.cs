﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SJP.Communication.Http;
using SJP.Core.Api.Controllers;
using SJP.Core.Cache;
using SJP.Scholarships.Api.Services;
using System;
using System.Threading.Tasks;

namespace SJP.Scholarships.Api.Controllers.Areas.v1.Dropdown
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class DropDownController : BaseApiController
    {
        private readonly IDropdownServices dropdownServices;
        private readonly ICacheHelper cacheHelper;
        private readonly IHttpCommunicator httpCommunicator;

        public DropDownController(ILogger<DropDownController> logger, ICacheHelper cacheHelper,
       IDropdownServices dropdownServices, IHttpCommunicator httpCommunicator) : base(logger)
        {
            this.dropdownServices = dropdownServices;
            this.httpCommunicator = httpCommunicator;
            this.cacheHelper = cacheHelper;
        }

        /// <summary>
        /// To Get Scholarship DropDowns
        /// </summary>
        /// <returns></returns>

        [HttpGet("GetDropdownDetailsAsyn")]
        public async Task<IActionResult> GetDropdownDetailsAsyn()
        {
            try
            {
                this.Logger.LogInformation("Loading SponsorshipDrodown Details for Category");
                var Scholar = await this.dropdownServices.GetDropdownDetailsAsyn();
                return Success("Get ScholarshipDrodown Details by Category", Scholar);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetDropdownDetailsAsyn Method for Category" + ex);
                return Error("Failed to Get ScholarshipDrodown Details ");
            }
        }
    }
}
