﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.DataAccess;
using SJP.Scholarships.Api.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using SJP.DataAccess.Extensions;

namespace SJP.Scholarships.Api.DataAccess
{
    public class ScholarshipDataAccess : DataAccessBase, IScholarshipDataAccess
    {
        private readonly ILogger logger;
        protected ILogger Logger => logger;
        public ScholarshipDataAccess(ILogger<ScholarshipDataAccess> logger, IConfiguration configuration) : base(configuration)
        {
            this.logger = logger;
        }

        public async Task<ScholarshipDetails> SaveScholarshipDetailsAsync(ScholarshipDetails scholarshipDetails)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveScholarshipDetailsAsync method");
                var paramid = new SqlParameter("@Id", SqlDbType.BigInt) { Value = scholarshipDetails.Id };
                var paramreferenceid = new SqlParameter("@ReferenceId", SqlDbType.BigInt) { Value = scholarshipDetails.Id, Direction = ParameterDirection.Output };
                var paramTitleEn = new SqlParameter("@TitleEn", SqlDbType.NVarChar) { Value = scholarshipDetails.TitleEn };
                var paramTitleAr = new SqlParameter("@TitleAr", SqlDbType.NVarChar) { Value = scholarshipDetails.TitleAr };
                var paramDescriptionEn = new SqlParameter("@DescriptionEn", SqlDbType.NVarChar) { Value = scholarshipDetails.DescriptionEn };
                var paramDescriptionAr = new SqlParameter("@DescriptionAr", SqlDbType.NVarChar) { Value = scholarshipDetails.DescriptionAr };
                var paramBenefitsEn = new SqlParameter("@BenefitsEn", SqlDbType.NVarChar) { Value = scholarshipDetails.BenefitsEn };
                var paramBenefitsAr = new SqlParameter("@BenefitsAr", SqlDbType.NVarChar) { Value = scholarshipDetails.BenefitsAr };
                var paramNationalityId = new SqlParameter("@NationalityId", SqlDbType.BigInt) { Value = scholarshipDetails.NationalityId };
                var paramHigherEducationId = new SqlParameter("@HigherEducationId", SqlDbType.NVarChar) { Value = scholarshipDetails.HigherEducationId };
                var paramMajorId = new SqlParameter("@MajorId", SqlDbType.NVarChar) { Value = scholarshipDetails.MajorId };
                var paramActive = new SqlParameter("@Active", SqlDbType.Bit) { Value = scholarshipDetails.Active };
                var paramYearId = new SqlParameter("@YearId", SqlDbType.NVarChar) { Value = scholarshipDetails.YearId };
                var paramEligibilityEn = new SqlParameter("@EligibilityEn", SqlDbType.NVarChar) { Value = scholarshipDetails.EligibilityEn };
                var paramEligibilityAr = new SqlParameter("@EligibilityAr", SqlDbType.NVarChar) { Value = scholarshipDetails.EligibilityAr };
                var paramHowToApplyEn = new SqlParameter("@HowToApplyEn", SqlDbType.NVarChar) { Value = scholarshipDetails.HowToApplyEn };
                var paramHowToApplyAr = new SqlParameter("@HowToApplyAr", SqlDbType.NVarChar) { Value = scholarshipDetails.HowToApplyAr };
                var paramExpiryDate = new SqlParameter("@ExpiryDate", SqlDbType.DateTime) { Value = scholarshipDetails.ExpiryDate };
                var paramUploadImage = new SqlParameter("@UploadImage", SqlDbType.NVarChar) { Value = scholarshipDetails.UploadImage };
                var paramStatusId = new SqlParameter("@StatusId", SqlDbType.BigInt) { Value = scholarshipDetails.StatusId };
                var paramOnBehalfOf = new SqlParameter("@OnBehalfOf", SqlDbType.BigInt) { Value = scholarshipDetails.OnBehalfOf };
                var paramApplicationUrl = new SqlParameter("@ApplicationUrl", SqlDbType.NVarChar) { Value = scholarshipDetails.ApplicationUrl };
                var paramContactEmail = new SqlParameter("@ContactEmail", SqlDbType.NVarChar) { Value = scholarshipDetails.ContactEmail };
                var paramCreatedBy = new SqlParameter("@CreatedBy", SqlDbType.NVarChar) { Value = scholarshipDetails.CreatedBy };
                var paramUpdatedBy = new SqlParameter("@UpdatedBy", SqlDbType.NVarChar) { Value = scholarshipDetails.UpdatedBy };
                var paramReason = new SqlParameter("@Reason", SqlDbType.NVarChar) { Value = scholarshipDetails.Reason };
                var paramScholarshiptype = new SqlParameter("@Scholarshiptype", SqlDbType.BigInt) { Value = scholarshipDetails.Scholarshiptype };
                var paramScholarshipfeature = new SqlParameter("@Scholarshipfeature", SqlDbType.BigInt) { Value = scholarshipDetails.Scholarshipfeature };
                var paramViews = new SqlParameter("@TotalViews", SqlDbType.BigInt) { Value = scholarshipDetails.TotalViews };

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveScholarshipDetails",
                        paramid,
                        paramreferenceid,
                        paramTitleEn,
                        paramTitleAr,
                        paramDescriptionEn,
                        paramDescriptionAr,
                        paramBenefitsEn,
                        paramBenefitsAr,
                        paramNationalityId,
                        paramHigherEducationId,
                        paramMajorId,
                        paramActive,
                        paramYearId,
                        paramEligibilityEn,
                        paramEligibilityAr,
                        paramHowToApplyEn,
                        paramHowToApplyAr,
                        paramExpiryDate,
                        paramUploadImage,
                        paramStatusId,
                        paramOnBehalfOf,
                        paramApplicationUrl,
                        paramContactEmail,
                        paramCreatedBy,
                        paramUpdatedBy,
                        paramReason,
                        paramScholarshiptype,
                        paramScholarshipfeature,
                        paramViews
                       
                        ).ConfigureAwait(false);
                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                scholarshipDetails.Id = (long)paramreferenceid.Value;

                this.Logger.LogInformation("Exiting from SaveScholarshipDetails Method");
                return scholarshipDetails;
            }

            catch (Exception Ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in SaveSponsorshipDetails Method : " + Ex.ToString());
                throw Ex;
            }
        }
        public async Task<IEnumerable<ScholarshipDetails>> GetScholarshipDetailsAsync()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetScholarshipDetailsAsync method");
                IList<ScholarshipDetails> scholarshipDetails = new List<ScholarshipDetails>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetScholarshipDetails").ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                scholarshipDetails.Add(new ScholarshipDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    TitleEn = reader.ToStringValue("TitleEn"),
                                    TitleAr = reader.ToStringValue("TitleAr"),
                                    DescriptionEn = reader.ToStringValue("DescriptionEn"),
                                    DescriptionAr = reader.ToStringValue("DescriptionAr"),
                                    BenefitsEn = reader.ToStringValue("BenefitsEn"),
                                    BenefitsAr = reader.ToStringValue("BenefitsAr"),
                                    NationalityId = reader.To<int>("NationalityId"),
                                    HigherEducationId = reader.ToStringValue("HigherEducationId"),
                                    MajorId = reader.ToStringValue("MajorId"),
                                    Active = reader.To<bool>("Active"),
                                    YearId = reader.ToStringValue("YearId"),
                                    EligibilityEn = reader.ToStringValue("EligibilityEn"),
                                    EligibilityAr = reader.ToStringValue("EligibilityAr"),
                                    HowToApplyEn = reader.ToStringValue("HowToApplyEn"),
                                    HowToApplyAr = reader.ToStringValue("HowToApplyAr"),
                                    ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                    UploadImage = reader.ToStringValue("UploadImage"),
                                    StatusId = reader.To<int>("StatusId"),
                                    OnBehalfOf = reader.To<int>("OnBehalfOf"),
                                    ApplicationUrl = reader.ToStringValue("ApplicationUrl"),
                                    ContactEmail = reader.ToStringValue("ContactEmail"),
                                    CreatedBy = reader.ToStringValue("CreatedBy"),
                                    UpdatedBy = reader.ToStringValue("UpdatedBy"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    UpdatedDate = reader.To<DateTime>("UpdatedDate"),
                                    Reason = reader.ToStringValue("Reason"),
                                    Scholarshipfeature = reader.To<int>("Scholarshipfeature"),
                                    Scholarshiptype = reader.To<int>("Scholarshiptype"),
                                    PreviewImage = reader.ToStringValue("PreviewImage"),
                                    TotalViews=reader.To<long>("TotalViews")
                                });
                            }
                        }
                    }

                }
                this.Logger.LogInformation("Exiting from GetScholarshipDetailsAsync method");
                return scholarshipDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetScholarshipDetailsAsync method : " + ex.ToString());
                throw ex;
            }
        }
        public async Task<ScholarshipDetails> GetScholarshipDetailsAsync(long Id)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetScholarshipDetailsAsync for Id : " + Id.ToString());
                ScholarshipDetails scholarshipDetails = null;
                var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = Id };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                                                connection,
                                                                CommandType.StoredProcedure,
                                                                "GetScholarshipDetails",
                                                                paramId).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                scholarshipDetails = new ScholarshipDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    TitleEn = reader.ToStringValue("TitleEn"),
                                    TitleAr = reader.ToStringValue("TitleAr"),
                                    DescriptionEn = reader.ToStringValue("DescriptionEn"),
                                    DescriptionAr = reader.ToStringValue("DescriptionAr"),
                                    BenefitsEn = reader.ToStringValue("BenefitsEn"),
                                    BenefitsAr = reader.ToStringValue("BenefitsAr"),
                                    NationalityId = reader.To<int>("NationalityId"),
                                    HigherEducationId = reader.ToStringValue("HigherEducationId"),
                                    MajorId = reader.ToStringValue("MajorId"),
                                    Active = reader.To<bool>("Active"),
                                    YearId = reader.ToStringValue("YearId"),
                                    EligibilityEn = reader.ToStringValue("EligibilityEn"),
                                    EligibilityAr = reader.ToStringValue("EligibilityAr"),
                                    HowToApplyEn = reader.ToStringValue("HowToApplyEn"),
                                    HowToApplyAr = reader.ToStringValue("HowToApplyAr"),
                                    ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                    UploadImage = reader.ToStringValue("UploadImage"),
                                    StatusId = reader.To<int>("StatusId"),
                                    OnBehalfOf = reader.To<int>("OnBehalfOf"),
                                    ApplicationUrl = reader.ToStringValue("ApplicationUrl"),
                                    ContactEmail = reader.ToStringValue("ContactEmail"),
                                    CreatedBy = reader.ToStringValue("CreatedBy"),
                                    UpdatedBy = reader.ToStringValue("UpdatedBy"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    UpdatedDate = reader.To<DateTime>("UpdatedDate"),
                                    Reason = reader.ToStringValue("Reason"),
                                    Scholarshipfeature = reader.To<int>("Scholarshipfeature"),
                                    Scholarshiptype = reader.To<int>("Scholarshiptype"),
                                    PreviewImage = reader.ToStringValue("PreviewImage"),
                                    TotalViews = reader.To<long>("TotalViews")
                                };
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetScholarshipDetailsAsync for Id : " + Id.ToString());
                return scholarshipDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetScholarshipDetailsAsync method :" + ex.ToString());
                throw ex;
            }

        }
        public async Task<bool> InActiveScholarship(long Id)
        {
            try
            {
                this.Logger.LogInformation("Entering into InActiveScholarship method");
                var paramid = new SqlParameter("@Id", SqlDbType.BigInt) { Value = Id };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    await ExecuteNonQueryAsync(connection, CommandType.StoredProcedure, "InActiveScholarshipById", paramid).ConfigureAwait(false);
                }
                this.Logger.LogInformation("Exiting from InActiveScholarship method");
                return true;
            }

            catch (Exception Ex)
            {
                this.Logger.LogError("Error Occured", "Error in InActiveScholarship method :" + Ex.ToString());
                throw Ex;
            }
        }
        public async Task<ScholarshipDetails> SaveApprovalDetailsAsync(ScholarshipDetails scholarshipDetails)
        {
            try
            {
                this.logger.LogInformation("Entering into SaveApprovalDetailsAsync Method");
                var paramReferenceId = new SqlParameter("@ReferenceId", SqlDbType.BigInt) { Value = scholarshipDetails.Id, Direction = ParameterDirection.Output };
                var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = scholarshipDetails.Id };
                var paramStatusId = new SqlParameter("@StatusId", SqlDbType.Int) { Value = scholarshipDetails.StatusId };
                var paramUpdatedBy = new SqlParameter("@UpdatedBy", SqlDbType.NVarChar) { Value = scholarshipDetails.UpdatedBy };
                var paramReason = new SqlParameter("@Reason", SqlDbType.NVarChar) { Value = scholarshipDetails.Reason };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveApprovalDetails",
                            paramReferenceId,
                            paramId,
                            paramStatusId,
                            paramUpdatedBy,
                            paramReason
                            ).ConfigureAwait(false);
                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                return scholarshipDetails;
            }

            catch (Exception Ex)
            {
                this.logger.LogError("Error Occured", "ERROR in SaveApprovalDetailsAsync Method : " + Ex.ToString());
                throw Ex;
            }
        }

        public async Task<IEnumerable<ScholarshipDetails>> GetScholarshipDetailsForUser()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetScholarshipDetailsForUser method");
                IList<ScholarshipDetails> scholarshipDetails = new List<ScholarshipDetails>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetScholarshipDetailsForUser").ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                scholarshipDetails.Add(new ScholarshipDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    TitleEn = reader.ToStringValue("TitleEn"),
                                    TitleAr = reader.ToStringValue("TitleAr"),
                                    DescriptionEn = reader.ToStringValue("DescriptionEn"),
                                    DescriptionAr = reader.ToStringValue("DescriptionAr"),
                                    BenefitsEn = reader.ToStringValue("BenefitsEn"),
                                    BenefitsAr = reader.ToStringValue("BenefitsAr"),
                                    NationalityId = reader.To<int>("NationalityId"),
                                    HigherEducationId = reader.ToStringValue("HigherEducationId"),
                                    MajorId = reader.ToStringValue("MajorId"),
                                    Active = reader.To<bool>("Active"),
                                    YearId = reader.ToStringValue("YearId"),
                                    EligibilityEn = reader.ToStringValue("EligibilityEn"),
                                    EligibilityAr = reader.ToStringValue("EligibilityAr"),
                                    HowToApplyEn = reader.ToStringValue("HowToApplyEn"),
                                    HowToApplyAr = reader.ToStringValue("HowToApplyAr"),
                                    ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                    UploadImage = reader.ToStringValue("UploadImage"),
                                    StatusId = reader.To<int>("StatusId"),
                                    OnBehalfOf = reader.To<int>("OnBehalfOf"),
                                    ApplicationUrl = reader.ToStringValue("ApplicationUrl"),
                                    ContactEmail = reader.ToStringValue("ContactEmail")
                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetScholarshipDetailsForUser method");
                return scholarshipDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetScholarshipDetailsForUser method : " + ex.ToString());
                throw ex;
            }

        }

        public async Task<IEnumerable<ScholarshipDetails>> GetUserScholarshipDetailsList()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetUserScholarshipDetailsList method");
                IList<ScholarshipDetails> scholarshipDetailsUsers = new List<ScholarshipDetails>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {

                    using (var reader = await ExecuteReaderAsync(
                                                connection,
                                                CommandType.StoredProcedure,
                                                "GetUserScholarshipDetailsList").ConfigureAwait(false))
                    {

                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                scholarshipDetailsUsers.Add(new ScholarshipDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    TitleEn = reader.ToStringValue("TitleEn"),
                                    TitleAr = reader.ToStringValue("TitleAr"),
                                    DescriptionEn = reader.ToStringValue("DescriptionEn"),
                                    DescriptionAr = reader.ToStringValue("DescriptionAr"),
                                    BenefitsEn = reader.ToStringValue("BenefitsEn"),
                                    BenefitsAr = reader.ToStringValue("BenefitsAr"),
                                    NationalityId = reader.To<int>("NationalityId"),
                                    HigherEducationId = reader.ToStringValue("HigherEducationId"),
                                    MajorId = reader.ToStringValue("MajorId"),
                                    Active = reader.To<bool>("Active"),
                                    YearId = reader.ToStringValue("YearId"),
                                    EligibilityEn = reader.ToStringValue("EligibilityEn"),
                                    EligibilityAr = reader.ToStringValue("EligibilityAr"),
                                    HowToApplyEn = reader.ToStringValue("HowToApplyEn"),
                                    HowToApplyAr = reader.ToStringValue("HowToApplyAr"),
                                    ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                    UploadImage = reader.ToStringValue("UploadImage"),
                                    StatusId = reader.To<int>("StatusId"),
                                    OnBehalfOf = reader.To<int>("OnBehalfOf"),
                                    ApplicationUrl = reader.ToStringValue("ApplicationUrl"),
                                    ContactEmail = reader.ToStringValue("ContactEmail")
                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetUserScholarshipDetailsList method");
                return scholarshipDetailsUsers;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetUserScholarshipDetailsList method : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<ScholarshipDetails> GetScholarshipDetailsForUserId(long Id)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetScholarshipDetailsForUserId method" +Id.ToString());
                ScholarshipDetails ScholarshipDetailsForUsers = null;
                var paramid = new SqlParameter("@Id", SqlDbType.BigInt) { Value = Id };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                                connection,
                                                CommandType.StoredProcedure,
                                                "GetScholarshipsDetailId", paramid).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                ScholarshipDetailsForUsers = new ScholarshipDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    TitleEn = reader.ToStringValue("TitleEn"),
                                    TitleAr = reader.ToStringValue("TitleAr"),
                                    DescriptionEn = reader.ToStringValue("DescriptionEn"),
                                    DescriptionAr = reader.ToStringValue("DescriptionAr"),
                                    BenefitsEn = reader.ToStringValue("BenefitsEn"),
                                    BenefitsAr = reader.ToStringValue("BenefitsAr"),
                                    EligibilityEn = reader.ToStringValue("EligibilityEn"),
                                    EligibilityAr = reader.ToStringValue("EligibilityAr"),
                                    HowToApplyEn = reader.ToStringValue("HowToApplyEn"),
                                    HowToApplyAr = reader.ToStringValue("HowToApplyAr"),
                                    ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                    UploadImage = reader.ToStringValue("UploadImage"),
                                    ApplicationUrl = reader.ToStringValue("ApplicationUrl"),
                                    NationalityValueEn = reader.ToStringValue("NationalityEn"),
                                    HigherEducationValueEn = reader.ToStringValue("EducationEn"),
                                    MajorValueEn = reader.ToStringValue("MajorEn"),
                                    YearValueEn = reader.ToStringValue("YearEn"),
                                    NationalityValueAr = reader.ToStringValue("NationalityAr"),
                                    HigherEducationValueAr = reader.ToStringValue("EducationAr"),
                                    MajorValueAr = reader.ToStringValue("MajorAr"),
                                    YearValueAr = reader.ToStringValue("YearAr"),
                                    TotalViews= reader.To<long>("TotalViews"),
                                };
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetScholarshipDetailsForUserId method" + Id.ToString());
                return ScholarshipDetailsForUsers;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetScholarshipDetailsForUserId method : " + ex.ToString());
                throw ex;

            }
        }


        public async Task<Feedback> SaveFeedbackDetails(Feedback feedback)

        {
            try
            {
                this.Logger.LogInformation("Entering into SaveFeedbackDetails method");
                var paramid = new SqlParameter("@Id", SqlDbType.BigInt) { Value = feedback.Id };
                var paramreferenceid = new SqlParameter("@ReferenceId", SqlDbType.BigInt) { Value = feedback.Id, Direction = ParameterDirection.Output };
                var paramscholarshipid = new SqlParameter("@ScholarshipId", SqlDbType.BigInt) { Value = feedback.ScholarshipId };
                var paramStudentid = new SqlParameter("@StudentId", SqlDbType.BigInt) { Value = feedback.StudentId };
                //var paramfeedbackType = new SqlParameter("@FeedbackType", SqlDbType.Int) { Value = feedback.FeedbackType };
                var paramContent = new SqlParameter("@Content", SqlDbType.Int) { Value = feedback.Content };
                var paramdesign = new SqlParameter("@Design", SqlDbType.Int) { Value = feedback.Design };
                var parampersonalization = new SqlParameter("@Personalization", SqlDbType.Int) { Value = feedback.Personalization };
                var paramfunctionality = new SqlParameter("@Functionality", SqlDbType.Int) { Value = feedback.Functionality };
                var paramCreatedBy = new SqlParameter("@CreatedBy", SqlDbType.NVarChar) { Value = feedback.CreatedBy };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveFeedbackDetails",
                        paramid,
                        paramreferenceid,
                        paramscholarshipid,
                        paramStudentid,
                        //paramfeedbackType,
                        paramContent,
                        paramdesign,
                        parampersonalization,
                        paramfunctionality,
                        paramCreatedBy
                        ).ConfigureAwait(false);
                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }

                }
                feedback.Id = (long)paramreferenceid.Value;
                this.Logger.LogInformation("Exiting from SaveFeedbackDetails Method");
                return feedback;
            }

            catch (Exception Ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in SaveFeedbackDetails Method : " + Ex.ToString());
                throw Ex;
            }

        }

        public async Task<IEnumerable<ScholarshipDetails>> Getscholarshipgrid()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetScholarshipDetailsAsync method");
                IList<ScholarshipDetails> scholarshipDetails = new List<ScholarshipDetails>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetScholarshipGrid").ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                scholarshipDetails.Add(new ScholarshipDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    TitleEn = reader.ToStringValue("TitleEn"),
                                    TitleAr = reader.ToStringValue("TitleAr"),
                                    ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                    StatusId = reader.To<int>("StatusId"),
                                    OnBehalfOf = reader.To<int>("OnBehalfOf"),
                                    CreatedBy = reader.ToStringValue("CreatedBy"),
                                    UpdatedBy = reader.ToStringValue("UpdatedBy"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    UpdatedDate = reader.To<DateTime>("UpdatedDate"),
                                    Reason = reader.ToStringValue("Reason"),
                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetScholarshipDetailsAsync method");
                return scholarshipDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetScholarshipDetailsAsync method : " + ex.ToString());
                throw ex;
            }

        }
        
        public async Task<ScholarshipDetails> UpdateTotalViews(ScholarshipDetails viewsUpdate)
        {
            try
            {
                this.logger.LogInformation("Entering into UpdateTotalViews Method");
                var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = viewsUpdate.Id };
                var paramViews = new SqlParameter("@TotalViews", SqlDbType.BigInt) { Value = viewsUpdate.TotalViews };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "UpdateTotalViews",
                            paramId,
                            paramViews
                            ).ConfigureAwait(false);
                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                this.logger.LogInformation("Exiting from UpdateTotalViews Method");
                return viewsUpdate;
            }
            catch (Exception ex)
            {
                this.logger.LogError("Error Occured", "ERROR in UpdateTotalViews Method : " + ex.ToString());
                throw ex;
            }
        }

        // Report 1 DataTable
        public async Task<IEnumerable<ScholarshipDetails>> GetScholarViewCountStatisticsGrid(ScholarshipParam scholarshipParam)
         {
             try
             {
                this.Logger.LogInformation("Entering into GetScholarViewCountStatisticsGrid method");
                IList<ScholarshipDetails> scholarshipDetails = new List<ScholarshipDetails>();
                var paramStartDate = new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = scholarshipParam.StartDate };
                var paramEndDate = new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = scholarshipParam.EndDate };
                var paramPostedBy = new SqlParameter("@PostedBy", SqlDbType.NVarChar) { Value = scholarshipParam.PostedBy,IsNullable = true };

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                 {
                     using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, 
                         "GetScholarViewCountStatistics",paramStartDate,paramEndDate,paramPostedBy).ConfigureAwait(false))
                     {
                         if (reader.HasRows)
                         {
                             while (await reader.ReadAsync().ConfigureAwait(false))
                             {
                                 scholarshipDetails.Add(new ScholarshipDetails
                                 {
                                     Id = reader.To<long>("Id"),
                                     TotalScholarshipInPortal= reader.To<long>("TotalScholarshipInPortal"),
                                     AdminName =reader.ToStringValue("AdminName"),
                                     CreatedDate = reader.To<DateTime>("CreatedDate"),
                                     TitleEn = reader.ToStringValue("TitleEn"),
                                     TitleAr = reader.ToStringValue("TitleAr"),
                                     YearId = reader.ToStringValue("YearId"),
                                     Scholarshiptype = reader.To<int>("Scholarshiptype"),
                                     Scholarshipfeature = reader.To<int>("Scholarshipfeature"),
                                     Nationality = reader.ToStringValue("Nationality"),
                                     HigherEducationId = reader.ToStringValue("HigherEducationId"),
                                     MajorId = reader.ToStringValue("MajorId"),
                                     ApplicationUrl = reader.ToStringValue("ApplicationUrl"),
                                     ContactEmail = reader.ToStringValue("ContactEmail"),
                                     ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                     TotalViews = reader.To<long>("TotalViews"),
                                     TotalStudentsLoggedIn =reader.To<long>("TotalStudentsLoggedIn"),                                   
                                     EmployerAdmin = reader.To<long>("EmployerAdmin"),
                                     HeiAdmin = reader.To<long>("HeiAdmin"),
                                     GeneralAdmin= reader.To<long>("GeneralAdmin"),
                                     MoeAdmin = reader.To<long>("MoeAdmin"),
                                     RequestedRole=reader.To<int>("RequestedRole")
                                 });
                             }
                         }
                     }
                 }
                 this.Logger.LogInformation("Exiting from GetScholarshipDetailsAsync method");
                 return scholarshipDetails;
             }
             catch (Exception ex)
             {
                 this.Logger.LogError("Error Occured", "ERROR in GetScholarshipDetailsAsync method : " + ex.ToString());
                 throw ex;
             }

         }

        // Report 2 DataTable
        public async Task<IEnumerable<ScholarshipCount>> GetScholarshipListingStatisticsGrid(ScholarshipParam scholarshipParam)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetScholarshipListingStatisticsGrid method");
                IList<ScholarshipCount> scholarshipDetails = new List<ScholarshipCount>();
                var paramStartDate = new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = scholarshipParam.StartDate };
                var paramEndDate = new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = scholarshipParam.EndDate };
                var paramPostedBy = new SqlParameter("@PostedBy", SqlDbType.NVarChar) { Value = scholarshipParam.PostedBy,IsNullable = true };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, 
                        "GetScholarshipListingStatistics", paramStartDate, paramEndDate, paramPostedBy).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                scholarshipDetails.Add(new ScholarshipCount
                                {
                                   // Id = reader.To<long>("Id"),
                                    AdminName = reader.ToStringValue("AdminName"),
                                   // CreatedDate= reader.To<DateTime>("CreatedDate"),
                                   // ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                    TotalScholarshipPosted = reader.To<long>("TotalPosted"),
                                    TotalScholarshipPending = reader.To<long>("TotalPending"),
                                    TotalScholarshipApproved = reader.To<long>("TotalApproved"),
                                    TotalScholarshipRejected = reader.To<long>("TotalRejected"),
                                    RequestedRole=reader.To<int>("Role"),
                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetScholarshipListingStatisticsGrid method");
                return scholarshipDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetScholarshipListingStatisticsGrid method : " + ex.ToString());
                throw ex;
            }

        }

        // Report 3 DataTable
        public async Task<IEnumerable<Feedback>> GetScholarSubModuleFeedbackGrid(FeedbackParam feedbackParam)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetScholarSubModuleFeedbackGrid method");
                IList<Feedback> scholarshipDetails = new List<Feedback>();
                var paramStartDate = new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = feedbackParam.StartDate };
                var paramEndDate = new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = feedbackParam.EndDate };
               // var paramHigherEducation = new SqlParameter("@HigherEducation", SqlDbType.Int) { Value = feedbackParam.HigherEducation };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, 
                        "GetScholarSubModuleFeedback", paramStartDate, paramEndDate).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                scholarshipDetails.Add(new Feedback
                                {
                                    //StudentId = reader.To<long>("StudentId"),
                                    //ScholarshipId= reader.To<long>("ScholarshipId"),
                                    AdminName = reader.ToStringValue("AdminName"),
                                    Institute = reader.ToStringValue("Institute"),
                                    MajorId= reader.ToStringValue("MajorId"),
                                    Content = reader.To<int>("Content"),
                                    Personalization = reader.To<int>("Personalization"),
                                    Design = reader.To<int>("Design"),
                                    Functionality = reader.To<int>("Functionality"),
                                    //HigherEducationId= reader.ToStringValue("HigherEducationId"),
                                   // SatisfiedContent = reader.To<long>("SatisfiedContent"),
                                   // NotContent= reader.To<long>("NotContent"),
                                    //SatisfiedPersonalization=reader.To<long>("SatisfiedPersonalization"),
                                    //NotPersonalization= reader.To<long>("NotPersonalization"),
                                    //SatisfiedDesign= reader.To<long>("SatisfiedDesign"),
                                    //NotDesign = reader.To<long>("NotDesign"),
                                   // SatisfiedFunctionality= reader.To<long>("SatisfiedFunctionality"),
                                   // NotFunctionality=reader.To<long>("NotFunctionality"),
                                    RequestedRole = reader.To<int>("RequestedRole"),
                                    EmirateEn = reader.ToStringValue("EmirateEn"),
                                    EmirateAr = reader.ToStringValue("EmirateAr")

                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetScholarSubModuleFeedbackGrid method");
                return scholarshipDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetScholarSubModuleFeedbackGrid method : " + ex.ToString());
                throw ex;
            }

        }

        // CHART COUNT
        public async Task<IEnumerable<ScholarshipCount>> GetScholarshipReportCountDetails()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetScholarshipReportCountDetails");
                IList<ScholarshipCount> count = new List<ScholarshipCount>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                                connection,
                                                CommandType.StoredProcedure,
                                                "GetScholarshipReportCountDetails").ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                count.Add(new ScholarshipCount
                                {
                                    PostedDate = reader.IsDBNull("PostedDate") ? string.Empty : reader.GetString("PostedDate"),
                                    TotalScholarshipInPortal=reader.To<long>("TotalScholarshipInPortal"),
                                    TotalScholarshipBachelor = reader.To<long>("TotalScholarshipBachelor"),
                                    TotalScholarshipMaster= reader.To<long>("TotalScholarshipMaster"),
                                    TotalStudentsLoggedIn= reader.To<long>("TotalStudentsLoggedIn"),
                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetScholarshipReportCountDetails");
                return count;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetScholarshipReportCountDetails method :" + ex.ToString());
                throw ex;
            }
        }

    }
}
