﻿using SJP.Sponsorship.Api.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SJP.Scholarships.Api.DataAccess
{
    public interface IDropdownDataAccess
    {
        Task<IEnumerable<DropdownDetails>> GetDropdownDetailsAsyn();
    }
}
