﻿using SJP.Scholarships.Api.Model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SJP.Scholarships.Api.DataAccess
{
    public interface IScholarshipDataAccess
    {
        Task<ScholarshipDetails> SaveScholarshipDetailsAsync(ScholarshipDetails scholarshipClass);
        Task<IEnumerable<ScholarshipDetails>> GetScholarshipDetailsAsync();
        Task<ScholarshipDetails> GetScholarshipDetailsAsync(long Id);

        //Delete Scholarship
        Task<bool> InActiveScholarship(long Id);

        //Scholarship Approval
        Task<ScholarshipDetails> SaveApprovalDetailsAsync(ScholarshipDetails scholarshipDetails);

        //Scholarship Details For Users
        Task<IEnumerable<ScholarshipDetails>> GetScholarshipDetailsForUser();
        Task<IEnumerable<ScholarshipDetails>> GetUserScholarshipDetailsList();
        Task<ScholarshipDetails> GetScholarshipDetailsForUserId(long Id);
        Task<Feedback> SaveFeedbackDetails(Feedback feedback);
        Task<IEnumerable<ScholarshipDetails>> Getscholarshipgrid();
        Task<ScholarshipDetails> UpdateTotalViews(ScholarshipDetails viewsUpdate);
        Task<IEnumerable<ScholarshipDetails>> GetScholarViewCountStatisticsGrid(ScholarshipParam scholarshipParam);
        Task<IEnumerable<ScholarshipCount>> GetScholarshipListingStatisticsGrid(ScholarshipParam scholarshipParam);
        Task<IEnumerable<Feedback>> GetScholarSubModuleFeedbackGrid(FeedbackParam feedbackParam);
        Task<IEnumerable<ScholarshipCount>> GetScholarshipReportCountDetails();


    }
}
