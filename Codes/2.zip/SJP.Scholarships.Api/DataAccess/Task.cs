﻿namespace SJP.Scholarships.Api.DataAccess
{
    internal class Task<T1, T2>
    {
    }
}