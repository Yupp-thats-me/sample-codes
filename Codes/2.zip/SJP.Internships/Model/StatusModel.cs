﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Internships.Api.Model
{
    public class StatusModel
    {
        public int StatusId { get; set; }
        public int Id { get; set; }
    }
}
