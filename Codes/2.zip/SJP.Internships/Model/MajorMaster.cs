﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Internships.Api.Model
{
    public class MajorMaster
    {
        public long MajorId { get; set; }
        public string MajorValueEn { get; set; }
        public string MajorValueAr { get; set; }
        public long ParentId { get; set; }
        public bool IsActive { get; set; }
        public List<MajorMaster> Children { get; set; }

    }
}
