﻿using SJP.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Internships.Api.Model
{
    public class UserAnswerDetails : DomainObject
    {
        //public long Id { get; set; }
        public long? QuestionnaireId { get; set; }
        public long? StudentId { get; set; }
        public string Answers { get; set; }

    }
}
