﻿namespace SJP.Internships.Api.Model.Report
{
    public class RatingReportModel
    {
        public string StudentName { get; set; }
        public int? Emirate { get; set; }
        public string EmirateEn { get; set; }
        public string EmirateAr { get; set; }
        public int Content { get; set; }
        public int Design { get; set; }
        public int Personalization { get; set; }
        public int Functionality { get; set; }
        public int MajorId { get; set; }
        public int InstituteId { get; set; }
        public string EnInstituteName { get; set; }
        public string ArInstituteName { get; set; }
    }
}
