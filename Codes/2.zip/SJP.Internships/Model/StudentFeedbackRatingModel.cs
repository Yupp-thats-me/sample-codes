﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Internships.Api.Model
{
    public class StudentFeedbackRatingModel
    {
        public long Id { get; set; }
        public long StudentFeedbackId { get; set; }
        public int? ParameterId { get; set; }
        public int Rating { get; set; }
        public bool IsApplicable { get; set; }
        public string? CreatedBy { get; set; }
        // public DateTime? CreatedDate { get; set; }
        public long? DropdownId { get; set; }
        public string? DropdownValueEn { get; set; }
        public string? DropdownValueAr { get; set; }


        
    }
}
