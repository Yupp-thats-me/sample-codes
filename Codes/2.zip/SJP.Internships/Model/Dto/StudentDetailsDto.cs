﻿using System;
using System.Collections.Generic;

namespace SJP.Internships.Api.Model.Dto
{
    public class StudentDetailsDto
    {
        public long Id { get; set; }
        public long InternshipId { get; set; }
        public long StudentId { get; set; }
        public DateTime CreatedDate { get; set; }
        public string StudentName { get; set; }
        public string Email { get; set; }
        public long MobileNo { get; set; }
        public string PermanentAddressLine1 { get; set; }
        public string Emirate { get; set; }
        public string Filename { get; set; }
        public string Resume { get; set; }
        public int Status { get; set; }
        public DateTime ProbableJoiningDate { get; set; }
        public int Applied { get; set; }
        public int Withdrawn { get; set; }
        public int Shortlisted { get; set; }
        public int Rejected { get; set; }
        public int Interviewed { get; set; }
        public int IsInterviewed { get; set; }
        public int DroppedOut { get; set; }
        public int IsDroppedOut { get; set; }
        public int Offered { get; set; }
        public int ScreenedOut { get; set; }
        public int Declined { get; set; }
        public int Accepted { get; set; }
        public int Hired { get; set; }
        public List<InternshipQuestionnaireDetails> InternshipQuestionnaireDetails { get; set; }
        public string InternshipRoleNameEn { get; set; }
        public string InternshipRoleNameAr { get; set; }
        public string CompanyNameEn { get; set; }
        public string CompanyNameAr { get; set; }
        public DateTime DisagreedDate { get; set; }
        public string DisagreedReason { get; set; }
        public string MajorId { get; set; }
        public string Institute { get; set; }
        public long ResumeId { get; set; }
        public DateTime CutoffDate { get; set; }
        public string CutOffReturn { get; set; }
        public int MonthlySalaryRangeId { get; set; }
        public string? SupervisorDesignation { get; set; }
        public int? Term { get; set; }
        public int? Duration { get; set; }
        public DateTime JoiningDate { get; set; }
        public bool IsSubmitted { get; set; }
        public DateTime ExpiryDate { get; set; }
    }
}
