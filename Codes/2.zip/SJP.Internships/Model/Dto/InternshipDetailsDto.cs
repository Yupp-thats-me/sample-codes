﻿using System;
using System.Collections.Generic;

namespace SJP.Internships.Api.Model.Dto
{
    public class InternshipDetailsDto
    {
        public long Id { get; set; }
        public string UploadImage { get; set; }
        public int InternshipTypeId { get; set; }
        public string InternshipTitleEn { get; set; }
        public string InternshipTitleAr { get; set; }
        public string DescriptionEn { get; set; }
        public string DescriptionAr { get; set; }
        public string EligibilityEn { get; set; }
        public string EligibilityAr { get; set; }
        public string CountryId { get; set; }
        public string EmirateId { get; set; }
        public string HigherEducationId { get; set; }
        public int GenderId { get; set; }
        public int AgeId { get; set; }
        public string MajorId { get; set; }
        public DateTime JoiningDate { get; set; }
        public string Duration { get; set; }
        public int NumberOfPositionsId { get; set; }
        public int MinimumHoursRequiredId { get; set; }
        public string OrganizationLink { get; set; }
        public string IndustryName { get; set; }
        public string InternshipRoleNameEn { get; set; }
        public string InternshipRoleNameAr { get; set; }
        public int MonthlySalaryRangeId { get; set; }
        public string HowToApplyEn { get; set; }
        public string HowToApplyAr { get; set; }
        public string ContactEmail { get; set; }
        public DateTime ExpiryDate { get; set; }
        public int StatusId { get; set; }
        public int OnBehalfOf { get; set; }
        public bool IsActive { get; set; }
        public string Reason { get; set; }
        public List<InternshipQuestionnaireDetails> InternshipQuestionnaireDetails { get; set; }
        public string Status { get; set; }
        public string questions { get; set; }
        public string AgeEn { get; internal set; }
        public string AgeAr { get; internal set; }
        public string MonthlySalaryRangeEn { get; internal set; }
        public string MonthlySalaryRangeAr { get; internal set; }
        public bool IsProbable { get; set; }
        public DateTime? LastProbableJoiningDate { get; set; }
        public int InternshipFor { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate {get; set;}
        public string UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string IndustryNameEn { get; internal set; }
        public string IndustryNameAr { get; internal set; }
        public long? UserId { get; set; }
        public DateTime ApplicationDeadline { get; set; }
        public string? CompanyNameEn { get; set; }
        public string? CompanyNameAr { get; set; }
        public string EmirateEn { get; internal set; }
        public string EmirateAr { get; internal set; }
        public long UserInternshipId { get; set; }
        public long StudentId { get; set; }
        public string PostedDays { get; set; }
        public long? DropdownId { get; set; }
        public string? Stream { get; set; }
        public int? RequestedRole { get; set; }
        public int? FieldofTraining { get; set; }
      //  public long? TotalViews { get; set; }

    }
}