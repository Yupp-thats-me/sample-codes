﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Internships.Api.Model.Dto
{
    public class InternshipQuestionnaireDetailsDto
    {
        public long QuestionnaireId { get; set; }
        public long InternshipId { get; set; }
        public int Type { get; set; }
        public string Questions { get; set; }
        public string Options1 { get; set; }
        public string Options2 { get; set; }
        public string Options3 { get; set; }
        public string Options4 { get; set; }
        public string Answers { get; set; }

    }
}
