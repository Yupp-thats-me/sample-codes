﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Internships.Api.Model.Dto
{
    public class MailTrackingDto
    {
        public long Id { get; internal set; }
        public long StudentId { get; set; }
        public long InternshipId { get; set; }
        public string FromEmail { get; set; }
        public string ToEmail { get; set; }
        public string CcEmail { get; set; }
        public string Subject { get; set; }
        public string EmailContent { get; set; }
        public string Attachment { get; set; }
        public int Status { get; set; }
        public string CreatedBy { get; internal set; }
    }
}
