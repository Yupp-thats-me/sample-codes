﻿using System;
using System.Collections.Generic;

namespace SJP.Internships.Api.Model.Dto
{
    public class UserApplyDetailsDto 
    {
        public long Id { get; set; }
        public long InternshipId { get; set; }
        public long StudentId { get; set; }
        public int Content { get; set; }
        public int Design { get; set; }
        public int Personalization { get; set; }
        public int Functionality { get; set; }
        public string UploadDocument { get; set; }
        public string DocumentTitle { get; set; }
        public string KeySkills { get; set; }
        public DateTime ProbableJoiningDate { get; set; }
        public bool IsStudentProfile { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public List<UserAnswerDetails> AnswerDetails { get; set; }
        public int StatusId { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public bool IsDisagreed { get; set; }
        public DateTime DisagreedDate { get; set; }
        public string DisagreedReason { get; set; }
    }
}
