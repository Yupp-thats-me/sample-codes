﻿
using Microsoft.AspNetCore.Mvc;
using SJP.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace SJP.Internships.Api.Model.Dto
{
    public class ReportModelDto
    {
        public string InternshipCounsellorName { get; set; }
        public string StudentsName { get; set; }
        public DateTime StudentApplieddate { get; set; }
        public string StudentsEmirate { get; set; }
        public int StudentsGender { get; set; }
        public string StudentsMajor { get; set; }
        public int ApplicationStatus { get; set; }
        public string ReasonforRejection { get; set; }
        public string CompanyNameEn { get; set; }
        public string CompanyNameAr { get; set; }
        public string InternshipTitleEn { get; set; }
        public string InternshipTitleAr { get; set; }
        public string InternshipRoleEn { get; set; }
        public string InternshipRoleAr { get; set; }
        public int NumberOfPositions { get; set; }
        public int InternshipType { get; set; }
        public int IndustryName { get; set; }
        public int EducationCategory { get; set; }
        public int EducationLevel { get; set; }
        public DateTime PostedDate { get; set; }
        public DateTime ApplicationDeadline { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int InternshipDuration { get; set; }
        public string InstituteNameEn { get; set; }
        public string InstituteNameAr { get; set; }
        public string EmirateNameEn { get; set; }
        public string EmirateNameAr { get; set; }
        public int RecruitmentStatus { get; set; }
        public long TotalInternshipPosted { get; set; }
        public long TotalFullTimePosted { get; set; }
        public long MostInternshipByCompany { get; set; }
        public long TotalGeneralPosted { get; set; }
        public long TotalHigherPosted { get; set; }
        public int TotalPosted { get; set; }
        public int TotalApproved { get; set; }
        public int TotalRejected { get; set; }
        public int TotalPending { get; set; }
        public string OrganizationName { get; set; }
        public string StudentName { get; set; }
        public string Institute { get; set; }
        public string MajorId { get; set; }
        public string EmirateEn { get; set; }
        public int SatisfiedContent { get; set; }
        public int NotContent { get; set; }
        public int SatisfiedPersonalization { get; set; }
        public int NotPersonalization { get; set; }
        public int SatisfiedDesign { get; set; }
        public int NotDesign { get; set; }
        public int SatisfiedFunctionality { get; set; }
        public int NotFunctionality { get; set; }
        public int Content { get; set; }
        public int Personalization { get; set; }
        public int Design { get; set; }
        public int Functionality { get; set; }
        public string SupervisorName { get; set; }
        public string SupervisorDesignation { get; set; }
        public DateTime DateofInternship { get; set; }
        public int EmployerOrientation { get; set; }
        public int TaskAssinged { get; set; }
        public int Employerliaise { get; set; }
        public int EmployerAgreeplan { get; set; }
        public int EmployerConductInterview { get; set; }
        public int ClearWhoYourManager { get; set; }
        public int SupervisorPerformance { get; set; }
        public int SupervisorTeamMeeting { get; set; }
        public int Exceptation { get; set; }
        public int RecommendEmployer { get; set; }
        public int OverallRating { get; set; }
        public string AnyFeedbackforEmployer { get; set; }
        public string InternshipCounsellorAgreed { get; set; }
        public string InternshipCounsellorDisAgreed { get; set; }
        public int TotalInternshipCounsellorAgreed { get; set; }
        public int TotalInternshipCounsellorDisAgreed { get; set; }
        public int TotalHigherEducationSatisfactory { get; set; }
        public int TotalHigherEducationNotSatisfactory { get; set; }
        public int TotalGeneralEducationSatisfactory { get; set; }
        public int TotalGeneralEducationNotSatisfactory { get; set; }
        public int ScientificLiteracy { get; set; }
        public int TechLiteracy { get; set; }
        public int FinancialLiteracy { get; set; }
        public int CriticalThinking { get; set; }
        public int Creativity { get; set; }
        public int Communication { get; set; }
        public int Collaboration { get; set; }
        public int Adaptability { get; set; }
        public int Leadership { get; set; }
        public int SocialCulturalAwareness { get; set; }
        public int Empathy { get; set; }
        public int GrowthMindset { get; set; }
        public int OverallSatisfaction { get; set; }
        public string DescriptionPerformedbyIntern { get; set; }
        public string StrengthsofIntern { get; set; }
        public string SuggestedDevelopmentAreas { get; set; }
        public string OtherComments { get; set; }
        public long HigherSatisfactory { get; set; }
        public long GeneralSatisfactory { get; set; }

        public long TotalHigherEducation { get; set; }
        public long TotalGeneralEducation { get; set; }
        public long TotalShortlisted { get; set; }
        public long TotalInterviewed { get; set; }
        public long TotalHired { get; set; }
        public string Education { get; set; }

        public string Industry { get; set; }

        public int? Emirate { get; set; }
        public int InstituteId { get; set; }
        public string EnInstituteName { get; set; }
        public string EmirateAr { get; set; }
        public string ArInstituteName { get; set; }

        // public int? Emirate { get; set; }
        // public int InstituteId { get; set; }
        //  public string InstitutenameEn { get; set; }
        //  public string ElementAr { get; set; }
        // public string InstitutenameAr { get; set; }
        public int MaxCount { get; set; }
        public int MinCount { get; set; }
        public string MaxCompany { get; set; }
        public string MinCompany { get; set; }

        public string MajorEn { get; set; }
        public string MajorAr { get; set; }
        public long IsDisagreed { get; set; }



    }
}
