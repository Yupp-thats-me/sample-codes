﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Internships.Api.Model.Dto
{
    public class UserAnswerDetailsDto
    {
        public long Id { get; set; }
        public long? QuestionnaireId { get; set; }
        public long? StudentId { get; set; }
        public string Answers { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
