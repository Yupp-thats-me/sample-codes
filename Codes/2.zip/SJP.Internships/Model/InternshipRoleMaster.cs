﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Internships.Api.Model
{
    public class InternshipRoleMaster
    {
        public int InternshipRoleId { get; set; }
        public string InternshipRoleNameEn { get; set; }
        public string InternshipRoleNameAr { get; set; }
    }
}
