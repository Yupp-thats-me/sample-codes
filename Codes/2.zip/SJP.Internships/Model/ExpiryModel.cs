﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Internships.Api.Model
{
    public class ExpiryModel
    {
        public DateTime ExpiryDate { get; set; }
        public int Id { get; set; }
    }
}
