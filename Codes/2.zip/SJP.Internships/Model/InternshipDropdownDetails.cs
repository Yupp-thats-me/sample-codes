﻿using SJP.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Internships.Api.Model
{
    public class InternshipDropdownDetails : DomainObject
    {
        public long DropdownId { get; set; }
        public string DropdownValueEn { get; set; }
        public string DropdownValueAr { get; set; }
        public string Category { get; set; }
        public bool IsActive { get; set; }
        public string ShortName { get; set; }
        public int StatusId { get; set; }
    }
}
