﻿using SJP.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Internships.Api.Model
{
    public class StudentFeedbackDetails : DomainObject
    {
        public long? StudentFeedbackId { get; set; }
        public long InternshipId { get; set; }
        public long StudentId { get; set; }
        public long UserId { get; set; }
        public int? Term { get; set; }
        public bool? IsPaidInternship { get; set; }
        public long EmployerId { get; set; }
        public string SupervisorName { get; set; }
        public string SupervisorDesignation { get; set; }
        public string SupervisorEmailId { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string? StudentName { get; set; }
        public string? Email { get; set; }
        public string? StudentLocation { get; set; }
        public string? Location { get; set; }
        public string? InternshipRoleNameEn { get; set; }
        public string? InternshipRoleNameAr { get; set; }
        public string? MajorEn { get; set; }
        public string? MajorAr { get; set; }
        public int Status { get; set; }
        public long MobileNo { get; set; }
        public string? Institute { get; set; }
        public string EmployerName { get; set; }
        public string AccountTYpe { get; set; }
        public string? Department { get; set; }
        public DateTime JoiningDate { get; set; }
        public int MonthlySalaryRangeId { get; set; }
        public int MinimumHoursRequiredId { get; set; }
        public int Duration { get; set; }

        public string? AnyFeedback { get; set; }
        public List<StudentFeedbackRatingModel> StudentFeedbackRatingModel { get; set; }
        public string? PhoneNumber { get; set; }
        public string? CompanyNameEn { get; set; }
        public string? CompanyNameAr { get; set; }
        public string? HEI { get; set; }
        public DateTime? CutOffDate { get; set; }
        public DateTime? CompletionDate { get; set; }
    }
}
