﻿using SJP.Internships.Api.Model;
using SJP.Internships.Api.Model.Report;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SJP.Internships.Api.DataAccess
{
    public interface IReportDataAccess
    {
        Task<IEnumerable<ReportModel>> StudentsReviewedbyInternship(InternshipsParams internshipsParam);
        Task<IEnumerable<ReportModel>> GetInternListingsSummary(InternshipsParams internshipsParam);
        Task<IEnumerable<ReportModel>>GetInternshipPostStatistics(InternshipsParams internshipsParam);
        Task<IEnumerable<RatingReportModel>> GetInternshipModuleFeedback(InternshipsParams internshipsParam);
        Task<IEnumerable<ReportModel>> GetInternApplicationSummary(InternshipsParams internshipsParam);
        Task<IEnumerable<ReportModel>> StudentsFeedback(InternshipsParams internshipsParam);
        Task<IEnumerable<ReportModel>> GetCompanyFeedbackOnStudents(InternshipsParams internshipsParam);


    }
}
