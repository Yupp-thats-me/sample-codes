﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Internships.Api.Model;
using SJP.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Extensions;
using System.Linq;
using System.Threading.Tasks;
using SJP.DataAccess.Extensions;
using System.Data.SqlClient;
using SJP.Core.Model;
using SJP.Internships.Api.Model.Report;

namespace SJP.Internships.Api.DataAccess
{

    public class ReportDataAccess : DataAccessBase, IReportDataAccess
    {
        private readonly ILogger logger;
        protected ILogger Logger => logger;
        public ReportDataAccess(ILogger<ReportDataAccess> logger, IConfiguration configuration) : base(configuration)
        {
            this.logger = logger;
        }

        //Report 1
        public async Task<IEnumerable<ReportModel>> GetInternListingsSummary(InternshipsParams internshipsParam)
        {
            try
            {
                this.Logger.LogInformation("Entering into StudentsReviewedbyInternship method");
                IList<ReportModel> internshipsDetails = new List<ReportModel>();
                var paramStartDate = new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = internshipsParam.StartDate };
                var paramEndDate = new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = internshipsParam.EndDate };
                var paramPostedBy = new SqlParameter("@PostedBy", SqlDbType.Int) { Value = internshipsParam.AdminName, IsNullable = true };
                var paramInternshipRole = new SqlParameter("@InternRole", SqlDbType.NVarChar) { Value = internshipsParam.InternRole, IsNullable = true };


                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure,
                        "GetInternListingSummary", paramStartDate, paramEndDate, paramPostedBy, paramInternshipRole).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                internshipsDetails.Add(new ReportModel
                                {
                                    CompanyNameEn = reader.ToStringValue("CompanyNameEn"),
                                    CompanyNameAr = reader.ToStringValue("CompanyNameAr"),
                                    InternshipTitleEn = reader.ToStringValue("InternshipTitleEn"),
                                    InternshipTitleAr = reader.ToStringValue("InternshipTitleAr"),
                                    InternshipRoleEn = reader.ToStringValue("InternshipRoleEn"),
                                    InternshipRoleAr = reader.ToStringValue("InternshipRoleAr"),
                                    NumberOfPositions = reader.To<int>("NumberOfPositions"),
                                    InternshipType = reader.To<int>("InternshipType"),
                                    Industry = reader.ToStringValue("Industry"),
                                    Education = reader.ToStringValue("Education"),
                                    EducationCategory = reader.To<int>("EducationCategory"),
                                    StudentsMajor = reader.ToStringValue("StudentsMajor"),
                                    PostedDate = reader.To<DateTime>("PostedDate"),
                                    ApplicationDeadline = reader.To<DateTime>("ApplicationDeadline"),
                                    StartDate = reader.To<DateTime>("StartDate"),
                                    EndDate = reader.To<DateTime>("EndDate"),
                                    InternshipDuration = reader.To<int>("InternshipDuration"),
                                    TotalInternshipPosted = reader.To<long>("TotalInternshipPosted"),
                                    TotalFullTimePosted = reader.To<long>("TotalFullTimePosted"),
                                    MostInternshipByCompany = reader.To<long>("MostInternshipByCompany"),
                                    TotalGeneralPosted = reader.To<long>("TotalGeneralPosted"),
                                    TotalHigherPosted = reader.To<long>("TotalHigherPosted"),
                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from StudentsReviewedbyInternship method");
                return internshipsDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in StudentsReviewedbyInternship method : " + ex.ToString());
                throw ex;
            }
        }

        // Report 2

        public async Task<IEnumerable<ReportModel>> GetInternshipPostStatistics(InternshipsParams internshipsParam)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetInternshipPostStatistics method");
                IList<ReportModel> internshipsDetails = new List<ReportModel>();
                var paramStartDate = new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = internshipsParam.StartDate };
                var paramEndDate = new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = internshipsParam.EndDate };
                var paramAdminName = new SqlParameter("@AdminName", SqlDbType.Int) { Value = internshipsParam.AdminName, IsNullable = true };


                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure,
                        "GetInternshipPostStatistics", paramStartDate, paramEndDate, paramAdminName).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                internshipsDetails.Add(new ReportModel
                                {
                                    OrganizationName = reader.ToStringValue("OrganizationName"),
                                    TotalPosted = reader.To<int>("TotalPosted"),
                                    TotalApproved = reader.To<int>("TotalApproved"),
                                    TotalRejected = reader.To<int>("TotalRejected"),
                                    TotalPending = reader.To<int>("TotalPending")
          

                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetInternshipPostStatistics method");
                return internshipsDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetInternshipPostStatistics method : " + ex.ToString());
                throw ex;
            }

        }


        //Report 3
        public async Task<IEnumerable<ReportModel>> GetInternApplicationSummary(InternshipsParams internshipsParam)
        {
            try
            {
                this.Logger.LogInformation("Entering into StudentsReviewedbyInternship method");
                IList<ReportModel> internshipsDetails = new List<ReportModel>();
                var paramStartDate = new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = internshipsParam.StartDate };
                var paramEndDate = new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = internshipsParam.EndDate };
                var paramEducationCategory = new SqlParameter("@EducationCategory", SqlDbType.Int) { Value = internshipsParam.EducationCategory, IsNullable = true };
                var paramEducationLevel = new SqlParameter("@EducationLevel", SqlDbType.NVarChar) { Value = internshipsParam.EducationLevel, IsNullable = true };
                var paramRecruitmentStatus = new SqlParameter("@RecruitmentStatus", SqlDbType.Int) { Value = internshipsParam.RecruitmentStatus, IsNullable = true };
                var paramCompanyName = new SqlParameter("@CompanyName", SqlDbType.NVarChar) { Value = internshipsParam.CompanyName, IsNullable = true };
                var paramIndustry = new SqlParameter("@Industry", SqlDbType.NVarChar) { Value = internshipsParam.Industry, IsNullable = true };


                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure,
                        "GetInternApplicationSummary", paramStartDate, paramEndDate, paramEducationCategory, paramEducationLevel, paramRecruitmentStatus).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                internshipsDetails.Add(new ReportModel
                                {
                                    StudentsName = reader.ToStringValue("StudentsName"),
                                    CompanyNameEn = reader.ToStringValue("CompanyNameEn"),
                                    CompanyNameAr = reader.ToStringValue("CompanyNameAr"),
                                    InternshipTitleEn = reader.ToStringValue("InternshipTitleEn"),
                                    InternshipTitleAr = reader.ToStringValue("InternshipTitleAr"),
                                    EducationLevel = reader.To<int>("EducationLevel"),
                                    EducationCategory = reader.To<int>("EducationCategory"),
                                    RecruitmentStatus = reader.To<int>("RecruitmentStatus"),
                                    InternshipRoleEn = reader.ToStringValue("InternshipRoleEn"),
                                    InternshipRoleAr = reader.ToStringValue("InternshipRoleAr"),
                                    Industry = reader.ToStringValue("Industry"),
                                    PostedDate = reader.To<DateTime>("PostedDate"),
                                    InstituteNameEn = reader.ToStringValue("InstituteNameEn"),
                                    InstituteNameAr = reader.ToStringValue("InstituteNameAr"),
                                    MajorEn = reader.ToStringValue("MajorEn"),
                                    MajorAr = reader.ToStringValue("MajorAr"),
                                    EmirateNameEn = reader.ToStringValue("EmirateNameEn"),
                                    EmirateNameAr = reader.ToStringValue("EmirateNameAr"),
                                    StudentsGender = reader.To<int>("StudentsGender"),
                                    TotalHigherEducation = reader.To<long>("TotalHigherEducation"),
                                    TotalGeneralEducation = reader.To<long>("TotalGeneralEducation"),
                                    TotalShortlisted = reader.To<long>("TotalShortlisted"),
                                    TotalInterviewed = reader.To<long>("TotalInterviewed"),
                                    TotalHired = reader.To<long>("TotalHired")

                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetInternApplicationSummary method");
                return internshipsDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetInternApplicationSummary method : " + ex.ToString());
                throw ex;
            }


        }

        //Report 4
        public async Task<IEnumerable<ReportModel>> StudentsReviewedbyInternship(InternshipsParams internshipsParam)
        {
            try
            {
                this.Logger.LogInformation("Entering into StudentsReviewedbyInternship method");
                IList<ReportModel> internshipsDetails = new List<ReportModel>();
                var paramStartDate = new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = internshipsParam.StartDate };
                var paramEndDate = new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = internshipsParam.EndDate };
                var paramEducationCategory = new SqlParameter("@EducationCategory", SqlDbType.Int) { Value = internshipsParam.EducationCategory, IsNullable = true };
                var paramEducationLevel = new SqlParameter("@EducationLevel", SqlDbType.Int) { Value = internshipsParam.EducationLevel, IsNullable = true };
                var paramInstituteName = new SqlParameter("@InstituteName", SqlDbType.Int) { Value = internshipsParam.InstituteName, IsNullable = true };


                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure,
                        "StudentsReviewedbyInternship", paramStartDate, paramEndDate, paramEducationCategory, paramEducationLevel, paramInstituteName).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                internshipsDetails.Add(new ReportModel
                                {
                                    InternshipCounsellorName = reader.ToStringValue("InternshipCounsellorName"),
                                    InstituteNameEn = reader.ToStringValue("InstituteNameEn"),
                                    InstituteNameAr = reader.ToStringValue("InstituteNameAr"),
                                    InternshipRoleEn = reader.ToStringValue("InternshipRoleEn"),
                                    InternshipRoleAr = reader.ToStringValue("InternshipRoleAr"),
                                    StudentsName = reader.ToStringValue("StudentsName"),
                                    StudentApplieddate = reader.To<DateTime>("StudentApplieddate"),
                                    EmirateNameEn = reader.ToStringValue("EmirateNameEn"),
                                    EmirateNameAr = reader.ToStringValue("EmirateNameAr"),
                                    StudentsGender = reader.To<int>("StudentsGender"),
                                    MajorAr = reader.ToStringValue("MajorAr"),
                                    MajorEn = reader.ToStringValue("MajorEn"),
                                    ApplicationStatus = reader.To<int>("ApplicationStatus"),
                                    ReasonforRejection = reader.ToStringValue("ReasonforRejection"),
                                    IsDisagreed = reader.To<long>("IsDisagreed"),
                                    //InternshipCounsellorAgreed = reader.ToStringValue("InternshipCounsellorAgreed"),
                                    //InternshipCounsellorDisAgreed = reader.ToStringValue("InternshipCounsellorDisAgreed"),
                                    //TotalInternshipCounsellorAgreed = reader.To<int>("TotalInternshipCounsellorAgreed"),
                                    //TotalInternshipCounsellorDisAgreed = reader.To<int>("TotalInternshipCounsellorDisAgreed"),



                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from StudentsReviewedbyInternship method");
                return internshipsDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in StudentsReviewedbyInternship method : " + ex.ToString());
                throw ex;
            }
        }


        //Report5
        public async Task<IEnumerable<ReportModel>> StudentsFeedback(InternshipsParams internshipsParam)
        {
            try
            {
                this.Logger.LogInformation("Entering into StudentsFeedback method");
                IList<ReportModel> internshipsDetails = new List<ReportModel>();
                var paramStartDate = new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = internshipsParam.StartDate };
                var paramEndDate = new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = internshipsParam.EndDate };
                var paramEducationCategory = new SqlParameter("@EducationCategory", SqlDbType.Int) { Value = internshipsParam.EducationCategory, IsNullable = true };
                var paramEducationLevel = new SqlParameter("@EducationLevel", SqlDbType.Int) { Value = internshipsParam.EducationLevel, IsNullable = true };
                var paramCompanyName = new SqlParameter("@CompanyName", SqlDbType.NVarChar) { Value = internshipsParam.CompanyName, IsNullable = true };


                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure,
                        "StudentsFeedback", paramStartDate, paramEndDate, paramEducationCategory, paramEducationLevel, paramCompanyName).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                internshipsDetails.Add(new ReportModel
                                {
                                    StudentsName = reader.ToStringValue("StudentName"),
                                    InternshipRoleEn = reader.ToStringValue("InternshipRoleEn"),
                                    // InternshipRoleAr = reader.ToStringValue("InternshipRoleAr"),
                                    CompanyNameEn = reader.ToStringValue("CompanyNameEn"),
                                    // CompanyNameAr = reader.ToStringValue("CompanyNameAr"),
                                    InstituteNameEn = reader.ToStringValue("InstituteNameEn"),
                                    // InstituteNameAr = reader.ToStringValue("InstituteNameAr"),
                                    // StudentsMajor = reader.ToStringValue("StudentMajor"),
                                    MajorAr = reader.ToStringValue("MajorAr"),
                                    MajorEn = reader.ToStringValue("MajorEn"),
                                    SupervisorName = reader.ToStringValue("SupervisorName"),
                                    SupervisorDesignation = reader.ToStringValue("SupervisorDesignation"),
                                    DateofInternship = reader.To<DateTime>("DateofInternship"),
                                    EmployerOrientation = reader.To<int>("EmployerOrientation"),
                                    TaskAssinged = reader.To<int>("TaskAssinged"),
                                    Employerliaise = reader.To<int>("Employerliaise"),
                                    EmployerAgreeplan = reader.To<int>("EmployerAgreeplan"),
                                    EmployerConductInterview = reader.To<int>("EmployerConductInterview"),
                                    ClearWhoYourManager = reader.To<int>("ClearWhoYourManager"),
                                    SupervisorPerformance = reader.To<int>("SupervisorPerformance"),
                                    SupervisorTeamMeeting = reader.To<int>("SupervisorTeamMeeting"),
                                    Exceptation = reader.To<int>("Exceptation"),
                                    RecommendEmployer = reader.To<int>("RecommendEmployer"),
                                    OverallRating = reader.To<int>("OverallRating"),
                                    AnyFeedbackforEmployer = reader.ToStringValue("AnyFeedbackforEmployer"),
                                    HigherSatisfactory = reader.To<long>("HigherSatisfactory"),
                                    GeneralSatisfactory = reader.To<long>("GeneralSatisfactory"),
                                    //TotalHigherEducationSatisfactory = reader.To<int>("TotalHigherEducationSatisfactory"),
                                    //TotalHigherEducationNotSatisfactory = reader.To<int>("TotalHigherEducationNotSatisfactory"),
                                    //TotalGeneralEducationSatisfactory = reader.To<int>("TotalGeneralEducationSatisfactory"),
                                    //TotalGeneralEducationNotSatisfactory = reader.To<int>("TotalGeneralEducationNotSatisfactory"),

                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from StudentsFeedback method");
                return internshipsDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in StudentsFeedback method : " + ex.ToString());
                throw ex;
            }

        }


        //Report6
        public async Task<IEnumerable<ReportModel>> GetCompanyFeedbackOnStudents(InternshipsParams internshipsParam)
        {
            try
            {
                this.Logger.LogInformation("Entering into StudentsFeedback method");
                IList<ReportModel> internshipsDetails = new List<ReportModel>();
                var paramStartDate = new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = internshipsParam.StartDate };
                var paramEndDate = new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = internshipsParam.EndDate };
                var paramEducationCategory = new SqlParameter("@EducationCategory", SqlDbType.Int) { Value = internshipsParam.EducationCategory, IsNullable = true };
                var paramEducationLevel = new SqlParameter("@EducationLevel", SqlDbType.Int) { Value = internshipsParam.EducationLevel, IsNullable = true };
                var paramCompanyName = new SqlParameter("@CompanyName", SqlDbType.NVarChar) { Value = internshipsParam.CompanyName, IsNullable = true };


                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure,
                        "GetCompanyFeedbackOnStudents", paramStartDate, paramEndDate, paramEducationCategory, paramEducationLevel, paramCompanyName).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                internshipsDetails.Add(new ReportModel
                                {
                                    CompanyNameEn = reader.ToStringValue("CompanyNameEn"),
                                    //CompanyNameAr = reader.ToStringValue("CompanyNameAr"),
                                    StudentsName = reader.ToStringValue("StudentsName"),
                                    InternshipRoleEn = reader.ToStringValue("InternshipRoleEn"),
                                    InternshipRoleAr = reader.ToStringValue("InternshipRoleAr"),
                                    InstituteNameEn = reader.ToStringValue("InstituteNameEn"),
                                    InstituteNameAr = reader.ToStringValue("InstituteNameAr"),
                                    MajorEn = reader.ToStringValue("MajorEn"),
                                    MajorAr = reader.ToStringValue("MajorAr"),
                                    SupervisorName = reader.ToStringValue("SupervisorName"),
                                    SupervisorDesignation = reader.ToStringValue("SupervisorDesignation"),
                                    DateofInternship = reader.To<DateTime>("DateofInternship"),
                                    ScientificLiteracy = reader.To<int>("ScientificLiteracy"),
                                    TechLiteracy = reader.To<int>("TechLiteracy"),
                                    FinancialLiteracy = reader.To<int>("FinancialLiteracy"),
                                    CriticalThinking = reader.To<int>("CriticalThinking"),
                                    Creativity = reader.To<int>("Creativity"),
                                    Communication = reader.To<int>("Communication"),
                                    Collaboration = reader.To<int>("Collaboration"),
                                    Adaptability = reader.To<int>("Adaptability"),
                                    Leadership = reader.To<int>("Leadership"),
                                    SocialCulturalAwareness = reader.To<int>("SocialCulturalAwareness"),
                                    Empathy = reader.To<int>("Empathy"),
                                    GrowthMindset = reader.To<int>("GrowthMindset"),
                                    OverallSatisfaction = reader.To<int>("OverallSatisfaction"),
                                    DescriptionPerformedbyIntern = reader.ToStringValue("DescriptionPerformedbyIntern"),
                                    StrengthsofIntern = reader.ToStringValue("StrengthsofIntern"),
                                    SuggestedDevelopmentAreas = reader.ToStringValue("SuggestedDevelopmentAreas"),
                                    OtherComments = reader.ToStringValue("OtherComments"),
                                    HigherSatisfactory= reader.To<long>("HigherSatisfactory"),
                                    GeneralSatisfactory = reader.To<long>("GeneralSatisfactory"),

                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetCompanyFeedbackOnStudents method");
                return internshipsDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetCompanyFeedbackOnStudents method : " + ex.ToString());
                throw ex;
            }
        }

        //report 7

        public async Task<IEnumerable<RatingReportModel>> GetInternshipModuleFeedback(InternshipsParams internshipsParam)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetInternshipModuleFeedback method");
                IList<RatingReportModel> internshipsDetails = new List<RatingReportModel>();
                var paramStartDate = new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = internshipsParam.StartDate };
                var paramEndDate = new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = internshipsParam.EndDate };
                var paramEducationCategory = new SqlParameter("@EducationCategoryId", SqlDbType.Int) { Value = internshipsParam.EducationCategory, IsNullable = true };
                var paramEducationLevel = new SqlParameter("@EducationLevelId", SqlDbType.Int) { Value = internshipsParam.EducationLevel, IsNullable = true };

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure,
                        "GetInternshipModuleFeedback", paramStartDate, paramEndDate, paramEducationCategory, paramEducationLevel).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                internshipsDetails.Add(new RatingReportModel
                                {
                                    Content = reader.To<int>("Content"),
                                    StudentName = reader.ToStringValue("StudentName"),
                                    Design = reader.To<int>("Design"),
                                    Personalization = reader.To<int>("Personalization"),
                                    Functionality = reader.To<int>("Functionality"),
                                    EmirateEn = reader.ToStringValue("EmirateEn"),
                                    EmirateAr = reader.ToStringValue("EmirateAr"),
                                    EnInstituteName = reader.ToStringValue("EnInstituteName"),
                                    MajorId = reader.To<int>("MajorId"),
                                    ArInstituteName = reader.ToStringValue("ArInstituteName")
                                    // InstituteId = reader.To<int>("InstituteId")

                                    //  StudentsName = reader.ToStringValue("StudentsName"),
                                    //Institute = reader.ToStringValue("Institute"),
                                    //StudentsMajor = reader.ToStringValue("StudentsMajor"),
                                    //EmirateEn = reader.ToStringValue("EmirateEn"),
                                    //SatisfiedContent = reader.To<int>("SatisfiedContent"),
                                    //NotContent = reader.To<int>("NotContent"),
                                    //SatisfiedPersonalization = reader.To<int>("SatisfiedPersonalization"),
                                    //NotPersonalization = reader.To<int>("NotPersonalization"),
                                    //SatisfiedDesign = reader.To<int>("SatisfiedDesign"),
                                    //NotDesign = reader.To<int>("NotDesign"),
                                    //SatisfiedFunctionality = reader.To<int>("SatisfiedFunctionality"),
                                    //NotFunctionality = reader.To<int>("NotFunctionality"),
                                    //Content = reader.To<int>("Content"),
                                    //Personalization = reader.To<int>("Personalization"),
                                    //Design = reader.To<int>("Design"),
                                    //Functionality = reader.To<int>("Functionality")

                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetInternshipModuleFeedback method");
                return internshipsDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetInternshipModuleFeedback method : " + ex.ToString());
                throw ex;
            }

        }

























    }



}



