﻿using SJP.Internships.Api.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Internships.Api.DataAccess
{
    public interface IInternshipDataAccess
    {
        Task<IEnumerable<InternshipDetails>> GetInternshipDetailsAsync();
        Task<InternshipDetails> GetInternshipDetailsAsync(long Id);
        Task<IEnumerable<InternshipDetails>> GetInternshipDetailsGrid();
        Task<InternshipDetails> SaveInternshipDetailsAsync(InternshipDetails internshipDetail);
        Task<IEnumerable<InternshipRoleMaster>> GetInternshipRoleMaster();
        Task<InternshipRoleMaster> SaveinternshipRoleMasterAsyc(InternshipRoleMaster internshipRoleMaster);
        Task<List<InternshipQuestionnaireDetails>> GetQuestionnaireDetailsAsync(long InternshipId);
        Task<List<InternshipQuestionnaireDetails>> GetQuestionAnswerDetails(long InternshipId, long StudentId);
        Task<List<InternshipQuestionnaireDetails>> GetQuestionnaireDetailsAsync();
        Task<List<InternshipQuestionnaireDetails>> SaveQuestionnaireDetailsAsync(IEnumerable<InternshipQuestionnaireDetails> internshipDetail, long InternshipId);
        Task<List<InternshipQuestionnaireDetails>> DeleteQuestionnaireDetailsAsync(List<InternshipQuestionnaireDetails> internshipQuestionnaireDetails, long InternshipId);
        Task<bool> IsActive(long Id);
        Task<InternshipDetails> SaveApprovalDetailsAsync(InternshipDetails internshipDetails);
     //   Task<InternshipDetails> UpdateTotalViews(InternshipDetails viewsUpdate);

        Task<InternshipDetails> GetInternshipDetailsUserviewById(long Id);
        Task<IEnumerable<InternshipDetails>> GetUserInternshipDetailsList(int InternshipFor);
        Task<UserApplyDetails> SaveApplyDetails(UserApplyDetails applyDetails);
        Task<IEnumerable<InternshipDetails>> GetRecruitmentDetailsGrid();
        Task<StudentDetails> GetFlowChartDetails(long InternshipId);
        Task<IEnumerable<InternshipDetails>> GetApplicationsList(long StudentId);
        Task<IEnumerable<InternshipDetails>> GetAcceptedList(long StudentId);
        Task<IEnumerable<StudentDetails>> GetDisagreedList();
        Task<IEnumerable<StudentDetails>> GetCandidatesListGrid(long InternshipId);
        Task<IEnumerable<StudentDetails>> GetAppliedList();
        Task<IEnumerable<StudentDetails>> GetUpdateList(long InternshipId);
        Task<IEnumerable<StudentDetails>> GetAcceptedCandidatesList(long InternshipId);
        Task<StudentDetails> GetStudentDetails(long StudentId, long InternshipId);
        Task<UserApplyDetails> UpdateStatusDetails(UserApplyDetails statusUpdate);
        Task<IEnumerable<StatusModel>> UpdateStatusList(IEnumerable<StatusModel> statusUpdate);
        Task<UserApplyDetails> UpdateDisagreeDetails(UserApplyDetails disagreeUpdate);
        Task<IEnumerable<InternshipDetails>> GetExpiryListGrid(long UserId);
        Task<IEnumerable<ExpiryModel>> UpdateExpiryList(IEnumerable<ExpiryModel> expiryUpdate);
        Task<IEnumerable<AdminFeedbackDetails>> GetPendingAdminFeedback(long InternshipId);
        Task<AdminFeedbackDetails> SaveAdminFeedbackDetails(AdminFeedbackDetails adminFeedbackdetail);
        Task<List<AdminFeedbackRatingModel>> SaveAdminFeedbackRatings(IEnumerable<AdminFeedbackRatingModel> adminFeedbackrating, long Id);
        Task<IEnumerable<AdminFeedbackDetails>> GetAdminFeedbackDetails(long InternshipId, long StudentId);
        Task<IEnumerable<AdminFeedbackDetails>> GetFeedbackReceivedListforStudent(long StudentId);
        Task<IEnumerable<AdminFeedbackDetails>> GetStudentFeedbackListforHEI();
        Task<List<AdminFeedbackRatingModel>> GetRatingsLoad();
        Task<AdminFeedbackDetails> GetFeedbackDetailsAdmin(long InternshipId, long FeedbackId);
        Task<List<AdminFeedbackRatingModel>> GetRatingsAdmin(long FeedbackId);
        Task<IEnumerable<AdminFeedbackDetails>> GetProvidedAdminFeedback(long InternshipId, string CreatedBy);
        Task<IEnumerable<StudentFeedbackDetails>> GetAdminFeedbackReceivedList(long UserId);
        Task<IEnumerable<StudentFeedbackDetails>> GetCounselorFeedbackReceivedList();
        Task<IEnumerable<StudentFeedbackDetails>> GetMoeFeedbackReceivedList();
        Task<StudentFeedbackDetails> SaveStudentFeedbackDetails(StudentFeedbackDetails studentFeedbackdetail);
        Task<List<StudentFeedbackRatingModel>> SaveStudentFeedbackRatings(IEnumerable<StudentFeedbackRatingModel> studentFeedbackrating, long Id);
        Task<IEnumerable<StudentFeedbackDetails>> GetPendingStudentFeedback(long StudentId);
        Task<IEnumerable<StudentFeedbackDetails>> GetStudentFeedbackDetails(long InternshipId, long StudentId);
        Task<List<StudentFeedbackRatingModel>> GetStudentRatingsLoad();
        Task<IEnumerable<StudentFeedbackDetails>> GetProvidedStudentFeedback(long StudentId, string CreatedBy);
        Task<List<StudentFeedbackRatingModel>> GetRatingsStudent(long StudentFeedbackId);
        Task<StudentFeedbackDetails> GetFeedbackDetailsStudents(long StudentFeedbackId);
        Task<MailTracking> SaveMailDetails(MailTracking mailDetails);
    }   
}