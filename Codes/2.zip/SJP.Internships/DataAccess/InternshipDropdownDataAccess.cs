﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Internships.Api.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using SJP.DataAccess;
using SJP.DataAccess.Extensions;
using SJP.Internships.Api.Model.Dto;
using System.Data.SqlClient;

namespace SJP.Internships.Api.DataAccess
{
    public class InternshipDropdownDataAccess : DataAccessBase, IInternshipDropdownDataAccess
    {
        private readonly ILogger logger;
        protected ILogger Logger => logger;
        public InternshipDropdownDataAccess(ILogger<InternshipDropdownDataAccess> logger, IConfiguration configuration) : base(configuration)
        {
            this.logger = logger;
        }
        public async Task<IEnumerable<InternshipDropdownDetails>> GetDropdownDetailsAsyn()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetDropdownDetailsAsyn Method");
                IList<InternshipDropdownDetails> dropdowndetails = new List<InternshipDropdownDetails>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                    connection,
                                    CommandType.StoredProcedure,
                                    "GetInternshipDropdownDetails"
                                    ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                dropdowndetails.Add(new InternshipDropdownDetails
                                {
                                    DropdownId = reader.To<long>("DropdownId"),
                                    DropdownValueEn = reader.ToStringValue("DropdownValueEn"),
                                    DropdownValueAr = reader.ToStringValue("DropdownValueAr"),
                                    Category = reader.ToStringValue("Category"),
                                    IsActive = reader.To<bool>("IsActive"),
                                    ShortName = reader.ToStringValue("ShortName"),
                                    StatusId=reader.To<int>("StatusId")
                                });
                            }
                        }
           
                    }
                }
                this.Logger.LogInformation("Exiting from GetDropdownDetailsAsyn Method");
                return dropdowndetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occurred", "ERROR in GetDropdownDetailsAsyn : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<IEnumerable<InternshipDetails>> GetOrgDetailsAsyn()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetOrgDetailsAsyn Method");
                IList<InternshipDetails> orgdetails = new List<InternshipDetails>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                    connection,
                                    CommandType.StoredProcedure,
                                    "[GetOrgDetails]"
                                    ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                orgdetails.Add(new InternshipDetails
                                {
                                    Id=reader.To<long>("Id"),
                                    CompanyNameEn = reader.ToStringValue("CompanyNameEn"),
                                    CompanyNameAr = reader.ToStringValue("CompanyNameAr")

                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetOrgDetailsAsyn Method");
                return orgdetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occurred", "ERROR in GetOrgDetailsAsyn : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<List<MajorMasterDto>> GetMajorMasterAsyn()
        {
            List<MajorMasterDto> Major = new List<MajorMasterDto>();
            List<MajorMasterDto> Majortreeview = new List<MajorMasterDto>();
            try
            {
                this.Logger.LogInformation("Entering into GetMajorMasterAsyn Method");
                using var connection = await OpenConnectionAsync().ConfigureAwait(false);
                using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetMajorMasterDetails").ConfigureAwait(false))
                {
                    if (reader.HasRows)
                    {
                        while (await reader.ReadAsync().ConfigureAwait(false))
                        {
                            Major.Add(new MajorMasterDto
                            {
                                MajorId = reader.To<long>("MajorId"),
                                MajorValueEn = reader.ToStringValue("MajorValueEn"),
                                MajorValueAr = reader.ToStringValue("MajorValueAr"),
                                ParentId = reader.To<long>("ParentId"),
                                IsActive = reader.To<bool>("IsActive")
                            });
                        }
                    }
                }
                Majortreeview = Major
                .Where(e => e.ParentId == 0) /* grab only the root parent nodes */
                .Select(e => new MajorMasterDto
                {
                    MajorId = e.MajorId,
                    Text = e.MajorValueEn,
                    TextAr = e.MajorValueAr,
                    Value = e.MajorId,
                    ParentId = e.ParentId,
                    Checked = false,
                    Children = GetChildren(Major, e.MajorId) /* Recursively grab the children */
                }).ToList();
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetMajorMasterAsyn method : " + ex.ToString());
                throw ex;
            }
            this.Logger.LogInformation("Exiting from GetMajorMasterAsyn Method");
            return Majortreeview;
        }

        private static List<MajorMasterDto> GetChildren(List<MajorMasterDto> items, long parentId)
        {
            return items
                .Where(x => x.ParentId == parentId)
                .Select(e => new MajorMasterDto
                {
                    MajorId = e.MajorId,
                    Text = e.MajorValueEn,
                    TextAr = e.MajorValueAr,
                    Value = e.MajorId,
                    ParentId = e.ParentId,
                    Checked = false,
                    Children = GetChildren(items, e.MajorId)
                }).ToList();
        }

        public async Task<IEnumerable<AdminUser>> GetAdminUserAsyn()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetAdminUserAsyn Method");
                IList<AdminUser> adminUserdetails = new List<AdminUser>();
               // var paramid = new SqlParameter("@Id", SqlDbType.BigInt) { Value = Id };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                    connection,
                                    CommandType.StoredProcedure,
                                    "GetInternshipAdminUser"
                                    ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                adminUserdetails.Add(new AdminUser
                                {
                                    Id = reader.To<int>("Id"),
                                    FirstName = reader.ToStringValue("FirstName"),
                                    LastName = reader.ToStringValue("LastName"),
                                    AccountType = reader.ToStringValue("AccountType"),
                                    CompanyNameEn= reader.ToStringValue("CompanyNameEn"),
                                    CompanyNameAr = reader.ToStringValue("CompanyNameAr"),
                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetAdminUserAsyn Method");
                return adminUserdetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occurred", "ERROR in GetAdminUserAsyn : " + ex.ToString());
                throw ex;
            }
        }
        public async Task<AdminUser> GetCompanyDetailsAsyn(long Id)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetCompanyDetailsAsyn for Id : " + Id.ToString());
                AdminUser internshipDetails = null;
                //var companydetails = await this.GetCompanyDetailsAsyn(Id);
                var paramid = new SqlParameter("@Id", SqlDbType.BigInt) { Value = Id };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                                connection,
                                                CommandType.StoredProcedure,
                                                "GetCompanyDetails", paramid).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                internshipDetails = new AdminUser
                                {
                                    Id = reader.To<long>("Id"),
                                    //FirstName = reader.ToStringValue("FirstName"),
                                    //LastName = reader.ToStringValue("LastName"),
                                    //AccountType = reader.ToStringValue("AccountType"),
                                    CompanyNameEn = reader.ToStringValue("CompanyNameEn"),
                                   // CompanyNameAr = reader.ToStringValue("CompanyNameAr")

                                };
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetCompanyDetails Method");
                return internshipDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occurred", "ERROR in GetCompanyDetails : " + ex.ToString());
                throw ex;
            }
        }


    }
}

