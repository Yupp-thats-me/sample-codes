﻿using SJP.Internships.Api.Model;
using SJP.Internships.Api.Model.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Internships.Api.DataAccess
{
    public interface IInternshipDropdownDataAccess
    {
        Task<IEnumerable<InternshipDropdownDetails>> GetDropdownDetailsAsyn();
        Task<List<MajorMasterDto>> GetMajorMasterAsyn();
        Task<IEnumerable<AdminUser>> GetAdminUserAsyn();
        Task<IEnumerable<InternshipDetails>> GetOrgDetailsAsyn();
        Task<AdminUser> GetCompanyDetailsAsyn(long Id);
    }
}
