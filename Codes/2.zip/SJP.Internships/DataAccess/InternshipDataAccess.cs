﻿using SJP.DataAccess;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using SJP.Internships.Api.Model;
using System.Data;
using System.Data.SqlClient;
using SJP.DataAccess.Extensions;

namespace SJP.Internships.Api.DataAccess
{
    public class InternshipDataAccess : DataAccessBase, IInternshipDataAccess
    {
        private readonly ILogger logger;
        protected ILogger Logger => logger;
        public InternshipDataAccess(ILogger<InternshipDataAccess> logger, IConfiguration configuration) : base(configuration)
        {
            this.logger = logger;
        }
        public async Task<IEnumerable<InternshipDetails>> GetInternshipDetailsAsync()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetInternshipDetailsAsync method");
                IList<InternshipDetails> internshipDetails = new List<InternshipDetails>();
                var questionnairedetails = await this.GetQuestionnaireDetailsAsync();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                                connection,
                                                CommandType.StoredProcedure,
                                                "GetInternshipDetails").ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                internshipDetails.Add(new InternshipDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    UploadImage = reader.ToStringValue("UploadImage"),
                                    InternshipTypeId = reader.To<int>("InternshipTypeId"),
                                    InternshipTitleEn = reader.ToStringValue("InternshipTitleEn"),
                                    InternshipTitleAr = reader.ToStringValue("InternshipTitleAr"),
                                    DescriptionEn = reader.ToStringValue("DescriptionEn"),
                                    DescriptionAr = reader.ToStringValue("DescriptionAr"),
                                    EligibilityEn = reader.ToStringValue("EligibilityEn"),
                                    EligibilityAr = reader.ToStringValue("EligibilityAr"),
                                    CountryId = reader.ToStringValue("CountryId"),
                                    EmirateId = reader.ToStringValue("EmirateId"),
                                    HigherEducationId = reader.ToStringValue("HigherEducationId"),
                                    GenderId = reader.To<int>("GenderId"),
                                    AgeId = reader.To<int>("AgeId"),
                                    MajorId = reader.ToStringValue("MajorId"),
                                    Stream = reader.ToStringValue("Stream"),
                                    JoiningDate = reader.To<DateTime>("JoiningDate"),
                                    Duration = reader.ToStringValue("Duration"),
                                    NumberOfPositionsId = reader.To<int>("NumberOfPositionsId"),
                                    MinimumHoursRequiredId = reader.To<int>("MinimumHoursRequiredId"),
                                    OrganizationLink = reader.ToStringValue("OrganizationLink"),
                                    IndustryName = reader.ToStringValue("IndustryName"),
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr"),
                                    MonthlySalaryRangeId = reader.To<int>("MonthlySalaryRangeId"),
                                    HowToApplyEn = reader.ToStringValue("HowToApplyEn"),
                                    HowToApplyAr = reader.ToStringValue("HowToApplyAr"),
                                    ContactEmail = reader.ToStringValue("ContactEmail"),
                                    ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                    StatusId = reader.To<int>("StatusId"),
                                    OnBehalfOf = reader.To<int>("OnBehalfOf"),
                                    IsActive = reader.To<bool>("IsActive"),
                                    CreatedBy = reader.ToStringValue("CreatedBy"),
                                    UpdatedBy = reader.ToStringValue("UpdatedBy"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    UpdatedDate = reader.To<DateTime>("UpdatedDate"),
                                    InternshipQuestionnaireDetails = questionnairedetails.Where(x => x.InternshipId == reader.To<long>("Id")).ToList(),
                                    Reason = reader.ToStringValue("Reason"),
                                    Status = reader.ToStringValue("Status"),
                                    IsProbable = reader.To<bool>("IsProbable"),
                                    LastProbableJoiningDate = reader.To<DateTime>("LastProbableJoiningDate"),
                                    InternshipFor = reader.To<int>("InternshipFor"),
                                    UserId = reader.To<long>("UserId"),
                                    ApplicationDeadline = reader.To<DateTime>("ApplicationDeadline"),
                                    CompanyNameEn = reader.ToStringValue("CompanyNameEn"),
                                    CompanyNameAr = reader.ToStringValue("CompanyNameAr"),
                                    RequestedRole = reader.To<int>("RequestedRole"),
                                    FieldofTraining =reader.To<int>("FieldofTraining"),
                                   // TotalViews = reader.To<long>("TotalViews")

                                }
                                );
                            }

                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetInternshipDetailsAsync method");
                return internshipDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetInternshipDetailsAsync method : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<InternshipDetails> GetInternshipDetailsAsync(long Id)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetInternshipDetailsAsync for Id : " + Id.ToString());
                InternshipDetails internshipDetails = null;
                var questionnairedetails = await this.GetQuestionnaireDetailsAsync(Id);
                var paramid = new SqlParameter("@Id", SqlDbType.BigInt) { Value = Id };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                                connection,
                                                CommandType.StoredProcedure,
                                                "GetInternshipDetails", paramid).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                internshipDetails = new InternshipDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    UploadImage = reader.ToStringValue("UploadImage"),
                                    InternshipTypeId = reader.To<int>("InternshipTypeId"),
                                    InternshipTitleEn = reader.ToStringValue("InternshipTitleEn"),
                                    InternshipTitleAr = reader.ToStringValue("InternshipTitleAr"),
                                    DescriptionEn = reader.ToStringValue("DescriptionEn"),
                                    DescriptionAr = reader.ToStringValue("DescriptionAr"),
                                    EligibilityEn = reader.ToStringValue("EligibilityEn"),
                                    EligibilityAr = reader.ToStringValue("EligibilityAr"),
                                    CountryId = reader.ToStringValue("CountryId"),
                                    EmirateId = reader.ToStringValue("EmirateId"),
                                    HigherEducationId = reader.ToStringValue("HigherEducationId"),
                                    GenderId = reader.To<int>("GenderId"),
                                    AgeId = reader.To<int>("AgeId"),
                                    MajorId = reader.ToStringValue("MajorId"),
                                    Stream = reader.ToStringValue("Stream"),
                                    JoiningDate = reader.To<DateTime>("JoiningDate"),
                                    Duration = reader.ToStringValue("Duration"),
                                    NumberOfPositionsId = reader.To<int>("NumberOfPositionsId"),
                                    MinimumHoursRequiredId = reader.To<int>("MinimumHoursRequiredId"),
                                    OrganizationLink = reader.ToStringValue("OrganizationLink"),
                                    IndustryName = reader.ToStringValue("IndustryName"),
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr"),
                                    MonthlySalaryRangeId = reader.To<int>("MonthlySalaryRangeId"),
                                    HowToApplyEn = reader.ToStringValue("HowToApplyEn"),
                                    HowToApplyAr = reader.ToStringValue("HowToApplyAr"),
                                    ContactEmail = reader.ToStringValue("ContactEmail"),
                                    ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                    StatusId = reader.To<int>("StatusId"),
                                    OnBehalfOf = reader.To<int>("OnBehalfOf"),
                                    IsActive = reader.To<bool>("IsActive"),
                                    CreatedBy = reader.ToStringValue("CreatedBy"),
                                    UpdatedBy = reader.ToStringValue("UpdatedBy"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    UpdatedDate = reader.To<DateTime>("UpdatedDate"),
                                    InternshipQuestionnaireDetails = questionnairedetails.ToList(),
                                    Reason = reader.ToStringValue("Reason"),
                                    Status = reader.ToStringValue("Status"),
                                    IsProbable = reader.To<bool>("IsProbable"),
                                    LastProbableJoiningDate = reader.To<DateTime>("LastProbableJoiningDate"),
                                    InternshipFor = reader.To<int>("InternshipFor"),
                                    UserId = reader.To<long>("UserId"),
                                    ApplicationDeadline = reader.To<DateTime>("ApplicationDeadline"),
                                    CompanyNameEn = reader.ToStringValue("CompanyNameEn"),
                                    CompanyNameAr = reader.ToStringValue("CompanyNameAr"),
                                    RequestedRole = reader.To<int>("RequestedRole"),
                                    FieldofTraining = reader.To<int>("FieldofTraining"),
                                  //  TotalViews = reader.To<long>("TotalViews")

                                };

                            }

                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetInternshipDetailsAsync for Id : " + Id.ToString());
                return internshipDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetInternshipDetailsAsync method :" + ex.ToString());
                throw ex;
            }
        }

        public async Task<IEnumerable<InternshipDetails>> GetInternshipDetailsGrid()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetInternshipDetailsGrid method");
                IList<InternshipDetails> internshipDetails = new List<InternshipDetails>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetInternshipDetailsGrid").ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                internshipDetails.Add(new InternshipDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    InternshipTitleEn = reader.ToStringValue("InternshipTitleEn"),
                                    InternshipTitleAr = reader.ToStringValue("InternshipTitleAr"),
                                    ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                    StatusId = reader.To<int>("StatusId"),
                                    OnBehalfOf = reader.To<int>("OnBehalfOf"),
                                    CreatedBy = reader.ToStringValue("CreatedBy"),
                                    UpdatedBy = reader.ToStringValue("UpdatedBy"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    UpdatedDate = reader.To<DateTime>("UpdatedDate"),
                                    Reason = reader.ToStringValue("Reason"),
                                    UserId = reader.To<long>("UserId"),
                                    RequestedRole = reader.To<int>("RequestedRole"),
                                    FieldofTraining = reader.To<int>("FieldofTraining"),
                                 //   TotalViews = reader.To<long>("TotalViews")

                                });
                            }
                        }
                    }

                }
                this.Logger.LogInformation("Exiting from GetInternshipDetailsGrid method");
                return internshipDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetInternshipDetailsGrid method : " + ex.ToString());
                throw ex;
            }
        }
        public async Task<InternshipDetails> SaveInternshipDetailsAsync(InternshipDetails internshipDetail)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveInternshipDetailsAsync method");
                var paramid = new SqlParameter("@Id", SqlDbType.BigInt) { Value = internshipDetail.Id };
                var paramreferenceid = new SqlParameter("@ReferenceId", SqlDbType.BigInt) { Value = internshipDetail.Id, Direction = ParameterDirection.Output };
                var paramUploadImage = new SqlParameter("@UploadImage", SqlDbType.NVarChar) { Value = internshipDetail.UploadImage };
                var paramOnBehalfOf = new SqlParameter("@OnBehalfOf", SqlDbType.Int) { Value = internshipDetail.OnBehalfOf };
                var paramInternshipTypeId = new SqlParameter("@InternshipTypeId", SqlDbType.Int) { Value = internshipDetail.InternshipTypeId };
                var paramTitleEn = new SqlParameter("@InternshipTitleEn", SqlDbType.NVarChar) { Value = internshipDetail.InternshipTitleEn };
                var paramTitleAr = new SqlParameter("@InternshipTitleAr", SqlDbType.NVarChar) { Value = internshipDetail.InternshipTitleAr };
                var paramDescriptionEn = new SqlParameter("@DescriptionEn", SqlDbType.NVarChar) { Value = internshipDetail.DescriptionEn };
                var paramDescriptionAr = new SqlParameter("@DescriptionAr", SqlDbType.NVarChar) { Value = internshipDetail.DescriptionAr };
                var paramEligibilityEn = new SqlParameter("@EligibilityEn", SqlDbType.NVarChar) { Value = internshipDetail.EligibilityEn };
                var paramEligibilityAr = new SqlParameter("@EligibilityAr", SqlDbType.NVarChar) { Value = internshipDetail.EligibilityAr };
                var paramCountryId = new SqlParameter("@CountryId", SqlDbType.NVarChar) { Value = internshipDetail.CountryId };
                var paramEmirateId = new SqlParameter("@EmirateId", SqlDbType.NVarChar) { Value = internshipDetail.EmirateId };
                var paramHigherEducationId = new SqlParameter("@HigherEducationId", SqlDbType.NVarChar) { Value = internshipDetail.HigherEducationId };
                var paramGenderId = new SqlParameter("@GenderId", SqlDbType.NVarChar) { Value = internshipDetail.GenderId };
                var paramAgeId = new SqlParameter("@AgeId", SqlDbType.NVarChar) { Value = internshipDetail.AgeId };
                var paramMajorId = new SqlParameter("@MajorId", SqlDbType.NVarChar) { Value = internshipDetail.MajorId };
                var paramStream = new SqlParameter("@Stream", SqlDbType.NVarChar) { Value = internshipDetail.Stream };
                var paramJoiningDate = new SqlParameter("@JoiningDate", SqlDbType.DateTime) { Value = internshipDetail.JoiningDate };
                var paramDuration = new SqlParameter("@Duration", SqlDbType.NVarChar) { Value = internshipDetail.Duration };
                var paramNumberOfPositionsId = new SqlParameter("@NumberOfPositionsId", SqlDbType.Int) { Value = internshipDetail.NumberOfPositionsId };
                var paramMinimumHoursRequiredId = new SqlParameter("@MinimumHoursRequiredId", SqlDbType.Int) { Value = internshipDetail.MinimumHoursRequiredId };
                var paramOrganizationLink = new SqlParameter("@OrganizationLink", SqlDbType.NVarChar) { Value = internshipDetail.OrganizationLink };
                var paramIndustryName = new SqlParameter("@IndustryName", SqlDbType.NVarChar) { Value = internshipDetail.IndustryName };
                var paramInternshipRoleNameEn = new SqlParameter("@InternshipRoleNameEn", SqlDbType.NVarChar) { Value = internshipDetail.InternshipRoleNameEn };
                var paramInternshipRoleNameAr = new SqlParameter("@InternshipRoleNameAr", SqlDbType.NVarChar) { Value = internshipDetail.InternshipRoleNameAr };
                var paramMonthlySalaryRangeId = new SqlParameter("@MonthlySalaryRangeId", SqlDbType.Int) { Value = internshipDetail.MonthlySalaryRangeId };
                var paramHowToApplyEn = new SqlParameter("@HowToApplyEn", SqlDbType.NVarChar) { Value = internshipDetail.HowToApplyEn };
                var paramHowToApplyAr = new SqlParameter("@HowToApplyAr", SqlDbType.NVarChar) { Value = internshipDetail.HowToApplyAr };
                var paramContactEmail = new SqlParameter("@ContactEmail", SqlDbType.NVarChar) { Value = internshipDetail.ContactEmail };
                var paramExpiryDate = new SqlParameter("@ExpiryDate", SqlDbType.DateTime) { Value = internshipDetail.ExpiryDate };
                var paramStatusId = new SqlParameter("@StatusId", SqlDbType.Int) { Value = internshipDetail.StatusId };
                var paramActive = new SqlParameter("@IsActive", SqlDbType.Bit) { Value = internshipDetail.Active };
                var paramCreatedBy = new SqlParameter("@CreatedBy", SqlDbType.NVarChar) { Value = internshipDetail.CreatedBy };
                var paramUpdatedBy = new SqlParameter("@UpdatedBy", SqlDbType.NVarChar) { Value = internshipDetail.UpdatedBy };
                var paramReason = new SqlParameter("@Reason", SqlDbType.NVarChar) { Value = internshipDetail.Reason };
                var paramIsProbable = new SqlParameter("@IsProbable", SqlDbType.Bit) { Value = internshipDetail.IsProbable };
                var paramLastProbableJoiningDate = new SqlParameter("@LastProbableJoiningDate", SqlDbType.DateTime) { Value = internshipDetail.LastProbableJoiningDate };
                var paramInternshipFor = new SqlParameter("@InternshipFor", SqlDbType.Int) { Value = internshipDetail.InternshipFor };
                var paramUserId = new SqlParameter("@UserId", SqlDbType.BigInt) { Value = internshipDetail.UserId };
                var paramApplicationDeadline = new SqlParameter("@ApplicationDeadline", SqlDbType.DateTime) { Value = internshipDetail.ApplicationDeadline };
                var paramCompanyNameEn = new SqlParameter("@CompanyNameEn", SqlDbType.NVarChar) { Value = internshipDetail.CompanyNameEn };
                var paramCompanyNameAr = new SqlParameter("@CompanyNameAr", SqlDbType.NVarChar) { Value = internshipDetail.CompanyNameAr };
                var paramFieldofTraining = new SqlParameter("@FieldofTraining", SqlDbType.Int) { Value = internshipDetail.FieldofTraining };
                //var paramViews = new SqlParameter("@TotalViews", SqlDbType.BigInt) { Value = internshipDetail.TotalViews };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveinternshipDetails",
                 paramid,
                 paramreferenceid,
                 paramUploadImage,
                 paramOnBehalfOf,
                 paramInternshipTypeId,
                 paramTitleEn,
                 paramTitleAr,
                 paramDescriptionEn,
                 paramDescriptionAr,
                 paramEligibilityEn,
                 paramEligibilityAr,
                 paramCountryId,
                 paramEmirateId,
                 paramHigherEducationId,
                 paramGenderId,
                 paramAgeId,
                 paramMajorId,
                 paramStream,
                 paramJoiningDate,
                 paramDuration,
                 paramNumberOfPositionsId,
                 paramMinimumHoursRequiredId,
                 paramOrganizationLink,
                 paramIndustryName,
                 paramInternshipRoleNameEn,
                 paramInternshipRoleNameAr,
                 paramMonthlySalaryRangeId,
                 paramHowToApplyEn,
                 paramHowToApplyAr,
                 paramContactEmail,
                 paramExpiryDate,
                 paramStatusId,
                 paramActive,
                 paramCreatedBy,
                 paramUpdatedBy,
                 paramReason,
                 paramIsProbable,
                 paramLastProbableJoiningDate,
                 paramInternshipFor,
                 paramUserId,
                 paramApplicationDeadline,
                 paramCompanyNameEn,
                 paramCompanyNameAr,
                 paramFieldofTraining
             //   , paramViews

                        ).ConfigureAwait(false);
                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                internshipDetail.Id = (long)paramreferenceid.Value;

                //to do delete existing question
                await DeleteQuestionnaireDetailsAsync(internshipDetail.InternshipQuestionnaireDetails, internshipDetail.Id);
                if (internshipDetail.InternshipQuestionnaireDetails != null)
                {
                    await SaveQuestionnaireDetailsAsync(internshipDetail.InternshipQuestionnaireDetails, internshipDetail.Id);
                }
                this.Logger.LogInformation("Exiting from SaveInternshipDetailsAsync Method");
                return internshipDetail;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in SaveInternshipDetailsAsync Method : " + ex.ToString());
                throw ex;
            }
        }
        public async Task<InternshipRoleMaster> SaveinternshipRoleMasterAsyc(InternshipRoleMaster internshipRoleMaster)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveinternshipRoleMasterAsyc method");
                var paramInternshipRoleNameEn = new SqlParameter("@InternshipRoleNameEn", SqlDbType.NVarChar) { Value = internshipRoleMaster.InternshipRoleNameEn };
                var paramInternshipRoleNameAr = new SqlParameter("@InternshipRoleNameAr", SqlDbType.NVarChar) { Value = internshipRoleMaster.InternshipRoleNameAr };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveInternshipRoleMaster",
                            paramInternshipRoleNameEn,
                            paramInternshipRoleNameAr
                            ).ConfigureAwait(false);
                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }

                }
                this.Logger.LogInformation("Exiting from SaveinternshipRoleMasterAsyc Method");
                return internshipRoleMaster;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in SaveinternshipRoleMasterAsyc Method : " + ex.ToString());
                throw ex;
            }
        }


        public async Task<IEnumerable<InternshipRoleMaster>> GetInternshipRoleMaster()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetInternshipRoleMaster Method");
                IList<InternshipRoleMaster> intershipRoleMaster = new List<InternshipRoleMaster>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                            connection,
                                            CommandType.StoredProcedure,
                                            "GetInternshipRoleMaster"
                                            ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                intershipRoleMaster.Add(new InternshipRoleMaster
                                {
                                    InternshipRoleId = reader.To<int>("InternshipRoleId"),
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr")

                                }); ;
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetInternshipRoleMaster Method");
                return intershipRoleMaster;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occurred", "ERROR in GetInternshipRoleMaster : " + ex.ToString());
                throw ex;
            }
        }
        public async Task<List<InternshipQuestionnaireDetails>> GetQuestionnaireDetailsAsync(long InternshipId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetQuestionnaireDetailsAsync for Id : " + InternshipId.ToString());
                var QuestionnaireList = new List<InternshipQuestionnaireDetails>();
                var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = InternshipId };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                                                connection,
                                                                CommandType.StoredProcedure,
                                                                "GetQuestionnaireDetails",
                                                                paramId).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                var Questionnaire = new InternshipQuestionnaireDetails();
                                Questionnaire.QuestionnaireId = reader.To<long>("QuestionnaireId");
                                Questionnaire.InternshipId = reader.To<long>("InternshipId");
                                Questionnaire.Type = reader.To<int>("Type");
                                Questionnaire.Questions = reader.ToStringValue("Questions");
                                Questionnaire.Options1 = reader.ToStringValue("Options1");
                                Questionnaire.Options2 = reader.ToStringValue("Options2");
                                Questionnaire.Options3 = reader.ToStringValue("Options3");
                                Questionnaire.Options4 = reader.ToStringValue("Options4");
                                QuestionnaireList.Add(Questionnaire);
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetQuestionnaireDetailsAsync for Id : " + InternshipId.ToString());
                return QuestionnaireList;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetQuestionnaireDetailsAsync method :" + ex.ToString());
                throw ex;
            }
        }

        public async Task<List<InternshipQuestionnaireDetails>> GetQuestionAnswerDetails(long InternshipId, long StudentId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetQuestionnaireDetailsAsync for Id : " + InternshipId.ToString());
                var QuestionnaireList = new List<InternshipQuestionnaireDetails>();
                var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = InternshipId };
                var paramstudentId = new SqlParameter("@StudentId", SqlDbType.BigInt) { Value = StudentId };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                                                connection,
                                                                CommandType.StoredProcedure,
                                                                "GetQuestionAnswerDetails",
                                                                paramId, paramstudentId).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                var Questionnaire = new InternshipQuestionnaireDetails();
                                Questionnaire.QuestionnaireId = reader.To<long>("QuestionnaireId");
                                Questionnaire.InternshipId = reader.To<long>("InternshipId");
                                Questionnaire.Type = reader.To<int>("Type");
                                Questionnaire.Questions = reader.ToStringValue("Questions");
                                Questionnaire.Options1 = reader.ToStringValue("Options1");
                                Questionnaire.Options2 = reader.ToStringValue("Options2");
                                Questionnaire.Options3 = reader.ToStringValue("Options3");
                                Questionnaire.Options4 = reader.ToStringValue("Options4");
                                QuestionnaireList.Add(Questionnaire);
                                Questionnaire.Answers = reader.ToStringValue("Answers");
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetQuestionnaireDetailsAsync for Id ");
                return QuestionnaireList;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetQuestionnaireDetailsAsync method :" + ex.ToString());
                throw ex;
            }
        }
        public async Task<List<InternshipQuestionnaireDetails>> GetQuestionnaireDetailsAsync()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetQuestionnaireDetailsAsync");
                IList<InternshipQuestionnaireDetails> questionnaireList = new List<InternshipQuestionnaireDetails>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                                                connection,
                                                                CommandType.StoredProcedure,
                                                                "GetQuestionnaireDetails"
                                                                 ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                questionnaireList.Add(new InternshipQuestionnaireDetails
                                {
                                    QuestionnaireId = reader.To<long>("QuestionnaireId"),
                                    InternshipId = reader.To<long>("InternshipId"),
                                    Type = reader.To<int>("Type"),
                                    Questions = reader.ToStringValue("Questions"),
                                    Options1 = reader.ToStringValue("Options1"),
                                    Options2 = reader.ToStringValue("Options2"),
                                    Options3 = reader.ToStringValue("Options3"),
                                    Options4 = reader.ToStringValue("Options4")

                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetQuestionnaireDetailsAsync");
                return (List<InternshipQuestionnaireDetails>)questionnaireList;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetQuestionnaireDetailsAsync method :" + ex.ToString());
                throw ex;
            }
        }
        public async Task<List<InternshipQuestionnaireDetails>> SaveQuestionnaireDetailsAsync(IEnumerable<InternshipQuestionnaireDetails> internshipDetail,
            long InternshipId)
        {
            List<InternshipQuestionnaireDetails> internshiplist = new List<InternshipQuestionnaireDetails>();
            internshiplist = internshipDetail.ToList();
            for (int i = 0; i < internshiplist.Count; i++)
            {
                internshiplist[i].QuestionnaireId = 0;
            }
            for (int i = 0; i < internshiplist.Count; i++)
            {
                try
                {
                    this.logger.LogInformation("Entering into SaveQuestionnaireDetailsAsync Method");
                    var paramReferenceId = new SqlParameter("@ReferenceId", SqlDbType.BigInt)
                    {
                        Value = internshiplist[i].QuestionnaireId,
                        Direction = ParameterDirection.Output
                    };

                    var paramQuestionnaireId = new SqlParameter("@QuestionnaireId", SqlDbType.BigInt) { Value = internshiplist[i].QuestionnaireId };
                    var paramInternshipId = new SqlParameter("@InternshipId", SqlDbType.BigInt) { Value = InternshipId };
                    var paramType = new SqlParameter("@Type", SqlDbType.Int) { Value = internshiplist[i].Type };
                    var paramQuestions = new SqlParameter("@Questions", SqlDbType.NVarChar) { Value = internshiplist[i].Questions };
                    var paramOptions1 = new SqlParameter("@Options1", SqlDbType.NVarChar) { Value = internshiplist[i].Options1 };
                    var paramOptions2 = new SqlParameter("@Options2", SqlDbType.NVarChar) { Value = internshiplist[i].Options2 };
                    var paramOptions3 = new SqlParameter("@Options3", SqlDbType.NVarChar) { Value = internshiplist[i].Options3 };
                    var paramOptions4 = new SqlParameter("@Options4", SqlDbType.NVarChar) { Value = internshiplist[i].Options4 };
                    using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                    {
                        SqlTransaction transaction = null;
                        try
                        {
                            transaction = connection.BeginTransaction();
                            await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveQuestionnaireDetails",
                                paramReferenceId,
                                paramInternshipId,
                                paramQuestionnaireId,
                                paramType,
                                paramQuestions,
                                paramOptions1,
                                paramOptions2,
                                paramOptions3,
                                paramOptions4
                                ).ConfigureAwait(false);
                            transaction.Commit();
                        }
                        catch (Exception)
                        {
                            if (transaction != null)
                            {
                                transaction.Rollback();
                                throw;
                            }
                        }
                    }
                    internshiplist[i].Id = (long)paramReferenceId.Value;
                }
                catch (Exception ex)
                {
                    this.logger.LogError("Error Occured", "ERROR in SaveQuestionnaireDetailsAsync Method : " + ex.ToString());
                    throw ex;
                }
            }
            this.Logger.LogInformation("Exiting from SaveQuestionnaireDetailsAsync Method");
            return internshiplist;
        }

        public async Task<List<InternshipQuestionnaireDetails>> DeleteQuestionnaireDetailsAsync(List<InternshipQuestionnaireDetails> internshipQuestionnaireDetails, long InternshipId)
        {
            try
            {
                this.Logger.LogInformation("Entering into DeleteQuestionnaireDetailsAsync Method");
                var QuestionnaireList = new List<InternshipQuestionnaireDetails>();
                var paraminternshipId = new SqlParameter("@InternshipId", SqlDbType.BigInt) { Value = InternshipId };

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "DeleteQuestionnaireDetail",
                            paraminternshipId
                            ).ConfigureAwait(false);
                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from DeleteQuestionnaireDetailsAsync Method");
                return QuestionnaireList;
            }

            catch (Exception Ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in DeleteSkillDetailsAsync Method :" + Ex.ToString());
                throw Ex;
            }
        }

        public async Task<InternshipDetails> SaveApprovalDetailsAsync(InternshipDetails internshipDetails)
        {
            try
            {
                this.logger.LogInformation("Entering into SaveApprovalDetailsAsync Method");
                var paramReferenceId = new SqlParameter("@ReferenceId", SqlDbType.BigInt) { Value = internshipDetails.Id, Direction = ParameterDirection.Output };
                var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = internshipDetails.Id };
                var paramStatusId = new SqlParameter("@StatusId", SqlDbType.Int) { Value = internshipDetails.StatusId };
                var paramUpdatedBy = new SqlParameter("@UpdatedBy", SqlDbType.NVarChar) { Value = internshipDetails.UpdatedBy };
                var paramReason = new SqlParameter("@Reason", SqlDbType.NVarChar) { Value = internshipDetails.Reason };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveApprovalDetails",
                            paramReferenceId,
                            paramId,
                            paramStatusId,
                            paramUpdatedBy,
                            paramReason
                            ).ConfigureAwait(false);
                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                this.logger.LogInformation("Exiting from SaveApprovalDetailsAsync Method");
                return internshipDetails;
            }
            catch (Exception ex)
            {
                this.logger.LogError("Error Occured", "ERROR in SaveApprovalDetailsAsync Method : " + ex.ToString());
                throw ex;
            }
        }
        public async Task<bool> IsActive(long Id)
        {
            try
            {
                this.Logger.LogInformation("Entering into IsActive method");
                var paramid = new SqlParameter("@Id", SqlDbType.BigInt) { Value = Id };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    await ExecuteNonQueryAsync(connection, CommandType.StoredProcedure, "SaveIsActiveInternshipById", paramid).ConfigureAwait(false);
                }
                this.Logger.LogInformation("Exiting from IsActive method");
                return true;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "Error in IsActive method :" + ex.ToString());
                throw ex;
            }
        }

        /*public async Task<InternshipDetails> UpdateTotalViews(InternshipDetails viewsUpdate)
        {
            try
            {
                this.logger.LogInformation("Entering into UpdateTotalViews Method");
                var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = viewsUpdate.Id };
                var paramViews = new SqlParameter("@TotalViews", SqlDbType.BigInt) { Value = viewsUpdate.TotalViews };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "UpdateTotalViews",
                            paramId,
                            paramViews
                            ).ConfigureAwait(false);
                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                this.logger.LogInformation("Exiting from UpdateTotalViews Method");
                return viewsUpdate;
            }
            catch (Exception ex)
            {
                this.logger.LogError("Error Occured", "ERROR in UpdateTotalViews Method : " + ex.ToString());
                throw ex;
            }
        }*/


        public async Task<InternshipDetails> GetInternshipDetailsUserviewById(long Id)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetInternshipDetailsUserviewById method");
                InternshipDetails InternshipDetailsForUsers = null;
                var questionnairedetails = await this.GetQuestionnaireDetailsAsync(Id);
                var paramid = new SqlParameter("@Id", SqlDbType.BigInt) { Value = Id };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                                connection,
                                                CommandType.StoredProcedure,
                                                "GetInternshipDetailsUserviewById", paramid).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                InternshipDetailsForUsers = new InternshipDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    InternshipTitleEn = reader.ToStringValue("InternshipTitleEn"),
                                    InternshipTitleAr = reader.ToStringValue("InternshipTitleAr"),
                                    DescriptionEn = reader.ToStringValue("DescriptionEn"),
                                    DescriptionAr = reader.ToStringValue("DescriptionAr"),
                                    EligibilityEn = reader.ToStringValue("EligibilityEn"),
                                    EligibilityAr = reader.ToStringValue("EligibilityAr"),
                                    HowToApplyEn = reader.ToStringValue("HowToApplyEn"),
                                    HowToApplyAr = reader.ToStringValue("HowToApplyAr"),
                                    ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                    OrganizationLink = reader.ToStringValue("OrganizationLink"),
                                    AgeEn = reader.ToStringValue("AgeEn"),
                                    AgeAr = reader.ToStringValue("AgeAr"),
                                    MonthlySalaryRangeEn = reader.ToStringValue("MonthlySalaryRangeEn"),
                                    MonthlySalaryRangeAr = reader.ToStringValue("MonthlySalaryRangeAr"),
                                    JoiningDate = reader.To<DateTime>("JoiningDate"),
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr"),
                                    LastProbableJoiningDate = reader.To<DateTime>("LastProbableJoiningDate"),
                                    UploadImage = reader.ToStringValue("UploadImage"),
                                    CountryId = reader.ToStringValue("CountryId"),
                                    EmirateId = reader.ToStringValue("EmirateId"),
                                    HigherEducationId = reader.ToStringValue("HigherEducationId"),
                                    GenderId = reader.To<int>("GenderId"),
                                    Duration = reader.ToStringValue("Duration"),
                                    NumberOfPositionsId = reader.To<int>("NumberOfPositionsId"),
                                    MinimumHoursRequiredId = reader.To<int>("MinimumHoursRequiredId"),
                                    InternshipTypeId = reader.To<int>("InternshipTypeId"),
                                    IndustryNameEn = reader.ToStringValue("IndustryNameEn"),
                                    IndustryNameAr = reader.ToStringValue("IndustryNameAr"),
                                    InternshipQuestionnaireDetails = questionnairedetails.ToList(),
                                    CompanyNameEn = reader.ToStringValue("CompanyNameEn"),
                                    CompanyNameAr = reader.ToStringValue("CompanyNameAr"),
                                    ApplicationDeadline = reader.To<DateTime>("ApplicationDeadline"),
                                    StudentId = reader.To<long>("StudentId")
                                };
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetInternshipDetailsUserviewById method");
                return InternshipDetailsForUsers;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetInternshipDetailsUserviewById method : " + ex.ToString());
                throw ex;
            }
        }
        public async Task<UserApplyDetails> SaveApplyDetails(UserApplyDetails applyDetails)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveApplyDetails method");
                var paramid = new SqlParameter("@Id", SqlDbType.BigInt) { Value = applyDetails.@Id };
                var paramreferenceid = new SqlParameter("@ReferenceId", SqlDbType.BigInt) { Value = applyDetails.Id, Direction = ParameterDirection.Output };
                var paraminternshipid = new SqlParameter("@InternshipId", SqlDbType.BigInt) { Value = applyDetails.InternshipId };
                var paramstudentid = new SqlParameter("@StudentId", SqlDbType.BigInt) { Value = applyDetails.StudentId };
                var paramContent = new SqlParameter("@Content", SqlDbType.Int) { Value = applyDetails.Content };
                var paramdesign = new SqlParameter("@Design", SqlDbType.Int) { Value = applyDetails.Design };
                var parampersonalization = new SqlParameter("@Personalization", SqlDbType.Int) { Value = applyDetails.Personalization };
                var paramfunctionality = new SqlParameter("@Functionality", SqlDbType.Int) { Value = applyDetails.Functionality };
                var paramuploaddocument = new SqlParameter("@UploadDocument", SqlDbType.NVarChar) { Value = applyDetails.UploadDocument };
                var paramdocumenttitle = new SqlParameter("@DocumentTitle", SqlDbType.NVarChar) { Value = applyDetails.DocumentTitle };
                var paramkeyskills = new SqlParameter("@KeySkills", SqlDbType.NVarChar) { Value = applyDetails.KeySkills };
                var paramprobablejoiningdate = new SqlParameter("@ProbableJoiningDate", SqlDbType.DateTime) { Value = applyDetails.ProbableJoiningDate };
                var paramkeyisstudentprofile = new SqlParameter("@IsStudentProfile", SqlDbType.Bit) { Value = applyDetails.IsStudentProfile };
                var paramCreatedBy = new SqlParameter("@CreatedBy", SqlDbType.NVarChar) { Value = applyDetails.CreatedBy };
                var paramstatusid = new SqlParameter("@StatusId", SqlDbType.Int) { Value = applyDetails.StatusId };

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveApplyDetails",
                        paramid,
                        paramreferenceid,
                        paraminternshipid,
                        paramstudentid,
                        paramContent,
                        paramdesign,
                        parampersonalization,
                        paramfunctionality,
                        paramuploaddocument,
                        paramdocumenttitle,
                        paramkeyskills,
                        paramprobablejoiningdate,
                        paramkeyisstudentprofile,
                        paramCreatedBy,
                        paramstatusid

                        ).ConfigureAwait(false);


                        applyDetails.Id = (long)paramreferenceid.Value;

                        if (applyDetails.AnswerDetails != null)
                        {
                            foreach (var item in applyDetails.AnswerDetails)
                            {
                                var paramAnswerId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = item.Id };
                                var paramquestionnaireid = new SqlParameter("@QuestionnaireId", SqlDbType.BigInt) { Value = item.QuestionnaireId };
                                var paramreference = new SqlParameter("@ReferenceId", SqlDbType.BigInt) { Value = item.Id, Direction = ParameterDirection.Output };
                                var paramstudent = new SqlParameter("@StudentId", SqlDbType.BigInt) { Value = applyDetails.StudentId };
                                var paramanswers = new SqlParameter("@Answers", SqlDbType.NVarChar) { Value = item.Answers };
                                var paramCreated = new SqlParameter("@CreatedBy", SqlDbType.NVarChar) { Value = applyDetails.CreatedBy };

                                await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveAnswerDetails",
                                paramAnswerId,
                                paramquestionnaireid,
                                paramreference,
                                paramstudent,
                                paramanswers,
                                paramCreated
                                ).ConfigureAwait(false);
                            }
                        }
                        transaction.Commit();
                    }

                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }

                this.Logger.LogInformation("Exiting from SaveApplyDetails Method");
                return applyDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in SaveApplyDetails Method : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<UserApplyDetails> UpdateStatusDetails(UserApplyDetails statusUpdate)
        {
            try
            {
                this.logger.LogInformation("Entering into UpdateStatusDetails Method");
                var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = statusUpdate.Id };
                var paramStatusId = new SqlParameter("@StatusId", SqlDbType.Int) { Value = statusUpdate.StatusId };
                var paramUpdatedBy = new SqlParameter("@UpdatedBy", SqlDbType.NVarChar) { Value = statusUpdate.UpdatedBy };

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "UpdateStatusDetails",
                            paramId,
                            paramStatusId,
                            paramUpdatedBy
                            ).ConfigureAwait(false);
                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                this.logger.LogInformation("Exiting from UpdateStatusDetails Method");
                return statusUpdate;
            }
            catch (Exception ex)
            {
                this.logger.LogError("Error Occured", "ERROR in UpdateStatusDetails Method : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<IEnumerable<StatusModel>> UpdateStatusList(IEnumerable<StatusModel> statusUpdate)
        {
            try
            {
                this.logger.LogInformation("Entering into UpdateStatusList Method");
                List<StatusModel> update = statusUpdate.ToList();
                for (int i = 0; i < update.Count; i++)
                {
                    var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = update[i].Id };
                    var paramStatusId = new SqlParameter("@StatusId", SqlDbType.Int) { Value = update[i].StatusId };

                    using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                    {
                        SqlTransaction transaction = null;
                        try
                        {
                            transaction = connection.BeginTransaction();
                            await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "UpdateStatusDetails",
                                paramId,
                                paramStatusId

                                ).ConfigureAwait(false);
                            transaction.Commit();
                        }
                        catch
                        {
                            if (transaction != null)
                            {
                                transaction.Rollback();
                                throw;
                            }
                        }
                    }

                }

                this.logger.LogInformation("Exiting from UpdateStatusList Method");
                return statusUpdate;
            }
            catch (Exception ex)
            {
                this.logger.LogError("Error Occured", "ERROR in UpdateStatusList Method : " + ex.ToString());
                throw ex;
            }
        }
        public async Task<UserApplyDetails> UpdateDisagreeDetails(UserApplyDetails disagreeUpdate)
        {
            try
            {
                this.logger.LogInformation("Entering into UpdateStatusDetails Method");
                var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = disagreeUpdate.Id };
                var paramUpdatedBy = new SqlParameter("@UpdatedBy", SqlDbType.NVarChar) { Value = disagreeUpdate.UpdatedBy };
                var paramIsDisagreed = new SqlParameter("@IsDisagreed", SqlDbType.Bit) { Value = disagreeUpdate.IsDisagreed };
                var paramDisagreedReason = new SqlParameter("@DisagreedReason", SqlDbType.NVarChar) { Value = disagreeUpdate.DisagreedReason };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "UpdateDisagreeDetails",
                            paramId,
                            paramUpdatedBy,
                            paramIsDisagreed,
                            paramDisagreedReason
                            ).ConfigureAwait(false);
                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                this.logger.LogInformation("Exiting from disagreeUpdateDetails Method");
                return disagreeUpdate;
            }
            catch (Exception ex)
            {
                this.logger.LogError("Error Occured", "ERROR in disagreeUpdateDetails Method : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<IEnumerable<InternshipDetails>> GetUserInternshipDetailsList(int InternshipFor)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetUserInternshipDetailsList method");
                var paramInternshipFor = new SqlParameter("@InternshipFor", SqlDbType.Int) { Value = InternshipFor };
                IList<InternshipDetails> internshipDetailsUsers = new List<InternshipDetails>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {

                    using (var reader = await ExecuteReaderAsync(
                                                connection,
                                                CommandType.StoredProcedure,
                                                "GetInternshipFilterDetails", paramInternshipFor).ConfigureAwait(false))
                    {

                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                internshipDetailsUsers.Add(new InternshipDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    UploadImage = reader.ToStringValue("UploadImage"),
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr"),
                                    EligibilityEn = reader.ToStringValue("EligibilityEn"),
                                    EligibilityAr = reader.ToStringValue("EligibilityAr"),
                                    CountryId = reader.ToStringValue("CountryId"),
                                    EmirateId = reader.ToStringValue("EmirateId"),
                                    HigherEducationId = reader.ToStringValue("HigherEducationId"),
                                    CompanyNameEn = reader.ToStringValue("companyNameEn"),
                                    CompanyNameAr = reader.ToStringValue("companyNameAr"),
                                    JoiningDate = reader.To<DateTime>("JoiningDate"),
                                    ApplicationDeadline = reader.To<DateTime>("ApplicationDeadline"),
                                    AgeId = reader.To<int>("AgeId"),
                                    Duration = reader.ToStringValue("Duration"),
                                    //PostedDays = reader.ToStringValue("PostedDays"),
                                    InternshipTitleEn = reader.ToStringValue("InternshipTitleEn"),
                                    InternshipTitleAr = reader.ToStringValue("InternshipTitleAr"),
                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetUserInternshipDetailsList method");
                return internshipDetailsUsers;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetUserInternshipDetailsList method : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<IEnumerable<InternshipDetails>> GetRecruitmentDetailsGrid()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetRecruitmentDetailsGrid method");
                IList<InternshipDetails> recruitmentDetails = new List<InternshipDetails>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetRecruitmentDetailsGrid").ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                recruitmentDetails.Add(new InternshipDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr"),
                                    ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                    InternshipTypeId = reader.To<int>("InternshipTypeId"),
                                    InternshipFor = reader.To<int>("InternshipFor"),
                                    IndustryNameEn = reader.ToStringValue("IndustryNameEn"),
                                    IndustryNameAr = reader.ToStringValue("IndustryNameAr"),
                                    EmirateEn = reader.ToStringValue("EmirateEn"),
                                    EmirateAr = reader.ToStringValue("EmirateAr"),
                                    EmirateId = reader.ToStringValue("EmirateId"),
                                    CreatedBy = reader.ToStringValue("CreatedBy"),
                                    UpdatedBy = reader.ToStringValue("UpdatedBy"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    UpdatedDate = reader.To<DateTime>("UpdatedDate"),
                                });
                            }
                        }
                    }

                }
                this.Logger.LogInformation("Exiting from GetRecruitmentDetailsGrid method");
                return recruitmentDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetRecruitmentDetailsGrid method : " + ex.ToString());
                throw ex;
            }
        }
        public async Task<StudentDetails> GetFlowChartDetails(long InternshipId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetFlowChartDetails for InternshipId : " + InternshipId.ToString());
                StudentDetails flowcount = null;
                var paramid = new SqlParameter("@InternshipId", SqlDbType.BigInt) { Value = InternshipId };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                                connection,
                                                CommandType.StoredProcedure,
                                                "GetFlowChartDetails", paramid).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                flowcount = new StudentDetails
                                {
                                    Applied = reader.To<int>("Applied"),
                                    Shortlisted = reader.To<int>("Shortlisted"),
                                    Rejected = reader.To<int>("Rejected"),
                                    Withdrawn = reader.To<int>("Withdrawn"),
                                    Interviewed = reader.To<int>("Interviewed"),
                                    DroppedOut = reader.To<int>("DroppedOut"),
                                    Offered = reader.To<int>("Offered"),
                                    ScreenedOut = reader.To<int>("ScreenedOut"),
                                    Accepted = reader.To<int>("Accepted"),
                                    Declined = reader.To<int>("Declined"),
                                    Hired = reader.To<int>("Hired"),
                                };

                            }

                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetFlowChartDetails for InternshipId : " + InternshipId.ToString());
                return flowcount;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetFlowChartDetails method :" + ex.ToString());
                throw ex;
            }
        }
        public async Task<IEnumerable<StudentDetails>> GetDisagreedList()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetDisagreedList method");
                IList<StudentDetails> disagreedlist = new List<StudentDetails>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetDisagreedList").ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                disagreedlist.Add(new StudentDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    InternshipId = reader.To<long>("InternshipId"),
                                    StudentId = reader.To<long>("StudentId"),
                                    StudentName = reader.ToStringValue("StudentName"),
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr"),
                                    CompanyNameEn = reader.ToStringValue("CompanyNameEn"),
                                    CompanyNameAr = reader.ToStringValue("CompanyNameAr"),
                                    DisagreedReason = reader.ToStringValue("DisagreedReason"),
                                    DisagreedDate = reader.To<DateTime>("DisagreedDate"),
                                    Status = reader.To<int>("StatusId"),
                                });
                            }
                        }
                    }

                }
                this.Logger.LogInformation("Exiting from GetDisagreedList method");
                return disagreedlist;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetDisagreedList method : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<IEnumerable<InternshipDetails>> GetApplicationsList(long StudentId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetApplicationsList method for Id : " + StudentId.ToString());
                IList<InternshipDetails> applicationlist = new List<InternshipDetails>();
                var paramstudentid = new SqlParameter("@StudentId", SqlDbType.BigInt) { Value = StudentId };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetApplicationsList", paramstudentid).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                applicationlist.Add(new InternshipDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    UserInternshipId = reader.To<long>("UserInternshipId"),
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr"),
                                    CompanyNameEn = reader.ToStringValue("CompanyNameEn"),
                                    CompanyNameAr = reader.ToStringValue("CompanyNameAr"),
                                    CreatedBy = reader.ToStringValue("CreatedBy"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    StatusId = reader.To<int>("StatusId"),
                                    UpdatedBy = reader.ToStringValue("UpdatedBy"),
                                    UpdatedDate = reader.To<DateTime>("UpdatedDate"),
                                });
                            }
                        }
                    }

                }
                this.Logger.LogInformation("Exiting from GetApplicationsList  method for Id : " + StudentId.ToString());
                return applicationlist;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetApplicationsList method : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<IEnumerable<InternshipDetails>> GetAcceptedList(long StudentId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetAcceptedList method for Id : " + StudentId.ToString());
                IList<InternshipDetails> acceptedlist = new List<InternshipDetails>();
                var paramstudentid = new SqlParameter("@StudentId", SqlDbType.BigInt) { Value = StudentId };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetAcceptedList", paramstudentid).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                acceptedlist.Add(new InternshipDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    UserInternshipId = reader.To<long>("UserInternshipId"),
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr"),
                                    CompanyNameEn = reader.ToStringValue("CompanyNameEn"),
                                    CompanyNameAr = reader.ToStringValue("CompanyNameAr"),
                                    CreatedBy = reader.ToStringValue("CreatedBy"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    StatusId = reader.To<int>("StatusId"),
                                    UpdatedBy = reader.ToStringValue("UpdatedBy"),
                                    UpdatedDate = reader.To<DateTime>("UpdatedDate"),
                                    LastProbableJoiningDate = reader.To<DateTime>("LastProbableJoiningDate")
                                });
                            }
                        }
                    }

                }
                this.Logger.LogInformation("Exiting from GetAcceptedList  method for Id : " + StudentId.ToString());
                return acceptedlist;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetAcceptedList method : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<IEnumerable<StudentDetails>> GetAcceptedCandidatesList(long InternshipId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetAcceptedCandidatesList method for Id : " + InternshipId.ToString());
                IList<StudentDetails> candidateslist = new List<StudentDetails>();
                var paramid = new SqlParameter("@InternshipId", SqlDbType.BigInt) { Value = InternshipId };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetAcceptedCandidatesList", paramid).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                candidateslist.Add(new StudentDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    InternshipId = reader.To<long>("InternshipId"),
                                    StudentId = reader.To<long>("StudentId"),
                                    StudentName = reader.ToStringValue("StudentName"),
                                    Email = reader.ToStringValue("Email"),
                                    MobileNo = reader.To<long>("MobileNo"),
                                    ProbableJoiningDate = reader.To<DateTime>("ProbableJoiningDate"),
                                    Status = reader.To<int>("StatusId")
                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetAcceptedCandidatesList method for Id : " + InternshipId.ToString());
                return candidateslist;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetAcceptedCandidatesList method : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<IEnumerable<StudentDetails>> GetUpdateList(long InternshipId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetUpdateList method for Id : " + InternshipId.ToString());
                IList<StudentDetails> candidateslist = new List<StudentDetails>();
                var paramid = new SqlParameter("@InternshipId", SqlDbType.BigInt) { Value = InternshipId };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetUpdateList", paramid).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                candidateslist.Add(new StudentDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    InternshipId = reader.To<long>("InternshipId"),
                                    StudentId = reader.To<long>("StudentId"),
                                    StudentName = reader.ToStringValue("StudentName"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    Status = reader.To<int>("StatusId"),
                                    Withdrawn = reader.To<int>("Withdrawn"),
                                    Shortlisted = reader.To<int>("Shortlisted"),
                                    Rejected = reader.To<int>("Rejected"),
                                    Interviewed = reader.To<int>("Interviewed"),
                                    IsInterviewed = reader.To<int>("IsInterviewed"),
                                    DroppedOut = reader.To<int>("DroppedOut"),
                                    IsDroppedOut = reader.To<int>("IsDroppedOut"),
                                    Offered = reader.To<int>("Offered"),
                                    ScreenedOut = reader.To<int>("ScreenedOut"),
                                    Declined = reader.To<int>("Declined"),
                                    Accepted = reader.To<int>("Accepted"),
                                    Hired = reader.To<int>("Hired")
                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetUpdateList method for Id : " + InternshipId.ToString());
                return candidateslist;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetUpdateList method : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<IEnumerable<StudentDetails>> GetCandidatesListGrid(long InternshipId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetCandidatesListGrid method for Id : " + InternshipId.ToString());
                IList<StudentDetails> candidateslist = new List<StudentDetails>();
                var paramid = new SqlParameter("@InternshipId", SqlDbType.BigInt) { Value = InternshipId };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetCandidatesListGrid", paramid).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                candidateslist.Add(new StudentDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    InternshipId = reader.To<long>("InternshipId"),
                                    StudentId = reader.To<long>("StudentId"),
                                    StudentName = reader.ToStringValue("StudentName"),
                                    Email = reader.ToStringValue("Email"),
                                    MobileNo = reader.To<long>("MobileNo"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    Status = reader.To<int>("StatusId"),
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr")
                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetCandidatesListGrid method for Id : " + InternshipId.ToString());
                return candidateslist;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetCandidatesListGrid method : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<IEnumerable<StudentDetails>> GetAppliedList()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetAppliedList method : ");
                IList<StudentDetails> candidateslist = new List<StudentDetails>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetAppliedList").ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                candidateslist.Add(new StudentDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    InternshipId = reader.To<long>("InternshipId"),
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr"),
                                    CompanyNameEn = reader.ToStringValue("CompanyNameEn"),
                                    CompanyNameAr = reader.ToStringValue("CompanyNameAr"),
                                    StudentId = reader.To<long>("StudentId"),
                                    StudentName = reader.ToStringValue("StudentName"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    CutoffDate = reader.To<DateTime>("CutoffDate"),
                                    Status = reader.To<int>("StatusId"),
                                    CutOffReturn = reader.ToStringValue("CutOffReturn")
                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetAppliedList method for Id : ");
                return candidateslist;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetAppliedList method : ");
                throw ex;
            }
        }

        public async Task<IEnumerable<InternshipDetails>> GetExpiryListGrid(long UserId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetExpiryListGrid method for Id : " + UserId.ToString());
                IList<InternshipDetails> candidateslist = new List<InternshipDetails>();
                var paramid = new SqlParameter("@UserId", SqlDbType.BigInt) { Value = UserId };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetExpiryList", paramid).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                candidateslist.Add(new InternshipDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr"),
                                    ExpiryDate = reader.To<DateTime>("ExpiryDate")
                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetExpiryListGrid method for Id : " + UserId.ToString());
                return candidateslist;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetExpiryListGrid method : " + ex.ToString());
                throw ex;
            }
        }


        public async Task<IEnumerable<ExpiryModel>> UpdateExpiryList(IEnumerable<ExpiryModel> expiryUpdate)
        {
            try
            {
                this.logger.LogInformation("Entering into UpdateExpiryList Method");
                List<ExpiryModel> update = expiryUpdate.ToList();
                for (int i = 0; i < update.Count; i++)
                {
                    var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = update[i].Id };
                    var paramExpiryDate = new SqlParameter("@ExpiryDate", SqlDbType.DateTime) { Value = update[i].ExpiryDate };

                    using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                    {
                        SqlTransaction transaction = null;
                        try
                        {
                            transaction = connection.BeginTransaction();
                            await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "UpdateExpiryList",
                                paramId,
                                paramExpiryDate

                                ).ConfigureAwait(false);
                            transaction.Commit();
                        }
                        catch
                        {
                            if (transaction != null)
                            {
                                transaction.Rollback();
                                throw;
                            }
                        }
                    }

                }

                this.logger.LogInformation("Exiting from UpdateExpiryList Method");
                return expiryUpdate;
            }
            catch (Exception ex)
            {
                this.logger.LogError("Error Occured", "ERROR in UpdateExpiryList Method : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<StudentDetails> GetStudentDetails(long StudentId, long InternshipId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetStudentDetails method");
                StudentDetails StudentDetailsforview = null;
                var questionnairedetails = await this.GetQuestionAnswerDetails(InternshipId, StudentId);
                var paramstudentid = new SqlParameter("@StudentId", SqlDbType.BigInt) { Value = StudentId };
                var paraminternshipid = new SqlParameter("@InternshipId", SqlDbType.BigInt) { Value = InternshipId };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                                connection,
                                                CommandType.StoredProcedure,
                                                "GetStudentDetails", paramstudentid, paraminternshipid).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                StudentDetailsforview = new StudentDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    InternshipId = reader.To<long>("InternshipId"),
                                    StudentId = reader.To<long>("StudentId"),
                                    //PermanentAddressLine1 = reader.ToStringValue("PermanentAddressLine1"),
                                    //Email = reader.ToStringValue("Email"),
                                    //MobileNo = reader.To<long>("MobileNo"),
                                    //Emirate = reader.ToStringValue("Emirate"),
                                    Resume = reader.ToStringValue("Resume"),
                                    InternshipQuestionnaireDetails = questionnairedetails.ToList(),
                                    ResumeId = reader.To<long>("ResumeId"),
                                };
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetStudentDetails method");
                return StudentDetailsforview;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetStudentDetails method : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<IEnumerable<AdminFeedbackDetails>> GetPendingAdminFeedback(long InternshipId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetPendingAdminFeedback method for Id : " + InternshipId.ToString());
                IList<AdminFeedbackDetails> studentlist = new List<AdminFeedbackDetails>();
                //AdminFeedbackDetails adminFeedbackDetails = null;
                var paramid = new SqlParameter("@InternshipId", SqlDbType.BigInt) { Value = InternshipId };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetPendingAdminFeedback", paramid).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                studentlist.Add(new AdminFeedbackDetails
                                {
                                    //Id = reader.To<long>("Id"),
                                    InternshipId = reader.To<long>("InternshipId"),
                                    StudentId = reader.To<long>("StudentId"),
                                    StudentName = reader.ToStringValue("StudentName"),
                                    Email = reader.ToStringValue("Email"),
                                    MobileNo = reader.To<long>("MobileNo"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    Duration = reader.To<int>("Duration"),
                                    CreatedBy = reader.ToStringValue("CreatedBy")

                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetPendingAdminFeedback method for Id : " + InternshipId.ToString());
                return studentlist;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetPendingAdminFeedback method : " + ex.ToString());
                throw ex;
            }
        }
        public async Task<AdminFeedbackDetails> SaveAdminFeedbackDetails(AdminFeedbackDetails adminFeedbackdetail)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveAdminFeedbackDetails method");
                var paramreferenceid = new SqlParameter("@ReferenceId", SqlDbType.BigInt) { Value = adminFeedbackdetail.Id, Direction = ParameterDirection.Output };
                var paramfeedbackId = new SqlParameter("@FeedbackId", SqlDbType.BigInt) { Value = adminFeedbackdetail.FeedbackId };
                var paramInternshipId = new SqlParameter("@InternshipId", SqlDbType.BigInt) { Value = adminFeedbackdetail.InternshipId };
                var paramStudentId = new SqlParameter("@StudentId", SqlDbType.BigInt) { Value = adminFeedbackdetail.StudentId };
                var paramTerm = new SqlParameter("@Term", SqlDbType.BigInt) { Value = adminFeedbackdetail.Term };
                var paramEmployerId = new SqlParameter("@EmployerId", SqlDbType.BigInt) { Value = adminFeedbackdetail.EmployerId };
                var paramSupervisorName = new SqlParameter("@SupervisorName", SqlDbType.NVarChar) { Value = adminFeedbackdetail.SupervisorName };
                var paramSupervisorDesignation = new SqlParameter("@SupervisorDesignation", SqlDbType.NVarChar) { Value = adminFeedbackdetail.SupervisorDesignation };
                var paramSupervisorEmail = new SqlParameter("@SupervisorEmailId", SqlDbType.NVarChar) { Value = adminFeedbackdetail.SupervisorEmailId };
                var paramshortDescription = new SqlParameter("@ShortDescription", SqlDbType.NVarChar) { Value = adminFeedbackdetail.ShortDescription };
                var paramstrength = new SqlParameter("@Strength", SqlDbType.NVarChar) { Value = adminFeedbackdetail.Strength };
                var paramDevelopmentAreas = new SqlParameter("@DevelopmentAreas", SqlDbType.NVarChar) { Value = adminFeedbackdetail.DevelopmentAreas };
                var paramComments = new SqlParameter("@Comments", SqlDbType.NVarChar) { Value = adminFeedbackdetail.Comments };
                var paramDepartment = new SqlParameter("@Department", SqlDbType.NVarChar) { Value = adminFeedbackdetail.Department };
                var paramCreatedBy = new SqlParameter("@CreatedBy", SqlDbType.NVarChar) { Value = adminFeedbackdetail.CreatedBy };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveAdminFeedbackDetails",

                        paramreferenceid,
                        paramfeedbackId,
                        paramInternshipId,
                        paramStudentId,
                        paramTerm,
                        paramEmployerId,
                        paramSupervisorName,
                        paramSupervisorDesignation,
                        paramSupervisorEmail,
                        paramshortDescription,
                        paramstrength,
                        paramDevelopmentAreas,
                        paramComments,
                        paramDepartment,
                        paramCreatedBy
                        ).ConfigureAwait(false);
                        transaction.Commit();

                    }

                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                adminFeedbackdetail.Id = (long)paramreferenceid.Value;
                if (adminFeedbackdetail.AdminFeedbackRatingModel != null)
                {
                    await SaveAdminFeedbackRatings(adminFeedbackdetail.AdminFeedbackRatingModel, adminFeedbackdetail.Id);
                }
                this.Logger.LogInformation("Exiting from SaveAdminFeedbackDetails Method");
                return adminFeedbackdetail;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in SaveAdminFeedbackDetails Method : " + ex.ToString());
                throw ex;
            }
        }
        public async Task<List<AdminFeedbackRatingModel>> SaveAdminFeedbackRatings(IEnumerable<AdminFeedbackRatingModel> adminFeedbackrating, long Id)
        {
            List<AdminFeedbackRatingModel> ratinglist = new List<AdminFeedbackRatingModel>();
            ratinglist = adminFeedbackrating.ToList();
            for (int i = 0; i < ratinglist.Count; i++)
            {
                try
                {
                    this.Logger.LogInformation("Entering into SaveFeedbackRatings method");

                    ratinglist[i].Id = Id;
                    var paramreferenceid = new SqlParameter("@ReferenceId", SqlDbType.BigInt) { Value = ratinglist[i].Id, Direction = ParameterDirection.Output };
                    var paramid = new SqlParameter("@Id", SqlDbType.BigInt) { Value = ratinglist[i].Id };
                    var paramfeedbackId = new SqlParameter("@FeedbackId", SqlDbType.BigInt) { Value = ratinglist[i].FeedbackId };
                    var paramParameterId = new SqlParameter("@ParameterId", SqlDbType.BigInt) { Value = ratinglist[i].ParameterId };
                    var paramRating = new SqlParameter("@Rating", SqlDbType.BigInt) { Value = ratinglist[i].Rating };
                    var paramIsApplicable = new SqlParameter("@IsApplicable", SqlDbType.Bit) { Value = ratinglist[i].IsApplicable };
                    var paramCreatedBy = new SqlParameter("@CreatedBy", SqlDbType.NVarChar) { Value = ratinglist[i].CreatedBy };
                    using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                    {
                        SqlTransaction transaction = null;
                        try
                        {
                            transaction = connection.BeginTransaction();
                            await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveAdminFeedbackRating",

                            paramreferenceid,
                            paramid,
                            paramfeedbackId,
                            paramParameterId,
                            paramRating,
                            paramIsApplicable,
                             paramCreatedBy
                            ).ConfigureAwait(false);
                            transaction.Commit();
                        }

                        catch
                        {
                            if (transaction != null)
                            {
                                transaction.Rollback();
                                throw;
                            }
                        }
                    }
                    ratinglist[i].Id = (long)paramreferenceid.Value;

                }
                catch (Exception ex)
                {
                    this.Logger.LogError("Error Occured", "ERROR in SaveFeedbackRatings Method : " + ex.ToString());
                    throw ex;
                }
            }

            this.Logger.LogInformation("Exiting from SaveFeedbackRatings Method");
            return ratinglist;
        }

        public async Task<IEnumerable<AdminFeedbackDetails>> GetAdminFeedbackDetails(long InternshipId, long StudentId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetPendingAdminFeedback method for Id : " + InternshipId.ToString());
                IList<AdminFeedbackDetails> studentlist = new List<AdminFeedbackDetails>();
                var ratinglist = await this.GetRatingsLoad();
                var paramid = new SqlParameter("@InternshipId", SqlDbType.BigInt) { Value = InternshipId };
                var paramstudentId = new SqlParameter("@StudentId", SqlDbType.BigInt) { Value = StudentId };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetAdminFeedbackDetails", paramid, paramstudentId).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                studentlist.Add(new AdminFeedbackDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    InternshipId = reader.To<long>("InternshipId"),
                                    StudentId = reader.To<long>("StudentId"),
                                    UserId = reader.To<long>("UserId"),
                                    StudentName = reader.ToStringValue("StudentName"),
                                    Email = reader.ToStringValue("Email"),
                                    StudentLocation = reader.ToStringValue("StudentLocation"),
                                    Institute = reader.ToStringValue("Institute"),
                                    MajorEn = reader.ToStringValue("MajorEn"),
                                    MajorAr = reader.ToStringValue("MajorAr"),
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr"),
                                    MonthlySalaryRangeId = reader.To<int>("MonthlySalaryRangeId"),
                                    EmployerName = reader.ToStringValue("EmployerName"),
                                    Location = reader.ToStringValue("Location"),
                                    MinimumHoursRequiredId = reader.To<int>("MinimumHoursRequiredId"),
                                    Duration = reader.To<int>("Duration"),
                                    JoiningDate = reader.To<DateTime>("JoiningDate"),
                                    CreatedBy = reader.ToStringValue("CreatedBy"),
                                    AdminFeedbackRatingModel = ratinglist.ToList(),

                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetPendingAdminFeedback method for Id : " + InternshipId.ToString());
                return studentlist;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetPendingAdminFeedback method : " + ex.ToString());
                throw ex;
            }
        }
        public async Task<List<AdminFeedbackRatingModel>> GetRatingsLoad()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetAdminFeedbackRatings");
                IList<AdminFeedbackRatingModel> ratingList = new List<AdminFeedbackRatingModel>();
                // IList<StudentFeedbackRatingModel> studentList = new List<StudentFeedbackRatingModel>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                                                connection,
                                                                CommandType.StoredProcedure,
                                                                "GetRatingsLoad"
                                                                 ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                ratingList.Add(new AdminFeedbackRatingModel
                                {
                                    //Id = reader.To<int>("Id"),
                                    //FeedbackId = reader.To<int>("FeedbackId"),
                                    //ParameterId = reader.To<int>("ParameterId"),
                                    //Rating = reader.To<int>("Rating"),
                                    //IsApplicable = reader.To<bool>("IsApplicable"),
                                    DropdownId = reader.To<int>("DropdownId"),
                                    DropdownValueEn = reader.ToStringValue("DropdownValueEn"),
                                    DropdownValueAr = reader.ToStringValue("DropdownValueAr"),

                                });
                            }
                        }


                    }
                }
                this.Logger.LogInformation("Exiting from GetAdminFeedbackRatings");
                return (List<AdminFeedbackRatingModel>)ratingList;

            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetAdminFeedbackRatings method :" + ex.ToString());
                throw ex;
            }
        }

        public async Task<IEnumerable<AdminFeedbackDetails>> GetFeedbackReceivedListforStudent(long StudentId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetFeedbackReceivedListforStudent method for Id : " + StudentId.ToString());
                IList<AdminFeedbackDetails> receivedlist = new List<AdminFeedbackDetails>();
                var paramid = new SqlParameter("@StudentId", SqlDbType.BigInt) { Value = StudentId };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetFeedbackReceivedListforStudent", paramid).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                receivedlist.Add(new AdminFeedbackDetails
                                {
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    CompanyNameEn = reader.ToStringValue("CompanyNameEn"),
                                    CompanyNameAr = reader.ToStringValue("CompanyNameAr"),
                                    Department = reader.ToStringValue("Department"),
                                    SupervisorDesignation = reader.ToStringValue("SupervisorDesignation"),
                                    InternshipId = reader.To<long>("InternshipId"),
                                    FeedbackId = reader.To<long>("FeedbackId"),
                                    StudentId = reader.To<long>("StudentId")
                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetFeedbackReceivedListforStudent method for Id : " + StudentId.ToString());
                return receivedlist;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetFeedbackReceivedListforStudent method : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<IEnumerable<AdminFeedbackDetails>> GetStudentFeedbackListforHEI()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetStudentFeedbackListforHEI method");
                IList<AdminFeedbackDetails> studentFeedback = new List<AdminFeedbackDetails>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetStudentFeedbackListforHEI").ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                studentFeedback.Add(new AdminFeedbackDetails
                                {
                                    CompanyNameEn = reader.ToStringValue("CompanyNameEn"),
                                    CompanyNameAr = reader.ToStringValue("CompanyNameAr"),
                                    Department = reader.ToStringValue("Department"),
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr"),
                                    StudentName = reader.ToStringValue("StudentName"),
                                    Email = reader.ToStringValue("Email"),
                                    MobileNo = reader.To<long>("MobileNo"),
                                    InternshipId = reader.To<long>("InternshipId"),
                                    FeedbackId = reader.To<long>("FeedbackId"),
                                    StudentId = reader.To<long>("StudentId")
                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetStudentFeedbackListforHEI method");
                return studentFeedback;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetStudentFeedbackListforHEI method : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<IEnumerable<AdminFeedbackDetails>> GetProvidedAdminFeedback(long InternshipId, string CreatedBy)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetProvidedAdminFeedback method for Id : " + InternshipId.ToString());
                IList<AdminFeedbackDetails> studentlist = new List<AdminFeedbackDetails>();
                //AdminFeedbackDetails adminFeedbackDetails = null;
                var paramid = new SqlParameter("@InternshipId", SqlDbType.BigInt) { Value = InternshipId };
                var paramCreatedBy = new SqlParameter("@CreatedBy", SqlDbType.NVarChar) { Value = CreatedBy };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetProvidedAdminFeedback", paramid, paramCreatedBy).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                studentlist.Add(new AdminFeedbackDetails
                                {
                                    //Id = reader.To<long>("Id"),
                                    InternshipId = reader.To<long>("InternshipId"),
                                    StudentId = reader.To<long>("StudentId"),
                                    StudentName = reader.ToStringValue("StudentName"),
                                    Email = reader.ToStringValue("Email"),
                                    MobileNo = reader.To<long>("MobileNo"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    FeedbackId = reader.To<long>("FeedbackId")

                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetProvidedAdminFeedback method for Id : " + InternshipId.ToString());
                return studentlist;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetProvidedAdminFeedback method : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<AdminFeedbackDetails> GetFeedbackDetailsAdmin(long InternshipId, long FeedbackId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetFeedbackDetailsAdmin method for Id : " + InternshipId.ToString());
                AdminFeedbackDetails studentlist = null;
                var ratinglist = await this.GetRatingsAdmin(FeedbackId);
                var paramid = new SqlParameter("@InternshipId", SqlDbType.BigInt) { Value = InternshipId };
                var paramFeedbackId = new SqlParameter("@FeedbackId", SqlDbType.BigInt) { Value = FeedbackId };
                //var paramstudentId = new SqlParameter("@StudentId", SqlDbType.BigInt) { Value = StudentId };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetFeedbackAdminDetails", paramid, paramFeedbackId).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                studentlist = new AdminFeedbackDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    InternshipId = reader.To<long>("InternshipId"),
                                    StudentId = reader.To<long>("StudentId"),
                                    //UserId = reader.To<long>("UserId"),
                                    StudentName = reader.ToStringValue("StudentName"),
                                    Email = reader.ToStringValue("Email"),
                                    StudentLocation = reader.ToStringValue("StudentLocation"),
                                    Institute = reader.ToStringValue("Institute"),
                                    MajorEn = reader.ToStringValue("MajorEn"),
                                    MajorAr = reader.ToStringValue("MajorAr"),
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr"),
                                    MonthlySalaryRangeId = reader.To<int>("MonthlySalaryRangeId"),
                                    EmployerName = reader.ToStringValue("EmployerName"),
                                    Location = reader.ToStringValue("Location"),
                                    MinimumHoursRequiredId = reader.To<int>("MinimumHoursRequiredId"),
                                    Duration = reader.To<int>("Duration"),
                                    JoiningDate = reader.To<DateTime>("JoiningDate"),
                                    CreatedBy = reader.ToStringValue("CreatedBy"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    Term = reader.To<int>("Term"),
                                    Department = reader.ToStringValue("Department"),
                                    SupervisorName = reader.ToStringValue("SupervisorName"),
                                    SupervisorDesignation = reader.ToStringValue("SupervisorDesignation"),
                                    SupervisorEmailId = reader.ToStringValue("SupervisorEmailId"),
                                    ShortDescription = reader.ToStringValue("ShortDescription"),
                                    Strength = reader.ToStringValue("Strength"),
                                    DevelopmentAreas = reader.ToStringValue("DevelopmentAreas"),
                                    Comments = reader.ToStringValue("Comments"),
                                    FeedbackId = reader.To<long>("FeedbackId"),
                                    AdminFeedbackRatingModel = ratinglist.ToList(),

                                };
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetFeedbackDetailsAdmin method for Id : " + InternshipId.ToString());
                return studentlist;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetFeedbackDetailsAdmin method : " + ex.ToString());
                throw ex;
            }
        }
        public async Task<List<AdminFeedbackRatingModel>> GetRatingsAdmin(long FeedbackId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetRatingsAdmin");
                IList<AdminFeedbackRatingModel> ratingList = new List<AdminFeedbackRatingModel>();
                var paramFeedbackId = new SqlParameter("@FeedbackId", SqlDbType.BigInt) { Value = FeedbackId };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                                                connection,
                                                                CommandType.StoredProcedure,
                                                                "GetRatingsAdmin", paramFeedbackId
                                                                 ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                ratingList.Add(new AdminFeedbackRatingModel
                                {
                                    FeedbackId = reader.To<int>("FeedbackId"),
                                    ParameterId = reader.To<int>("ParameterId"),
                                    Rating = reader.To<int>("Rating"),
                                    // IsApplicable = reader.To<bool>("IsApplicable"),
                                    DropdownValueEn = reader.ToStringValue("DropdownValueEn"),
                                    DropdownValueAr = reader.ToStringValue("DropdownValueAr"),

                                });
                            }
                        }


                    }
                }
                this.Logger.LogInformation("Exiting from GetRatingsAdmin");
                return ratingList.ToList();
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetRatingsAdmin method :" + ex.ToString());
                throw ex;
            }
        }

        public async Task<IEnumerable<StudentFeedbackDetails>> GetAdminFeedbackReceivedList(long UserId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetAdminFeedbackReceivedList method" + UserId.ToString());
                IList<StudentFeedbackDetails> feedbacklist = new List<StudentFeedbackDetails>();
                var paramUserid = new SqlParameter("@UserId", SqlDbType.BigInt) { Value = UserId };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetAdminFeedbackReceived", paramUserid).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                feedbacklist.Add(new StudentFeedbackDetails
                                {
                                    StudentFeedbackId = reader.To<long>("StudentFeedbackId"),
                                    InternshipId = reader.To<long>("InternshipId"),
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    StudentId = reader.To<long>("StudentId"),
                                    StudentName = reader.ToStringValue("StudentName"),
                                    Email = reader.ToStringValue("Email"),
                                    PhoneNumber = reader.ToStringValue("PhoneNumber")
                                });
                            }
                        }
                    }

                }
                this.Logger.LogInformation("Exiting from GetAdminFeedbackReceivedList method" + UserId.ToString());
                return feedbacklist;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetAdminFeedbackReceivedList method : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<IEnumerable<StudentFeedbackDetails>> GetCounselorFeedbackReceivedList()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetCounselorFeedbackReceivedList method : ");
                IList<StudentFeedbackDetails> feedbacklist = new List<StudentFeedbackDetails>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetCounselorFeedbackReceived").ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                feedbacklist.Add(new StudentFeedbackDetails
                                {
                                    StudentFeedbackId = reader.To<long>("StudentFeedbackId"),
                                    InternshipId = reader.To<long>("InternshipId"),
                                    CompanyNameEn = reader.ToStringValue("CompanyNameEn"),
                                    CompanyNameAr = reader.ToStringValue("CompanyNameAr"),
                                    Department = reader.ToStringValue("Department"),
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr"),
                                    StudentId = reader.To<long>("StudentId"),
                                    StudentName = reader.ToStringValue("StudentName"),
                                    Email = reader.ToStringValue("Email"),
                                    PhoneNumber = reader.ToStringValue("PhoneNumber")
                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetCounselorFeedbackReceivedList method ");
                return feedbacklist;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetCounselorFeedbackReceivedList method : ");
                throw ex;
            }
        }

        public async Task<IEnumerable<StudentFeedbackDetails>> GetMoeFeedbackReceivedList()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetMoeFeedbackReceivedList method : ");
                IList<StudentFeedbackDetails> feedbacklist = new List<StudentFeedbackDetails>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetMoeFeedbackReceived").ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                feedbacklist.Add(new StudentFeedbackDetails
                                {
                                    StudentFeedbackId = reader.To<long>("StudentFeedbackId"),
                                    InternshipId = reader.To<long>("InternshipId"),
                                    CompanyNameEn = reader.ToStringValue("CompanyNameEn"),
                                    CompanyNameAr = reader.ToStringValue("CompanyNameAr"),
                                    Department = reader.ToStringValue("Department"),
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr"),
                                    StudentId = reader.To<long>("StudentId"),
                                    StudentName = reader.ToStringValue("StudentName"),
                                    HEI = reader.ToStringValue("HEI")
                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetMoeFeedbackReceivedList method ");
                return feedbacklist;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetMoeFeedbackReceivedList method : ");
                throw ex;
            }
        }

        public async Task<StudentFeedbackDetails> SaveStudentFeedbackDetails(StudentFeedbackDetails studentFeedbackdetail)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveAdminFeedbackDetails method");
                var paramreferenceid = new SqlParameter("@ReferenceId", SqlDbType.BigInt) { Value = studentFeedbackdetail.Id, Direction = ParameterDirection.Output };
                var paramStudentFeedbackId = new SqlParameter("@StudentFeedbackId", SqlDbType.BigInt) { Value = studentFeedbackdetail.StudentFeedbackId };
                var paramInternshipId = new SqlParameter("@InternshipId", SqlDbType.BigInt) { Value = studentFeedbackdetail.InternshipId };
                var paramStudentId = new SqlParameter("@StudentId", SqlDbType.BigInt) { Value = studentFeedbackdetail.StudentId };
                var paramTerm = new SqlParameter("@Term", SqlDbType.BigInt) { Value = studentFeedbackdetail.Term };
                var paramDepartment = new SqlParameter("@Department", SqlDbType.NVarChar) { Value = studentFeedbackdetail.Department };
                var paramEmployerId = new SqlParameter("@EmployerId", SqlDbType.BigInt) { Value = studentFeedbackdetail.EmployerId };
                var paramSupervisorName = new SqlParameter("@SupervisorName", SqlDbType.NVarChar) { Value = studentFeedbackdetail.SupervisorName };
                var paramSupervisorDesignation = new SqlParameter("@SupervisorDesignation", SqlDbType.NVarChar) { Value = studentFeedbackdetail.SupervisorDesignation };
                var paramSupervisorEmail = new SqlParameter("@SupervisorEmailId", SqlDbType.NVarChar) { Value = studentFeedbackdetail.SupervisorEmailId };
                var paramAnyFeedback = new SqlParameter("@AnyFeedback", SqlDbType.NVarChar) { Value = studentFeedbackdetail.AnyFeedback };
                var paramCreatedBy = new SqlParameter("@CreatedBy", SqlDbType.NVarChar) { Value = studentFeedbackdetail.CreatedBy };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveStudentFeedbackDetails",

                        paramreferenceid,
                        paramStudentFeedbackId,
                        paramInternshipId,
                        paramStudentId,
                        paramTerm,
                        paramDepartment,
                        paramEmployerId,
                        paramSupervisorName,
                        paramSupervisorDesignation,
                        paramSupervisorEmail,
                        paramAnyFeedback,
                        paramCreatedBy
                        ).ConfigureAwait(false);
                        transaction.Commit();

                    }

                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                studentFeedbackdetail.Id = (long)paramreferenceid.Value;
                if (studentFeedbackdetail.StudentFeedbackRatingModel != null)
                {
                    await SaveStudentFeedbackRatings(studentFeedbackdetail.StudentFeedbackRatingModel, studentFeedbackdetail.Id);
                }
                this.Logger.LogInformation("Exiting from SaveAdminFeedbackDetails Method");
                return studentFeedbackdetail;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in SaveAdminFeedbackDetails Method : " + ex.ToString());
                throw ex;
            }
        }
        public async Task<List<StudentFeedbackRatingModel>> SaveStudentFeedbackRatings(IEnumerable<StudentFeedbackRatingModel> studentFeedbackrating, long Id)
        {
            List<StudentFeedbackRatingModel> ratinglist = new List<StudentFeedbackRatingModel>();
            ratinglist = studentFeedbackrating.ToList();
            for (int i = 0; i < ratinglist.Count; i++)
            {
                try
                {
                    this.Logger.LogInformation("Entering into SaveStudentFeedbackRatings method");

                    ratinglist[i].Id = Id;
                    var paramreferenceid = new SqlParameter("@ReferenceId", SqlDbType.BigInt) { Value = ratinglist[i].Id, Direction = ParameterDirection.Output };
                    var paramid = new SqlParameter("@Id", SqlDbType.BigInt) { Value = ratinglist[i].Id };
                    var paramStudentFeedbackId = new SqlParameter("@StudentFeedbackId", SqlDbType.BigInt) { Value = ratinglist[i].StudentFeedbackId };
                    var paramParameterId = new SqlParameter("@ParameterId", SqlDbType.BigInt) { Value = ratinglist[i].ParameterId };
                    var paramRating = new SqlParameter("@Rating", SqlDbType.BigInt) { Value = ratinglist[i].Rating };
                    var paramIsApplicable = new SqlParameter("@IsApplicable", SqlDbType.Bit) { Value = ratinglist[i].IsApplicable };
                    // var paramCreatedBy = new SqlParameter("@CreatedBy", SqlDbType.NVarChar) { Value = studentFeedbackrating.CreatedBy };

                    var paramCreatedBy = new SqlParameter("@CreatedBy", SqlDbType.NVarChar) { Value = ratinglist[i].CreatedBy };
                    using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                    {
                        SqlTransaction transaction = null;
                        try
                        {
                            transaction = connection.BeginTransaction();
                            await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveStudentFeedbackRating",

                            paramreferenceid,
                            paramid,
                            paramStudentFeedbackId,
                            paramParameterId,
                            paramRating,
                            paramIsApplicable,
                             paramCreatedBy
                            ).ConfigureAwait(false);
                            transaction.Commit();
                        }

                        catch
                        {
                            if (transaction != null)
                            {
                                transaction.Rollback();
                                throw;
                            }
                        }
                    }
                    ratinglist[i].Id = (long)paramreferenceid.Value;

                }
                catch (Exception ex)
                {
                    this.Logger.LogError("Error Occured", "ERROR in SaveStudentFeedbackRatings Method : " + ex.ToString());
                    throw ex;
                }
            }

            this.Logger.LogInformation("Exiting from SaveStudentFeedbackRatings Method");
            return ratinglist;
        }

        public async Task<IEnumerable<StudentFeedbackDetails>> GetPendingStudentFeedback(long StudentId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetPendingStudentFeedback method for Id : " + StudentId.ToString());
                IList<StudentFeedbackDetails> studentlist = new List<StudentFeedbackDetails>();
                var paramid = new SqlParameter("@StudentId", SqlDbType.BigInt) { Value = StudentId };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetPendingStudentFeedback", paramid).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                studentlist.Add(new StudentFeedbackDetails
                                {
                                    //Id = reader.To<long>("Id"),
                                    InternshipId = reader.To<long>("InternshipId"),
                                    StudentId = reader.To<long>("StudentId"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    Duration = reader.To<int>("Duration"),
                                    CreatedBy = reader.ToStringValue("CreatedBy"),
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr"),
                                    CompanyNameEn = reader.ToStringValue("CompanyNameEn"),
                                    CompanyNameAr = reader.ToStringValue("CompanyNameAr"),
                                    CompletionDate = reader.To<DateTime>("CompletionDate"),
                                    CutOffDate = reader.To<DateTime>("CutOffDate"),
                                    Department = reader.ToStringValue("Department"),
                                    SupervisorDesignation = reader.ToStringValue("SupervisorDesignation"),
                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetPendingStudentFeedback method for Id : " + StudentId.ToString());
                return studentlist;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetPendingStudentFeedback method : " + ex.ToString());
                throw ex;
            }
        }
        public async Task<IEnumerable<StudentFeedbackDetails>> GetStudentFeedbackDetails(long InternshipId, long StudentId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetStudentFeedbackDetails method for Id : " + InternshipId.ToString());
                IList<StudentFeedbackDetails> studentlist = new List<StudentFeedbackDetails>();
                var ratinglist = await this.GetStudentRatingsLoad();
                var paramid = new SqlParameter("@InternshipId", SqlDbType.BigInt) { Value = InternshipId };
                var paramstudentId = new SqlParameter("@StudentId", SqlDbType.BigInt) { Value = StudentId };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetAdminFeedbackDetails", paramid, paramstudentId).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                studentlist.Add(new StudentFeedbackDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    InternshipId = reader.To<long>("InternshipId"),
                                    StudentId = reader.To<long>("StudentId"),
                                    UserId = reader.To<long>("UserId"),
                                    StudentName = reader.ToStringValue("StudentName"),
                                    Email = reader.ToStringValue("Email"),
                                    StudentLocation = reader.ToStringValue("StudentLocation"),
                                    Institute = reader.ToStringValue("Institute"),
                                    MajorEn = reader.ToStringValue("MajorEn"),
                                    MajorAr = reader.ToStringValue("MajorAr"),
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr"),
                                    MonthlySalaryRangeId = reader.To<int>("MonthlySalaryRangeId"),
                                    EmployerName = reader.ToStringValue("EmployerName"),
                                    Location = reader.ToStringValue("Location"),
                                    MinimumHoursRequiredId = reader.To<int>("MinimumHoursRequiredId"),
                                    Duration = reader.To<int>("Duration"),
                                    JoiningDate = reader.To<DateTime>("JoiningDate"),
                                    CreatedBy = reader.ToStringValue("CreatedBy"),
                                    StudentFeedbackRatingModel = ratinglist.ToList(),

                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetStudentFeedbackDetails method for Id : " + InternshipId.ToString());
                return studentlist;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetStudentFeedbackDetails method : " + ex.ToString());
                throw ex;
            }
        }
        public async Task<List<StudentFeedbackRatingModel>> GetStudentRatingsLoad()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetAdminFeedbackRatings");
                IList<StudentFeedbackRatingModel> ratingList = new List<StudentFeedbackRatingModel>();
                // IList<StudentFeedbackRatingModel> studentList = new List<StudentFeedbackRatingModel>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                                                connection,
                                                                CommandType.StoredProcedure,
                                                                "GetStudentRatingsLoad"
                                                                 ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                ratingList.Add(new StudentFeedbackRatingModel
                                {
                                    //Id = reader.To<int>("Id"),
                                    //FeedbackId = reader.To<int>("FeedbackId"),
                                    //ParameterId = reader.To<int>("ParameterId"),
                                    //Rating = reader.To<int>("Rating"),
                                    //IsApplicable = reader.To<bool>("IsApplicable"),
                                    DropdownId = reader.To<int>("DropdownId"),
                                    DropdownValueEn = reader.ToStringValue("DropdownValueEn"),
                                    DropdownValueAr = reader.ToStringValue("DropdownValueAr"),

                                });
                            }
                        }


                    }
                }
                this.Logger.LogInformation("Exiting from GetAdminFeedbackRatings");
                return (List<StudentFeedbackRatingModel>)ratingList;

            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetAdminFeedbackRatings method :" + ex.ToString());
                throw ex;
            }
        }

        public async Task<IEnumerable<StudentFeedbackDetails>> GetProvidedStudentFeedback(long StudentId, string CreatedBy)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetProvidedAdminFeedback method for Id : " + StudentId.ToString());
                IList<StudentFeedbackDetails> studentlist = new List<StudentFeedbackDetails>();
                //AdminFeedbackDetails adminFeedbackDetails = null;
                var paramid = new SqlParameter("@StudentId", SqlDbType.BigInt) { Value = StudentId };
                var paramCreatedBy = new SqlParameter("@CreatedBy", SqlDbType.NVarChar) { Value = CreatedBy };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetProvidedStudentFeedback", paramid, paramCreatedBy).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                studentlist.Add(new StudentFeedbackDetails
                                {
                                    //Id = reader.To<long>("Id"),
                                    InternshipId = reader.To<long>("InternshipId"),
                                    StudentId = reader.To<long>("StudentId"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    Duration = reader.To<int>("Duration"),
                                    CreatedBy = reader.ToStringValue("CreatedBy"),
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr"),
                                    CompanyNameEn = reader.ToStringValue("CompanyNameEn"),
                                    CompanyNameAr = reader.ToStringValue("CompanyNameAr"),
                                    CompletionDate = reader.To<DateTime>("CompletionDate"),
                                    CutOffDate = reader.To<DateTime>("CutOffDate"),
                                    Department = reader.ToStringValue("Department"),
                                    SupervisorDesignation = reader.ToStringValue("SupervisorDesignation"),
                                    StudentFeedbackId = reader.To<long>("StudentFeedbackId")

                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetProvidedAdminFeedback method for Id : " + StudentId.ToString());
                return studentlist;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetProvidedAdminFeedback method : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<StudentFeedbackDetails> GetFeedbackDetailsStudents(long StudentFeedbackId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetFeedbackDetailsStudents method for Id : " + StudentFeedbackId.ToString());
                StudentFeedbackDetails studentlist = null;
                var ratinglist = await this.GetRatingsStudent(StudentFeedbackId);
                var paramStudentFeedbackId = new SqlParameter("@StudentFeedbackId", SqlDbType.BigInt) { Value = StudentFeedbackId };
                //var paramstudentId = new SqlParameter("@StudentId", SqlDbType.BigInt) { Value = StudentId };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetFeedbackStudentDetails", paramStudentFeedbackId).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                studentlist = new StudentFeedbackDetails
                                {
                                    Id = reader.To<long>("Id"),
                                    InternshipId = reader.To<long>("InternshipId"),
                                    StudentId = reader.To<long>("StudentId"),
                                    //UserId = reader.To<long>("UserId"),
                                    StudentName = reader.ToStringValue("StudentName"),
                                    Email = reader.ToStringValue("Email"),
                                    StudentLocation = reader.ToStringValue("StudentLocation"),
                                    Institute = reader.ToStringValue("Institute"),
                                    MajorEn = reader.ToStringValue("MajorEn"),
                                    MajorAr = reader.ToStringValue("MajorAr"),
                                    InternshipRoleNameEn = reader.ToStringValue("InternshipRoleNameEn"),
                                    InternshipRoleNameAr = reader.ToStringValue("InternshipRoleNameAr"),
                                    MonthlySalaryRangeId = reader.To<int>("MonthlySalaryRangeId"),
                                    EmployerName = reader.ToStringValue("EmployerName"),
                                    Location = reader.ToStringValue("Location"),
                                    MinimumHoursRequiredId = reader.To<int>("MinimumHoursRequiredId"),
                                    Duration = reader.To<int>("Duration"),
                                    JoiningDate = reader.To<DateTime>("JoiningDate"),
                                    CreatedDate = reader.To<DateTime>("CreatedDate"),
                                    CreatedBy = reader.ToStringValue("CreatedBy"),
                                    Term = reader.To<int>("Term"),
                                    Department = reader.ToStringValue("Department"),
                                    SupervisorName = reader.ToStringValue("SupervisorName"),
                                    SupervisorDesignation = reader.ToStringValue("SupervisorDesignation"),
                                    SupervisorEmailId = reader.ToStringValue("SupervisorEmailId"),
                                    AnyFeedback = reader.ToStringValue("AnyFeedback"),
                                    StudentFeedbackId = reader.To<long>("StudentFeedbackId"),
                                    StudentFeedbackRatingModel = ratinglist.ToList(),

                                };
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetFeedbackDetailsAdmin method for Id : " + StudentFeedbackId.ToString());
                return studentlist;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetFeedbackDetailsAdmin method : " + ex.ToString());
                throw ex;
            }
        }
        public async Task<List<StudentFeedbackRatingModel>> GetRatingsStudent(long StudentFeedbackId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetRatingsStudent");
                IList<StudentFeedbackRatingModel> ratingList = new List<StudentFeedbackRatingModel>();
                var paramStudentFeedbackId = new SqlParameter("@StudentFeedbackId", SqlDbType.BigInt) { Value = StudentFeedbackId };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                                                connection,
                                                                CommandType.StoredProcedure,
                                                                "GetRatingsStudent", paramStudentFeedbackId
                                                                 ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                ratingList.Add(new StudentFeedbackRatingModel
                                {
                                    //Id = reader.To<int>("Id"),
                                    StudentFeedbackId = reader.To<long>("StudentFeedbackId"),
                                    ParameterId = reader.To<int>("ParameterId"),
                                    Rating = reader.To<int>("Rating"),
                                    DropdownValueEn = reader.ToStringValue("DropdownValueEn"),
                                    DropdownValueAr = reader.ToStringValue("DropdownValueAr"),

                                });
                            }
                        }


                    }
                }
                this.Logger.LogInformation("Exiting from GetRatingsStudent");
                return ratingList.ToList();
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetRatingsStudent method :" + ex.ToString());
                throw ex;
            }
        }
        public async Task<MailTracking> SaveMailDetails(MailTracking mailDetails)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveMailDetails method");
                var paramid = new SqlParameter("@Id", SqlDbType.BigInt) { Value = mailDetails.@Id };
                var paramreferenceid = new SqlParameter("@ReferenceId", SqlDbType.BigInt) { Value = mailDetails.Id, Direction = ParameterDirection.Output };
                var paraminternshipid = new SqlParameter("@InternshipId", SqlDbType.BigInt) { Value = mailDetails.InternshipId };
                var paramstudentid = new SqlParameter("@StudentId", SqlDbType.BigInt) { Value = mailDetails.StudentId };
                var paramFromEmail = new SqlParameter("@FromEmail", SqlDbType.NVarChar) { Value = mailDetails.FromEmail };
                var paramToEmail = new SqlParameter("@ToEmail", SqlDbType.NVarChar) { Value = mailDetails.ToEmail };
                var paramCcEmail = new SqlParameter("@CcEmail", SqlDbType.NVarChar) { Value = mailDetails.CcEmail };
                var paramSubject = new SqlParameter("@Subject", SqlDbType.NVarChar) { Value = mailDetails.Subject };
                var paramEmailContent = new SqlParameter("@EmailContent", SqlDbType.NVarChar) { Value = mailDetails.EmailContent };
                var paramAttachment = new SqlParameter("@Attachment", SqlDbType.NVarChar) { Value = mailDetails.Attachment };
                var paramStatus = new SqlParameter("@Status", SqlDbType.Int) { Value = mailDetails.Status };
                var paramCreatedBy = new SqlParameter("@CreatedBy", SqlDbType.NVarChar) { Value = mailDetails.CreatedBy };

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveMailDetails",
                        paramid,
                        paramreferenceid,
                        paraminternshipid,
                        paramstudentid,
                        paramFromEmail,
                        paramToEmail,
                        paramCcEmail,
                        paramSubject,
                        paramEmailContent,
                        paramAttachment,
                        paramStatus,
                        paramCreatedBy
                        ).ConfigureAwait(false);
                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from SaveMailDetails Method");
                return mailDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in SaveMailDetails Method : " + ex.ToString());
                throw ex;
            }
        }


    }
}
