﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using SJP.Communication.Http;
using SJP.Core.Api.Extensions;
using SJP.Logger.Extensions;
using SJP.Internships.Api.DataAccess;
using SJP.Internships.Api.Services;
using SJP.Common.EmailService;

namespace SJP.Internships.Api.Extensions
{
    public static class Extensions
    {
        public static IServiceCollection AddServices(this IServiceCollection services)
        {
            services.AddDatabaseLogger();
            services.AddDistributedMemCache();

            /// Use AddHttpCommunicatorWithOAuth only if the oauth is enabled otherwise use simple form 
            ///services.AddHttpCommunicatorWithOAuth();
            ///

            services.AddHttpCommunicator();
            services.AddScoped<IInternshipDataAccess, InternshipDataAccess>();
            services.AddScoped<IInternshipService, InternshipService>();
            services.AddScoped<IInternshipDropdownDataAccess, InternshipDropdownDataAccess>();
            services.AddScoped<IInternshipDropdownService, InternshipDropdownService>();
            services.AddScoped<IEmailService, EmailService>();
            services.AddScoped<IReportDataAccess, ReportDataAccess>();
            services.AddScoped<IReportService, ReportService>();

            return services;
        }
        public static IApplicationBuilder UseServices(this IApplicationBuilder app)
        {
            app.UseDatabaseLogger();
            return app;
        }
    }
}
