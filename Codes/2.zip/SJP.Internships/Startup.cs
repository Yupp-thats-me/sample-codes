using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using SJP.Common.JWTConfiguration;
using SJP.Core.Api.Services;
using SJP.Core.Utility;
using SJP.Internships.Api.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace SJP.Internships.Api
{
    public class Startup
    {
        readonly string MyAllowSpecificOrigins = "_myAllowSpecificOrigins";
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();

            services.AddCors(options =>
            {
                options.AddPolicy(name: MyAllowSpecificOrigins,
                                  builder =>
                                  {
                                      builder.WithOrigins("http://localhost:44354",
                                                          "https://localhost:44354")
                                                            .AllowAnyHeader()
                                                          .AllowAnyMethod()
                                                          .AllowAnyOrigin();
                                  });
            });

            var authenticationConfig = new AuthenticationConfig();

            Configuration.Bind("Authentication", authenticationConfig);

            services.AddAuthentication(x =>
            {
                x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;


            })
            .AddJwtBearer(options =>
            {
                //options.Authority = authenticationConfig.JWTAuthSettings.Authority;
                options.RequireHttpsMetadata = authenticationConfig.JWTAuthSettings.RequireHttpsMetadata;
                options.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters
                {

                    ValidateIssuer = false,
                    ValidateAudience = false,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = false,
                    IssuerSigningKey = new Microsoft.IdentityModel.Tokens.SymmetricSecurityKey(
                        System.Text.Encoding.UTF8.GetBytes(authenticationConfig.JWTAuthSettings.Key))

                };

                //options.Events = new JwtBearerEvents
                //{
                //    OnChallenge = async (context) =>
                //    {
                //        context.HandleResponse();

                //        if (context.AuthenticateFailure != null)
                //        {
                //            if (context.Request.HttpContext.User.Identity.IsAuthenticated)
                //            {
                //                context.Response.StatusCode = (int)HttpStatusCode.Forbidden;
                //            }
                //        }
                //    }
                //};

                //if (authenticationConfig.JWTAuthSettings.ValidAudiences != null && authenticationConfig.JWTAuthSettings.ValidAudiences.Length > 0)
                //{

                //    options.TokenValidationParameters.ValidateAudience = true;

                //    options.TokenValidationParameters.ValidAudiences = authenticationConfig.JWTAuthSettings.ValidAudiences;
                //}
            });

            services.AddHttpClient<UserManager>(c =>
            {
                c.BaseAddress = new Uri(Configuration.GetSection("AccountAPIURL").Value);
            });

            services.AddApiVersioning(config =>
            {
                // Specify the default API Version as 1.0
                config.DefaultApiVersion = new ApiVersion(1, 0);
                // If the client hasn't specified the API version in the request, use the default API version number 
                config.AssumeDefaultVersionWhenUnspecified = true;
            });
            services.AddServices();
            services.AddSingleton<IFileUtility, FileUtility>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)


        {
            app.UseCors(MyAllowSpecificOrigins);
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseServices();

            //temporary
            if (env.IsDevelopment())
            {
                app.UseHttpsRedirection();
            }

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }

    }
}
