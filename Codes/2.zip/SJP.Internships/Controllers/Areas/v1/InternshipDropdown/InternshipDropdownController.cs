﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SJP.Communication.Http;
using SJP.Core.Api.Controllers;
using SJP.Core.Cache;
using SJP.Internships.Api.Model.Dto;
using SJP.Internships.Api.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Internships.Api.Controllers.Areas.v1.InternshipDropdown
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class InternshipDropdownController : BaseApiController
    {
        private readonly IInternshipDropdownService InternshipDropdownService;
        private readonly ICacheHelper cacheHelper;
        private readonly IHttpCommunicator httpCommunicator;
        public InternshipDropdownController(ILogger<InternshipDropdownController> logger, ICacheHelper cacheHelper,
        IInternshipDropdownService InternshipDropdownService, IHttpCommunicator httpCommunicator) : base(logger)
        {
            this.InternshipDropdownService = InternshipDropdownService;
            this.httpCommunicator = httpCommunicator;
            this.cacheHelper = cacheHelper;
        }

        [HttpGet("InternshipDropdown")]
        public async Task<IActionResult> GetDropdownDetailsAsyn()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetDropdownDetailsAsyn Method for Category");
                var intern = await this.InternshipDropdownService.GetDropdownDetailsAsyn();
                return Success("GetDropdownDetailsAsyn Method by Category", intern);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetDropdownDetailsAsyn Method for Category" + ex);
                return Error("Failed to Get InternshipDropdown Method");
            }
        }

        [HttpGet("OrgDropdown")]
        public async Task<IActionResult> GetOrgDetailsAsyn()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetOrgDetailsAsyn Method for Category");
                var org = await this.InternshipDropdownService.GetOrgDetailsAsyn();
                return Success("GetOrgDetailsAsyn Method by Category", org);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetOrgDetailsAsyn Method" + ex);
                return Error("Failed to Get GetOrgDetailsAsyn Method");
            }
        }

        [HttpGet("InternshipMajor")]
        public async Task<List<MajorMasterDto>> GetMajorMasterAsyn()
        {
            this.Logger.LogInformation("Loading Major Details");
            List<MajorMasterDto> Major = new List<MajorMasterDto>();
            try
            {
                Major = await InternshipDropdownService.GetMajorMasterAsyn();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Major;
        }

        [HttpGet("AdminUsers")]
        public async Task<IActionResult> GetAdminUserAsyn()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetAdminUserAsyn Method for Category");
                var intern = await this.InternshipDropdownService.GetAdminUserAsyn();
                return Success("GetAdminUserAsyn Method by Category", intern);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetAdminUserAsyn Method for Category" + ex);
                return Error("Failed to GetAdminUser Method");
            }
        }

        [HttpGet("CompanyDropdown/{Id}")]
        public async Task<IActionResult> GetCompanyDetails(int Id)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetCompanyDetails Method by Id" + Id.ToString());
                var company = await this.InternshipDropdownService.GetCompanyDetailsAsync(Id);
                return Success("GetCompanyDetails Method by Category", company);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetCompanyDetails Method for Id" + Id.ToString(), ex.ToString());
                return Error("Failed to Get GetCompanyDetails Method");
            }
        }

    }

}
