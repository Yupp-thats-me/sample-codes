﻿using SJP.Core.Api.Controllers;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using SJP.Internships.Api.Model;
using System;
using SJP.Internships.Api.Services;
using SJP.Core.Composition;
using SJP.Core.Models;
namespace SJP.Internships.Api.Controllers.Areas.v1.Internship
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class ReportController : BaseApiController
    {
        private readonly IReportService ReportService;
        private readonly IConfiguration Configuration;
        public ReportController(ILogger<ReportController> logger, IConfiguration configuration, IReportService reportService) : base(logger)
        {
            this.ReportService = reportService;
            this.Configuration = configuration;

        }
        /// <summary>
        /// to fetch the list of internship summary for reports based on the filters
        /// </summary>
        /// <param name="internshipsParam"></param>
        /// <returns></returns>
        // Report 1 

        [HttpGet("GetInternListingsSummary")]
        public async Task<IActionResult> GetInternListingsSummary([FromQuery] InternshipsParams internshipsParam)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetInternListingsSummary Method");
                var internships = await this.ReportService.GetInternListingsSummary(internshipsParam);
                this.Logger.LogInformation("Exiting from GetInternListingsSummary  Method");
                return Success("GetInternListingsSummary Details", internships);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetInternListingsSummary Method" + Ex);
                return Error("Failed to Get GetInternListingsSummary Details ");
            }
        }
        /// <summary>
        /// to fetch the post ststistics of the internship for reports based on the filter
        /// </summary>
        /// <param name="internshipsParam"></param>
        /// <returns></returns>
        //report 2

        [HttpGet("GetInternshipPostStatistics")]
        public async Task<IActionResult> GetInternshipPostStatistics([FromQuery] InternshipsParams internshipsParam)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetInternshipPostStatistics Method");
                var internships = await this.ReportService.GetInternshipPostStatistics(internshipsParam);
                this.Logger.LogInformation("Exiting from GetInternshipPostStatistics  Method");
                return Success("GetInternshipPostStatistics Details", internships);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetInternshipPostStatistics Method" + Ex);
                return Error("Failed to Get GetInternshipPostStatistics Details ");
            }
        }
        /// <summary>
        /// to fetch the application summary of the internship based on internship
        /// </summary>
        /// <param name="internshipsParam"></param>
        /// <returns></returns>
        // Report 3

        [HttpGet("GetInternApplicationSummary")]
        public async Task<IActionResult> GetInternApplicationSummary([FromQuery] InternshipsParams internshipsParam)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetInternApplicationSummary Method");
                var internships = await this.ReportService.GetInternApplicationSummary(internshipsParam);
                this.Logger.LogInformation("Exiting from GetInternApplicationSummary  Method");
                return Success("GetInternApplicationSummary Details", internships);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetInternApplicationSummary Method" + Ex);
                return Error("Failed to Get GetInternApplicationSummary Details ");
            }
        }       

        /// <summary>
        /// to fetch the review given  for the student based on the internship
        /// </summary>
        /// <param name="internshipsParam"></param>
        /// <returns></returns>
        //Report 4
        [HttpGet("StudentsReviewedbyInternship")]
        public async Task<IActionResult> StudentsReviewedbyInternship([FromQuery] InternshipsParams internshipsParam)
        {
            try
            {
                this.Logger.LogInformation("Entering into StudentsReviewedbyInternship Method");
                var internships = await this.ReportService.GetStudentsReviewedbyInternship(internshipsParam);
                this.Logger.LogInformation("Exiting from StudentsReviewedbyInternship  Method");
                return Success("StudentsReviewedbyInternship Details", internships);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in StudentsReviewedbyInternship Method" + Ex);
                return Error("Failed to Get StudentsReviewedbyInternship Details ");
            }
        }

/// <summary>
/// to fetch the feedback of the student for the report
/// </summary>
/// <param name="internshipsParam"></param>
/// <returns></returns>
        //Report 5

        [HttpGet("StudentsFeedback")]
        public async Task<IActionResult> StudentsFeedback([FromQuery] InternshipsParams internshipsParam)
        {
            try
            {
                this.Logger.LogInformation("Entering into StudentsFeedback Method");
                var internships = await this.ReportService.StudentsFeedback(internshipsParam);
                this.Logger.LogInformation("Exiting from StudentsFeedback  Method");
                return Success("StudentsFeedback Details", internships);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in StudentsFeedback Method" + Ex);
                return Error("Failed to Get StudentsFeedback Details ");
            }
        }
        /// <summary>
        /// to fetch the companies feedback on the student based on filter
        /// </summary>
        /// <param name="internshipsParam"></param>
        /// <returns></returns>
        // Report 6

        [HttpGet("GetCompanyFeedbackOnStudents")]
        public async Task<IActionResult> GetCompanyFeedbackOnStudents([FromQuery] InternshipsParams internshipsParam)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetCompanyFeedbackOnStudents Method");
                var internships = await this.ReportService.GetCompanyFeedbackOnStudents(internshipsParam);
                this.Logger.LogInformation("Exiting from GetCompanyFeedbackOnStudents  Method");
                return Success("GetCompanyFeedbackOnStudents Details", internships);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetCompanyFeedbackOnStudents Method" + Ex);
                return Error("Failed to Get GetCompanyFeedbackOnStudents Details ");
            }
        }
        /// <summary>
        /// to fetch the entire module feedback  based on the filter
        /// </summary>
        /// <param name="internshipsParam"></param>
        /// <returns></returns>

        // report 7

        [HttpGet("GetInternshipModuleFeedback")]
        public async Task<IActionResult> GetInternshipModuleFeedback([FromQuery] InternshipsParams internshipsParam)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetInternshipModuleFeedback Method");
                var internships = await this.ReportService.GetInternshipModuleFeedback(internshipsParam);
                this.Logger.LogInformation("Exiting from GetInternshipModuleFeedback  Method");
                return Success("GetInternshipModuleFeedback Details", internships);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetInternshipModuleFeedback Method" + Ex);
                return Error("Failed to Get GetInternshipModuleFeedback Details ");
            }
        }



    }
}
