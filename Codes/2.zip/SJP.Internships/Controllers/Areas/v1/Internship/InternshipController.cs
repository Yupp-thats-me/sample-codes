﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Communication.Http;
using SJP.Core.Api.Controllers;
using SJP.Core.Cache;
using SJP.Core.Constants;
using SJP.Core.Utility;
using SJP.DataAccess.Exceptions;
using SJP.Internships.Api.Model.Dto;
using SJP.Internships.Api.Services;
using System.Collections.Generic;
using System;
using System.Linq;
using System.Threading.Tasks;
using SJP.Internships.Api.Model;
using SJP.Common.EmailService;
using SJP.Core.Composition;
using SJP.Core.Models;
//using SJP.Core.Api.Services;

namespace SJP.Internships.Api.Controllers.Areas.v1.Internship
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    //[Authorize]
    public class InternshipController : BaseApiController
    {
        private readonly IInternshipService internshipService;
        private readonly ICacheHelper cacheHelper;
        private readonly IHttpCommunicator httpCommunicator;
        private readonly IConfiguration configuration;
        private readonly IFileUtility FileUtility;
        private readonly string SUB_Directory = "Internship";
        //   private readonly UserManager userManager;


        private readonly IEmailService emailService;
        public InternshipController(ILogger<InternshipController> logger, ICacheHelper cacheHelper,
           IInternshipService internshipService, IHttpCommunicator httpCommunicator,
           IConfiguration _configuration, IFileUtility FileUtility,/* UserManager userManager,*/ IEmailService emailService) : base(logger)
        {
            this.internshipService = internshipService;
            this.httpCommunicator = httpCommunicator;
            this.cacheHelper = cacheHelper;
            this.configuration = _configuration;
            this.FileUtility = FileUtility;
            this.emailService = emailService;

            // this.userManager = userManager;
        }
        /// <summary>
        /// to fetch the internship details
        /// </summary>
        /// <returns></returns>

        [HttpGet]
        public async Task<IActionResult> GetInternshipDetails()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetInternshipDetails Method");
                var intern = await this.internshipService.GetInternshipDetails();
                foreach (var item in intern.ToList())
                {
                    item.UploadImage = FileUtility.GetThumbnailBase64String(SUB_Directory, item.Id.ToString(), item.UploadImage ?? "");
                }
                this.Logger.LogInformation("Exiting from GetInternshipDetails Method");
                return Success("GetInternshipDetails successfully", intern);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "ERROR Occured in GetInternshipDetails  method " + ex);
                return Error("Failed to GetInternshipDetails");
            }
        }
        /// <summary>
        /// to fetch the internship details based on id
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.Employer, Role.ContentApprover)]
        [HttpGet("{Id}")]
        public async Task<IActionResult> GetInternshipDetails(int Id)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetInternshipDetails Method by Id" + Id.ToString());
                var internRecord = await this.internshipService.GetInternshipDetails(Id);
                if (internRecord != null)
                {
                    internRecord.UploadImage = FileUtility.GetThumbnailBase64String(SUB_Directory, internRecord.Id.ToString(), internRecord.UploadImage ?? "");
                }
                this.Logger.LogInformation("Exiting from GetInternshipDetails  Method");
                return Success("GetInternshipDetails by Id", internRecord);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetInternshipDetails Method for Id" + Id.ToString(), ex.ToString());
                return Error("Failed to GetInternshipDetails by Id ");
            }
        }
/// <summary>
/// to fetch the internship details for the grid
/// </summary>
/// <returns></returns>

        [HttpGet("GetInternshipDetailsGrid")]
        public async Task<IActionResult> GetInternshipDetailsGrid()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetInternshipDetailsGrid Method");
                var intern = await this.internshipService.GetInternshipDetailsGrid();
                this.Logger.LogInformation("Exiting from GetInternshipDetailsGrid  Method");
                return Success("GetInternshipDetailsGrid", intern);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetInternshipDetailsGrid Method" + ex);
                return Error("Failed to GetInternshipDetailsGrid");
            }
        }
        /// <summary>
        /// to save the given internship details
        /// </summary>
        /// <param name="internshipDetail"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.Employer)]
        [HttpPost("SaveInternshipDetails")]
        public async Task<IActionResult> SaveInternshipDetails([FromForm] InternshipDetailsDto internshipDetail)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveInternshipDetails Method");
                //internshipDetail.InternshipQuestionnaireDetails = JsonConvert.DeserializeObject<List<InternshipQuestionnaireDetails>>(internshipDetail.questions);
                var files = HttpContext.Request.Form.Files;
                if (files != null && files.Count > 0)
                {
                    internshipDetail.UploadImage = this.FileUtility.GetFileNames(this.FileUtility.FileType_Images, files);
                }
                var savedData = await this.internshipService.SaveInternshipDetails(internshipDetail);
                #region Save files
                try
                {
                    this.FileUtility.Save(files, SUB_Directory, savedData.Id.ToString());
                }

                catch (Exception ex)
                {
                    this.Logger.LogError(new Exception("Error Occured"), "Failed to save the file" + ex);
                }
                #endregion
                this.Logger.LogInformation("Loading UploadDocuments Info");
                var intern = new { Id = internshipDetail.Id };
                return Success("Data Saved Successfully", intern);
            }
            catch (DuplicateDataException ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SaveInternshipDetails Method" + ex);
                return Error("", ErrorCode.Duplicate);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SaveInternshipDetails Method" + ex);
                return Error("Failed to SaveInternshipDetails ");
            }
        }
        /// <summary>
        /// to put the internship data based on particular id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="internship"></param>
        /// <returns></returns>

        //For Approval
        [AuthorizeByRole(Role.ContentApprover)]
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(long id, [FromBody] InternshipDetailsDto internship)
        {
            try
            {
                if (id == 0)
                {
                    return BadRequest("Invalid Data");
                }
                internship.Id = id;
                await this.internshipService.UpdatedApprovalDetails(internship);
                var intern = new { Id = internship.Id };
                return Success("Data Updated and saved Successfully", intern);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Failed to Update the Data" + ex);
                return Error("Failed to Update Internship Details");
            }
        }
        /// <summary>
        /// to save the data of the internship role master
        /// </summary>
        /// <param name="internshipRoleMaster"></param>
        /// <returns></returns>
        [HttpPost("internshipRoleMaster")]
        public async Task<IActionResult> SaveinternshipRoleMaster(InternshipRoleMasterDto internshipRoleMaster)
        {
            try
            {
                if (internshipRoleMaster.InternshipRoleId > 0)
                {
                    return BadRequest("Invalid Data");
                }
                await this.internshipService.SaveinternshipRoleMaster(internshipRoleMaster);
                var intern = new { InternshipRoleId = internshipRoleMaster.InternshipRoleId };
                return Success("Data Saved Successfully", intern);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SaveinternshipRoleMaster Method" + ex);
                return Error("Failed to SaveinternshipRoleMaster ");
            }
        }
        /// <summary>
        /// to fetch the data of the internship role master
        /// </summary>
        /// <returns></returns>

        [HttpGet("internshipRoleMaster")]
        public async Task<IActionResult> GetInternshipRoleMaster()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetInternshipRoleMaster Method");
                var intern = await this.internshipService.GetInternshipRoleMaster();
                this.Logger.LogInformation("Exiting from GetInternshipRoleMaster Method");
                return Success("GetInternshipRoleMaster Details", intern);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetInternshipRoleMaster Method" + ex);
                return Error("Failed to GetInternshipRoleMaster");
            }
        }
        /// <summary>
        /// to get the status of the internship based on particular id
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.Employer)]
        [HttpPut("IsActive/{Id}")]
        public async Task<IActionResult> IsActive(long Id)
        {
            this.Logger.LogInformation("Delete Internship Info");
            try
            {
                await internshipService.IsActive(Id);
                return Success("Deleted Successfully");
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in IsActive Method" + ex);
                return Error("Failed to Delete");
            }
        }
        // Update Total Views
        /*  [HttpPut("update/{id}")]
          public async Task<IActionResult> UpdateTotalViews(long id, [FromBody] InternshipDetailsDto viewDetails)
          {
              try
              {
                  if (id == 0)
                  {
                      return BadRequest("Invalid Data");
                  }
                  viewDetails.Id = id;
                  await this.internshipService.UpdateTotalViews(viewDetails);
                  var status = new { Id = viewDetails.Id };
                  return Success("TotalViews Updated Successfully", status);
              }
              catch (Exception ex)
              {
                  this.Logger.LogError(new Exception("Error Occured"), "Failed to Update the Data" + ex);
                  return Error("Failed to Update TotalViews");
              }
          }*/
        /// <summary>
        /// to fetch the views based on id
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>

        //[AuthorizeByRole(Role.Student)]
        [HttpGet("GetInternshipDetailsUserviewById/{Id}")]
        public async Task<IActionResult> GetInternshipDetailsUserviewById(long Id)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetInternshipDetailsUserviewById Method");
                InternshipDetailsDto internshipDetails = new InternshipDetailsDto();
                internshipDetails = await this.internshipService.GetInternshipDetailsUserviewById(Id);
                if (internshipDetails != null)
                {
                    internshipDetails.UploadImage = FileUtility.GetThumbnailBase64String(SUB_Directory, internshipDetails.Id.ToString(), internshipDetails.UploadImage ?? "");
                }
                this.Logger.LogInformation("Exiting from GetInternshipDetailsUserviewById Method");
                return Success("Get InternshipDetailsUserviewById", internshipDetails);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetInternshipDetailsUserviewById Method" + ex);
                return Error("Failed to GetInternshipDetailsUserviewById");
            }
        }
        /// <summary>
        /// to save the internship applied details 
        /// </summary>
        /// <param name="applyDetails"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.Student)]
        [Route("apply-details")]
        [HttpPost]
        public async Task<IActionResult> SaveApplyDetails([FromForm] UserApplyDetailsDto applyDetails)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveApplyDetails Method");
                var files = HttpContext.Request.Form.Files;
                if (files != null && files.Count > 0)
                {
                    applyDetails.UploadDocument = this.FileUtility.GetFileNames(this.FileUtility.FileType_Documents, files);
                }
                var savedData = await this.internshipService.SaveApplyDetails(applyDetails);
                #region Save files
                try
                {
                    this.FileUtility.Save(files, SUB_Directory, savedData.InternshipId.ToString());
                }

                catch (Exception ex)
                {
                    this.Logger.LogError(new Exception("Error Occured"), "Failed to save the file" + ex);
                }
                #endregion
                this.Logger.LogInformation("Loading UploadDocuments Info");

                var id = new { Id = applyDetails.Id };
                return Success("Data Saved Successfully", id);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SaveApplyDetails Method" + ex);
                return Error("Failed to SaveApplyDetails ");
            }
        }
        /// <summary>
        /// to update the applyDetails based on id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="applyDetails"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.Employer, Role.Student)]
        [HttpPut("update/{id}")]
        public async Task<IActionResult> Put(long id, [FromBody] UserApplyDetailsDto applyDetails)
        {
            try
            {
                if (id == 0)
                {
                    return BadRequest("Invalid Data");
                }
                applyDetails.Id = id;
                await this.internshipService.UpdateStatusDetails(applyDetails);
                var status = new { Id = applyDetails.Id };
                return Success("Status Updated Successfully", status);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Failed to Update the Data" + ex);
                return Error("Failed to Update Status");
            }
        }
        /// <summary>
        /// to update the status of the internship
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.Employer)]
        [HttpPut("updateStatus")]
        public async Task<IActionResult> updateStatus([FromBody] IEnumerable<StatusModel> data)
        {
            try
            {
                await this.internshipService.UpdateStatusList(data);
                return Success("Status Updated Successfully", data);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Failed to Update the Data" + ex);
                return Error("Failed to Update Status");
            }
        }
        /// <summary>
        /// to update the status for disagree based on id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="disagreeDetails"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.InternshipCounsellor, Role.Student)]
        [HttpPut("updateDisagree/{id}")]
        public async Task<IActionResult> updateDisagree(long id, [FromBody] UserApplyDetailsDto disagreeDetails)
        {
            try
            {
                if (id == 0)
                {
                    return BadRequest("Invalid Data");
                }
                disagreeDetails.Id = id;
                await this.internshipService.UpdateDisagreeDetails(disagreeDetails);
                var status = new { Id = disagreeDetails.Id };
                return Success("DisagreeDetails Updated Successfully", status);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Failed to Update the Data" + ex);
                return Error("Failed to Update DisagreeDetails");
            }
        }
        /// <summary>
        /// to update the expiry list of the data
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.Employer)]
        [HttpPut("updateExpiry")]
        public async Task<IActionResult> updateExpiry(IEnumerable<ExpiryModel> data)
        {
            try
            {
                await this.internshipService.UpdateExpiryList(data);
                return Success(" Updated Successfully", data);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Failed to Update the Data" + ex);
                return Error("Failed to Update");
            }
        }
        /// <summary>
        /// to fetch the recruitment details for the grid
        /// </summary>
        /// <returns></returns>

        [AuthorizeByRole(Role.Employer)]
        [Route("recruitment-details")]
        [HttpGet]
        public async Task<IActionResult> GetRecruitmentDetailsGrid()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetRecruitmentDetailsGrid Method");
                var recruitment = await this.internshipService.GetRecruitmentDetailsGrid();
                this.Logger.LogInformation("Exiting from GetRecruitmentDetailsGrid  Method");
                return Success("GetRecruitmentDetailsGrid", recruitment);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetRecruitmentDetailsGrid Method" + ex);
                return Error("Failed to GetRecruitmentDetailsGrid");
            }
        }
        /// <summary>
        /// to fetch the flow chart details based on the internship id
        /// </summary>
        /// <param name="InternshipId"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.Employer)]
        [HttpGet("FlowChart/{InternshipId}")]
        public async Task<IActionResult> GetFlowChartDetails(int InternshipId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetFlowChartDetails Method by InternshipId" + InternshipId.ToString());
                var flowCount = await this.internshipService.GetFlowChartDetails(InternshipId);

                this.Logger.LogInformation("Exiting from GetFlowChartDetails  Method");
                return Success("GetFlowChartDetails by InternshipId", flowCount);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetFlowChartDetails Method for InternshipId" + InternshipId.ToString(), ex.ToString());
                return Error("Failed to GetFlowChartDetails by InternshipId ");
            }
        }
        /// <summary>
        /// to get the list of disagreed internship
        /// </summary>
        /// <returns></returns>
        //[AuthorizeByRole(Role.ContentApprover)]
        [Route("disagreed-list")]
        [HttpGet]
        public async Task<IActionResult> GetDisagreedList()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetDisagreedList Method");
                var disagreed = await this.internshipService.GetDisagreedList();
                this.Logger.LogInformation("Exiting from GetDisagreedList  Method");
                return Success("GetDisagreedList", disagreed);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetDisagreedList Method" + ex);
                return Error("Failed to GetDisagreedList");
            }
        }
        /// <summary>
        /// to fetch the list of application based on id
        /// </summary>
        /// <param name="StudentId"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.Student)]
        [Route("application-list/{StudentId}")]
        [HttpGet]
        public async Task<IActionResult> GetApplicationsList(long StudentId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetApplicationsList Method");
                var application = await this.internshipService.GetApplicationsList(StudentId);
                this.Logger.LogInformation("Exiting from GetApplicationsList  Method");
                return Success("GetApplicationsList", application);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetApplicationsList Method by Id" + ex);
                return Error("Failed to GetApplicationsList");
            }
        }
        /// <summary>
        /// to fetch the accepted list of data based on the id
        /// </summary>
        /// <param name="StudentId"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.Student)]
        [Route("accepted-list/{StudentId}")]
        [HttpGet]
        public async Task<IActionResult> GetAcceptedList(long StudentId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetAcceptedList Method");
                var accepted = await this.internshipService.GetAcceptedList(StudentId);
                this.Logger.LogInformation("Exiting from GetAcceptedList  Method");
                return Success("GetAcceptedList", accepted);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetAcceptedList Method by Id" + ex);
                return Error("Failed to GetAcceptedList");
            }
        }
        /// <summary>
        /// to fetch the Accepted Candidates List based on id
        /// </summary>
        /// <param name="InternshipId"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.Employer, Role.Student)]
        [Route("acceptedcandidates-list/{InternshipId}")]
        [HttpGet]
        public async Task<IActionResult> GetAcceptedCandidatesList(long InternshipId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetAcceptedCandidatesList Method by Id" + InternshipId.ToString());
                var candidates = await this.internshipService.GetAcceptedCandidatesList(InternshipId);
                this.Logger.LogInformation("Exiting from GetAcceptedCandidatesList Method");
                return Success("GetAcceptedCandidatesList", candidates);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetAcceptedCandidatesList Method by Id" + InternshipId.ToString() + ex);
                return Error("Failed to GetAcceptedCandidatesList");
            }
        }
        /// <summary>
        /// to update the list of internship details based on id
        /// </summary>
        /// <param name="InternshipId"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.Employer)]
        [Route("update-list/{InternshipId}")]
        [HttpGet]
        public async Task<IActionResult> GetUpdateList(long InternshipId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetUpdateList Method by Id" + InternshipId.ToString());
                var candidates = await this.internshipService.GetUpdateList(InternshipId);
                this.Logger.LogInformation("Exiting from GetUpdateList Method");
                return Success("GetUpdateList", candidates);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetUpdateList Method by Id" + InternshipId.ToString() + ex);
                return Error("Failed to GetUpdateList");
            }
        }
        /// <summary>
        /// to fetch the candidates list of data for the grid based on InternshipId
        /// </summary>
        /// <param name="InternshipId"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.Employer)]
        [Route("candidates-list/{InternshipId}")]
        [HttpGet]
        public async Task<IActionResult> GetCandidatesListGrid(long InternshipId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetCandidatesListGrid Method by Id" + InternshipId.ToString());
                var candidates = await this.internshipService.GetCandidatesListGrid(InternshipId);
                this.Logger.LogInformation("Exiting from GetCandidatesListGrid Method");
                return Success("GetCandidatesListGrid", candidates);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetCandidatesListGrid Method by Id" + InternshipId.ToString() + ex);
                return Error("Failed to GetCandidatesListGrid");
            }
        }
        /// <summary>
        /// to fetch the list of applied internship
        /// </summary>
        /// <returns></returns>

        //[AuthorizeByRole(Role.Student,Role.InternshipCounsellor)]
        [Route("applied-list")]
        [HttpGet]
        public async Task<IActionResult> GetAppliedList()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetAppliedList Method");
                var candidates = await this.internshipService.GetAppliedList();
                this.Logger.LogInformation("Exiting from GetAppliedList Method");
                return Success("GetAppliedList", candidates);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetAppliedList Method" + ex);
                return Error("Failed to GetAppliedList");
            }
        }
        /// <summary>
        /// to fetch the list of expiry internship for the grid based on userid
        /// </summary>
        /// <param name="UserId"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.Employer)]
        [Route("expiry-list/{UserId}")]
        [HttpGet]
        public async Task<IActionResult> GetExpiryListGrid(long UserId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetExpiryListGrid Method by Id" + UserId.ToString());
                var candidates = await this.internshipService.GetExpiryListGrid(UserId);
                this.Logger.LogInformation("Exiting from GetExpiryListGrid Method");
                return Success("GetExpiryListGrid", candidates);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetExpiryListGrid Method by Id" + UserId.ToString() + ex);
                return Error("Failed to GetExpiryListGrid");
            }
        }
        /// <summary>
        /// to fetch the student details based on student id and internship id
        /// </summary>
        /// <param name="StudentId"></param>
        /// <param name="InternshipId"></param>
        /// <returns></returns>

        //[AuthorizeByRole(Role.Student)]
        [Route("students-view")]
        [HttpGet]
        public async Task<IActionResult> GetStudentDetails(long StudentId, long InternshipId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetStudentDetails Method");
                StudentDetailsDto studentDetails = new StudentDetailsDto();
                studentDetails = await this.internshipService.GetStudentDetails(StudentId, InternshipId);

                if (studentDetails != null)
                {
                    studentDetails.Filename = FileUtility.GetThumbnailBase64String("Internship", studentDetails.InternshipId.ToString(), studentDetails.Resume);
                }
                this.Logger.LogInformation("Exiting from GetStudentDetails Method");
                return Success("GetStudentDetails", studentDetails);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetStudentDetails Method" + ex);
                return Error("Failed to GetStudentDetails");
            }
        }
        /// <summary>
        /// to fetch the internship detail for a user
        /// </summary>
        /// <param name="InternshipFor"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.Student)]
        [Route("GetUserInternshipDetailsList/{InternshipFor}")]
        [HttpGet]
        public async Task<IActionResult> GetUserInternshipDetailsList(int InternshipFor)
        {
            try
            {
                this.Logger.LogInformation("Loading GetUserInternshipDetailsList Method");
                IEnumerable<InternshipDetailsDto> internship = new List<InternshipDetailsDto>();
                List<InternshipDetailsDto> s = new List<InternshipDetailsDto>();
                internship = await this.internshipService.GetUserInternshipDetailsList(InternshipFor);
                s = internship.ToList();

                foreach (var item in s)
                {
                    item.UploadImage = FileUtility.GetThumbnailBase64String(SUB_Directory, item.Id.ToString(), item.UploadImage ?? "");
                }

                return Success("Get Internship Details successfully for User", s);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetUserInternshipDetailsList Method" + Ex);
                return Error("Failed to GetUserInternshipDetailsList For Users");
            }
        }
        /// <summary>
        /// to fetch the data of pending feedback based on InternshipId
        /// </summary>
        /// <param name="InternshipId"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.Employer)]
        [Route("pendinglist-feedback/{InternshipId}")]
        [HttpGet]
        public async Task<IActionResult> GetPendingAdminFeedback(long InternshipId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetPendingAdminFeedback Method by Id" + InternshipId.ToString());
                var students = await this.internshipService.GetPendingAdminFeedback(InternshipId);
                this.Logger.LogInformation("Exiting from GetPendingAdminFeedback Method");
                return Success("GetPendingAdminFeedback", students);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetPendingAdminFeedback Method by Id" + InternshipId.ToString() + ex);
                return Error("Failed to GetPendingAdminFeedback");
            }
        }
        /// <summary>
        /// to save the given feedback details
        /// </summary>
        /// <param name="feedbackrating"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.Employer)]
        [Route("adminfeedback-details")]
        [HttpPost]
        public async Task<IActionResult> SaveAdminFeedbackDetails([FromForm] AdminFeedbackDetailsDto feedbackrating)
        {
            try
            {
                if (feedbackrating.FeedbackId > 0)
                {
                    return BadRequest("Invalid Data");
                }
                await this.internshipService.SaveAdminFeedbackDetails(feedbackrating);
                var rating = new { FeedbackId = feedbackrating.FeedbackId };
                return Success("Feedback Saved Successfully", rating);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SaveAdminFeedbackDetails Method" + ex);
                return Error("Failed to Save Admin FeedbackDetails  ");
            }
        }
        /// <summary>
        /// to fetch the  admin feedback details based on InternshipId and StudentId
        /// </summary>
        /// <param name="InternshipId"></param>
        /// <param name="StudentId"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.Employer, Role.HEI)]
        [Route("feedback-details-admin/{InternshipId}/{StudentId}")]
        [HttpGet]
        public async Task<IActionResult> GetAdminFeedbackDetails(long InternshipId, long StudentId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetAdminFeedbackDetails Method by Id" + InternshipId.ToString());
                var students = await this.internshipService.GetAdminFeedbackDetails(InternshipId, StudentId);
                this.Logger.LogInformation("Exiting from GetAdminFeedbackDetails Method");
                return Success("GetAdminFeedbackDetails", students);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetAdminFeedbackDetails Method by Id" + InternshipId.ToString() + ex);
                return Error("Failed to GetAdminFeedbackDetails");
            }
        }
        /// <summary>
        /// to fetch the list of feedback received for the students based on StudentId
        /// </summary>
        /// <param name="StudentId"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.Student)]
        [Route("studentfeedback-received/{StudentId}")]
        [HttpGet]
        public async Task<IActionResult> GetFeedbackReceivedListforStudent(long StudentId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetFeedbackReceivedListforStudent Method");
                var received = await this.internshipService.GetFeedbackReceivedListforStudent(StudentId);
                this.Logger.LogInformation("Exiting from GetFeedbackReceivedListforStudent  Method");
                return Success("GetFeedbackReceivedListforStudent", received);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetFeedbackReceivedListforStudent Method by Id" + ex);
                return Error("Failed to GetFeedbackReceivedListforStudent");
            }
        }
        /// <summary>
        /// to fetch the student feedback list for hei
        /// </summary>
        /// <returns></returns>

        [AuthorizeByRole(Role.InternshipCounsellor)]
        [Route("studentfeedback-hei")]
        [HttpGet]
        public async Task<IActionResult> GetStudentFeedbackListforHEI()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetStudentFeedbackListforHEI Method");
                var recruitment = await this.internshipService.GetStudentFeedbackListforHEI();
                this.Logger.LogInformation("Exiting from GetStudentFeedbackListforHEI  Method");
                return Success("GetStudentFeedbackListforHEI", recruitment);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetStudentFeedbackListforHEI Method" + ex);
                return Error("Failed to GetStudentFeedbackListforHEI");
            }
        }
        /// <summary>
        /// to fetch the feedback provided by admin based on InternshipId and CreatedBy
        /// </summary>
        /// <param name="InternshipId"></param>
        /// <param name="CreatedBy"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.Employer)]
        [Route("providedlist-admin/{InternshipId}/{CreatedBy}")]
        [HttpGet]
        public async Task<IActionResult> GetProvidedAdminFeedback(long InternshipId, string CreatedBy)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetProvidedAdminFeedback Method by Id" + InternshipId.ToString());
                var students = await this.internshipService.GetProvidedAdminFeedback(InternshipId, CreatedBy);
                this.Logger.LogInformation("Exiting from GetProvidedAdminFeedback Method");
                return Success("GetProvidedAdminFeedback", students);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetAdminFeedbackDetails Method by Id" + InternshipId.ToString() + ex);
                return Error("Failed to GetAdminFeedbackDetails");
            }
        }
        /// <summary>
        /// to fetch the admins feedback details 
        /// </summary>
        /// <param name="InternshipId"></param>
        /// <param name="FeedbackId"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.Employer, Role.Student, Role.InternshipCounsellor)]
        [Route("admin-details/{InternshipId}/{FeedbackId}")]
        [HttpGet]
        public async Task<IActionResult> GetFeedbackDetailsAdmin(long InternshipId, long FeedbackId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetFeedbackDetailsAdmin Method by Id" + FeedbackId.ToString());
                var students = await this.internshipService.GetFeedbackDetailsAdmin(InternshipId, FeedbackId);
                this.Logger.LogInformation("Exiting from GetFeedbackDetailsAdmin Method");
                return Success("GetFeedbackDetailsAdmin", students);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetFeedbackDetailsAdmin Method by Id" + FeedbackId.ToString() + ex);
                return Error("Failed to GetFeedbackDetailsAdmin");
            }
        }
        /// <summary>
        /// to fetch the list of feedback  admin
        /// </summary>
        /// <param name="UserId"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.Employer)]
        [Route("adminfeedbackreceived/{UserId}")]
        [HttpGet]
        public async Task<IActionResult> GetAdminFeedbackReceivedList(long UserId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetAdminFeedbackReceivedList Method by Id" + UserId.ToString());
                var feedback = await this.internshipService.GetAdminFeedbackReceivedList(UserId);
                this.Logger.LogInformation("Exiting from GetAdminFeedbackReceivedList Method");
                return Success("GetAdminFeedbackReceivedList", feedback);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetAdminFeedbackReceivedList Method by Id" + UserId.ToString() + ex);
                return Error("Failed to GetAdminFeedbackReceivedList");
            }
        }
        /// <summary>
        /// to fetch the list of feedback given by the Counsellor
        /// </summary>
        /// <returns></returns>
        [AuthorizeByRole(Role.InternshipCounsellor)]
        [Route("counselorfeedbackreceived")]
        [HttpGet]
        public async Task<IActionResult> GetCounselorFeedbackReceivedList()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetCounselorFeedbackReceivedList Method ");
                var feedback = await this.internshipService.GetCounselorFeedbackReceivedList();
                this.Logger.LogInformation("Exiting from GetCounselorFeedbackReceivedList Method");
                return Success("GetCounselorFeedbackReceivedList", feedback);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetCounselorFeedbackReceivedList Method " + ex);
                return Error("Failed to GetCounselorFeedbackReceivedList");
            }
        }
        /// <summary>
        /// to fetch the feedback list received from moe
        /// </summary>
        /// <returns></returns>
        [AuthorizeByRole(Role.SuperAdmin)]
        [Route("moefeedbackreceived")]
        [HttpGet]
        public async Task<IActionResult> GetMoeFeedbackReceivedList()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetMoeFeedbackReceivedList Method ");
                var feedback = await this.internshipService.GetMoeFeedbackReceivedList();
                this.Logger.LogInformation("Exiting from GetMoeFeedbackReceivedList Method");
                return Success("GetMoeFeedbackReceivedList", feedback);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetMoeFeedbackReceivedList Method " + ex);
                return Error("Failed to GetMoeFeedbackReceivedList");
            }
        }
        /// <summary>
        /// to save the student feedback details
        /// </summary>
        /// <param name="feedbackrating"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.Student)]
        [Route("studentfeedback-details")]
        [HttpPost]
        public async Task<IActionResult> SaveStudentFeedbackDetails([FromForm] StudentFeedbackDetailsDto feedbackrating)
        {
            try
            {
                if (feedbackrating.StudentFeedbackId > 0)
                {
                    return BadRequest("Invalid Data");
                }
                await this.internshipService.SaveStudentFeedbackDetails(feedbackrating);
                var rating = new { StudentFeedbackId = feedbackrating.StudentFeedbackId };
                return Success("Feedback Saved Successfully", rating);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SaveStudentFeedbackDetails Method" + ex);
                return Error("Failed to Save student FeedbackDetails  ");
            }
        }
        /// <summary>
        /// the fetch the list of pending feedback  based on StudentId
        /// </summary>
        /// <param name="StudentId"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.Student)]
        [Route("pendinglist-students/{StudentId}")]
        [HttpGet]
        public async Task<IActionResult> GetPendingStudentFeedback(long StudentId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetPendingStudentFeedback Method by Id" + StudentId.ToString());
                var students = await this.internshipService.GetPendingStudentFeedback(StudentId);
                this.Logger.LogInformation("Exiting from GetPendingStudentFeedback Method");
                return Success("GetPendingAdminFeedback", students);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetPendingStudentFeedback Method by Id" + StudentId.ToString() + ex);
                return Error("Failed to GetPendingAdminFeedback");
            }
        }
        /// <summary>
        /// to fetch students feedback details
        /// </summary>
        /// <param name="InternshipId"></param>
        /// <param name="StudentId"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.Student)]
        [Route("feedback-details-student/{InternshipId}/{StudentId}")]
        [HttpGet]
        public async Task<IActionResult> GetStudentFeedbackDetails(long InternshipId, long StudentId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetStudentFeedbackDetails Method by Id" + InternshipId.ToString());
                var students = await this.internshipService.GetStudentFeedbackDetails(InternshipId, StudentId);
                this.Logger.LogInformation("Exiting from GetStudentFeedbackDetails Method");
                return Success("GetStudentFeedbackDetails", students);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetStudentFeedbackDetails Method by Id" + InternshipId.ToString() + ex);
                return Error("Failed to GetStudentFeedbackDetails");
            }
        }
        /// <summary>
        /// to fetch the provided students feedback 
        /// </summary>
        /// <param name="StudentId"></param>
        /// <param name="CreatedBy"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.Student)]
        [Route("providedlist-student/{StudentId}/{CreatedBy}")]
        [HttpGet]
        public async Task<IActionResult> GetProvidedStudentFeedback(long StudentId, string CreatedBy)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetProvidedStudentFeedback Method by Id" + StudentId.ToString());
                var students = await this.internshipService.GetProvidedStudentFeedback(StudentId, CreatedBy);
                this.Logger.LogInformation("Exiting from GetProvidedStudentFeedback Method");
                return Success("GetProvidedStudentFeedback", students);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetProvidedStudentFeedback Method by Id" + StudentId.ToString() + ex);
                return Error("Failed to GetProvidedStudentFeedback");
            }
        }
        /// <summary>
        /// to fetch the students feedback based on feedback id
        /// </summary>
        /// <param name="StudentFeedbackId"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.Student, Role.Employer, Role.InternshipCounsellor, Role.SuperAdmin)]
        [Route("students-details/{StudentFeedbackId}")]
        [HttpGet]
        public async Task<IActionResult> GetFeedbackDetailsStudent(long StudentFeedbackId)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetFeedbackDetailsStudent Method by Id" + StudentFeedbackId.ToString());
                var students = await this.internshipService.GetFeedbackDetailsStudents(StudentFeedbackId);
                this.Logger.LogInformation("Exiting from GetFeedbackDetailsStudent Method");
                return Success("GetFeedbackDetailsStudent", students);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetFeedbackDetailsStudent Method by Id" + StudentFeedbackId.ToString() + ex);
                return Error("Failed to GetFeedbackDetailsStudent");
            }
        }
        /// <summary>
        /// to save the details of the mail
        /// </summary>
        /// <param name="mailDetails"></param>
        /// <returns></returns>

        [HttpPost("SaveMailDetails")]
        public async Task<IActionResult> SaveMailDetails([FromForm] MailTrackingDto mailDetails)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveMailDetails Method");
                var files = HttpContext.Request.Form.Files;
                if (files != null && files.Count > 0)
                {
                    mailDetails.Attachment = this.FileUtility.GetFileNames(this.FileUtility.FileType_Documents, files);
                }
                var savedData = await this.internshipService.SaveMailDetails(mailDetails);
                #region Save files
                try
                {
                    this.FileUtility.Save(files, SUB_Directory, savedData.Id.ToString());
                }

                catch (Exception ex)
                {
                    this.Logger.LogError(new Exception("Error Occured"), "Failed to save the file" + ex);
                }
                #endregion
                this.Logger.LogInformation("Loading Attachment Info");

                var id = new { Id = mailDetails.Id };
                return Success("Data Saved Successfully", id);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SaveMailDetails Method" + ex);
                return Error("Failed to SaveMailDetails ");
            }
        }
        /// <summary>
        /// to send the mail
        /// </summary>
        /// <param name="mailDetails"></param>
        /// <returns></returns>
        [Route("MailTracking")]
        [HttpPost]
        public IActionResult SendMail([FromForm] MailTrackingDto mailDetails)
        {
            try
            {
                //await this.internshipService.SaveMailDetails(mailDetails);

                EmailMessage emailMessage = new EmailMessage();

                EmailAddress emailAddress = new EmailAddress();

                //toaddress
                emailAddress.Name = "";
                emailAddress.Address = mailDetails.ToEmail;

                emailMessage.ToAddress.Add(emailAddress);

                //ccaddress
                emailAddress = new EmailAddress();
                emailAddress.Name = "";
                //emailAddress.Address = mailDetails.CcEmail;
                //emailMessage.CcAddress.Add(emailAddress);  

                string[] CcAddress = mailDetails.CcEmail.Split(',');
                foreach (string Cc in CcAddress)
                {
                    emailAddress = new EmailAddress();
                    emailAddress.Address = Cc;
                    emailMessage.CcAddress.Add(emailAddress);
                }

                //from address
                emailAddress = new EmailAddress();
                emailAddress.Name = "No-reply";
                //var configSection = configuration.GetSection("EmailConfiguration");
                var RequireUppercase = configuration.GetValue<string>("EmailConfiguration:smtpUserName");
                //var FromMail = configSection.Key.["smtpUserName"];
                emailAddress.Address = RequireUppercase;

                emailMessage.FromAddress.Add(emailAddress);
                emailMessage.Content = mailDetails.EmailContent;
                emailMessage.Subject = mailDetails.Subject;

                var files = HttpContext.Request.Form.Files;
                if (files != null && files.Count > 0)
                {
                    emailMessage.Attachment = files[0];
                }

                emailService.Send(emailMessage);
                return Success("success");
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SendMail Method" + ex);
                return Error("Failed to Send");
            }
        }

        /* [Authorize]
         [HttpGet("GetStudentDetails/{Id}")]
         public async Task<IActionResult> GetStudentDetails(long userId)
         {
             try
             {
                 var data = await userManager.GetUserAsync(userId);

                 return Success("", data);
             }
             catch (Exception ex)
             {
                 return Error("Failed to get the data");
             }
         }
 */

    }
}
