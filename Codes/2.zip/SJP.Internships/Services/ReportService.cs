﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Core.Model;
using SJP.Core.Services;
using SJP.Internships.Api.DataAccess;
using SJP.Internships.Api.Model;
using SJP.Internships.Api.Model.Dto;
using SJP.Internships.Api.Model.Report;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Internships.Api.Services
{
    public class ReportService : ServiceBase, IReportService

    {
        private readonly IReportDataAccess ReportDataAccess;

        private readonly ILogger logger;
        protected ILogger Logger => logger;
        public ReportService(IReportDataAccess reportDataAccess, ILogger<ReportService> logger, IConfiguration configuration) : base(configuration)
        {
            this.ReportDataAccess = reportDataAccess;
            this.logger = logger;
        }

        // Report 1
        public async Task<IEnumerable<ReportModelDto>> GetInternListingsSummary(InternshipsParams internshipsParam)
        {
            try
            {
                this.logger.LogInformation("Loading StudentsReviewedbyInternship Method");
                var InternshipsRecords = await this.ReportDataAccess.GetInternListingsSummary(internshipsParam);

                if (InternshipsRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetInternListingsSummary Method with" + InternshipsRecords.Count().ToString());
                    return InternshipsRecords.Select(internships => new ReportModelDto
                    {
                        CompanyNameEn = internships.CompanyNameEn,
                        CompanyNameAr = internships.CompanyNameAr,
                        InternshipTitleEn = internships.InternshipTitleEn,
                        InternshipTitleAr = internships.InternshipTitleAr,
                        InternshipRoleEn = internships.InternshipRoleEn,
                        InternshipRoleAr = internships.InternshipRoleAr,
                        NumberOfPositions = internships.NumberOfPositions,
                        InternshipType = internships.InternshipType,
                        Industry = internships.Industry,
                        Education = internships.Education,
                        EducationCategory = internships.EducationCategory,
                        StudentsMajor = internships.StudentsMajor,
                        PostedDate = internships.PostedDate,
                        ApplicationDeadline = internships.ApplicationDeadline,
                        StartDate = internships.StartDate,
                        EndDate = internships.EndDate,
                        InternshipDuration = internships.InternshipDuration,
                        TotalInternshipPosted = internships.TotalInternshipPosted,
                        TotalFullTimePosted = internships.TotalFullTimePosted,
                        MostInternshipByCompany = internships.MostInternshipByCompany,
                        TotalGeneralPosted = internships.TotalGeneralPosted,
                        TotalHigherPosted = internships.TotalHigherPosted
                    });
                }

                this.Logger.LogInformation("Exiting from GetInternListingsSummary Method ");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipsServices at GetInternListingsSummary Method" + Ex);
                throw Ex;
            }
        }

        //report 2

        public async Task<IEnumerable<ReportModelDto>> GetInternshipPostStatistics(InternshipsParams internshipsParam)
        {
            try
            {
                this.logger.LogInformation("Loading GetInternshipPostStatistics Method");
                var InternshipsRecords = await this.ReportDataAccess.GetInternshipPostStatistics(internshipsParam);

                if (InternshipsRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetInternshipPostStatistics Method with" + InternshipsRecords.Count().ToString());
                    return InternshipsRecords.Select(internships => new ReportModelDto
                    {
                        OrganizationName = internships.OrganizationName,
                        TotalPosted = internships.TotalPosted,
                        TotalApproved = internships.TotalApproved,
                        TotalRejected = internships.TotalRejected,
                        TotalPending = internships.TotalPending


                    });
                }

                this.Logger.LogInformation("Exiting from GetInternshipPostStatistics Method ");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipsServices at GetInternshipPostStatistics Method" + Ex);
                throw Ex;
            }
        }


        // Report 3
        public async Task<IEnumerable<ReportModelDto>> GetInternApplicationSummary(InternshipsParams internshipsParam)
        {
            try
            {
                this.logger.LogInformation("Loading GetInternApplicationSummary Method");
                var InternshipsRecords = await this.ReportDataAccess.GetInternApplicationSummary(internshipsParam);

                if (InternshipsRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetInternApplicationSummary Method with" + InternshipsRecords.Count().ToString());
                    return InternshipsRecords.Select(internships => new ReportModelDto
                    {
                        StudentsName = internships.StudentsName,
                        CompanyNameEn = internships.CompanyNameEn,
                        CompanyNameAr = internships.CompanyNameAr,
                        InternshipTitleEn = internships.InternshipTitleEn,
                        InternshipTitleAr = internships.InternshipTitleAr,
                        RecruitmentStatus = internships.RecruitmentStatus,
                        InternshipRoleEn = internships.InternshipRoleEn,
                        InternshipRoleAr = internships.InternshipRoleAr,
                        Education=internships.Education,
                        EducationCategory=internships.EducationCategory,
                        Industry = internships.Industry,
                        PostedDate = internships.PostedDate,
                        InstituteNameEn = internships.InstituteNameEn,
                        InstituteNameAr = internships.InstituteNameAr,
                        MajorEn = internships.MajorEn,
                        MajorAr = internships.MajorAr,
                        EmirateNameEn = internships.EmirateNameEn,
                        EmirateNameAr = internships.EmirateNameAr,
                        StudentsGender = internships.StudentsGender,
                        TotalHigherEducation = internships.TotalHigherEducation,
                        TotalGeneralEducation = internships.TotalGeneralEducation,
                        TotalShortlisted = internships.TotalShortlisted,
                        TotalInterviewed = internships.TotalInterviewed,
                        TotalHired = internships.TotalHired
                    });
                }

                this.Logger.LogInformation("Exiting from GetInternApplicationSummary Method ");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipsServices at GetInternApplicationSummary Method" + Ex);
                throw Ex;
            }
        }




        //Report 4
        public async Task<IEnumerable<ReportModelDto>> GetStudentsReviewedbyInternship(InternshipsParams internshipsParam)
        {
            try
            {
                this.logger.LogInformation("Loading StudentsReviewedbyInternship Method");
                var InternshipsRecords = await this.ReportDataAccess.StudentsReviewedbyInternship(internshipsParam);

                if (InternshipsRecords != null)
                {
                    this.Logger.LogInformation("Exiting from StudentsReviewedbyInternship Method with" + InternshipsRecords.Count().ToString());
                    return InternshipsRecords.Select(internships => new ReportModelDto
                    {
                        InternshipCounsellorName = internships.InternshipCounsellorName,
                        InstituteNameEn = internships.InstituteNameEn,
                        InstituteNameAr = internships.InstituteNameAr,
                        InternshipRoleEn = internships.InternshipRoleEn,
                        InternshipRoleAr = internships.InternshipRoleAr,
                        StudentsName = internships.StudentsName,
                        StudentApplieddate = internships.StudentApplieddate,
                        EmirateNameEn = internships.EmirateNameEn,
                        EmirateNameAr = internships.EmirateNameAr,
                        StudentsGender = internships.StudentsGender,
                        MajorAr = internships.MajorAr,
                        MajorEn = internships.MajorEn,
                        ApplicationStatus = internships.ApplicationStatus,
                        ReasonforRejection = internships.ReasonforRejection,
                        IsDisagreed = internships.IsDisagreed,
                        //InternshipCounsellorAgreed = internships.InternshipCounsellorAgreed,
                        //InternshipCounsellorDisAgreed = internships.InternshipCounsellorDisAgreed,
                        //TotalInternshipCounsellorAgreed = internships.TotalInternshipCounsellorAgreed,
                        //TotalInternshipCounsellorDisAgreed = internships.TotalInternshipCounsellorDisAgreed,





                    });
                }

                this.Logger.LogInformation("Exiting from StudentsReviewedbyInternship Method ");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipsServices at StudentsReviewedbyInternship Method" + Ex);
                throw Ex;
            }
        }


        //Report 5
        public async Task<IEnumerable<ReportModelDto>> StudentsFeedback(InternshipsParams internshipsParam)
        {
            try
            {
                this.logger.LogInformation("Loading StudentsFeedback Method");
                var InternshipsRecords = await this.ReportDataAccess.StudentsFeedback(internshipsParam);

                if (InternshipsRecords != null)
                {
                    this.Logger.LogInformation("Exiting from StudentsFeedback Method with" + InternshipsRecords.Count().ToString());
                    return InternshipsRecords.Select(internships => new ReportModelDto
                    {
                        StudentsName = internships.StudentsName,
                        InternshipRoleEn = internships.InternshipRoleEn,
                        // InternshipRoleAr = internships.InternshipRoleAr,
                        CompanyNameEn = internships.CompanyNameEn,
                        // CompanyNameAr = internships.CompanyNameAr,
                        InstituteNameEn = internships.InstituteNameEn,
                        // InstituteNameAr = internships.InstituteNameAr,
                        MajorAr = internships.MajorAr,
                        MajorEn = internships.MajorEn,
                        SupervisorName = internships.SupervisorName,
                        SupervisorDesignation = internships.SupervisorDesignation,
                        DateofInternship = internships.DateofInternship,
                        EmployerOrientation = internships.EmployerOrientation,
                        TaskAssinged = internships.TaskAssinged,
                        Employerliaise = internships.Employerliaise,
                        EmployerAgreeplan = internships.EmployerAgreeplan,
                        EmployerConductInterview = internships.EmployerConductInterview,
                        ClearWhoYourManager = internships.ClearWhoYourManager,
                        SupervisorPerformance = internships.SupervisorPerformance,
                        SupervisorTeamMeeting = internships.SupervisorTeamMeeting,
                        Exceptation = internships.Exceptation,
                        RecommendEmployer = internships.RecommendEmployer,
                        OverallRating = internships.OverallRating,
                        AnyFeedbackforEmployer = internships.AnyFeedbackforEmployer,
                        HigherSatisfactory = internships.HigherSatisfactory,
                        GeneralSatisfactory = internships.GeneralSatisfactory
                        // TotalHigherEducationSatisfactory = internships.TotalHigherEducationSatisfactory,
                        //TotalHigherEducationNotSatisfactory = internships.TotalHigherEducationNotSatisfactory,
                        //TotalGeneralEducationSatisfactory = internships.TotalGeneralEducationSatisfactory,
                        //TotalGeneralEducationNotSatisfactory = internships.TotalGeneralEducationNotSatisfactory

                    });
                }

                this.Logger.LogInformation("Exiting from StudentsFeedback Method ");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipsServices at StudentsFeedback Method" + Ex);
                throw Ex;
            }
        }


        // Report 6
        public async Task<IEnumerable<ReportModelDto>> GetCompanyFeedbackOnStudents(InternshipsParams internshipsParam)
        {
            try
            {
                this.logger.LogInformation("Loading StudentsReviewedbyInternship Method");
                var InternshipsRecords = await this.ReportDataAccess.GetCompanyFeedbackOnStudents(internshipsParam);

                if (InternshipsRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetCompanyFeedbackOnStudents Method with" + InternshipsRecords.Count().ToString());
                    return InternshipsRecords.Select(internships => new ReportModelDto
                    {
                        CompanyNameEn = internships.CompanyNameEn,
                        //CompanyNameAr = internships.CompanyNameAr,
                        StudentsName = internships.StudentsName,
                        InternshipRoleEn = internships.InternshipRoleEn,
                        InternshipRoleAr = internships.InternshipRoleAr,
                        InstituteNameEn = internships.InstituteNameEn,
                        InstituteNameAr = internships.InstituteNameAr,
                        MajorEn = internships.MajorEn,
                        MajorAr= internships.MajorAr,
                        NumberOfPositions = internships.NumberOfPositions,
                        InternshipType = internships.InternshipType,
                        IndustryName = internships.IndustryName,
                        EducationLevel = internships.EducationLevel,
                        EducationCategory = internships.EducationCategory,
                        SupervisorName=internships.SupervisorName,
                        SupervisorDesignation=internships.SupervisorDesignation,
                        DateofInternship=internships.DateofInternship,
                        ScientificLiteracy=internships.ScientificLiteracy,
                      TechLiteracy=internships.TechLiteracy,
                      FinancialLiteracy=internships.FinancialLiteracy,
                      CriticalThinking=internships.CriticalThinking,
                      Creativity=internships.Creativity,
                      Communication=internships.Communication,
                      Collaboration=internships.Collaboration,
                      Adaptability =internships.Adaptability,
                      Leadership =internships.Leadership,
                      SocialCulturalAwareness=internships.SocialCulturalAwareness,
                      Empathy = internships.Empathy,
                      GrowthMindset =internships.GrowthMindset,
                      OverallSatisfaction = internships.OverallSatisfaction,
                      DescriptionPerformedbyIntern = internships.DescriptionPerformedbyIntern,
                      StrengthsofIntern = internships.StrengthsofIntern,
                      SuggestedDevelopmentAreas =internships.SuggestedDevelopmentAreas,
                      OtherComments = internships.OtherComments,
                      HigherSatisfactory=internships.HigherSatisfactory,
                      GeneralSatisfactory=internships.GeneralSatisfactory
                    });
                }

                this.Logger.LogInformation("Exiting from GetCompanyFeedbackOnStudents Method ");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipsServices at GetCompanyFeedbackOnStudents Method" + Ex);
                throw Ex;
            }
        }


        //report 7
        public async Task<IEnumerable<RatingReportModel>> GetInternshipModuleFeedback(InternshipsParams internshipsParam)
        {
            try
            {
                this.logger.LogInformation("Loading GetInternshipModuleFeedback Method");
                var InternshipsRecords = await this.ReportDataAccess.GetInternshipModuleFeedback(internshipsParam);

                if (InternshipsRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetInternshipModuleFeedback Method with" + InternshipsRecords.Count().ToString());
                    return InternshipsRecords.Select(internships => new RatingReportModel
                    {

                        StudentName = internships.StudentName,
                        Content = internships.Content,
                        Design = internships.Design,
                        Personalization = internships.Personalization,
                        Functionality = internships.Functionality,
                        MajorId = internships.MajorId,
                        EmirateEn = internships.EmirateEn,
                        EmirateAr = internships.EmirateAr,
                        EnInstituteName = internships.EnInstituteName,
                        ArInstituteName = internships.ArInstituteName
                        // Emirate = internships.Emirate,
                        //  InstituteId = internships.InstituteId

                    });
                }

                this.Logger.LogInformation("Exiting from GetInternshipModuleFeedback Method ");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipsServices at GetInternshipModuleFeedback Method" + Ex);
                throw Ex;
            }
        }







        public override void Dispose()
        {
            //throw new NotImplementedException();
        }

    }
}
