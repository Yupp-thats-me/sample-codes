﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Core.Services;
using SJP.Internships.Api.DataAccess;
using SJP.Internships.Api.Model;
using SJP.Internships.Api.Model.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Internships.Api.Services
{
    public class InternshipService : ServiceBase, IInternshipService
    {
        private readonly IInternshipDataAccess internshipDataAccess;

        private readonly ILogger logger;
        protected ILogger Logger => logger;
        public InternshipService(ILogger<InternshipService> logger, IInternshipDataAccess internshipDataAccess, IConfiguration configuration) : base(configuration)
        {
            this.internshipDataAccess = internshipDataAccess;
            this.logger = logger;
        }
        public override void Dispose()
        {
            //  throw new NotImplementedException();
        }
        public async Task<IEnumerable<InternshipDetailsDto>> GetInternshipDetails()
        {
            try
            {
                this.logger.LogInformation("Loading GetInternshipDetails Method");
                var internRecord = await this.internshipDataAccess.GetInternshipDetailsAsync();
                if (internRecord != null)
                {
                    this.Logger.LogInformation("Entering into GetInternshipDetails Method" + internRecord.Count().ToString());
                    return internRecord.Select(intern => new InternshipDetailsDto
                    {
                        Id = intern.Id,
                        UploadImage = intern.UploadImage,
                        OnBehalfOf = intern.OnBehalfOf,
                        InternshipTypeId = intern.InternshipTypeId,
                        InternshipTitleEn = intern.InternshipTitleEn,
                        InternshipTitleAr = intern.InternshipTitleAr,
                        DescriptionEn = intern.DescriptionEn,
                        DescriptionAr = intern.DescriptionAr,
                        EligibilityEn = intern.EligibilityEn,
                        EligibilityAr = intern.EligibilityAr,
                        CountryId = intern.CountryId,
                        EmirateId = intern.EmirateId,
                        HigherEducationId = intern.HigherEducationId,
                        GenderId = intern.GenderId,
                        AgeId = intern.AgeId,
                        MajorId = intern.MajorId,
                        Stream = intern.Stream,
                        JoiningDate = intern.JoiningDate,
                        Duration = intern.Duration,
                        NumberOfPositionsId = intern.NumberOfPositionsId,
                        MinimumHoursRequiredId = intern.MinimumHoursRequiredId,
                        OrganizationLink = intern.OrganizationLink,
                        IndustryName = intern.IndustryName,
                        InternshipRoleNameEn = intern.InternshipRoleNameEn,
                        InternshipRoleNameAr = intern.InternshipRoleNameAr,
                        MonthlySalaryRangeId = intern.MonthlySalaryRangeId,
                        HowToApplyEn = intern.HowToApplyEn,
                        HowToApplyAr = intern.HowToApplyAr,
                        ContactEmail = intern.ContactEmail,
                        ExpiryDate = intern.ExpiryDate,
                        StatusId = intern.StatusId,
                        IsActive = intern.IsActive,
                        CreatedBy = intern.CreatedBy,
                        UpdatedBy = intern.UpdatedBy,
                        CreatedDate = intern.CreatedDate,
                        UpdatedDate = intern.UpdatedDate,
                        InternshipQuestionnaireDetails = intern.InternshipQuestionnaireDetails,
                        Reason = intern.Reason,
                        Status = intern.Status,
                        IsProbable = intern.IsProbable,
                        LastProbableJoiningDate = intern.LastProbableJoiningDate,
                        InternshipFor = intern.InternshipFor,
                        UserId = intern.UserId,
                        ApplicationDeadline = intern.ApplicationDeadline,
                        CompanyNameEn = intern.CompanyNameEn,
                        CompanyNameAr = intern.CompanyNameAr,
                        RequestedRole = intern.RequestedRole,
                        FieldofTraining = intern.FieldofTraining,


                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetInternshipDetails Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetInternshipDetails at InternshipDetailsAsync Method" + ex);
                throw ex;
            }
        }
        public async Task<InternshipDetailsDto> GetInternshipDetails(long Id)
        {
            try
            {
                var internRecord = await this.internshipDataAccess.GetInternshipDetailsAsync(Id);
                if (internRecord != null)
                {
                    this.Logger.LogInformation("Entering into GetInternshipDetails Method" + internRecord.ToString());
                    return new InternshipDetailsDto
                    {
                        Id = internRecord.Id,
                        UploadImage = internRecord.UploadImage,
                        OnBehalfOf = internRecord.OnBehalfOf,
                        InternshipTypeId = internRecord.InternshipTypeId,
                        InternshipTitleEn = internRecord.InternshipTitleEn,
                        InternshipTitleAr = internRecord.InternshipTitleAr,
                        DescriptionEn = internRecord.DescriptionEn,
                        DescriptionAr = internRecord.DescriptionAr,
                        EligibilityEn = internRecord.EligibilityEn,
                        EligibilityAr = internRecord.EligibilityAr,
                        CountryId = internRecord.CountryId,
                        EmirateId = internRecord.EmirateId,
                        HigherEducationId = internRecord.HigherEducationId,
                        GenderId = internRecord.GenderId,
                        AgeId = internRecord.AgeId,
                        MajorId = internRecord.MajorId,
                        Stream = internRecord.Stream,
                        JoiningDate = internRecord.JoiningDate,
                        Duration = internRecord.Duration,
                        NumberOfPositionsId = internRecord.NumberOfPositionsId,
                        MinimumHoursRequiredId = internRecord.MinimumHoursRequiredId,
                        OrganizationLink = internRecord.OrganizationLink,
                        IndustryName = internRecord.IndustryName,
                        InternshipRoleNameEn = internRecord.InternshipRoleNameEn,
                        InternshipRoleNameAr = internRecord.InternshipRoleNameAr,
                        MonthlySalaryRangeId = internRecord.MonthlySalaryRangeId,
                        HowToApplyEn = internRecord.HowToApplyEn,
                        HowToApplyAr = internRecord.HowToApplyAr,
                        ContactEmail = internRecord.ContactEmail,
                        ExpiryDate = internRecord.ExpiryDate,
                        StatusId = internRecord.StatusId,
                        IsActive = internRecord.IsActive,
                        CreatedBy = internRecord.CreatedBy,
                        UpdatedBy = internRecord.UpdatedBy,
                        CreatedDate = internRecord.CreatedDate,
                        UpdatedDate = internRecord.UpdatedDate,
                        InternshipQuestionnaireDetails = internRecord.InternshipQuestionnaireDetails,
                        Reason = internRecord.Reason,
                        Status = internRecord.Status,
                        IsProbable = internRecord.IsProbable,
                        LastProbableJoiningDate = internRecord.LastProbableJoiningDate,
                        InternshipFor = internRecord.InternshipFor,
                        UserId = internRecord.UserId,
                        ApplicationDeadline = internRecord.ApplicationDeadline,
                        CompanyNameEn = internRecord.CompanyNameEn,
                        CompanyNameAr = internRecord.CompanyNameAr,
                        RequestedRole = internRecord.RequestedRole,
                        FieldofTraining = internRecord.FieldofTraining,


                    };
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetInternshipDetails Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipDetailsService at InternshipDetailsAsync Method" + ex);
                throw ex;
            }
        }
        public async Task<IEnumerable<InternshipDetailsDto>> GetInternshipDetailsGrid()
        {
            try
            {
                this.logger.LogInformation("Entering into GetInternshipDetailsGrid Method");
                var internshipRecords = await this.internshipDataAccess.GetInternshipDetailsGrid();
                if (internshipRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetInternshipDetailsGrid Method with" + internshipRecords.Count().ToString());
                    return internshipRecords.Select(internship => new InternshipDetailsDto
                    {
                        Id = internship.Id,
                        InternshipTitleEn = internship.InternshipTitleEn,
                        InternshipTitleAr = internship.InternshipTitleAr,
                        ExpiryDate = internship.ExpiryDate,
                        StatusId = internship.StatusId,
                        OnBehalfOf = internship.OnBehalfOf,
                        CreatedBy = internship.CreatedBy,
                        CreatedDate = internship.CreatedDate,
                        UpdatedDate = internship.UpdatedDate,
                        Reason = internship.Reason,
                        UserId = internship.UserId,
                        RequestedRole = internship.RequestedRole,
                        FieldofTraining = internship.FieldofTraining,

                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetInternshipDetailsGrid Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipDetailsService  at GetInternshipDetailsGrid Method" + ex);
                throw ex;
            }
        }
        public async Task<InternshipDetailsDto> SaveInternshipDetails(InternshipDetailsDto internshipDetail)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveInternshipDetails Method");


                var saveInternship = new InternshipDetails
                {
                    Id = internshipDetail.Id,
                    UploadImage = internshipDetail.UploadImage,
                    OnBehalfOf = internshipDetail.OnBehalfOf,
                    InternshipTypeId = internshipDetail.InternshipTypeId,
                    InternshipTitleEn = internshipDetail.InternshipTitleEn,
                    InternshipTitleAr = internshipDetail.InternshipTitleAr,
                    DescriptionEn = internshipDetail.DescriptionEn,
                    DescriptionAr = internshipDetail.DescriptionAr,
                    EligibilityEn = internshipDetail.EligibilityEn,
                    EligibilityAr = internshipDetail.EligibilityAr,
                    CountryId = internshipDetail.CountryId,
                    EmirateId = internshipDetail.EmirateId,
                    HigherEducationId = internshipDetail.HigherEducationId,
                    GenderId = internshipDetail.GenderId,
                    AgeId = internshipDetail.AgeId,
                    MajorId = internshipDetail.MajorId,
                    Stream = internshipDetail.Stream,
                    JoiningDate = internshipDetail.JoiningDate,
                    Duration = internshipDetail.Duration,
                    NumberOfPositionsId = internshipDetail.NumberOfPositionsId,
                    MinimumHoursRequiredId = internshipDetail.MinimumHoursRequiredId,
                    OrganizationLink = internshipDetail.OrganizationLink,
                    IndustryName = internshipDetail.IndustryName,
                    InternshipRoleNameEn = internshipDetail.InternshipRoleNameEn,
                    InternshipRoleNameAr = internshipDetail.InternshipRoleNameAr,
                    MonthlySalaryRangeId = internshipDetail.MonthlySalaryRangeId,
                    HowToApplyEn = internshipDetail.HowToApplyEn,
                    HowToApplyAr = internshipDetail.HowToApplyAr,
                    ContactEmail = internshipDetail.ContactEmail,
                    ExpiryDate = internshipDetail.ExpiryDate,
                    StatusId = internshipDetail.StatusId,
                    IsActive = internshipDetail.IsActive,
                    CreatedBy = internshipDetail.CreatedBy,
                    UpdatedBy = internshipDetail.UpdatedBy,
                    CreatedDate = internshipDetail.CreatedDate,
                    UpdatedDate = internshipDetail.UpdatedDate,
                    //InternshipQuestionnaireDetails = internshipDetail.InternshipQuestionnaireDetails.ToList(),
                    Reason = internshipDetail.Reason,
                    IsProbable = internshipDetail.IsProbable,
                    LastProbableJoiningDate = internshipDetail.LastProbableJoiningDate,
                    InternshipFor = internshipDetail.InternshipFor,
                    UserId = internshipDetail.UserId,
                    ApplicationDeadline = internshipDetail.ApplicationDeadline,
                    CompanyNameEn = internshipDetail.CompanyNameEn,
                    CompanyNameAr = internshipDetail.CompanyNameAr,
                    FieldofTraining = internshipDetail.FieldofTraining,

                };
                if (internshipDetail.InternshipQuestionnaireDetails != null)
                {
                    saveInternship.InternshipQuestionnaireDetails = internshipDetail.InternshipQuestionnaireDetails.ToList();
                }

                var dataSaved = await this.internshipDataAccess.SaveInternshipDetailsAsync(saveInternship);
                internshipDetail.Id = dataSaved.Id;
                this.Logger.LogInformation("Exiting from SaveInternshipDetails Method");
                return internshipDetail;
            }
            catch (Exception ex)
            {
                this.Logger.LogInformation("Error Occured in SaveInternshipDetails Method" + ex);
                throw ex;

            }
        }

        public async Task<InternshipDetailsDto> UpdatedApprovalDetails(InternshipDetailsDto internshipDetail)
        {
            try
            {
                this.Logger.LogInformation("Entering into UpdatedApprovalDetails Method");
                var approvalInternship = new InternshipDetails
                {
                    Id = internshipDetail.Id,
                    Reason = internshipDetail.Reason,
                    StatusId = internshipDetail.StatusId,
                    UpdatedBy = internshipDetail.UpdatedBy
                };
                var save = await this.internshipDataAccess.SaveApprovalDetailsAsync(approvalInternship);
                internshipDetail.Id = save.Id;
                this.Logger.LogInformation("Exiting from UpdatedApprovalDetails");
                return internshipDetail;
            }
            catch (Exception ex)
            {
                this.Logger.LogInformation("Error Occured in UpdatedApprovalDetails" + ex);
                throw ex;
            }
        }

        public async Task<IEnumerable<InternshipRoleMasterDto>> GetInternshipRoleMaster()
        {
            try
            {
                this.logger.LogInformation("Entering into GetInternshipRoleMaster Method");
                var internshipRoleMasters = await this.internshipDataAccess.GetInternshipRoleMaster();
                if (internshipRoleMasters != null)
                {
                    this.Logger.LogInformation("Exiting from GetInternshipRoleMaster method with " + internshipRoleMasters.Count().ToString() + "Records");
                    return internshipRoleMasters.Select(internshipRole => new InternshipRoleMasterDto
                    {
                        InternshipRoleId = internshipRole.InternshipRoleId,
                        InternshipRoleNameEn = internshipRole.InternshipRoleNameEn,
                        InternshipRoleNameAr = internshipRole.InternshipRoleNameAr

                    });
                }
                this.Logger.LogInformation("Exiting from GetInternshipRoleMaster Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipService at GetInternshipRoleMaster Method" + ex);
                throw ex;
            }
        }
        public async Task<InternshipRoleMasterDto> SaveinternshipRoleMaster(InternshipRoleMasterDto internshipRoleMaster)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveinternshipRoleMaster Method");
                var saveInternshipRole = new InternshipRoleMaster
                {
                    InternshipRoleNameEn = internshipRoleMaster.InternshipRoleNameEn,
                    InternshipRoleNameAr = internshipRoleMaster.InternshipRoleNameAr
                };
                var dataSaved = await this.internshipDataAccess.SaveinternshipRoleMasterAsyc(saveInternshipRole);
                this.Logger.LogInformation("Exiting from SaveinternshipRoleMaster Method");
                return internshipRoleMaster;
            }
            catch (Exception ex)
            {
                this.Logger.LogInformation("Error Occured in SaveinternshipRoleMaster Method" + ex);
                throw ex;
            }
        }
        public async Task<bool> IsActive(long Id)
        {
            try
            {
                this.Logger.LogInformation("Entering into IsActive Method");
                await this.internshipDataAccess.IsActive(Id);
                this.Logger.LogInformation("Exiting from IsActive Method");
                return true;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "Error in IsActive Method :" + ex);
                throw ex;
            }
        }

        /* public async Task<InternshipDetailsDto> UpdateTotalViews(InternshipDetailsDto viewsUpdate)
         {
             try
             {
                 this.Logger.LogInformation("Entering into UpdateTotalViews Method");
                 var views = new ScholarshipDetails
                 {
                     Id = viewsUpdate.Id ?? 0,
                     TotalViews = viewsUpdate.TotalViews

                 };
                 var save = await this.internshipDataAccess.UpdateTotalViews(views);
                 viewsUpdate.Id = save.Id;
                 this.Logger.LogInformation("Exiting from UpdateTotalViews");
                 return viewsUpdate;
             }
             catch (Exception ex)
             {
                 this.Logger.LogInformation("Error Occured in UpdateTotalViews" + ex);
                 throw ex;
             }
         }*/

        public async Task<InternshipDetailsDto> GetInternshipDetailsUserviewById(long Id)
        {
            try
            {
                this.logger.LogInformation("Entering into  GetInternshipDetailsUserviewById Method");
                var internviewRecord = await this.internshipDataAccess.GetInternshipDetailsUserviewById(Id);
                if (internviewRecord != null)
                {
                    this.Logger.LogInformation("Entering into  GetInternshipDetailsUserviewById Method with" + internviewRecord.ToString());
                    return new InternshipDetailsDto
                    {
                        Id = internviewRecord.Id,
                        InternshipTitleEn = internviewRecord.InternshipTitleEn,
                        InternshipTitleAr = internviewRecord.InternshipTitleAr,
                        DescriptionEn = internviewRecord.DescriptionEn,
                        DescriptionAr = internviewRecord.DescriptionAr,
                        EligibilityEn = internviewRecord.EligibilityEn,
                        EligibilityAr = internviewRecord.EligibilityAr,
                        HowToApplyEn = internviewRecord.HowToApplyEn,
                        HowToApplyAr = internviewRecord.HowToApplyAr,
                        ExpiryDate = internviewRecord.ExpiryDate,
                        OrganizationLink = internviewRecord.OrganizationLink,
                        AgeEn = internviewRecord.AgeEn,
                        AgeAr = internviewRecord.AgeAr,
                        MonthlySalaryRangeEn = internviewRecord.MonthlySalaryRangeEn,
                        MonthlySalaryRangeAr = internviewRecord.MonthlySalaryRangeAr,
                        JoiningDate = internviewRecord.JoiningDate,
                        InternshipRoleNameEn = internviewRecord.InternshipRoleNameEn,
                        InternshipRoleNameAr = internviewRecord.InternshipRoleNameAr,
                        UploadImage = internviewRecord.UploadImage,
                        LastProbableJoiningDate = internviewRecord.LastProbableJoiningDate,
                        CountryId = internviewRecord.CountryId,
                        EmirateId = internviewRecord.EmirateId,
                        HigherEducationId = internviewRecord.HigherEducationId,
                        GenderId = internviewRecord.GenderId,
                        Duration = internviewRecord.Duration,
                        NumberOfPositionsId = internviewRecord.NumberOfPositionsId,
                        MinimumHoursRequiredId = internviewRecord.MinimumHoursRequiredId,
                        InternshipTypeId = internviewRecord.InternshipTypeId,
                        IndustryNameEn = internviewRecord.IndustryNameEn,
                        IndustryNameAr = internviewRecord.IndustryNameAr,
                        InternshipQuestionnaireDetails = internviewRecord.InternshipQuestionnaireDetails,
                        CompanyNameEn = internviewRecord.CompanyNameEn,
                        CompanyNameAr = internviewRecord.CompanyNameAr,
                        ApplicationDeadline = internviewRecord.ApplicationDeadline,
                        StudentId = internviewRecord.StudentId,
                        FieldofTraining = internviewRecord.FieldofTraining,
                    };
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetInternshipDetailsUserviewById Method with 0 records");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetInternshipDetailsUserviewById Method" + ex);
                throw ex;
            }
        }
        public async Task<UserApplyDetailsDto> SaveApplyDetails(UserApplyDetailsDto applyDetails)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveApplyDetails Method ");


                var apply = new UserApplyDetails
                {
                    Id = applyDetails.Id,
                    InternshipId = applyDetails.InternshipId,
                    StudentId = applyDetails.StudentId,
                    Content = applyDetails.Content,
                    Design = applyDetails.Design,
                    Personalization = applyDetails.Personalization,
                    Functionality = applyDetails.Functionality,
                    UploadDocument = applyDetails.UploadDocument,
                    DocumentTitle = applyDetails.DocumentTitle,
                    KeySkills = applyDetails.KeySkills,
                    ProbableJoiningDate = applyDetails.ProbableJoiningDate,
                    IsStudentProfile = applyDetails.IsStudentProfile,
                    CreatedBy = applyDetails.CreatedBy,
                    StatusId = applyDetails.StatusId
                };
                if (applyDetails.AnswerDetails != null)
                {
                    apply.AnswerDetails = applyDetails.AnswerDetails.Select(a => new UserAnswerDetails
                    {
                        QuestionnaireId = a.QuestionnaireId,
                        Answers = a.Answers,
                        StudentId = applyDetails.StudentId,
                        CreatedBy = applyDetails.CreatedBy

                    }).ToList();

                }

                var dataSaved = await this.internshipDataAccess.SaveApplyDetails(apply);
                applyDetails.Id = dataSaved.Id;
                this.Logger.LogInformation("Exiting from SaveApplyDetails Method");
                return applyDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogInformation("Error Occured in SaveApplyDetails Method" + ex);
                throw ex;
            }
        }
        public async Task<UserApplyDetailsDto> UpdateStatusDetails(UserApplyDetailsDto statusUpdate)
        {
            try
            {
                this.Logger.LogInformation("Entering into UpdateStatusDetails Method");
                var status = new UserApplyDetails
                {
                    Id = statusUpdate.Id,
                    StatusId = statusUpdate.StatusId,
                    UpdatedBy = statusUpdate.UpdatedBy
                };
                var save = await this.internshipDataAccess.UpdateStatusDetails(status);
                statusUpdate.Id = save.Id;
                this.Logger.LogInformation("Exiting from UpdateStatusDetails");
                return statusUpdate;
            }
            catch (Exception ex)
            {
                this.Logger.LogInformation("Error Occured in UpdateStatusDetails" + ex);
                throw ex;
            }
        }

        public async Task<IEnumerable<StatusModel>> UpdateStatusList(IEnumerable<StatusModel> statusUpdate)
        {
            try
            {
                this.Logger.LogInformation("Entering into UpdateStatusList Method");
                var status = statusUpdate.Select(status => new StatusModel
                {
                    Id = status.Id,
                    StatusId = status.StatusId,
                });
                var save = await this.internshipDataAccess.UpdateStatusList(status);
                this.Logger.LogInformation("Exiting from UpdateStatusList");
                return statusUpdate;
            }
            catch (Exception ex)
            {
                this.Logger.LogInformation("Error Occured in UpdateStatusList" + ex);
                throw ex;
            }
        }

        public async Task<UserApplyDetailsDto> UpdateDisagreeDetails(UserApplyDetailsDto disagreeUpdate)
        {
            try
            {
                this.Logger.LogInformation("Entering into disagreeUpdateDetails Method");
                var status = new UserApplyDetails
                {
                    Id = disagreeUpdate.Id,
                    UpdatedBy = disagreeUpdate.UpdatedBy,
                    IsDisagreed = disagreeUpdate.IsDisagreed,
                    DisagreedReason = disagreeUpdate.DisagreedReason
                };
                var save = await this.internshipDataAccess.UpdateDisagreeDetails(status);
                disagreeUpdate.Id = save.Id;
                this.Logger.LogInformation("Exiting from disagreeUpdateDetails");
                return disagreeUpdate;
            }
            catch (Exception ex)
            {
                this.Logger.LogInformation("Error Occured in disagreeUpdateDetails" + ex);
                throw ex;
            }
        }


        public async Task<IEnumerable<InternshipDetailsDto>> GetUserInternshipDetailsList(int InternshipFor)
        {
            try
            {
                this.logger.LogInformation("Loading GetUserInternshipDetailsList Method");
                var internshipRecord = await this.internshipDataAccess.GetUserInternshipDetailsList(InternshipFor);

                if (internshipRecord != null)
                {
                    this.Logger.LogInformation("Exiting from GetUserInternshipDetailsList Method with" + internshipRecord.Count().ToString());
                    return internshipRecord.Select(intern => new InternshipDetailsDto
                    {
                        Id = intern.Id,
                        UploadImage = intern.UploadImage,
                        InternshipRoleNameEn = intern.InternshipRoleNameEn,
                        InternshipRoleNameAr = intern.InternshipRoleNameAr,
                        EligibilityEn = intern.EligibilityEn,
                        EligibilityAr = intern.EligibilityAr,
                        CountryId = intern.CountryId,
                        EmirateId = intern.EmirateId,
                        HigherEducationId = intern.HigherEducationId,
                        CompanyNameEn = intern.CompanyNameEn,
                        CompanyNameAr = intern.CompanyNameAr,
                        JoiningDate = intern.JoiningDate,
                        ApplicationDeadline = intern.ApplicationDeadline,
                        AgeId = intern.AgeId,
                        Duration = intern.Duration,
                        //PostedDays=intern.PostedDays,
                        InternshipTitleEn = intern.InternshipTitleEn,
                        InternshipTitleAr = intern.InternshipTitleAr

                    });
                }
                this.Logger.LogInformation("Exiting from GetUserInternshipDetailsList Method");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetUserInternshipDetailsList Method" + Ex);
                throw Ex;
            }
        }

        public async Task<IEnumerable<InternshipDetailsDto>> GetRecruitmentDetailsGrid()
        {
            try
            {
                this.logger.LogInformation("Entering into GetRecruitmentDetailsGrid Method");
                var recruitmentRecords = await this.internshipDataAccess.GetRecruitmentDetailsGrid();
                if (recruitmentRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetRecruitmentDetailsGrid Method with" + recruitmentRecords.Count().ToString());
                    return recruitmentRecords.Select(recruitment => new InternshipDetailsDto
                    {
                        Id = recruitment.Id,
                        InternshipRoleNameEn = recruitment.InternshipRoleNameEn,
                        InternshipRoleNameAr = recruitment.InternshipRoleNameAr,
                        ExpiryDate = recruitment.ExpiryDate,
                        InternshipTypeId = recruitment.InternshipTypeId,
                        InternshipFor = recruitment.InternshipFor,
                        IndustryNameEn = recruitment.IndustryNameEn,
                        IndustryNameAr = recruitment.IndustryNameAr,
                        EmirateEn = recruitment.EmirateEn,
                        EmirateAr = recruitment.EmirateAr,
                        CreatedBy = recruitment.CreatedBy,
                        CreatedDate = recruitment.CreatedDate,
                        UpdatedDate = recruitment.UpdatedDate,
                        UpdatedBy = recruitment.UpdatedBy,
                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetRecruitmentDetailsGrid Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipDetailsService  at GetRecruitmentDetailsGrid Method" + ex);
                throw ex;
            }
        }
        public async Task<StudentDetailsDto> GetFlowChartDetails(long InternshipId)
        {
            try
            {
                var flowcount = await this.internshipDataAccess.GetFlowChartDetails(InternshipId);
                if (flowcount != null)
                {
                    this.Logger.LogInformation("Entering into GetFlowChartDetails Method" + flowcount.ToString());
                    return new StudentDetailsDto
                    {
                        Applied = flowcount.Applied,
                        Shortlisted = flowcount.Shortlisted,
                        Rejected = flowcount.Rejected,
                        Withdrawn = flowcount.Withdrawn,
                        Interviewed = flowcount.Interviewed,
                        DroppedOut = flowcount.DroppedOut,
                        Offered = flowcount.Offered,
                        ScreenedOut = flowcount.ScreenedOut,
                        Accepted = flowcount.Accepted,
                        Declined = flowcount.Declined,
                        Hired = flowcount.Hired
                    };
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetFlowChartDetails Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipDetailsService at GetFlowChartDetails Method" + ex);
                throw ex;
            }
        }

        public async Task<IEnumerable<StudentDetailsDto>> GetDisagreedList()
        {
            try
            {
                this.logger.LogInformation("Entering into GetDisagreedList Method");
                var disagreedlist = await this.internshipDataAccess.GetDisagreedList();
                if (disagreedlist != null)
                {
                    this.Logger.LogInformation("Exiting from GetDisagreedList Method with" + disagreedlist.Count().ToString());
                    return disagreedlist.Select(disagreed => new StudentDetailsDto
                    {
                        Id = disagreed.Id,
                        InternshipId = disagreed.InternshipId,
                        StudentId = disagreed.StudentId,
                        StudentName = disagreed.StudentName,
                        InternshipRoleNameEn = disagreed.InternshipRoleNameEn,
                        InternshipRoleNameAr = disagreed.InternshipRoleNameAr,
                        CompanyNameEn = disagreed.CompanyNameEn,
                        CompanyNameAr = disagreed.CompanyNameAr,
                        DisagreedReason = disagreed.DisagreedReason,
                        DisagreedDate = disagreed.DisagreedDate,
                        Status = disagreed.Status
                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetDisagreedList Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipDetailsService  at GetDisagreedList Method" + ex);
                throw ex;
            }
        }
        public async Task<IEnumerable<InternshipDetailsDto>> GetApplicationsList(long StudentId)
        {
            try
            {
                this.logger.LogInformation("Entering into GetApplicationsList Method");
                var applicationRecords = await this.internshipDataAccess.GetApplicationsList(StudentId);
                if (applicationRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetApplicationsList Method with" + applicationRecords.Count().ToString());
                    return applicationRecords.Select(application => new InternshipDetailsDto
                    {
                        Id = application.Id,
                        UserInternshipId = application.UserInternshipId,
                        InternshipRoleNameEn = application.InternshipRoleNameEn,
                        InternshipRoleNameAr = application.InternshipRoleNameAr,
                        CompanyNameEn = application.CompanyNameEn,
                        CompanyNameAr = application.CompanyNameAr,
                        CreatedBy = application.CreatedBy,
                        CreatedDate = application.CreatedDate,
                        StatusId = application.StatusId,
                        UpdatedBy = application.UpdatedBy,
                        UpdatedDate = application.UpdatedDate,
                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetApplicationsList Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipDetailsService  at GetApplicationsList Method" + ex);
                throw ex;
            }
        }

        public async Task<IEnumerable<InternshipDetailsDto>> GetAcceptedList(long StudentId)
        {
            try
            {
                this.logger.LogInformation("Entering into GetAcceptedList Method");
                var acceptedRecords = await this.internshipDataAccess.GetAcceptedList(StudentId);
                if (acceptedRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetAcceptedList Method with" + acceptedRecords.Count().ToString());
                    return acceptedRecords.Select(accepted => new InternshipDetailsDto
                    {
                        Id = accepted.Id,
                        UserInternshipId = accepted.UserInternshipId,
                        InternshipRoleNameEn = accepted.InternshipRoleNameEn,
                        InternshipRoleNameAr = accepted.InternshipRoleNameAr,
                        CompanyNameEn = accepted.CompanyNameEn,
                        CompanyNameAr = accepted.CompanyNameAr,
                        CreatedBy = accepted.CreatedBy,
                        CreatedDate = accepted.CreatedDate,
                        StatusId = accepted.StatusId,
                        UpdatedBy = accepted.UpdatedBy,
                        UpdatedDate = accepted.UpdatedDate,
                        LastProbableJoiningDate = accepted.LastProbableJoiningDate
                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetAcceptedList Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipDetailsService  at GetAcceptedList Method" + ex);
                throw ex;
            }
        }
        public async Task<IEnumerable<StudentDetailsDto>> GetAcceptedCandidatesList(long InternshipId)
        {
            try
            {
                this.logger.LogInformation("Entering into GetAcceptedCandidatesList Method");
                var candidatesRecords = await this.internshipDataAccess.GetAcceptedCandidatesList(InternshipId);
                if (candidatesRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetAcceptedCandidatesList Method with" + candidatesRecords.Count().ToString());
                    return candidatesRecords.Select(candidates => new StudentDetailsDto
                    {
                        Id = candidates.Id,
                        InternshipId = candidates.InternshipId,
                        StudentId = candidates.StudentId,
                        StudentName = candidates.StudentName,
                        Email = candidates.Email,
                        MobileNo = candidates.MobileNo,
                        ProbableJoiningDate = candidates.ProbableJoiningDate,
                        Status = candidates.Status
                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetAcceptedCandidatesList Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipDetailsService  at GetAcceptedCandidatesList Method" + ex);
                throw ex;
            }
        }

        public async Task<IEnumerable<StudentDetailsDto>> GetUpdateList(long InternshipId)
        {
            try
            {
                this.logger.LogInformation("Entering into GetUpdateList Method");
                var candidatesRecords = await this.internshipDataAccess.GetUpdateList(InternshipId);
                if (candidatesRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetUpdateList Method with" + candidatesRecords.Count().ToString());
                    return candidatesRecords.Select(candidates => new StudentDetailsDto
                    {
                        Id = candidates.Id,
                        InternshipId = candidates.InternshipId,
                        StudentId = candidates.StudentId,
                        CreatedDate = candidates.CreatedDate,
                        StudentName = candidates.StudentName,
                        Status = candidates.Status,
                        Withdrawn = candidates.Withdrawn,
                        Shortlisted = candidates.Shortlisted,
                        Rejected = candidates.Rejected,
                        Interviewed = candidates.Interviewed,
                        IsInterviewed = candidates.IsInterviewed,
                        DroppedOut = candidates.DroppedOut,
                        IsDroppedOut = candidates.IsDroppedOut,
                        Offered = candidates.Offered,
                        ScreenedOut = candidates.ScreenedOut,
                        Declined = candidates.Declined,
                        Accepted = candidates.Accepted,
                        Hired = candidates.Hired,
                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetUpdateList Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipDetailsService  at GetUpdateList Method" + ex);
                throw ex;
            }
        }
        public async Task<IEnumerable<StudentDetailsDto>> GetCandidatesListGrid(long InternshipId)
        {
            try
            {
                this.logger.LogInformation("Entering into GetCandidatesListGrid Method");
                var candidatesRecords = await this.internshipDataAccess.GetCandidatesListGrid(InternshipId);
                if (candidatesRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetCandidatesListGrid Method with" + candidatesRecords.Count().ToString());
                    return candidatesRecords.Select(candidates => new StudentDetailsDto
                    {
                        Id = candidates.Id,
                        InternshipId = candidates.InternshipId,
                        StudentId = candidates.StudentId,
                        CreatedDate = candidates.CreatedDate,
                        StudentName = candidates.StudentName,
                        Email = candidates.Email,
                        MobileNo = candidates.MobileNo,
                        Status = candidates.Status,
                        InternshipRoleNameEn = candidates.InternshipRoleNameEn,
                        InternshipRoleNameAr = candidates.InternshipRoleNameAr
                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetCandidatesListGrid Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipDetailsService  at GetCandidatesListGrid Method" + ex);
                throw ex;
            }
        }

        public async Task<IEnumerable<StudentDetailsDto>> GetAppliedList()
        {
            try
            {
                this.logger.LogInformation("Entering into GetAppliedList Method");
                var candidatesRecords = await this.internshipDataAccess.GetAppliedList();
                if (candidatesRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetAppliedList Method with" + candidatesRecords.Count().ToString());
                    return candidatesRecords.Select(candidates => new StudentDetailsDto
                    {
                        Id = candidates.Id,
                        InternshipId = candidates.InternshipId,
                        InternshipRoleNameEn = candidates.InternshipRoleNameEn,
                        InternshipRoleNameAr = candidates.InternshipRoleNameAr,
                        CompanyNameEn = candidates.CompanyNameEn,
                        CompanyNameAr = candidates.CompanyNameAr,
                        StudentId = candidates.StudentId,
                        StudentName = candidates.StudentName,
                        CreatedDate = candidates.CreatedDate,
                        CutoffDate = candidates.CutoffDate,
                        Status = candidates.Status,
                        CutOffReturn = candidates.CutOffReturn
                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetAppliedList Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipDetailsService  at GetAppliedList Method" + ex);
                throw ex;
            }
        }


        public async Task<IEnumerable<InternshipDetailsDto>> GetExpiryListGrid(long UserId)
        {
            try
            {
                this.logger.LogInformation("Entering into GetExpiryListGrid Method");
                var candidatesRecords = await this.internshipDataAccess.GetExpiryListGrid(UserId);
                if (candidatesRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetExpiryListGrid Method with" + candidatesRecords.Count().ToString());
                    return candidatesRecords.Select(candidates => new InternshipDetailsDto
                    {
                        Id = candidates.Id,
                        CreatedDate = candidates.CreatedDate,
                        InternshipRoleNameEn = candidates.InternshipRoleNameEn,
                        InternshipRoleNameAr = candidates.InternshipRoleNameAr,
                        ExpiryDate = candidates.ExpiryDate
                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetExpiryListGrid Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipDetailsService  at GetExpiryListGrid Method" + ex);
                throw ex;
            }
        }

        public async Task<IEnumerable<ExpiryModel>> UpdateExpiryList(IEnumerable<ExpiryModel> expiryUpdate)
        {
            try
            {
                this.Logger.LogInformation("Entering into UpdateExpiryList Method");
                var status = expiryUpdate.Select(status => new ExpiryModel
                {
                    Id = status.Id,
                    ExpiryDate = status.ExpiryDate,
                });
                var save = await this.internshipDataAccess.UpdateExpiryList(status);
                this.Logger.LogInformation("Exiting from UpdateExpiryList");
                return expiryUpdate;
            }
            catch (Exception ex)
            {
                this.Logger.LogInformation("Error Occured in UpdateExpiryList" + ex);
                throw ex;
            }
        }


        public async Task<StudentDetailsDto> GetStudentDetails(long StudentId, long InternshipId)
        {
            try
            {
                this.logger.LogInformation("Entering into  GetStudentDetails Method");
                var studentRecord = await this.internshipDataAccess.GetStudentDetails(StudentId, InternshipId);
                if (studentRecord != null)
                {
                    this.Logger.LogInformation("Entering into  GetStudentDetails Method with" + studentRecord.ToString());
                    return new StudentDetailsDto
                    {
                        Id = studentRecord.Id,
                        InternshipId = studentRecord.InternshipId,
                        StudentId = studentRecord.StudentId,
                        //PermanentAddressLine1 = studentRecord.PermanentAddressLine1,
                        //Email = studentRecord.Email,
                        //MobileNo = studentRecord.MobileNo,
                        //Emirate = studentRecord.Emirate,
                        Filename = studentRecord.Filename,
                        Resume = studentRecord.Resume,
                        InternshipQuestionnaireDetails = studentRecord.InternshipQuestionnaireDetails,
                        ResumeId = studentRecord.ResumeId,
                    };
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetStudentDetails Method with 0 records");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetStudentDetails Method" + ex);
                throw ex;
            }
        }
        public async Task<IEnumerable<AdminFeedbackDetailsDto>> GetPendingAdminFeedback(long InternshipId)
        {
            try
            {
                this.logger.LogInformation("Entering into GetPendingAdminFeedback Method");
                var studentsRecords = await this.internshipDataAccess.GetPendingAdminFeedback(InternshipId);
                if (studentsRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetPendingAdminFeedback Method with" + studentsRecords.Count().ToString());
                    return studentsRecords.Select(students => new AdminFeedbackDetailsDto
                    {

                        InternshipId = students.InternshipId,
                        StudentId = students.StudentId,
                        CreatedDate = students.CreatedDate,
                        StudentName = students.StudentName,
                        Email = students.Email,
                        MobileNo = students.MobileNo,
                        Duration = students.Duration,
                        CreatedBy = students.CreatedBy

                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetPendingAdminFeedback Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetPendingAdminFeedback Method" + ex);
                throw ex;
            }
        }

        public async Task<AdminFeedbackDetailsDto> SaveAdminFeedbackDetails(AdminFeedbackDetailsDto adminFeedbackDetail)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveAdminFeedbackDetails Method ");
                var rating = new AdminFeedbackDetails
                {

                    FeedbackId = adminFeedbackDetail.FeedbackId,
                    InternshipId = adminFeedbackDetail.InternshipId,
                    StudentId = adminFeedbackDetail.StudentId,
                    Term = adminFeedbackDetail.Term,
                    EmployerId = adminFeedbackDetail.EmployerId,
                    SupervisorName = adminFeedbackDetail.SupervisorName,
                    SupervisorDesignation = adminFeedbackDetail.SupervisorDesignation,
                    SupervisorEmailId = adminFeedbackDetail.SupervisorEmailId,
                    ShortDescription = adminFeedbackDetail.ShortDescription,
                    Strength = adminFeedbackDetail.Strength,
                    DevelopmentAreas = adminFeedbackDetail.DevelopmentAreas,
                    Comments = adminFeedbackDetail.Comments,
                    CreatedBy = adminFeedbackDetail.CreatedBy,
                    Department = adminFeedbackDetail.Department,


                };
                if (adminFeedbackDetail.AdminFeedbackRatingModel != null)
                {
                    rating.AdminFeedbackRatingModel = adminFeedbackDetail.AdminFeedbackRatingModel.ToList();
                }

                var dataSaved = await this.internshipDataAccess.SaveAdminFeedbackDetails(rating);
                adminFeedbackDetail.FeedbackId = dataSaved.FeedbackId;
                this.Logger.LogInformation("Exiting from SaveAdminFeedbackDetails Method");
                return adminFeedbackDetail;
            }
            catch (Exception ex)
            {
                this.Logger.LogInformation("Error Occured in SaveAdminFeedbackDetails Method" + ex);
                throw ex;
            }
        }
        public async Task<IEnumerable<AdminFeedbackDetailsDto>> GetAdminFeedbackDetails(long InternshipId, long StudentId)
        {
            try
            {
                this.logger.LogInformation("Entering into GetPendingAdminFeedback Method");
                var studentsRecords = await this.internshipDataAccess.GetAdminFeedbackDetails(InternshipId, StudentId);
                if (studentsRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetAdminFeedbackDetails Method with" + studentsRecords.Count().ToString());
                    return studentsRecords.Select(students => new AdminFeedbackDetailsDto
                    {

                        InternshipId = students.InternshipId,
                        StudentId = students.StudentId,
                        CreatedDate = students.CreatedDate,
                        StudentName = students.StudentName,
                        UserId = students.UserId,
                        Email = students.Email,
                        StudentLocation = students.StudentLocation,
                        Institute = students.Institute,
                        MajorEn = students.MajorEn,
                        MajorAr = students.MajorAr,
                        InternshipRoleNameEn = students.InternshipRoleNameEn,
                        InternshipRoleNameAr = students.InternshipRoleNameAr,
                        MonthlySalaryRangeId = students.MonthlySalaryRangeId,
                        EmployerName = students.EmployerName,
                        Location = students.Location,
                        MinimumHoursRequiredId = students.MinimumHoursRequiredId,
                        Duration = students.Duration,
                        JoiningDate = students.JoiningDate,
                        CreatedBy = students.CreatedBy,
                        AdminFeedbackRatingModel = students.AdminFeedbackRatingModel,

                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetAdminFeedbackDetails Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetAdminFeedbackDetails Method" + ex);
                throw ex;
            }
        }
        public async Task<IEnumerable<AdminFeedbackDetailsDto>> GetFeedbackReceivedListforStudent(long StudentId)
        {
            try
            {
                this.logger.LogInformation("Entering into GetFeedbackReceivedListforStudent Method");
                var receivedlist = await this.internshipDataAccess.GetFeedbackReceivedListforStudent(StudentId);
                if (receivedlist != null)
                {
                    this.Logger.LogInformation("Exiting from GetFeedbackReceivedListforStudent Method with" + receivedlist.Count().ToString());
                    return receivedlist.Select(receivedlist => new AdminFeedbackDetailsDto
                    {
                        InternshipRoleNameEn = receivedlist.InternshipRoleNameEn,
                        InternshipRoleNameAr = receivedlist.InternshipRoleNameAr,
                        CreatedDate = receivedlist.CreatedDate,
                        CompanyNameEn = receivedlist.CompanyNameEn,
                        CompanyNameAr = receivedlist.CompanyNameAr,
                        Department = receivedlist.Department,
                        SupervisorDesignation = receivedlist.SupervisorDesignation,
                        InternshipId = receivedlist.InternshipId,
                        FeedbackId = receivedlist.FeedbackId,
                        StudentId = receivedlist.StudentId
                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetFeedbackReceivedListforStudent Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipDetailsService  at GetFeedbackReceivedListforStudent Method" + ex);
                throw ex;
            }
        }

        public async Task<IEnumerable<AdminFeedbackDetailsDto>> GetProvidedAdminFeedback(long InternshipId, string CreatedBy)
        {
            try
            {
                this.logger.LogInformation("Entering into GetProvidedAdminFeedback Method");
                var studentsRecords = await this.internshipDataAccess.GetProvidedAdminFeedback(InternshipId, CreatedBy);
                if (studentsRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetAdminFeedbackDetails Method with" + studentsRecords.Count().ToString());
                    return studentsRecords.Select(students => new AdminFeedbackDetailsDto
                    {

                        InternshipId = students.InternshipId,
                        StudentId = students.StudentId,
                        CreatedDate = students.CreatedDate,
                        StudentName = students.StudentName,
                        UserId = students.UserId,
                        Email = students.Email,
                        MobileNo = students.MobileNo,
                        CreatedBy = students.CreatedBy,
                        FeedbackId = students.FeedbackId


                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetProvidedAdminFeedback Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetProvidedAdminFeedback Method" + ex);
                throw ex;
            }
        }


        public async Task<AdminFeedbackDetailsDto> GetFeedbackDetailsAdmin(long InternshipId, long FeedbackId)
        {
            try
            {
                this.logger.LogInformation("Entering into GetFeedbackDetailsAdmin Method");
                var studentsRecords = await this.internshipDataAccess.GetFeedbackDetailsAdmin(InternshipId, FeedbackId);
                if (studentsRecords != null)
                {
                    return new AdminFeedbackDetailsDto
                    {
                        InternshipId = studentsRecords.InternshipId,
                        StudentId = studentsRecords.StudentId,
                        CreatedDate = studentsRecords.CreatedDate,
                        StudentName = studentsRecords.StudentName,
                        Email = studentsRecords.Email,
                        StudentLocation = studentsRecords.StudentLocation,
                        Institute = studentsRecords.Institute,
                        MajorEn = studentsRecords.MajorEn,
                        MajorAr = studentsRecords.MajorAr,
                        InternshipRoleNameEn = studentsRecords.InternshipRoleNameEn,
                        InternshipRoleNameAr = studentsRecords.InternshipRoleNameAr,
                        MonthlySalaryRangeId = studentsRecords.MonthlySalaryRangeId,
                        EmployerName = studentsRecords.EmployerName,
                        Location = studentsRecords.Location,
                        MinimumHoursRequiredId = studentsRecords.MinimumHoursRequiredId,
                        Duration = studentsRecords.Duration,
                        JoiningDate = studentsRecords.JoiningDate,
                        CreatedBy = studentsRecords.CreatedBy,
                        Term = studentsRecords.Term,
                        Department = studentsRecords.Department,
                        SupervisorName = studentsRecords.SupervisorName,
                        SupervisorEmailId = studentsRecords.SupervisorEmailId,
                        SupervisorDesignation = studentsRecords.SupervisorDesignation,
                        ShortDescription = studentsRecords.ShortDescription,
                        Strength = studentsRecords.Strength,
                        DevelopmentAreas = studentsRecords.DevelopmentAreas,
                        Comments = studentsRecords.Comments,
                        FeedbackId = studentsRecords.FeedbackId,
                        AdminFeedbackRatingModel = studentsRecords.AdminFeedbackRatingModel,

                    };
                }

                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetFeedbackDetailsAdmin Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetFeedbackDetailsAdmin Method" + ex);
                throw ex;
            }
        }

        public async Task<IEnumerable<AdminFeedbackDetailsDto>> GetStudentFeedbackListforHEI()
        {
            try
            {
                this.logger.LogInformation("Entering into GetStudentFeedbackListforHEI Method");
                var studentFeedback = await this.internshipDataAccess.GetStudentFeedbackListforHEI();
                if (studentFeedback != null)
                {
                    this.Logger.LogInformation("Exiting from GetRecruitmentDetailsGrid Method with" + studentFeedback.Count().ToString());
                    return studentFeedback.Select(feedback => new AdminFeedbackDetailsDto
                    {
                        CompanyNameEn = feedback.CompanyNameEn,
                        CompanyNameAr = feedback.CompanyNameAr,
                        Department = feedback.Department,
                        InternshipRoleNameEn = feedback.InternshipRoleNameEn,
                        InternshipRoleNameAr = feedback.InternshipRoleNameAr,
                        StudentName = feedback.StudentName,
                        Email = feedback.Email,
                        MobileNo = feedback.MobileNo,
                        InternshipId = feedback.InternshipId,
                        FeedbackId = feedback.FeedbackId,
                        StudentId = feedback.StudentId
                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetStudentFeedbackListforHEI Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipDetailsService  at GetStudentFeedbackListforHEI Method" + ex);
                throw ex;
            }
        }

        public async Task<IEnumerable<AdminFeedbackRatingModelDto>> GetRatingsAdmin(long FeedbackId)
        {
            try
            {
                this.logger.LogInformation("Entering into GetFeedbackDetailsAdmin Method");
                var studentsRecords = await this.internshipDataAccess.GetRatingsAdmin(FeedbackId);
                if (studentsRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetRatingsAdmin Method with" + studentsRecords.Count().ToString());
                    return studentsRecords.Select(students => new AdminFeedbackRatingModelDto
                    {


                        FeedbackId = students.FeedbackId,
                        ParameterId = students.ParameterId,
                        Rating = students.Rating,
                        IsApplicable = students.IsApplicable,
                        DropdownValueEn = students.DropdownValueEn,
                        DropdownValueAr = students.DropdownValueAr

                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetRatingsAdmin Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetRatingsAdmin Method" + ex);
                throw ex;
            }
        }

        public async Task<IEnumerable<StudentFeedbackDetailsDto>> GetAdminFeedbackReceivedList(long UserId)
        {
            try
            {
                this.logger.LogInformation("Entering into GetAdminFeedbackReceivedList Method");
                var feedbacklist = await this.internshipDataAccess.GetAdminFeedbackReceivedList(UserId);
                if (feedbacklist != null)
                {
                    this.Logger.LogInformation("Exiting from GetAdminFeedbackReceivedList Method with" + feedbacklist.Count().ToString());
                    return feedbacklist.Select(received => new StudentFeedbackDetailsDto
                    {
                        StudentFeedbackId = received.StudentFeedbackId,
                        InternshipId = received.InternshipId,
                        InternshipRoleNameEn = received.InternshipRoleNameEn,
                        InternshipRoleNameAr = received.InternshipRoleNameAr,
                        CreatedDate = received.CreatedDate,
                        StudentId = received.StudentId,
                        StudentName = received.StudentName,
                        Email = received.Email,
                        PhoneNumber = received.PhoneNumber
                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetAdminFeedbackReceivedList Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in InternshipDetailsService  at GetAdminFeedbackReceivedList Method" + ex);
                throw ex;
            }
        }

        public async Task<IEnumerable<StudentFeedbackDetailsDto>> GetCounselorFeedbackReceivedList()
        {
            try
            {
                this.logger.LogInformation("Entering into GetCounselorFeedbackReceivedList Method");
                var feedbacklist = await this.internshipDataAccess.GetCounselorFeedbackReceivedList();
                if (feedbacklist != null)
                {
                    this.Logger.LogInformation("Exiting from GetCounselorFeedbackReceivedList Method with" + feedbacklist.Count().ToString());
                    return feedbacklist.Select(received => new StudentFeedbackDetailsDto
                    {
                        StudentFeedbackId = received.StudentFeedbackId,
                        InternshipId = received.InternshipId,
                        CompanyNameEn = received.CompanyNameEn,
                        CompanyNameAr = received.CompanyNameAr,
                        Department = received.Department,
                        InternshipRoleNameEn = received.InternshipRoleNameEn,
                        InternshipRoleNameAr = received.InternshipRoleNameAr,
                        StudentId = received.StudentId,
                        StudentName = received.StudentName,
                        Email = received.Email,
                        PhoneNumber = received.PhoneNumber
                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetCounselorFeedbackReceivedList Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetCounselorFeedbackReceivedList  at GetCounselorFeedbackReceivedList Method" + ex);
                throw ex;
            }
        }

        public async Task<IEnumerable<StudentFeedbackDetailsDto>> GetMoeFeedbackReceivedList()
        {
            try
            {
                this.logger.LogInformation("Entering into GetMoeFeedbackReceivedList Method");
                var feedbacklist = await this.internshipDataAccess.GetMoeFeedbackReceivedList();
                if (feedbacklist != null)
                {
                    this.Logger.LogInformation("Exiting from GetMoeFeedbackReceivedList Method with" + feedbacklist.Count().ToString());
                    return feedbacklist.Select(received => new StudentFeedbackDetailsDto
                    {
                        StudentFeedbackId = received.StudentFeedbackId,
                        InternshipId = received.InternshipId,
                        CompanyNameEn = received.CompanyNameEn,
                        CompanyNameAr = received.CompanyNameAr,
                        Department = received.Department,
                        InternshipRoleNameEn = received.InternshipRoleNameEn,
                        InternshipRoleNameAr = received.InternshipRoleNameAr,
                        StudentId = received.StudentId,
                        StudentName = received.StudentName,
                        HEI = received.HEI
                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetMoeFeedbackReceivedList Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetMoeFeedbackReceivedList  at GetMoeFeedbackReceivedList Method" + ex);
                throw ex;
            }
        }

        public async Task<StudentFeedbackDetailsDto> SaveStudentFeedbackDetails(StudentFeedbackDetailsDto studentFeedbackDetail)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveAdminFeedbackDetails Method ");
                var rating = new StudentFeedbackDetails
                {

                    StudentFeedbackId = studentFeedbackDetail.StudentFeedbackId,
                    InternshipId = studentFeedbackDetail.InternshipId,
                    StudentId = studentFeedbackDetail.StudentId,
                    Term = studentFeedbackDetail.Term,
                    Department = studentFeedbackDetail.Department,
                    EmployerId = studentFeedbackDetail.EmployerId,
                    SupervisorName = studentFeedbackDetail.SupervisorName,
                    SupervisorDesignation = studentFeedbackDetail.SupervisorDesignation,
                    SupervisorEmailId = studentFeedbackDetail.SupervisorEmailId,
                    AnyFeedback = studentFeedbackDetail.AnyFeedback,
                    CreatedBy = studentFeedbackDetail.CreatedBy

                };
                if (studentFeedbackDetail.StudentFeedbackRatingModel != null)
                {
                    rating.StudentFeedbackRatingModel = studentFeedbackDetail.StudentFeedbackRatingModel.ToList();
                }

                var dataSaved = await this.internshipDataAccess.SaveStudentFeedbackDetails(rating);
                studentFeedbackDetail.StudentFeedbackId = dataSaved.StudentFeedbackId;
                this.Logger.LogInformation("Exiting from SaveAdminFeedbackDetails Method");
                return studentFeedbackDetail;
            }
            catch (Exception ex)
            {
                this.Logger.LogInformation("Error Occured in SaveAdminFeedbackDetails Method" + ex);
                throw ex;
            }
        }

        public async Task<IEnumerable<StudentFeedbackDetailsDto>> GetPendingStudentFeedback(long StudentId)
        {
            try
            {
                this.logger.LogInformation("Entering into GetPendingStudentFeedback Method");
                var studentsRecords = await this.internshipDataAccess.GetPendingStudentFeedback(StudentId);
                if (studentsRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetPendingAdminFeedback Method with" + studentsRecords.Count().ToString());
                    return studentsRecords.Select(students => new StudentFeedbackDetailsDto
                    {

                        InternshipId = students.InternshipId,
                        StudentId = students.StudentId,
                        CreatedDate = students.CreatedDate,
                        Duration = students.Duration,
                        CreatedBy = students.CreatedBy,
                        InternshipRoleNameEn = students.InternshipRoleNameEn,
                        InternshipRoleNameAr = students.InternshipRoleNameAr,
                        CompanyNameEn = students.CompanyNameEn,
                        CompanyNameAr = students.CompanyNameAr,
                        CompletionDate = students.CompletionDate,
                        CutOffDate = students.CutOffDate,
                        Department = students.Department,
                        SupervisorDesignation = students.SupervisorDesignation,

                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetPendingStudentFeedback Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetPendingStudentFeedback Method" + ex);
                throw ex;
            }
        }
        public async Task<IEnumerable<StudentFeedbackDetailsDto>> GetStudentFeedbackDetails(long InternshipId, long StudentId)
        {
            try
            {
                this.logger.LogInformation("Entering into GetStudemtFeedbackDetails Method");
                var studentsRecords = await this.internshipDataAccess.GetStudentFeedbackDetails(InternshipId, StudentId);
                if (studentsRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetStudemtFeedbackDetails Method with" + studentsRecords.Count().ToString());
                    return studentsRecords.Select(students => new StudentFeedbackDetailsDto
                    {

                        InternshipId = students.InternshipId,
                        StudentId = students.StudentId,
                        CreatedDate = students.CreatedDate,
                        StudentName = students.StudentName,
                        UserId = students.UserId,
                        Email = students.Email,
                        StudentLocation = students.StudentLocation,
                        Institute = students.Institute,
                        MajorEn = students.MajorEn,
                        MajorAr = students.MajorAr,
                        InternshipRoleNameEn = students.InternshipRoleNameEn,
                        InternshipRoleNameAr = students.InternshipRoleNameAr,
                        MonthlySalaryRangeId = students.MonthlySalaryRangeId,
                        EmployerName = students.EmployerName,
                        Location = students.Location,
                        MinimumHoursRequiredId = students.MinimumHoursRequiredId,
                        Duration = students.Duration,
                        JoiningDate = students.JoiningDate,
                        CreatedBy = students.CreatedBy,
                        StudentFeedbackRatingModel = students.StudentFeedbackRatingModel,

                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetStudemtFeedbackDetails Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetStudemtFeedbackDetails Method" + ex);
                throw ex;
            }
        }
        public async Task<IEnumerable<StudentFeedbackDetailsDto>> GetProvidedStudentFeedback(long StudentId, string CreatedBy)
        {
            try
            {
                this.logger.LogInformation("Entering into GetProvidedStudentFeedback Method");
                var studentsRecords = await this.internshipDataAccess.GetProvidedStudentFeedback(StudentId, CreatedBy);
                if (studentsRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetProvidedStudentFeedback Method with" + studentsRecords.Count().ToString());
                    return studentsRecords.Select(students => new StudentFeedbackDetailsDto
                    {

                        InternshipId = students.InternshipId,
                        StudentId = students.StudentId,
                        CreatedDate = students.CreatedDate,
                        Duration = students.Duration,
                        CreatedBy = students.CreatedBy,
                        InternshipRoleNameEn = students.InternshipRoleNameEn,
                        InternshipRoleNameAr = students.InternshipRoleNameAr,
                        CompanyNameEn = students.CompanyNameEn,
                        CompanyNameAr = students.CompanyNameAr,
                        CompletionDate = students.CompletionDate,
                        CutOffDate = students.CutOffDate,
                        Department = students.Department,
                        SupervisorDesignation = students.SupervisorDesignation,
                        StudentFeedbackId = students.StudentFeedbackId


                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetProvidedStudentFeedback Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetProvidedStudentFeedback Method" + ex);
                throw ex;
            }
        }

        public async Task<StudentFeedbackDetailsDto> GetFeedbackDetailsStudents(long StudentFeedbackId)
        {
            try
            {
                this.logger.LogInformation("Entering into GetFeedbackDetailsStudents Method");
                var studentsRecords = await this.internshipDataAccess.GetFeedbackDetailsStudents(StudentFeedbackId);
                if (studentsRecords != null)
                {
                    return new StudentFeedbackDetailsDto
                    {
                        InternshipId = studentsRecords.InternshipId,
                        StudentId = studentsRecords.StudentId,
                        CreatedDate = studentsRecords.CreatedDate,
                        StudentName = studentsRecords.StudentName,
                        //UserId = students.UserId,
                        Email = studentsRecords.Email,
                        StudentLocation = studentsRecords.StudentLocation,
                        Institute = studentsRecords.Institute,
                        MajorEn = studentsRecords.MajorEn,
                        MajorAr = studentsRecords.MajorAr,
                        InternshipRoleNameEn = studentsRecords.InternshipRoleNameEn,
                        InternshipRoleNameAr = studentsRecords.InternshipRoleNameAr,
                        MonthlySalaryRangeId = studentsRecords.MonthlySalaryRangeId,
                        EmployerName = studentsRecords.EmployerName,
                        Location = studentsRecords.Location,
                        MinimumHoursRequiredId = studentsRecords.MinimumHoursRequiredId,
                        Duration = studentsRecords.Duration,
                        JoiningDate = studentsRecords.JoiningDate,
                        CreatedBy = studentsRecords.CreatedBy,
                        Term = studentsRecords.Term,
                        Department = studentsRecords.Department,
                        SupervisorName = studentsRecords.SupervisorName,
                        SupervisorEmailId = studentsRecords.SupervisorEmailId,
                        SupervisorDesignation = studentsRecords.SupervisorDesignation,
                        AnyFeedback = studentsRecords.AnyFeedback,
                        StudentFeedbackId = studentsRecords.StudentFeedbackId,
                        StudentFeedbackRatingModel = studentsRecords.StudentFeedbackRatingModel,

                    };
                }

                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetFeedbackDetailsAdmin Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetFeedbackDetailsAdmin Method" + ex);
                throw ex;
            }
        }
        public async Task<MailTrackingDto> SaveMailDetails(MailTrackingDto mailDetails)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveMailDetails Method");
                var mail = new MailTracking
                {
                    Id = mailDetails.Id,
                    StudentId = mailDetails.StudentId,
                    InternshipId = mailDetails.InternshipId,
                    FromEmail = mailDetails.FromEmail,
                    ToEmail = mailDetails.ToEmail,
                    CcEmail = mailDetails.CcEmail,
                    EmailContent = mailDetails.EmailContent,
                    Subject = mailDetails.Subject,
                    Attachment = mailDetails.Attachment,
                    Status = mailDetails.Status,
                    CreatedBy = mailDetails.CreatedBy
                };
                var dataSaved = await this.internshipDataAccess.SaveMailDetails(mail);
                this.Logger.LogInformation("Exiting from SaveMailDetails Method");
                return mailDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogInformation("Error Occured in SaveMailDetails Method" + ex);
                throw ex;
            }
        }


    }
}






