﻿using SJP.Internships.Api.Model;
using SJP.Internships.Api.Model.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Internships.Api.Services
{
    public interface IInternshipService
    {
        Task<IEnumerable<InternshipDetailsDto>> GetInternshipDetails();
        Task<InternshipDetailsDto> GetInternshipDetails(long Id);
        Task<IEnumerable<InternshipDetailsDto>> GetInternshipDetailsGrid();
        Task<InternshipDetailsDto> SaveInternshipDetails(InternshipDetailsDto internshipDetail);
        Task<InternshipDetailsDto> UpdatedApprovalDetails(InternshipDetailsDto internshipDetail);
        Task<InternshipRoleMasterDto> SaveinternshipRoleMaster(InternshipRoleMasterDto internshipRoleMaster);
        Task<IEnumerable<InternshipRoleMasterDto>> GetInternshipRoleMaster();
        Task<bool> IsActive(long id);
        //Task<InternshipDetailsDto> UpdateTotalViews(InternshipDetailsDto viewsUpdate)
        Task<InternshipDetailsDto> GetInternshipDetailsUserviewById(long Id);
        Task<IEnumerable<InternshipDetailsDto>> GetUserInternshipDetailsList(int InternshipFor);
        Task<UserApplyDetailsDto> SaveApplyDetails(UserApplyDetailsDto applyDetails);
        Task<IEnumerable<InternshipDetailsDto>> GetRecruitmentDetailsGrid();
        Task<StudentDetailsDto> GetFlowChartDetails(long InternshipId);
        Task<IEnumerable<StudentDetailsDto>> GetDisagreedList();
        Task<IEnumerable<InternshipDetailsDto>> GetApplicationsList(long StudentId);
        Task<IEnumerable<InternshipDetailsDto>> GetAcceptedList(long StudentId);
        Task<IEnumerable<StudentDetailsDto>> GetCandidatesListGrid(long InternshipId);
        Task<IEnumerable<StudentDetailsDto>> GetAppliedList();
        Task<IEnumerable<StudentDetailsDto>> GetUpdateList(long InternshipId);
        Task<IEnumerable<StudentDetailsDto>> GetAcceptedCandidatesList(long InternshipId);
        Task<StudentDetailsDto> GetStudentDetails(long StudentId, long InternshipId);
        Task<UserApplyDetailsDto> UpdateStatusDetails(UserApplyDetailsDto statusUpdate);
        Task<IEnumerable<StatusModel>> UpdateStatusList(IEnumerable<StatusModel> statusUpdate);
        Task<UserApplyDetailsDto> UpdateDisagreeDetails(UserApplyDetailsDto disagreeUpdate);
        Task<IEnumerable<InternshipDetailsDto>> GetExpiryListGrid(long UserId);
        Task<IEnumerable<ExpiryModel>> UpdateExpiryList(IEnumerable<ExpiryModel> expiryUpdate);
        Task<IEnumerable<AdminFeedbackDetailsDto>> GetPendingAdminFeedback(long InternshipId);
        Task<AdminFeedbackDetailsDto> SaveAdminFeedbackDetails(AdminFeedbackDetailsDto adminFeedbackDetail);
        Task<IEnumerable<AdminFeedbackDetailsDto>> GetAdminFeedbackDetails(long InternshipId, long StudentId);
        Task<IEnumerable<AdminFeedbackDetailsDto>> GetFeedbackReceivedListforStudent(long StudentId);
        Task<IEnumerable<AdminFeedbackDetailsDto>> GetStudentFeedbackListforHEI();
        Task<AdminFeedbackDetailsDto> GetFeedbackDetailsAdmin(long InternshipId, long FeedbackId);
        Task<IEnumerable<AdminFeedbackDetailsDto>> GetProvidedAdminFeedback(long InternshipId, string CreatedBy);
        Task<IEnumerable<AdminFeedbackRatingModelDto>> GetRatingsAdmin(long FeedbackId);
        Task<IEnumerable<StudentFeedbackDetailsDto>> GetAdminFeedbackReceivedList(long UserId);
        Task<IEnumerable<StudentFeedbackDetailsDto>> GetCounselorFeedbackReceivedList();
        Task<IEnumerable<StudentFeedbackDetailsDto>> GetMoeFeedbackReceivedList();
        Task<StudentFeedbackDetailsDto> SaveStudentFeedbackDetails(StudentFeedbackDetailsDto studentFeedbackDetail);
        Task<IEnumerable<StudentFeedbackDetailsDto>> GetPendingStudentFeedback(long StudentId);
        Task<IEnumerable<StudentFeedbackDetailsDto>> GetStudentFeedbackDetails(long InternshipId, long StudentId);
        Task<IEnumerable<StudentFeedbackDetailsDto>> GetProvidedStudentFeedback(long StudentId, string CreatedBy);
        Task<StudentFeedbackDetailsDto> GetFeedbackDetailsStudents(long StudentFeedbackId);
        Task<MailTrackingDto> SaveMailDetails(MailTrackingDto mailDetails);
    }
}  