﻿using SJP.Internships.Api.Model.Dto;
using SJP.Internships.Api.Model.Report;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace SJP.Internships.Api.Services
{
    public interface IReportService
    {
        Task<IEnumerable<ReportModelDto>> GetStudentsReviewedbyInternship(InternshipsParams internshipsParam);
        Task<IEnumerable<ReportModelDto>> GetInternListingsSummary(InternshipsParams internshipsParam);
        Task<IEnumerable<ReportModelDto>> GetInternApplicationSummary(InternshipsParams internshipsParam);
        Task<IEnumerable<ReportModelDto>> GetInternshipPostStatistics(InternshipsParams internshipsParam);
        Task<IEnumerable<RatingReportModel>>GetInternshipModuleFeedback(InternshipsParams internshipsParam);
        Task<IEnumerable<ReportModelDto>> StudentsFeedback(InternshipsParams internshipsParam);
        Task<IEnumerable<ReportModelDto>> GetCompanyFeedbackOnStudents(InternshipsParams internshipsParam);
    }
}
