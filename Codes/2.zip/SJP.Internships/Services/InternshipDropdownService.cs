﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Core.Services;
using SJP.Internships.Api.DataAccess;
using SJP.Internships.Api.Model;
using SJP.Internships.Api.Model.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Internships.Api.Services
{
    public class InternshipDropdownService : ServiceBase, IInternshipDropdownService
    {
        private readonly IInternshipDropdownDataAccess InternshipDropdownDataAccess;

        private readonly ILogger logger;
        protected ILogger Logger => logger;
        public InternshipDropdownService(ILogger<InternshipDropdownService> logger, IInternshipDropdownDataAccess InternshipDropdownDataAccess, IConfiguration configuration) : base(configuration)
        {
            this.InternshipDropdownDataAccess = InternshipDropdownDataAccess;

            this.logger = logger;
        }
        public override void Dispose()
        {
            //  throw new NotImplementedException();
        }
        public async Task<IEnumerable<InternshipDropdownDetailsDto>> GetDropdownDetailsAsyn()
        {
            try
            {
                this.logger.LogInformation("Entering into GetDropdownDetailsAsyn Method");
                var internRecord = await this.InternshipDropdownDataAccess.GetDropdownDetailsAsyn();
                if (internRecord != null)
                {
                    this.Logger.LogInformation("Entering into GetDropdownDetailsAsyn Method" + internRecord.ToString());
                    return internRecord.Select(intern => new InternshipDropdownDetailsDto
                    {
                        DropdownId = intern.DropdownId,
                        DropdownValueEn = intern.DropdownValueEn,
                        DropdownValueAr = intern.DropdownValueAr,
                        Category = intern.Category,
                        IsActive = intern.IsActive,
                        ShortName = intern.ShortName,
                        StatusId=intern.StatusId
                    });
                }
                this.Logger.LogInformation("Exiting from GetDropdownDetailsAsyn Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetDropdownDetailsAsyn Method" + ex);
                throw ex;
            }
        }

        public async Task<IEnumerable<InternshipDetailsDto>> GetOrgDetailsAsyn()
        {
            try
            {
                this.logger.LogInformation("Entering into GetOrgDetailsAsyn Method");
                var orgRecord = await this.InternshipDropdownDataAccess.GetOrgDetailsAsyn();
                if (orgRecord != null)
                {
                    this.Logger.LogInformation("Entering into GetOrgDetailsAsyn Method" + orgRecord.ToString());
                    return orgRecord.Select(intern => new InternshipDetailsDto
                    {
                        Id = intern.Id,
                        CompanyNameEn = intern.CompanyNameEn,
                        CompanyNameAr = intern.CompanyNameAr
                    });
                }
                this.Logger.LogInformation("Exiting from GetOrgDetailsAsyn Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetOrgDetailsAsyn Method" + ex);
                throw ex;
            }
        }

        public async Task<List<MajorMasterDto>> GetMajorMasterAsyn()
        {
            List<MajorMasterDto> Major = new List<MajorMasterDto>();
            Major = await InternshipDropdownDataAccess.GetMajorMasterAsyn();
            return Major;
        }

        public async Task<IEnumerable<AdminUserDto>> GetAdminUserAsyn()
        {
            try
            {
                this.logger.LogInformation("Entering into GetAdminUserAsyn Method");
                var adminUser = await this.InternshipDropdownDataAccess.GetAdminUserAsyn();
                if (adminUser != null)
                {
                    this.Logger.LogInformation("Entering into GetDropdownDetailsAsyn Method" + adminUser.ToString());
                    return adminUser.Select(user => new AdminUserDto
                    {
                        Id = user.Id,
                        FirstName = user.FirstName,
                        LastName = user.LastName,
                        AccountType = user.AccountType,
                        CompanyNameEn=user.CompanyNameEn,
                        CompanyNameAr=user.CompanyNameAr
                        
                    });
                }
                this.Logger.LogInformation("Exiting from GetAdminUserAsyn Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetAdminUserAsyn Method" + ex);
                throw ex;
            }
        }

        public async Task<AdminUserDto> GetCompanyDetailsAsync(long Id)
        {
            try
            {
                var internRecord = await this.InternshipDropdownDataAccess.GetCompanyDetailsAsyn(Id);
                if (internRecord != null)
                {
                    this.Logger.LogInformation("Entering into GetInternshipDetails Method" + internRecord.ToString());
                    return new AdminUserDto
                    {
                        Id = internRecord.Id,
                        //FirstName=internRecord.FirstName,
                        //LastName=internRecord.LastName,
                        //AccountType=internRecord.AccountType,
                        CompanyNameEn = internRecord.CompanyNameEn,
                        //CompanyNameAr = internRecord.CompanyNameAr
                    };
                }
                this.Logger.LogInformation("Exiting from GetCompanyDetails Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetCompanyDetails Method" + ex);
                throw ex;
            }
        }
    }
}

