﻿using SJP.Internships.Api.Model.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Internships.Api.Services
{
    public interface IInternshipDropdownService
    {
        Task<IEnumerable<InternshipDropdownDetailsDto>> GetDropdownDetailsAsyn();
        Task<List<MajorMasterDto>> GetMajorMasterAsyn();
        Task<IEnumerable<AdminUserDto>> GetAdminUserAsyn();
        Task<IEnumerable<InternshipDetailsDto>> GetOrgDetailsAsyn();
        Task<AdminUserDto> GetCompanyDetailsAsync(long Id);
    }
}
