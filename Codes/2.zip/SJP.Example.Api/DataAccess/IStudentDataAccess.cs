﻿using SJP.Example.Api.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Example.Api.DataAccess
{
    public interface IStudentDataAccess
    {
        Task<IEnumerable<Student>> GetStudentsAsync();
        Task<Student> GetStudentAsync(int studentid);
        Task<Student> SaveStudentAsync(Student student);
        Task<bool> DeleteStudent(int studentid);
    }
}
