﻿using SJP.Example.Api.Model;
using SJP.Example.Api.Model.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.Example.Api.Services
{
   public interface IStudentService
    {
        Task<IEnumerable<StudentDto>> GetStudents();
        Task<StudentDto> GetStudent(int studentid);
        Task<StudentDto> SaveStudent(StudentDto student);
        Task<bool> DeleteStudent(int studentid);
    }
}
