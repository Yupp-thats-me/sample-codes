﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using SJP.Communication.Http;
using SJP.Core.Api.Extensions;
using SJP.CreditTransfer.Api.DataAccess;
using SJP.CreditTransfer.Api.Services;
using SJP.Logger.Extensions;


namespace SJP.CreditTransfer.Api.Extensions
{
    public static class Extension
    {
        public static IServiceCollection AddServices(this IServiceCollection services)
        {
            services.AddDatabaseLogger();
            services.AddDistributedMemCache();
            services.AddHttpCommunicator();
            services.AddScoped<ICreditTransferService, CreditTransferService>();
            services.AddScoped<ICreditDropdownService, CreditDropdownService>();
            services.AddScoped<ICreditTransferDataAccess, CreditTransferDataAccess>();
            services.AddScoped<ICreditDropdownDataAccess, CreditDropdownDataAccess>();
            return services;
        }
        public static IApplicationBuilder UseServices(this IApplicationBuilder app)
        {
            app.UseDatabaseLogger();
            return app;
        }
    }
}
