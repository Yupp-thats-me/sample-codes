﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.CreditTransfer.Api.Model;
using SJP.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using SJP.DataAccess.Extensions;
using SJP.CreditTransfer.Api.Model.Dto;
using static SJP.CreditTransfer.Api.Model.CreditTransferDetail;

namespace SJP.CreditTransfer.Api.DataAccess
{
    public class CreditTransferDataAccess : DataAccessBase, ICreditTransferDataAccess
    {
        private readonly ILogger logger;
        protected ILogger Logger => logger;
        public CreditTransferDataAccess(ILogger<CreditTransferDataAccess> logger, IConfiguration configuration) : base(configuration)
        {
            this.logger = logger;
        }

        public async Task<CreditTransferDetail> SaveCreditTransferDetailsAsync(CreditTransferDetail creditDetails)
        {
            try
            {
                this.logger.LogInformation("Entering into SaveCreditTransferDetailsAsync Method");
                var paramReferenceId = new SqlParameter("@ReferenceId", SqlDbType.BigInt) { Value = creditDetails.Id, Direction = ParameterDirection.Output };
                var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = creditDetails.Id };
                var paramFromHEI = new SqlParameter("@FromHEI", SqlDbType.Int) { Value = creditDetails.FromHEI };
                var paramToHEI = new SqlParameter("@ToHEI", SqlDbType.Int) { Value = creditDetails.ToHEI };
                var paramAcademicYear = new SqlParameter("@AcademicYear", SqlDbType.Int) { Value = creditDetails.AcademicYear };
                var paramDepartmentFrom = new SqlParameter("@DepartmentFromEn", SqlDbType.Int) { Value = creditDetails.DepartmentFromId };
                var paramDepartmentTo = new SqlParameter("@DepartmentToEn", SqlDbType.Int) { Value = creditDetails.DepartmentToId };
                var paramDepartmentFromAr = new SqlParameter("@DepartmentFromAr", SqlDbType.Int) { Value = creditDetails.ArDepartmentFromId };
                var paramDepartmentToAr = new SqlParameter("@DepartmentToAr", SqlDbType.Int) { Value = creditDetails.ArDepartmentToId };
                var paramMajorFrom= new SqlParameter("@MajorFromEn", SqlDbType.Int) { Value = creditDetails.MajorFromId };
                var paramMajorTo = new SqlParameter("@MajorToEn", SqlDbType.Int) { Value = creditDetails.MajorToId };
                var paramMajorFromAr = new SqlParameter("@MajorFromAr", SqlDbType.Int) { Value = creditDetails.ArMajorFromId };
                var paramMajorToAr = new SqlParameter("@MajorToAr", SqlDbType.Int) { Value = creditDetails.ArMajorToId };
                var paramExpiryDate = new SqlParameter("@ExpiryDate", SqlDbType.DateTime) { Value = creditDetails.ExpiryDate };
                var paramStatusId = new SqlParameter("@StatusId", SqlDbType.Int) { Value = creditDetails.StatusId };
                var paramOnBehalfOf = new SqlParameter("@OnBehalfOf", SqlDbType.Int) { Value = creditDetails.OnBehalfOf };
                var paramActive = new SqlParameter("@Active", SqlDbType.Bit) { Value = creditDetails.Active };
                var paramCreatedBy = new SqlParameter("@Created_By", SqlDbType.NVarChar) { Value = creditDetails.CreatedBy };
                var paramCreatedDate = new SqlParameter("@Created_Date", SqlDbType.DateTime) { Value = creditDetails.CreatedDate };
                var paramUploadFile = new SqlParameter("@UploadFile", SqlDbType.NVarChar) { Value = creditDetails.UploadFile };
                var paramUploadId = new SqlParameter("@UploadId", SqlDbType.BigInt) { Value = creditDetails.UploadId };
                var paramReason = new SqlParameter("@Reason", SqlDbType.NVarChar) { Value = creditDetails.Reason };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;

                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveCreditTransferDetails",
                            paramReferenceId,
                            paramId,
                            paramFromHEI,
                            paramToHEI,
                            paramAcademicYear,
                            paramDepartmentFrom,
                            paramDepartmentTo,
                            paramDepartmentFromAr,
                            paramDepartmentToAr,
                            paramMajorFrom,
                            paramMajorTo,
                            paramMajorFromAr,
                            paramMajorToAr,
                            paramExpiryDate,
                            paramStatusId,
                            paramOnBehalfOf,
                            paramActive,
                            paramCreatedBy,
                            paramCreatedDate,
                            paramUploadFile,
                            paramUploadId,
                            paramReason
                            ).ConfigureAwait(false);
                        transaction.Commit();

                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                    if(creditDetails.Id != 0)
                    {
                        await DeleteCourseDetails(creditDetails.Id);
                    }

                }

                creditDetails.Id = (long)paramReferenceId.Value;
                await SaveCourseDetailsAsync(creditDetails.Courses, creditDetails.Id); 
                this.Logger.LogInformation("Exiting from SaveCreditTransferDetailsAsync Method");
                return creditDetails;
            }

            catch (Exception Ex)
            {
                this.logger.LogError("Error Occured", "ERROR in SaveCreditTransferDetailsAsync Method : " + Ex.ToString());
                throw Ex;
            }
        }

        public async Task DeleteCreditDetailsAsync(long id, bool active)
        {
            try
            {
                this.logger.LogInformation("Entering into DeleteCreditDetailsAsync Method");
                var paramReferenceId = new SqlParameter("@ReferenceId", SqlDbType.BigInt) { Value =id };
                var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = id };
                var paramActive = new SqlParameter("@Active", SqlDbType.Bit) { Value = active };
           using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
            {
                SqlTransaction transaction = null;

                try
                {
                    transaction = connection.BeginTransaction();
                    await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveInActiveCreditTransfer",
                        paramReferenceId,
                        paramId,
                        paramActive
                        ).ConfigureAwait(false);
                    transaction.Commit();

                }
                catch
                {
                    if (transaction != null)
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
            return ;
        }

            catch (Exception Ex)
            {
                this.logger.LogError("Error Occured", "ERROR in SaveInActiveCreditTransfer Method : " + Ex.ToString());
                throw Ex;
            }
}

        public async Task<CreditApproval> SaveApprovalDetailsAsync(CreditApproval creditDetails)
        {
            try
            {
                this.logger.LogInformation("Entering into SaveCreditTransferDetailsAsync Method");
                var paramReferenceId = new SqlParameter("@ReferenceId", SqlDbType.BigInt) { Value = creditDetails.id, Direction = ParameterDirection.Output };
                var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = creditDetails.id };
                var paramStatusId = new SqlParameter("@StatusId", SqlDbType.Int) { Value = creditDetails.Status };
                var paramUpdatedBy = new SqlParameter("@UpdatedBy", SqlDbType.NVarChar) { Value = creditDetails.Updated };
                var paramReason = new SqlParameter("@Reason", SqlDbType.NVarChar) { Value = creditDetails.Reason };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;

                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveApprovalDetails",
                            paramReferenceId,
                            paramId,
                            paramStatusId,
                            paramUpdatedBy,
                            paramReason
                            ).ConfigureAwait(false);
                        transaction.Commit();

                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }                 
                }
                return creditDetails;
            }

            catch (Exception Ex)
            {
                this.logger.LogError("Error Occured", "ERROR in SaveCreditTransferDetailsAsync Method : " + Ex.ToString());
                throw Ex;
            }
        }

        public async Task <List<Course>> SaveCourseDetailsAsync(List<Course> CourseDetails, long id)
        {
            for (int i = 0; i < CourseDetails.Count; i++)
            {
                try
                {
                    this.logger.LogInformation("Entering into SaveCourseDetailsAsync Method");
                    var paramReferenceId = new SqlParameter("@ReferenceId", SqlDbType.BigInt) { Value = id, Direction = ParameterDirection.Output };
                    var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = 0 };
                    var paramCreditId = new SqlParameter("@CreditTransferId", SqlDbType.BigInt) { Value = id };
                    var paramCourseFromEn = new SqlParameter("@CourseFromEn", SqlDbType.NVarChar) { Value = CourseDetails[i].courseFromEn };
                    var paramCourseToEn = new SqlParameter("@CourseToEn", SqlDbType.NVarChar) { Value = CourseDetails[i].courseToEn };
                    var paramCourseFromAr = new SqlParameter("@CourseFromAr", SqlDbType.NVarChar) { Value = CourseDetails[i].courseFromAr };
                    var paramCourseToAr = new SqlParameter("@CourseToAr", SqlDbType.NVarChar) { Value = CourseDetails[i].courseToAr };
                    using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                    {
                        SqlTransaction transaction = null;

                        try
                        {
                            transaction = connection.BeginTransaction();
                            await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveCourseDetails",
                                paramReferenceId,
                                paramId,
                                paramCreditId,
                                paramCourseFromEn,
                                paramCourseToEn,
                                paramCourseFromAr,
                                paramCourseToAr
                                ).ConfigureAwait(false);
                            transaction.Commit();

                        }
                        catch(Exception e)
                        {
                            if (transaction != null)
                            {
                                transaction.Rollback();
                                throw;
                            }
                        }

                    }
                    CourseDetails[i].Id = (long)paramReferenceId.Value;

                }


                catch (Exception Ex)
                {
                    this.logger.LogError("Error Occured", "ERROR in SaveCreditTransferDetailsAsync Method : " + Ex.ToString());
                    throw Ex;
                }
               

            }
           
            this.Logger.LogInformation("Exiting from SaveCreditTransferDetailsAsync Method");
            return CourseDetails;
        }
        public async Task<IEnumerable<CreditTransferDetail>> GetCreditTransferDetailsAsync()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetCreditTransferDetailsAsync method");
                IList<CreditTransferDetail> creditDetails = new List<CreditTransferDetail>();

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetCreditTransferDetails").ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                creditDetails.Add(new CreditTransferDetail
                                {
                                    Id = reader.To<long>("Id"),
                                    FromHEI = reader.To<int>("FromHEI"),
                                    ToHEI = reader.To<int>("ToHEI"),
                                    AcademicYear = reader.To<int>("AcademicYear"),
                                    FromHEIName = reader.ToStringValue("FromHei"),
                                    ToHEIName = reader.ToStringValue("ToHei"),
                                    AcademicName = reader.ToStringValue("AcademicYears"),
                                    DepartmentFrom = reader.ToStringValue("DepartmentFromEns"),
                                    DepartmentTo = reader.ToStringValue("DepartmentToEns"),
                                    ArDepartmentFrom = reader.ToStringValue("DepartmentFromArs"),
                                    ArDepartmentTo = reader.ToStringValue("DepartmentToArs"),
                                    DepartmentFromId = reader.To<int>("DepartmentFromEn"),
                                    DepartmentToId = reader.To<int>("DepartmentToEn"),
                                    ArDepartmentFromId = reader.To<int>("DepartmentFromAr"),
                                    ArDepartmentToId = reader.To<int>("DepartmentToAr"),
                                    MajorFrom = reader.ToStringValue("MajorFromEns"),
                                    MajorTo = reader.ToStringValue("MajorToEns"),
                                    ArMajorFrom = reader.ToStringValue("MajorFromArs"),
                                    ArMajorTo = reader.ToStringValue("MajorToArs"),
                                    MajorFromId = reader.To<int>("MajorFromEn"),
                                    MajorToId = reader.To<int>("MajorToEn"),
                                    ArMajorFromId = reader.To<int>("MajorFromAr"),
                                    ArMajorToId =  reader.To<int>("MajorToAr"),
                                    ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                    OnBehalfOf = reader.To<int>("OnBehalfOf"),
                                    StatusId = reader.To<int>("StatusId"),
                                    UploadFile = reader.ToStringValue("UploadFile"),
                                    CreatedDate =  reader.To<DateTime>("CreatedOn"),
                                    UploadId = reader.To<long>("UploadId"),
                                    Reason = reader.ToStringValue("Reason"),
                                    Actives = reader.To<bool>("Active"),
                                    TotalViews= reader.To<long>("TotalViews")
                                }
                                );
                            }
                            for (int i = 0; i < creditDetails.Count; i++)
                            {
                                var course = await GetCourseDetailsAsync(creditDetails[i].Id);
                                creditDetails[i].Courses = course;
                            }
                        }
                    }

                }
               
                this.Logger.LogInformation("Exiting from GetCreditTransferDetailsAsync method");
                return creditDetails;


            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetCreditTransferDetailsAsync method : " + ex.ToString());
                throw ex;
            }

        }

        public async Task<CreditTransferDetail> GetCreditTransferDetailsAsyncStudent(FilterCreditDto credit)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetCreditTransferDetailsAsyncStudent method");
                var creditDetails = new CreditTransferDetail();
                var paramFromHEI = new SqlParameter("@FromHEI", SqlDbType.Int) { Value = credit.FromHEI };
                var paramToHEI = new SqlParameter("@ToHEI", SqlDbType.Int) { Value = credit.ToHEI};
                var paramAcademicYear = new SqlParameter("@AcademicYear", SqlDbType.Int) { Value = credit.AcademicYear};
                var paramDepartment = new SqlParameter("@Department", SqlDbType.NVarChar) { Value = credit.Department };
                var paramMajor = new SqlParameter("@Major", SqlDbType.NVarChar) { Value = credit.Major };
                var paramCourses = new SqlParameter("@Course", SqlDbType.NVarChar) { Value = credit.Course };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetCreditTransferDetailsStudent",paramFromHEI,paramToHEI,paramAcademicYear,paramDepartment,paramMajor).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                creditDetails = new CreditTransferDetail
                                {
                                    Id = reader.To<long>("Id"),
                                    FromHEI = reader.To<int>("FromHEI"),
                                    ToHEI = reader.To<int>("ToHEI"),
                                    AcademicYear = reader.To<int>("AcademicYear"),
                                    DepartmentFromId = reader.To<int>("DepartmentFromEn"),
                                    DepartmentToId = reader.To<int>("DepartmentToEn"),
                                    ArDepartmentFromId = reader.To<int>("DepartmentFromAr"),
                                    ArDepartmentToId = reader.To<int>("DepartmentToAr"),
                                    MajorFromId = reader.To<int>("MajorFromEn"),
                                    MajorToId = reader.To<int>("MajorToEn"),
                                    ArMajorFromId = reader.To<int>("MajorFromAr"),
                                    ArMajorToId = reader.To<int>("MajorToAr"),
                                    ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                    OnBehalfOf = reader.To<int>("OnBehalfOf"),
                                    StatusId = reader.To<int>("StatusId"),
                                    UploadFile = reader.ToStringValue("UploadFile"),
                                    CreatedDate = reader.To<DateTime>("CreatedOn"),
                                    UploadId = reader.To<long>("UploadId"),
                                    Reason = reader.ToStringValue("Reason"),
                                    Actives = reader.To<bool>("Active")
                                };
                         
                            }
                        }
                    }

                }
               
                    var courses = await GetCourseDetailsAsyncStudent(creditDetails.Id, credit.Course);
                    creditDetails.Courses = courses;
                
                this.Logger.LogInformation("Exiting from GetCreditTransferDetailsAsync method");
                return creditDetails;


            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetCreditTransferDetailsAsync method : " + ex.ToString());
                throw ex;
            }

        }
        public async Task<CreditTransferDetail> GetCreditTransferDetailsAsync(long Id)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetCreditTransferDetailsAsync for Id : " + Id.ToString());

                CreditTransferDetail creditDetails = null;
                var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = Id };


                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                                                connection,
                                                                CommandType.StoredProcedure,
                                                                "GetCreditTransferDetails",
                                                                paramId).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                creditDetails = new CreditTransferDetail
                                {
                                    Id = reader.To<long>("Id"),
                                    FromHEI = reader.To<int>("FromHEI"),
                                    ToHEI = reader.To<int>("ToHEI"),
                                    AcademicYear = reader.To<int>("AcademicYear"),
                                    FromHEIName = reader.ToStringValue("FromHei"),
                                    ToHEIName = reader.ToStringValue("ToHei"),
                                    AcademicName = reader.ToStringValue("AcademicYears"),
                                    DepartmentFrom = reader.ToStringValue("DepartmentFromEns"),
                                    DepartmentTo = reader.ToStringValue("DepartmentToEns"),
                                    ArDepartmentFrom = reader.ToStringValue("DepartmentFromArs"),
                                    ArDepartmentTo = reader.ToStringValue("DepartmentToArs"),
                                    DepartmentFromId = reader.To<int>("DepartmentFromEn"),
                                    DepartmentToId = reader.To<int>("DepartmentToEn"),
                                    ArDepartmentFromId = reader.To<int>("DepartmentFromAr"),
                                    ArDepartmentToId = reader.To<int>("DepartmentToAr"),
                                    MajorFrom = reader.ToStringValue("MajorFromEns"),
                                    MajorTo = reader.ToStringValue("MajorToEns"),
                                    ArMajorFrom = reader.ToStringValue("MajorFromArs"),
                                    ArMajorTo = reader.ToStringValue("MajorToArs"),
                                    MajorFromId = reader.To<int>("MajorFromEn"),
                                    MajorToId = reader.To<int>("MajorToEn"),
                                    ArMajorFromId = reader.To<int>("MajorFromAr"),
                                    ArMajorToId = reader.To<int>("MajorToAr"),
                                    ExpiryDate = reader.To<DateTime>("ExpiryDate"),
                                    OnBehalfOf = reader.To<int>("OnBehalfOf"),
                                    StatusId = reader.To<int>("StatusId"),
                                    UploadFile = reader.ToStringValue("UploadFile"),
                                    CreatedDate = reader.To<DateTime>("CreatedOn"),
                                    UploadId = reader.To<long>("UploadId"),
                                    Reason = reader.ToStringValue("Reason"),
                                    Actives = reader.To<bool>("Active")
                                };
                            }
                           

                        }
                    }


                }
                this.Logger.LogInformation("Exiting from GetCreditTransferDetailsAsync for Id : " + Id.ToString());
                 var course = await GetCourseDetailsAsync(Id);
                creditDetails.Courses = course;
                return creditDetails;

            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetCreditTransferDetailsAsync method :" + ex.ToString());
                throw ex;
            }

        }

        public async Task<List<Course>> GetCourseDetailsAsync(long id)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetCourseDetailsAsync for Id : " + id.ToString());

                var courseList = new List<Course>();



                var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = id };


                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                                                connection,
                                                                CommandType.StoredProcedure,
                                                                "GetCourseDetails",
                                                                paramId).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                var course = new Course();
                                course.courseid = reader.To<int>("Id");
                                course.creditId = reader.To<int>("CreditTransferId");
                                course.courseFromEn = reader.ToStringValue("CourseFromEn");
                                course.courseToEn = reader.ToStringValue("CourseToEn");
                                course.courseFromAr = reader.ToStringValue("CourseFromAr");
                                course.courseToAr = reader.ToStringValue("CourseToAr");
                                courseList.Add(course);

                            }
                        }
                    }


                }
                this.Logger.LogInformation("Exiting from GetCreditTransferDetailsAsync for Id : " + id.ToString());


                return courseList;


            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetCreditTransferDetailsAsync method :" + ex.ToString());
                throw ex;
            }

        }
        public async Task<List<Course>> GetAllCourseDetailsAsync()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetCourseDetailsAsync for Id : ");

                var courseList = new List<Course>();

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                                                connection,
                                                                CommandType.StoredProcedure,
                                                                "GetAllCoursesDetails"
                                                                ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                var course = new Course();
                                course.courseid = reader.To<int>("Id");
                                course.creditId = reader.To<int>("CreditTransferId");
                                course.courseFromEn = reader.ToStringValue("CourseFromEn");
                                course.courseToEn = reader.ToStringValue("CourseToEn");
                                course.courseFromAr = reader.ToStringValue("CourseFromAr");
                                course.courseToAr = reader.ToStringValue("CourseToAr");
                                courseList.Add(course);

                            }
                        }
                    }
                }

                return courseList;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetCreditTransferDetailsAsync method :" + ex.ToString());
                throw ex;
            }
        }
        public async Task<List<Course>> GetCourseDetailsAsyncStudent(long id, string credit)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetCourseDetailsAsync for Id : " + id.ToString());

                var courseList = new List<Course>();



                var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = id };
                var paramCourse = new SqlParameter("@Course", SqlDbType.VarChar) { Value = credit };

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                                                connection,
                                                                CommandType.StoredProcedure,
                                                                "GetCourseDetailsStudent",
                                                                paramId,paramCourse).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                var course = new Course();
                                course.courseid = reader.To<int>("Id");
                                course.creditId = reader.To<int>("CreditTransferId");
                                course.courseFromEn = reader.ToStringValue("CourseFromEn");
                                course.courseToEn = reader.ToStringValue("CourseToEn");
                                course.courseFromAr = reader.ToStringValue("CourseFromAr");
                                course.courseToAr = reader.ToStringValue("CourseToAr");
                                courseList.Add(course);

                            }
                        }
                    }


                }
                this.Logger.LogInformation("Exiting from GetCreditTransferDetailsAsync for Id : " + id.ToString());


                return courseList;


            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetCreditTransferDetailsAsync method :" + ex.ToString());
                throw ex;
            }

        }

        public async Task<bool> DeleteCourseDetails(long id)
        {
            try
            {
                this.Logger.LogInformation("Entering into DeleteCourseDetails Method");

                var paramcreditId = new SqlParameter("@CreditTransferId", SqlDbType.BigInt) { Value = id };

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "DeleteCourseDetails",
                            paramcreditId
                            ).ConfigureAwait(false);
                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from DeleteCourseDetails Method");
                return true;
            }

            catch (Exception Ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in DeleteCourseDetails Method :" + Ex.ToString());
                throw Ex;
            }
        }

        public async Task<IEnumerable<CreditTransferDetail>> GetViewCountStatistics(CreditTransferParam creditTransfer)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetViewCountStatistics method");
                IList<CreditTransferDetail> creditTransferDetails = new List<CreditTransferDetail>();
                var paramStartDate = new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = creditTransfer.StartDate };
                var paramEndDate = new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = creditTransfer.EndDate };
                var paramPostedBy = new SqlParameter("@PostedBy", SqlDbType.Int) { Value = creditTransfer.PostedBy, IsNullable = true };
                var ParamFromHei = new SqlParameter("@FromHei", SqlDbType.Int) { Value = creditTransfer.FromHei, IsNullable = true };
                var paramToHei = new SqlParameter("@ToHei", SqlDbType.Int) { Value = creditTransfer.ToHei, IsNullable = true };
                var paramAcademicYear = new SqlParameter("@AcademicYear", SqlDbType.Int) { Value = creditTransfer.AcademicYear, IsNullable = true };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetCreditViewCountStatistics", paramStartDate, paramEndDate, paramPostedBy, ParamFromHei, paramToHei, paramAcademicYear).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                creditTransferDetails.Add(new CreditTransferDetail
                                {
                                   // Id = reader.To<long>("Id"),
                                    CreatedBy = reader.ToStringValue("AdminName"),
                                    CreatedDate = reader.To<DateTime>("CreatedOn"),
                                    AcademicName = reader.ToStringValue("AcademicYear"),
                                    FromHEIName = reader.ToStringValue("FromHEI"),
                                    DepartmentFrom = reader.ToStringValue("FromDepartment"),
                                    MajorFrom = reader.ToStringValue("FromMajor"),
                                    FromCourses = reader.ToStringValue("FromCourses"),
                                    ToHEIName = reader.ToStringValue("ToHEI"),
                                    DepartmentTo = reader.ToStringValue("ToDepartment"),
                                    MajorTo = reader.ToStringValue("ToMajor"),
                                    ToCourses = reader.ToStringValue("ToCourses"),
                                    TotalViews = reader.To<long>("TotalViews"),
                                    TotalCount = reader.To<long>("TotalCOUNT"),
                                    HigestView=reader.To<long>("HighestView"),
                                    LeastView=reader.To<long>("LeastView"),
                                    





                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetViewCountStatistics method");
                return creditTransferDetails;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetViewCountStatistics method : " + ex.ToString());
                throw ex;
            }

        }

        public async Task<IEnumerable<CreditTransferDetail>> GetCreditListingStatistics(CreditTransferParam creditTransfer)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetCreditListingStatistics method");
                IList<CreditTransferDetail> CreditTransferDetail = new List<CreditTransferDetail>();
                var paramStartDate = new SqlParameter("@StartDate", SqlDbType.DateTime) { Value = creditTransfer.StartDate };
                var paramEndDate = new SqlParameter("@EndDate", SqlDbType.DateTime) { Value = creditTransfer.EndDate };
                var paramPostedBy = new SqlParameter("@PostedBy", SqlDbType.Int) { Value = creditTransfer.PostedBy, IsNullable = true };
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(connection, CommandType.StoredProcedure, "GetCreditListingStatistics", paramStartDate, paramEndDate, paramPostedBy).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                CreditTransferDetail.Add(new CreditTransferDetail
                                {
                                    //Id = reader.To<long>("Id"),
                                    CreatedBy = reader.ToStringValue("AdminName"),
                                    TotalCreditPosted = reader.To<long>("TotalCreditPosted"),
                                    TotalCreditPending = reader.To<long>("TotalCreditPending"),
                                    TotalCreditApproved = reader.To<long>("TotalCreditApproved"),
                                    TotalCreditRejected = reader.To<long>("TotalCreditRejected"),
                                    TotalMoePosted = reader.To<long>("TotalMoePosted"),
                                    TotalHEIPosted = reader.To<long>("TotalHEIPosted"),
                                    TotalHEIApproved = reader.To<long>("TotalHEIApproved"),
                                    TotalHEIRejected = reader.To<long>("TotalHEIRejected"),
                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetCreditListingStatistics method");
                return CreditTransferDetail;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetCreditListingStatistics method : " + ex.ToString());
                throw ex;
            }

        }

        public async Task<CreditTransferDetail> UpdateTotalViews(CreditTransferDetail viewsUpdate)
        {
            try
            {
                this.logger.LogInformation("Entering into UpdateTotalViews Method");
                var paramId = new SqlParameter("@Id", SqlDbType.BigInt) { Value = viewsUpdate.Id };
                var paramViews = new SqlParameter("@TotalViews", SqlDbType.BigInt) { Value = viewsUpdate.TotalViews };

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "UpdateTotalViews",
                            paramId,
                            paramViews
                            ).ConfigureAwait(false);
                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                this.logger.LogInformation("Exiting from UpdateTotalViews Method");
                return viewsUpdate;
            }
            catch (Exception ex)
            {
                this.logger.LogError("Error Occured", "ERROR in UpdateTotalViews Method : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<IEnumerable<CreditTransferDetail>> GetCreditReportCountDetails()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetCreditReportCountDetails");
                IList<CreditTransferDetail> count = new List<CreditTransferDetail>();

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                                connection,
                                                CommandType.StoredProcedure,
                                                "GetCreditReportCountDetails").ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                count.Add(new CreditTransferDetail
                                {
                                    PostedDate = reader.ToStringValue("PostedDate"),
                                    TotalCTInPortal = reader.To<long>("TotalCTInPortal"),
                                    TotalStudentsLoggedIn = reader.To<long>("TotalStudentsLoggedIn")
                                });

                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetCreditReportCountDetails");
                return count;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in GetCreditReportCountDetails method :" + ex.ToString());
                throw ex;
            }
        }

    }
}