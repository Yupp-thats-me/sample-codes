﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.CreditTransfer.Api.Model;
using SJP.DataAccess;
using SJP.DataAccess.Extensions;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace SJP.CreditTransfer.Api.DataAccess
{
    public class CreditDropdownDataAccess :  DataAccessBase, ICreditDropdownDataAccess
    {
        private readonly ILogger logger;
        protected ILogger Logger => logger;
        public CreditDropdownDataAccess(ILogger<CreditDropdownDataAccess> logger, IConfiguration configuration) : base(configuration)
        {
            this.logger = logger;
        }

        public async Task<IEnumerable<HeiMaster>> GetHighereducationInstAsync()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetHighereducationInstAsync Method");

                IList<HeiMaster> heiMasters = new List<HeiMaster>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                    connection,
                                    CommandType.StoredProcedure,
                                    "GetHigherEducationInstitute"
                                    ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                heiMasters.Add(new HeiMaster
                                {
                                    HeiId = reader.To<int>("HeiId"),
                                    HeiName = reader.ToStringValue("HeiName"),
                                    HeiNameAr = reader.ToStringValue("HeiNameAr")

                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetHighereducationInstAsync Method");
                return heiMasters;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occurred", "ERROR in GetHighereducationInstAsync : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<IEnumerable<Academic>> GetAcademicYear()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetAcademicYear Method");

                IList<Academic> academics = new List<Academic>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                    connection,
                                    CommandType.StoredProcedure,
                                    "GetAcademicYear"
                                    ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                academics.Add(new Academic
                                {
                                    AcademicId = reader.To<int>("AcademicId"),
                                    AcademicYear = reader.ToStringValue("AcademicYear")

                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetAcademicYear Method");
                return academics;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occurred", "ERROR in GetAcademicYear : " + ex.ToString());
                throw ex;
            }
        }

        public async Task<IEnumerable<Department>> GetDepartment()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetDepartment Method");

                IList<Department> department = new List<Department>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                    connection,
                                    CommandType.StoredProcedure,
                                    "GetDepartment"
                                    ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                department.Add(new Department
                                {
                                    DepartmentId = reader.To<int>("DepartmentId"),
                                    DepartmentNameEn = reader.ToStringValue("DepartmentNameEn"),
                                    DepartmentNameAr = reader.ToStringValue("DepartmentNameAr")

                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetDepartment Method");
                return department;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occurred", "ERROR in GetDepartment : " + ex.ToString());
                throw ex;
            }
        }
        public async Task<IEnumerable<Major>> GetMajor()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetMajor Method");

                IList<Major> major = new List<Major>();
                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    using (var reader = await ExecuteReaderAsync(
                                    connection,
                                    CommandType.StoredProcedure,
                                    "GetMajor"
                                    ).ConfigureAwait(false))
                    {
                        if (reader.HasRows)
                        {
                            while (await reader.ReadAsync().ConfigureAwait(false))
                            {
                                major.Add(new Major
                                {
                                    MajorId = reader.To<int>("MajorId"),
                                    MajorNameEn = reader.ToStringValue("MajorNameEn"),
                                    MajorNameAr = reader.ToStringValue("MajorNameAr")

                                });
                            }
                        }
                    }
                }
                this.Logger.LogInformation("Exiting from GetMajor Method");
                return major;
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Error Occurred", "ERROR in GetMajor : " + ex.ToString());
                throw ex;
            }
        }
        public async Task<Department> SaveDepartment(Department department)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveDepartment method");
                var paramReferenceId = new SqlParameter("@ReferenceId", SqlDbType.Int) { Value = department.DepartmentId, Direction = ParameterDirection.Output };
                var paramId = new SqlParameter("@DepartmentId", SqlDbType.Int) { Value = department.DepartmentId };
                var paramDepartEn = new SqlParameter("@DepartmentNameEn", SqlDbType.NVarChar) { Value = department.DepartmentNameEn };
                var paramDepartAr = new SqlParameter("@DepartmentNameAr", SqlDbType.NVarChar) { Value = department.DepartmentNameAr };

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveDepartment",
                            paramReferenceId,
                            paramId,
                            paramDepartEn,
                            paramDepartAr

                            ).ConfigureAwait(false);
                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }

                }
                department.DepartmentId = (int)paramReferenceId.Value;
                this.Logger.LogInformation("Exiting from SaveDepartment Method");
                return department;
            }

            catch (Exception Ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in SaveDepartment Method : " + Ex.ToString());
                throw Ex;
            }
        }
        public async Task<Major> SaveMajor(Major major)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveMajor method");

                var paramId = new SqlParameter("@MajorId", SqlDbType.Int) { Value = major.MajorId };
                var paramReferenceId = new SqlParameter("@ReferenceId", SqlDbType.Int) { Value = major.MajorId, Direction = ParameterDirection.Output };
                var paramMajorEn = new SqlParameter("@MajorNameEn", SqlDbType.NVarChar) { Value = major.MajorNameEn };
                var paramMajorAr = new SqlParameter("@MajorNameAr", SqlDbType.NVarChar) { Value = major.MajorNameAr };

                using (var connection = await OpenConnectionAsync().ConfigureAwait(false))
                {
                    SqlTransaction transaction = null;
                    try
                    {
                        transaction = connection.BeginTransaction();
                        await ExecuteNonQueryAsync(connection, transaction, CommandType.StoredProcedure, "SaveMajor",
                            paramId,
                            paramReferenceId,
                            paramMajorEn,
                            paramMajorAr

                            ).ConfigureAwait(false);
                        transaction.Commit();
                    }
                    catch
                    {
                        if (transaction != null)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }

                }
                major.MajorId = (int)paramReferenceId.Value;
                this.Logger.LogInformation("Exiting from SaveMajor Method");
                return major;
            }

            catch (Exception Ex)
            {
                this.Logger.LogError("Error Occured", "ERROR in SaveMajor Method : " + Ex.ToString());
                throw Ex;
            }
        }
    }
}
