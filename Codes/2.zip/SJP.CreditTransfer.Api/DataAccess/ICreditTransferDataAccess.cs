﻿using SJP.CreditTransfer.Api.Model;
using SJP.CreditTransfer.Api.Model.Dto;
using System.Collections.Generic;
using System.Threading.Tasks;
using static SJP.CreditTransfer.Api.Model.CreditTransferDetail;

namespace SJP.CreditTransfer.Api.DataAccess
{
    public interface ICreditTransferDataAccess
    {
        Task<CreditTransferDetail> SaveCreditTransferDetailsAsync(CreditTransferDetail creditDetails);
        Task<CreditApproval> SaveApprovalDetailsAsync(CreditApproval creditDetails);
        Task<IEnumerable<CreditTransferDetail>> GetCreditTransferDetailsAsync();
        Task<CreditTransferDetail> GetCreditTransferDetailsAsync(long Id);
        Task<CreditTransferDetail> GetCreditTransferDetailsAsyncStudent(FilterCreditDto credit);
        Task<List<Course>> GetAllCourseDetailsAsync();
        Task DeleteCreditDetailsAsync(long id, bool active);

        Task<IEnumerable<CreditTransferDetail>> GetViewCountStatistics(CreditTransferParam creditTransfer);

        Task<IEnumerable<CreditTransferDetail>> GetCreditListingStatistics(CreditTransferParam creditTransfer);

        Task<CreditTransferDetail> UpdateTotalViews(CreditTransferDetail viewsUpdate);

        Task<IEnumerable<CreditTransferDetail>> GetCreditReportCountDetails();
    }
}
