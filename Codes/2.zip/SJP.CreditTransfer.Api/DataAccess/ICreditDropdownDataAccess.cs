﻿using SJP.CreditTransfer.Api.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CreditTransfer.Api.DataAccess
{
    public interface ICreditDropdownDataAccess
    {
        Task<IEnumerable<HeiMaster>> GetHighereducationInstAsync();
        Task<IEnumerable<Academic>> GetAcademicYear();
        Task<IEnumerable<Department>> GetDepartment();
        Task<IEnumerable<Major>> GetMajor();
        Task<Major> SaveMajor(Major major);
        Task<Department> SaveDepartment(Department department);
    }
}
