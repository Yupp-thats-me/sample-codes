﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SJP.Core.Model;

namespace SJP.CreditTransfer.Api.Model
{
    public class HeiMaster: DomainObject
    {
        public int HeiId { get; set; }
        public string HeiName { get; set; }
        public string HeiNameAr { get; set; }
    }
}
