﻿using SJP.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CreditTransfer.Api.Model
{
    public class FilterCredit : DomainObject
    {
        public int FromHEI { get; set; }
        public int ToHEI { get; set; }
        public int AcademicYear { get; set; }
        public string Department { get; set; }
        public string Major { get; set; }
        public string Course { get; set; }
        
    }
}
