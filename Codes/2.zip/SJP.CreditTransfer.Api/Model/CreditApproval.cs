﻿using SJP.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CreditTransfer.Api.Model
{
    public class CreditApproval:DomainObject
    {
        public int id { get; set; }
        public int Status { get; set; }
        public string Updated { get; set; }
        public string Reason { get; set; }

    }
}
