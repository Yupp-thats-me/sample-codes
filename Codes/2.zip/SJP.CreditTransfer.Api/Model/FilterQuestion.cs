﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CreditTransfer.Api.Model
{
    public class FilterQuestion
    {
        public string? searchText { get; set; }
        public int? page { get; set; }
        public int? category { get; set; }
        public int pagesize { get; set; }
    }
}
