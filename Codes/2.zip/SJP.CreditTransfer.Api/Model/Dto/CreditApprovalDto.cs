﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CreditTransfer.Api.Model.Dto
{
    public class CreditApprovalDto
    {
        public int id { get; set; }
        public int Status { get; set; }
        public string Updated { get; set; }
        public string Reason { get; set; }
    }
}
