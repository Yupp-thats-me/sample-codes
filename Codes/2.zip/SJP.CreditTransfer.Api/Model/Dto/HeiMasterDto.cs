﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CreditTransfer.Api.Model.Dto
{
    public class HeiMasterDto
    {
        public int HeiId { get; set; }
        public string HeiName { get; set; }
        public string HeiNameAr { get; set; }
    }
}
