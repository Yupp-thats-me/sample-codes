﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CreditTransfer.Api.Model.Dto
{
    public class CreditTransferDto
    {
        public long Id { get; set; }
        public int FromHEI { get; set; }
        public int ToHEI { get; set; }
        public int AcademicYear { get; set; }
        public string AcademicName { get; set; }
        public string FromHEIName { get; set; }
        public string ToHEIName { get; set; }
        public long UploadId { get; set; }
        public string DepartmentFrom { get; set; }
        public string DepartmentTo { get; set; }
        public string ArDepartmentFrom { get; set; }
        public string ArDepartmentTo { get; set; }
        public string MajorFrom { get; set; }
        public string MajorTo { get; set; }
        public string ArMajorFrom { get; set; }
        public string ArMajorTo { get; set; }
        public int DepartmentFromId { get; set; }
        public int DepartmentToId { get; set; }
        public int ArDepartmentFromId { get; set; }
        public int ArDepartmentToId { get; set; }
        public int MajorFromId { get; set; }
        public int MajorToId { get; set; }
        public int ArMajorFromId { get; set; }
        public int ArMajorToId { get; set; }
        public bool IsFileDelete { get; set; }
        public string DeleteFilename { get; set; }
        public List<Course> Courses { get; set; }
        public DateTime ExpiryDate { get; set; }
        public string UploadFile { get; set; }
        public int StatusId { get; set; }
        public int OnBehalfOf { get; set; }
        public bool Active { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string Reason { get; set; }
        public string DocumentFiles { get; set; }

        public long TotalViews { get; set; }

        public long TotalCount { get; set; }
         
        public string FromCourses { get; set; }

        public string ToCourses { get; set; }

        public long TotalCreditPosted { get; set; }

        public long TotalCreditPending { get; set; }


        public long TotalCreditApproved { get; set; }

        public long TotalCreditRejected { get; set; }

        public long TotalCTInPortal { get; set; }
        public long TotalStudentsLoggedIn { get; set; }
        public long HigestView { get; set; }

        public long LeastView { get; set; }

        public long TotalMoePosted { get; set; }
        public long TotalHEIPosted { get; set; }
        public long TotalHEIApproved { get; set; }
        public long TotalHEIRejected { get; set; }





        public string PostedDate { get; set; }
 
    }

}
