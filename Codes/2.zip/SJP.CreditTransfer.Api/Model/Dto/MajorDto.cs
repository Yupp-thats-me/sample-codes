﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CreditTransfer.Api.Model.Dto
{
    public class MajorDto
    {
        public int MajorId { get; set; }
        public string MajorNameEn { get; set; }
        public string MajorNameAr { get; set; }
    }
}
