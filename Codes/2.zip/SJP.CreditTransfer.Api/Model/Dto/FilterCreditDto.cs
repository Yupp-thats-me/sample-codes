﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CreditTransfer.Api.Model.Dto
{
    public class FilterCreditDto
    {
        [FromQuery]
        public int FromHEI { get; set; }
        [FromQuery]
        public int ToHEI { get; set; }
        [FromQuery]
        public int AcademicYear { get; set; }
        [FromQuery]
        public string Department { get; set; }
        [FromQuery]
        public string Major { get; set; }
        [FromQuery]
        public string Course { get; set; }
    }
}
