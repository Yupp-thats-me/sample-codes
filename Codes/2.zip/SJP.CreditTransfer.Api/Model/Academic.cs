﻿using SJP.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CreditTransfer.Api.Model
{
    public class Academic : DomainObject
    {
        public int AcademicId { get; set; }
        public string AcademicYear { get; set; }
    }
}
