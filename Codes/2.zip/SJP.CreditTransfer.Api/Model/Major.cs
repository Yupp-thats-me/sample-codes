﻿using SJP.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CreditTransfer.Api.Model
{
    public class Major: DomainObject
    {
        public int MajorId { get; set; }
        public string MajorNameEn { get; set; }
        public string MajorNameAr { get; set; }
    }
}
