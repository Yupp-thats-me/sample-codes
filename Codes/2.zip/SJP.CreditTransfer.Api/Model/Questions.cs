﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CreditTransfer.Api.Model
{
    public class Questions
    {

        public Questions(int id, int catId, string question, string anwser)
        {
            Id = id;
            CategoryId = catId;
            Question = question;
            Answer = anwser;

        }

        public int Id { get; set; }
        public int CategoryId { get; set; }
        public string Question { get; set; }
        public string Answer { get; set; }

    }
}
