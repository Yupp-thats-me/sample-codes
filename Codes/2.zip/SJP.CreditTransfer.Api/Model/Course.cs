﻿using SJP.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CreditTransfer.Api.Model
{
    public class Course : DomainObject
    {
        public int courseid { get; set; }
        public int creditId { get; set; }
        public string courseFromEn { get; set; }
        public string courseToEn { get; set; }
        public string courseFromAr { get; set; }
        public string courseToAr { get; set; }

    }
}
