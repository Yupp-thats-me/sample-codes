﻿using SJP.CreditTransfer.Api.Model;
using SJP.CreditTransfer.Api.Model.Dto;
using System.Collections.Generic;
using System.Threading.Tasks;
using static SJP.CreditTransfer.Api.Model.CreditTransferDetail;

namespace SJP.CreditTransfer.Api.Services
{
    public interface ICreditTransferService
    {
        Task<CreditTransferDto> SaveCreditTransferDetails(CreditTransferDto credittransfer);
        Task<IEnumerable<CreditTransferDto>> GetCreditTransferDetails();
        Task<CreditTransferDto> GetCreditTransferDetails(long Id);
        Task<CreditTransferDto> GetCreditTransferDetailsStudent(FilterCreditDto credit);
        Task<IEnumerable<CourseDto>> GetAllCourses();
        Task<CreditTransferDetail> GetMajorandDepartment(CreditTransferDetail creditDto);
        Task DeleteCredit(long id, bool active);
        Task<CreditApprovalDto> SaveApprovalDetails(CreditApprovalDto credit);
       
        Task<IEnumerable<CreditTransferDto>> GetViewCountStatistics(CreditTransferParam creditTransfer);
        Task<IEnumerable<CreditTransferDto>> GetCreditListingStatistics(CreditTransferParam creditTransfer);
        Task<CreditTransferDto> UpdateTotalViews(CreditTransferDto viewsUpdate);
        Task<IEnumerable<CreditTransferDto>> GetCreditReportCountDetails();

    }
       
}
