﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Core.Services;
using SJP.CreditTransfer.Api.DataAccess;
using SJP.CreditTransfer.Api.Model;
using SJP.CreditTransfer.Api.Model.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CreditTransfer.Api.Services
{
    public class CreditDropdownService : ServiceBase, ICreditDropdownService
    {
        private readonly ICreditDropdownDataAccess creditDropdownDataAccess;

        private readonly ILogger logger;
        protected ILogger Logger => logger;

        public CreditDropdownService(ILogger<CreditDropdownService> logger, ICreditDropdownDataAccess creditDropdownDataAccess, IConfiguration configuration) : base(configuration)
        {
            this.creditDropdownDataAccess = creditDropdownDataAccess;
            this.logger = logger;
        }
        public async Task<IEnumerable<HeiMasterDto>> GetHighereducationInst()
        {
            try
            {
                this.logger.LogInformation("Loading GetHighereducationInst method ");
                var HighereducationInst = await this.creditDropdownDataAccess.GetHighereducationInstAsync();
                if (HighereducationInst != null)
                {
                    this.Logger.LogInformation("Exiting from GetHighereducationInst method with " + HighereducationInst.Count().ToString() + "Records");
                    return HighereducationInst.Select(highereducationinst => new HeiMasterDto
                    {
                        HeiId = highereducationinst.HeiId,
                        HeiName = highereducationinst.HeiName,
                        HeiNameAr = highereducationinst.HeiNameAr
                    });

                }
                this.Logger.LogInformation("Exiting from GetHighereducationInst method with 0 Records");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in DropdownDetailsService at GetHighereducationInst method" + ex);
                throw ex;
            }
        }

        public async Task<IEnumerable<AcademicDto>> GetAcademicYear()
        {
            try
            {
                this.logger.LogInformation("Loading GetAcademicYear method ");
                var academicYear = await this.creditDropdownDataAccess.GetAcademicYear();
                if (academicYear != null)
                {
                    this.Logger.LogInformation("Exiting from GetAcademicYear method with " + academicYear.Count().ToString() + "Records");
                    return academicYear.Select(academicYear => new AcademicDto
                    {
                        AcademicId = academicYear.AcademicId,
                        AcademicYear = academicYear.AcademicYear
                    });

                }
                this.Logger.LogInformation("Exiting from GetAcademicYear method with 0 Records");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in DropdownDetailsService at GetAcademicYear method" + ex);
                throw ex;
            }
        }
        public async Task<IEnumerable<DepartmentDto>> GetDepartment()
        {
            try
            {
                this.logger.LogInformation("Loading GetDepartment method ");
                var department = await this.creditDropdownDataAccess.GetDepartment();
                if (department != null)
                {
                    this.Logger.LogInformation("Exiting from GetDepartment method with " + department.Count().ToString() + "Records");
                    return department.Select(department => new DepartmentDto
                    {
                        DepartmentId = department.DepartmentId,
                        DepartmentNameEn = department.DepartmentNameEn,
                        DepartmentNameAr = department.DepartmentNameAr
                    });

                }
                this.Logger.LogInformation("Exiting from GetDepartment method with 0 Records");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in DropdownDetailsService at GetDepartment method" + ex);
                throw ex;
            }
        }
        public async Task<IEnumerable<MajorDto>> GetMajor()
        {
            try
            {
                this.logger.LogInformation("Loading GetMajor method ");
                var major = await this.creditDropdownDataAccess.GetMajor();
                if (major != null)
                {
                    this.Logger.LogInformation("Exiting from GetMajor method with " + major.Count().ToString() + "Records");
                    return major.Select(major => new MajorDto
                    {
                        MajorId = major.MajorId,
                       MajorNameEn = major.MajorNameEn,
                       MajorNameAr = major.MajorNameAr
                    });

                }
                this.Logger.LogInformation("Exiting from GetMajor method with 0 Records");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetMajor at GetDepartment method" + ex);
                throw ex;
            }
        }
        public async Task<Department> SaveDepartment(DepartmentDto depart)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveDepartment ");

                var saveMaster = new Department
                {
                    DepartmentId = depart.DepartmentId,
                    DepartmentNameEn = depart.DepartmentNameEn,
                    DepartmentNameAr = depart.DepartmentNameAr
                };

                var dataSaved = await this.creditDropdownDataAccess.SaveDepartment(saveMaster);
                this.Logger.LogInformation("Exiting from SaveSkillMaster Details");
                return dataSaved;

            }
            catch (Exception Ex)
            {
                this.Logger.LogInformation("Error Occured in SaveSkillMaster" + Ex);
                throw Ex;
            }
        }
        public async Task<Major> SaveMajor(MajorDto major)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveMajor");

                var saveMaster = new Major
                {
                    MajorId = major.MajorId,
                    MajorNameEn = major.MajorNameEn,
                    MajorNameAr = major.MajorNameAr
                };

                var dataSaved = await this.creditDropdownDataAccess.SaveMajor(saveMaster);
                this.Logger.LogInformation("Exiting from SaveMajor Details");
                return dataSaved;

            }
            catch (Exception Ex)
            {
                this.Logger.LogInformation("Error Occured in SaveMajor" + Ex);
                throw Ex;
            }
        }
        public override void Dispose()
        {
            //throw new NotImplementedException();
        }
    }
}
