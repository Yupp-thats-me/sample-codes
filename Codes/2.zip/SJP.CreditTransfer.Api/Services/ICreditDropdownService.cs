﻿using SJP.CreditTransfer.Api.Model;
using SJP.CreditTransfer.Api.Model.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SJP.CreditTransfer.Api.Services
{
    public interface ICreditDropdownService
    {
        Task<IEnumerable<HeiMasterDto>> GetHighereducationInst();
        Task<IEnumerable<AcademicDto>> GetAcademicYear();
        Task<IEnumerable<DepartmentDto>> GetDepartment();
        Task<IEnumerable<MajorDto>> GetMajor();
        Task<Major> SaveMajor(MajorDto major);
        Task<Department> SaveDepartment(DepartmentDto department);
    }
}
