﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Core.Services;
using SJP.CreditTransfer.Api.DataAccess;
using SJP.CreditTransfer.Api.Model;
using SJP.CreditTransfer.Api.Model.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static SJP.CreditTransfer.Api.Model.CreditTransferDetail;

namespace SJP.CreditTransfer.Api.Services
{
    public class CreditTransferService : ServiceBase, ICreditTransferService
    {
        private readonly ICreditTransferDataAccess credittransferDataAccess;

        private readonly ILogger logger;

        protected ILogger Logger => logger;
        private readonly ICreditDropdownService dropdownService;
        public CreditTransferService(ILogger<CreditTransferService> logger, ICreditTransferDataAccess credittransferDataAccess, ICreditDropdownService dropdownService, IConfiguration configuration) : base(configuration)
        {
            this.credittransferDataAccess = credittransferDataAccess;
            this.logger = logger;
            this.dropdownService = dropdownService;
        }
        public override void Dispose()
        {
            //throw new NotImplementedException();
        }

        public async Task<CreditTransferDto> SaveCreditTransferDetails(CreditTransferDto creditTransferDto)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveCreditTransferDetails Method");
                var saveCreditTransfer = new CreditTransferDetail
                {
                    Id = creditTransferDto.Id,
                    FromHEI = creditTransferDto.FromHEI,
                    ToHEI = creditTransferDto.ToHEI,
                    DepartmentFromId = creditTransferDto.DepartmentFromId,
                    DepartmentToId = creditTransferDto.DepartmentToId,
                    ArDepartmentFromId = creditTransferDto.ArDepartmentFromId,
                    ArDepartmentToId = creditTransferDto.ArDepartmentToId,
                    DepartmentFrom = creditTransferDto.DepartmentFrom,
                    DepartmentTo = creditTransferDto.DepartmentTo,
                    ArDepartmentFrom = creditTransferDto.ArDepartmentFrom,
                    ArDepartmentTo = creditTransferDto.ArDepartmentTo,
                    MajorFromId = creditTransferDto.MajorFromId,
                    MajorToId = creditTransferDto.MajorToId,
                    ArMajorFromId = creditTransferDto.ArMajorFromId,
                    ArMajorToId = creditTransferDto.ArMajorToId,
                    MajorFrom = creditTransferDto.MajorFrom,
                    MajorTo = creditTransferDto.MajorTo,
                    ArMajorFrom = creditTransferDto.ArMajorFrom,
                    ArMajorTo = creditTransferDto.ArMajorTo,
                    AcademicYear = creditTransferDto.AcademicYear,
                    Courses = creditTransferDto.Courses.ToList(),
                    ExpiryDate = creditTransferDto.ExpiryDate,
                    StatusId = creditTransferDto.StatusId,
                    OnBehalfOf = creditTransferDto.OnBehalfOf,
                    Active = creditTransferDto.Active,
                    CreatedBy = creditTransferDto.CreatedBy,
                    CreatedDate = DateTime.Now,
                    UploadFile = creditTransferDto.UploadFile,
                    UploadId = creditTransferDto.UploadId,
                    Reason = creditTransferDto.Reason
                };
                saveCreditTransfer = await GetMajorandDepartment(saveCreditTransfer);
                var save = await this.credittransferDataAccess.SaveCreditTransferDetailsAsync(saveCreditTransfer);
                creditTransferDto.Id = save.Id;
                this.Logger.LogInformation("Exiting from SaveCreditTransfer Details");
                return creditTransferDto;
            }
            catch (Exception Ex)
            {
                this.Logger.LogInformation("Error Occured in SaveCreditTransferDetailsAsync" + Ex);
                throw Ex;
            }
        }
        public async Task<CreditApprovalDto> SaveApprovalDetails(CreditApprovalDto credit)
        {
            try
            {
                this.Logger.LogInformation("Entering into SaveApprovalDetails Method");
                var saveApproval = new CreditApproval
                {
                    id = credit.id,
                    Status = credit.Status,
                    Updated = credit.Updated,
                    Reason = credit.Reason
                };
                var save = await this.credittransferDataAccess.SaveApprovalDetailsAsync(saveApproval);
                this.Logger.LogInformation("Exiting from SaveApprovalDetails Details");
                return credit;
            }
            catch (Exception Ex)
            {
                this.Logger.LogInformation("Error Occured in SaveApprovalDetails" + Ex);
                throw Ex;
            }
        }
        public async Task<IEnumerable<CreditTransferDto>> GetCreditTransferDetails()
        {
            try
            {
                this.logger.LogInformation("Loading GetCreditTransferDetails Method");
                var creditList = await this.credittransferDataAccess.GetCreditTransferDetailsAsync();
                if (creditList != null)
                {
                    this.Logger.LogInformation("Exiting from GetCreditTransferDetails Method with" + creditList.Count().ToString());
                    return creditList.Select(credit => new CreditTransferDto
                    {
                        Id = credit.Id,
                        FromHEI = credit.FromHEI,
                        ToHEI = credit.ToHEI,
                        FromHEIName = credit.FromHEIName,
                        ToHEIName = credit.ToHEIName,
                        DepartmentFromId = credit.DepartmentFromId,
                        DepartmentToId = credit.DepartmentToId,
                        ArDepartmentFromId = credit.ArDepartmentFromId,
                        ArDepartmentToId = credit.ArDepartmentToId,
                        DepartmentFrom =credit.DepartmentFrom,
                        DepartmentTo = credit.DepartmentTo,
                        ArDepartmentFrom = credit.ArDepartmentFrom,
                        ArDepartmentTo = credit.ArDepartmentTo,
                        MajorFrom = credit.MajorFrom,
                        MajorTo = credit.MajorTo,
                        ArMajorFrom = credit.ArMajorFrom,
                        ArMajorTo = credit.ArMajorTo,
                        MajorFromId = credit.MajorFromId,
                        MajorToId = credit.MajorToId,
                        ArMajorFromId = credit.ArMajorFromId,
                        ArMajorToId = credit.ArMajorToId,
                        AcademicYear = credit.AcademicYear,
                        AcademicName = credit.AcademicName,
                        Courses = credit.Courses,
                        ExpiryDate = credit.ExpiryDate,
                        StatusId = credit.StatusId,
                        OnBehalfOf = credit.OnBehalfOf,
                        Active = credit.Active,
                        CreatedBy = credit.CreatedBy,
                        CreatedDate = credit.CreatedDate,
                        UploadFile = credit.UploadFile,
                        UploadId = credit.UploadId,
                        Reason = credit.Reason,
                        TotalViews=credit.TotalViews

                    });
                }

                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetCreditTransferDetails Method with 0 records");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in CreditTransferServices at GetCreditTransferDetails Method" + Ex);
                throw Ex;
            }
        }

        public async Task<CreditTransferDto> GetCreditTransferDetailsStudent(FilterCreditDto credit)
        {
            try
            {
                this.logger.LogInformation("Loading GetCreditTransferDetails Method");
                var credittransferRecords = await this.credittransferDataAccess.GetCreditTransferDetailsAsyncStudent(credit);

                if (credittransferRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetCreditTransferDetailsStudent Method with" + credittransferRecords.ToString());
                    return new CreditTransferDto
                    {
                        Id = credittransferRecords.Id,
                        FromHEI = credittransferRecords.FromHEI,
                        ToHEI = credittransferRecords.ToHEI,
                        DepartmentFromId = credittransferRecords.DepartmentFromId,
                        DepartmentToId = credittransferRecords.DepartmentToId,
                        ArDepartmentFromId = credittransferRecords.ArDepartmentFromId,
                        ArDepartmentToId = credittransferRecords.ArDepartmentToId,
                        MajorFromId = credittransferRecords.MajorFromId,
                        MajorToId = credittransferRecords.MajorToId,
                        ArMajorFromId = credittransferRecords.ArMajorFromId,
                        ArMajorToId = credittransferRecords.ArMajorToId,
                        Courses = credittransferRecords.Courses,
                        UploadFile = credittransferRecords.UploadFile,
                        AcademicYear = credittransferRecords.AcademicYear,
                        ExpiryDate = credittransferRecords.ExpiryDate,
                        StatusId = credittransferRecords.StatusId,
                        OnBehalfOf = credittransferRecords.OnBehalfOf,
                        Active = credittransferRecords.Active,
                        CreatedBy = credittransferRecords.CreatedBy,
                        CreatedDate = credittransferRecords.CreatedDate,
                        Reason = credittransferRecords.Reason,
                        UploadId = credittransferRecords.UploadId

                    };
                }

                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetCreditTransferDetailsStudent Method with 0 records");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in CreditTransferServices at GetCreditTransferDetailsStudent Method" + Ex);
                throw Ex;
            }
        }
        public async Task<CreditTransferDto> GetCreditTransferDetails(long Id)
        {
            try
            {
                this.logger.LogInformation("Loading GetCreditTransferDetails Method for Id" + Id.ToString());
                var creditRecords = await this.credittransferDataAccess.GetCreditTransferDetailsAsync(Id);
      
                if (creditRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetCreditTransferDetails Method with" + creditRecords.ToString());
                    return new CreditTransferDto
                    {
                        Id = creditRecords.Id,
                        FromHEI = creditRecords.FromHEI,
                        ToHEI = creditRecords.ToHEI,
                        FromHEIName = creditRecords.FromHEIName,
                        ToHEIName = creditRecords.ToHEIName,
                        DepartmentFromId = creditRecords.DepartmentFromId,
                        DepartmentToId = creditRecords.DepartmentToId,
                        ArDepartmentFromId = creditRecords.ArDepartmentFromId,
                        ArDepartmentToId = creditRecords.ArDepartmentToId,
                        DepartmentFrom = creditRecords.DepartmentFrom,
                        DepartmentTo = creditRecords.DepartmentTo,
                        ArDepartmentFrom = creditRecords.ArDepartmentFrom,
                        ArDepartmentTo = creditRecords.ArDepartmentTo,
                        MajorFrom = creditRecords.MajorFrom,
                        MajorTo = creditRecords.MajorTo,
                        ArMajorFrom = creditRecords.ArMajorFrom,
                        ArMajorTo = creditRecords.ArMajorTo,
                        MajorFromId = creditRecords.MajorFromId,
                        MajorToId = creditRecords.MajorToId,
                        ArMajorFromId = creditRecords.ArMajorFromId,
                        ArMajorToId = creditRecords.ArMajorToId,
                        AcademicYear = creditRecords.AcademicYear,
                        AcademicName = creditRecords.AcademicName,
                        Courses = creditRecords.Courses,
                        UploadFile = creditRecords.UploadFile,
                        ExpiryDate = creditRecords.ExpiryDate,
                        StatusId = creditRecords.StatusId,
                        OnBehalfOf = creditRecords.OnBehalfOf,
                        Active = creditRecords.Active,
                        CreatedBy = creditRecords.CreatedBy,
                        CreatedDate = creditRecords.CreatedDate,
                        Reason = creditRecords.Reason,
                        UploadId = creditRecords.UploadId

                    };
                }

                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetCreditTransferDetails Method with 0 records for Id" + Id.ToString());
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError("Error Occured", "Error Occured in CreditTransferServices at GetCreditTransferDetails Method" + Ex);
                throw Ex;
            }
        }
        public async Task<IEnumerable<CourseDto>> GetAllCourses()
        {
            try
            {
                this.logger.LogInformation("Loading GetAllCourses Method for Id");
                var course = await this.credittransferDataAccess.GetAllCourseDetailsAsync();
                if (course != null)
                {
                    this.Logger.LogInformation("Exiting from GetAllCourses Method with");
                    return course.Select(credit => new CourseDto
                    {
                        courseid = credit.courseid,
                        creditId = credit.creditId,
                        courseFromEn = credit.courseFromEn,
                        courseToEn = credit.courseToEn,
                        courseFromAr = credit.courseFromAr,
                        courseToAr = credit.courseToAr
                    });
                   
                }

                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetAllCourses Method with 0 records for Id");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError("Error Occured", "Error Occured in CreditTransferServices at GetAllCourses Method" + Ex);
                throw Ex;
            }
        }
        public Task DeleteCredit(long id, bool active)
        {
            try
            {
                this.logger.LogInformation("Loading GetAllCourses Method for Id");
                var credit = credittransferDataAccess.DeleteCreditDetailsAsync(id, active);
                return credit;
            }
            catch(Exception Ex)
            {
                this.Logger.LogError("Error Occured", "Error Occured in CreditTransferServices at DeleteCredit Method" + Ex);
                throw Ex;
            }
         }
         public async Task<CreditTransferDetail> GetMajorandDepartment(CreditTransferDetail creditDto)
        {
            IEnumerable<DepartmentDto> depart = await dropdownService.GetDepartment();
            foreach (var value in depart)
            {
                if (value.DepartmentNameEn == creditDto.DepartmentFrom)
                {
                    creditDto.DepartmentFromId = value.DepartmentId;
                }
                if (value.DepartmentNameEn == creditDto.DepartmentTo)
                {
                    creditDto.DepartmentToId = value.DepartmentId;
                }
                if (value.DepartmentNameAr == creditDto.ArDepartmentFrom)
                {
                    creditDto.ArDepartmentFromId = value.DepartmentId;
                }
                if (value.DepartmentNameAr == creditDto.ArDepartmentTo)
                {
                    creditDto.ArDepartmentToId = value.DepartmentId;
                }
            }
            IEnumerable<MajorDto> major = await dropdownService.GetMajor();
            foreach (var majorVal in major)
            {
                if (majorVal.MajorNameEn == creditDto.MajorFrom)
                {
                    creditDto.MajorFromId = majorVal.MajorId;
                }
                if (majorVal.MajorNameEn == creditDto.MajorTo)
                {
                    creditDto.MajorToId = majorVal.MajorId;
                }
                if (majorVal.MajorNameAr == creditDto.ArMajorFrom)
                {
                    creditDto.ArMajorFromId = majorVal.MajorId;
                }
                if (majorVal.MajorNameAr == creditDto.ArMajorTo)
                {
                    creditDto.ArMajorToId = majorVal.MajorId;
                }
            }
            return creditDto;
        }

        public async Task<IEnumerable<CreditTransferDto>> GetViewCountStatistics(CreditTransferParam creditTransfer)
        {
            try
            {
                this.logger.LogInformation("Loading GetViewCountStatistics Method");
                var creditRecords = await this.credittransferDataAccess.GetViewCountStatistics(creditTransfer);

                if (creditRecords != null)
                {
                    this.Logger.LogInformation("Exiting from GetViewCountStatistics Method with" + creditRecords.Count().ToString());
                    return creditRecords.Select(creditRecords => new CreditTransferDto
                    {
                       // Id = creditRecords.Id,
                        CreatedBy = creditRecords.CreatedBy,
                        CreatedDate = creditRecords.CreatedDate,
                        AcademicName = creditRecords.AcademicName,
                        FromHEIName = creditRecords.FromHEIName,
                        DepartmentFrom = creditRecords.DepartmentFrom,
                        MajorFrom = creditRecords.MajorFrom,
                        FromCourses = creditRecords.FromCourses,
                        ToHEIName = creditRecords.ToHEIName,
                        DepartmentTo = creditRecords.DepartmentTo,
                        MajorTo = creditRecords.MajorTo,
                        ToCourses = creditRecords.ToCourses,
                        TotalViews = creditRecords.TotalViews,
                        TotalCount = creditRecords.TotalCount,
                        HigestView=creditRecords.HigestView,
                        LeastView=creditRecords.LeastView,
                        

                    });
                }

                this.Logger.LogInformation("Exiting from GetViewCountStatistics Method ");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in CreditServices at GetViewCountStatistics Method" + Ex);
                throw Ex;
            }
        }

        //Report 2 DataTable
        public async Task<IEnumerable<CreditTransferDto>> GetCreditListingStatistics(CreditTransferParam creditTransfer)
        {
            try
            {
                this.logger.LogInformation("Loading GetCreditListingStatistics Method");
                var creditTransfers = await this.credittransferDataAccess.GetCreditListingStatistics(creditTransfer);

                if (creditTransfers != null)
                {
                    this.Logger.LogInformation("Exiting from GetCreditListingStatistics Method with" + creditTransfers.Count().ToString());
                    return creditTransfers.Select(credit => new CreditTransferDto
                    {
                       // Id = credit.Id,
                        CreatedBy = credit.CreatedBy,
                        TotalCreditPosted = credit.TotalCreditPosted,
                        TotalCreditPending = credit.TotalCreditPending,
                        TotalCreditApproved = credit.TotalCreditApproved,
                        TotalCreditRejected = credit.TotalCreditRejected,
                        TotalMoePosted = credit.TotalMoePosted,
                        TotalHEIPosted = credit.TotalHEIPosted,
                        TotalHEIApproved = credit.TotalHEIApproved,
                        TotalHEIRejected = credit.TotalHEIRejected
                    });
                }

                this.Logger.LogInformation("Exiting from GetCreditListingStatistics Method ");
                return null;
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetCreditListingStatistics Method" + Ex);
                throw Ex;
            }
        }
        public async Task<CreditTransferDto> UpdateTotalViews(CreditTransferDto viewsUpdate)
        {
            try
            {
                this.Logger.LogInformation("Entering into UpdateTotalViews Method");
                var views = new CreditTransferDetail
                {
                    Id = viewsUpdate.Id,
                    TotalViews = viewsUpdate.TotalViews
                };
                var save = await this.credittransferDataAccess.UpdateTotalViews(views);
                viewsUpdate.Id = save.Id;
                this.Logger.LogInformation("Exiting from UpdateTotalViews");
                return viewsUpdate;
            }
            catch (Exception ex)
            {
                this.Logger.LogInformation("Error Occured in UpdateTotalViews" + ex);
                throw ex;
            }
        }

        public async Task<IEnumerable<CreditTransferDto>> GetCreditReportCountDetails()
        {
            try
            {
                var count = await this.credittransferDataAccess.GetCreditReportCountDetails();
                if (count != null)
                {
                    this.Logger.LogInformation("Entering into GetCreditpReportCountDetails Method");
                    return count.Select(count => new CreditTransferDto
                    {
                        PostedDate= count.PostedDate,
                        TotalCTInPortal = count.TotalCTInPortal,
                        TotalStudentsLoggedIn = count.TotalStudentsLoggedIn
                    });
                }
                this.Logger.LogInformation(new Exception("Error Occured"), "Exiting from GetCreditpReportCountDetails Method");
                return null;
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetCreditpReportCountDetails Method" + ex);
                throw ex;
            }
        }
    }
}