﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SJP.Communication.Http;
using SJP.Core.Api.Controllers;
using SJP.Core.Cache;
using SJP.Core.Composition;
using SJP.Core.Models;
using SJP.CreditTransfer.Api.Model;
using SJP.CreditTransfer.Api.Model.Dto;
using SJP.CreditTransfer.Api.Services;

namespace SJP.CreditTransfer.Api.Controllers.Areas.v1.CreditDropdown
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class CreditDropdownController : BaseApiController
    {


        private readonly ICreditDropdownService creditDropdownService;
        private readonly ICacheHelper cacheHelper;
        private readonly IHttpCommunicator httpCommunicator;


        public CreditDropdownController(ILogger<CreditDropdownController> logger, ICacheHelper cacheHelper,
              ICreditDropdownService creditDropdownService, IHttpCommunicator httpCommunicator) : base(logger)
        {
            this.creditDropdownService = creditDropdownService;
            this.httpCommunicator = httpCommunicator;
            this.cacheHelper = cacheHelper;
        }
        /// <summary>
        /// to fetch the  dropdown details
        /// </summary>
        /// <returns></returns>
        //Get creditdropdowns by ID
        [HttpGet("creditdropdowns")]
        public async Task<IActionResult> Getcreditdropdowns()
        {
            try
            {
                this.Logger.LogInformation("Loading Get credit dropdowns ");
                var institute = await this.creditDropdownService.GetHighereducationInst();
                var academic = await this.creditDropdownService.GetAcademicYear();
                var department = await this.creditDropdownService.GetDepartment();
                var major = await this.creditDropdownService.GetMajor();
                this.Logger.LogInformation("Exiting from credit dropdowns Info");
                return Success("", new { institute = institute, academic = academic, department = department, major = major });
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in Getcreditdropdowns Method" + Ex);
                return Error("Failed to Getcreditdropdowns Type ");
            }
        }
        /// <summary>
        /// to save the department details
        /// </summary>
        /// <param name="departCombo"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.ContentCreator, Role.HEI, Role.HEI)]
        [HttpPost("Department")]
        public async Task<IActionResult> SaveDepartment(DepartmentDto departCombo)
        {
            try
            {
                var id = await this.creditDropdownService.SaveDepartment(departCombo);
                return Success("Data Saved Successfully", id);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SaveDepartment Method" + Ex);
                return Error("Failed to SaveDepartment ");
            }
        }
        /// <summary>
        /// to save the major details
        /// </summary>
        /// <param name="majorCombo"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.ContentCreator, Role.HEI)]

        [HttpPost("Major")]
        public async Task<IActionResult> SaveMajor(MajorDto majorCombo)
        {
            try
            {
                var id = await this.creditDropdownService.SaveMajor(majorCombo);
                return Success("Data Saved Major", id);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in SaveMajor Method" + Ex);
                return Error("Failed to SaveMajor ");
            }
        }

    }
}
