﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using SJP.Communication.Http;
using SJP.Core.Api.Controllers;
using SJP.Core.Cache;
using SJP.Core.Composition;
using SJP.Core.Constants;
using SJP.Core.Models;
using SJP.Core.Utility;
using SJP.CreditTransfer.Api.Model;
using SJP.CreditTransfer.Api.Model.Dto;
using SJP.CreditTransfer.Api.Services;
using SJP.DataAccess.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static SJP.CreditTransfer.Api.Model.CreditTransferDetail;

namespace SJP.CreditTransfer.Api.Controllers.Areas.v1.CreditTransfer
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class CreditTransferController : BaseApiController
    {
        private readonly ICreditTransferService creditTransferServices;
        private readonly ICacheHelper cacheHelper;
        private readonly IConfiguration configuration;
        private readonly IHttpCommunicator httpCommunicator;
        private readonly IConfiguration Configuration;
        private readonly IFileUtility FileUtility;
        private readonly ICreditDropdownService dropdownService;

        private readonly string subDirectory = "credit-transfer";


        public CreditTransferController(ILogger<CreditTransferController> logger, ICacheHelper cacheHelper, IFileUtility FileUtility, ICreditTransferService creditTransferServices, IHttpCommunicator httpCommunicator, ICreditDropdownService dropdownService, IConfiguration _configuration) : base(logger)
        {
            this.creditTransferServices = creditTransferServices;
            this.cacheHelper = cacheHelper;
            this.configuration = _configuration;
            this.httpCommunicator = httpCommunicator;
            this.FileUtility = FileUtility;
            this.Configuration = _configuration;
            this.dropdownService = dropdownService;

        }
        /// <summary>
        /// to save the credittransfer details
        /// </summary>
        /// <param name="creditDto"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.ContentCreator, Role.HEI)]
        [HttpPost]
        public async Task<IActionResult> SaveCreditTransferDetails([FromForm] CreditTransferDto creditDto)
        {
            try
            {

                var files = HttpContext.Request.Form.Files;
                var file = files.Count > 0 ? HttpContext.Request.Form.Files[0] : null;
                if (file != null)
                {
                    creditDto.UploadFile = file.FileName;
                }
                var data = await this.creditTransferServices.SaveCreditTransferDetails(creditDto);
                this.FileUtility.Save(files, this.subDirectory, data.Id.ToString());
                return Success("Data Saved Successfully", data);
            }
            catch (DuplicateDataException e)
            {
                return Error("", ErrorCode.Duplicate);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception(), "Error Occured in Save CreditTransfer Details Medthod" + Ex);
                return Error("Failed to Save CreditTransfer Details");
            }
        }
        /// <summary>
        /// to fetch the  details of  credit transfered
        /// </summary>
        /// <returns></returns>

        [HttpGet]
        public async Task<IActionResult> GetCreditTransfer()
        {
            try
            {
                this.Logger.LogInformation("Loading CreditTransfer");
                var credit = await this.creditTransferServices.GetCreditTransferDetails();
                this.Logger.LogInformation("Exiting from CreditTransfer");
                return Success("Get CreditTransfer", credit);
            }

            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetCreditTransfer Method" + Ex);
                return Error("Failed to Get CreditTransfer Method ");
            }


        }
        /// <summary>
        /// to fetch the details of  credit transfered based on id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.ContentCreator, Role.HEI, Role.ContentApprover)]
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(long id)
        {
            try
            {
                this.Logger.LogInformation("Loading CreditTransfer Information for:" + id.ToString());

                var v = (await this.creditTransferServices.GetCreditTransferDetails(id));
                v.DocumentFiles = this.FileUtility.GetThumbnailBase64String(this.subDirectory, id.ToString(), v.UploadFile);

                this.Logger.LogInformation("Exiting from CreditTransfer");
                return Success("Get CreditTransfer", v);
            }

            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetCreditTransfer Method" + Ex);
                return Error("Failed to Get CreditTransfer Method ");
            }


        }
        /// <summary>
        /// to delete or remove the credittransfer records from the portal based on id
        /// </summary>
        /// <param name="id"></param>
        /// <param name="active"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.ContentCreator, Role.HEI)]
        [HttpPut("delete/{id}/{active}")]
        public async Task<IActionResult> DeleteRecords(long id, bool active)
        {
            try
            {
                if (id == 0)
                {
                    return BadRequest("Invalid  Details");
                }
                await this.creditTransferServices.DeleteCredit(id, active);
                return Success("Data Deleted Successfully", new { Id = id });
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in Update CreditTransfer Method" + Ex);
                return Error("Failed to Update CreditTransfer ");
            }

        }
        /// <summary>
        /// to save the details of approved credits
        /// </summary>
        /// <param name="credit"></param>
        /// <returns></returns>

        [AuthorizeByRole(Role.ContentApprover)]

        [HttpPost("approval")]
        public async Task<IActionResult> CreditApproval(CreditApprovalDto credit)
        {
            try
            {
                await this.creditTransferServices.SaveApprovalDetails(credit);
                return Success("Data Approve Successfully", new { Id = credit.id });
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in Approve CreditTransfer Method" + Ex);
                return Error("Failed to Approve CreditTransfer ");
            }

        }
        /// <summary>
        /// to fetch the details of the credit
        /// </summary>
        /// <param name="credit"></param>
        /// <returns></returns>

        [HttpGet("view")]
        public async Task<IActionResult> GetCreditTransfer([FromQuery] FilterCreditDto credit)
        {
            try
            {
                var v = (await this.creditTransferServices.GetCreditTransferDetailsStudent(credit));
                this.Logger.LogInformation("Exiting from CreditTransfer");
                return Success("Get CreditTransfer", v);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetCreditTransfer Method" + Ex);
                return Error("Failed to Get CreditTransfer Method");
            }
        }
        /// <summary>
        /// to download the credit
        /// </summary>
        /// <param name="file"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        [AuthorizeByRole(Role.Student, Role.General)]
        [Route("download-file/{file}/{id}")]
        [HttpGet]
        [Obsolete]
        public IActionResult Download(string file, int id)
        {

            try
            {
                var filepath = this.FileUtility.GetThumbnailBase64String(this.subDirectory, id.ToString(), file);

                return Success("", filepath);

            }
            catch (Exception)
            {
                return Error("");
            }

        }

        /// <summary>
        /// to fetch the course details
        /// </summary>
        /// <returns></returns>

        [HttpGet("courses")]
        public async Task<IActionResult> GetCourses()
        {
            try
            {
                this.Logger.LogInformation("Loading GetCourses");
                var insct = await this.creditTransferServices.GetAllCourses();
                this.Logger.LogInformation("Exiting from GetCourses Info");
                return Success("", new { insct = insct });
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetCourses Method" + Ex);
                return Error("Failed to GetCourses Type ");
            }
        }

        /// <summary>
        /// to fetch the employee details based on filter
        /// </summary>
        /// <param name="ques"></param>
        /// <returns></returns>
        [HttpGet("questions")]
        public async Task<IActionResult> GetAllEmployees([FromQuery] FilterQuestion ques)
        {
            ques.pagesize = 10;
            var serversize = 50;
            var list =  GetQuestions();
            List<Questions> filter = new List<Questions>();
            if(ques.searchText == "undefined")
            {
                ques.searchText = "";
            }
            for (int i = 0; i < list.Count; i++)
            {
                if(list[i].CategoryId == ques.category)
                {
                    filter.Add(list[i]);
                }
            }
            var query =  string.IsNullOrEmpty(ques.searchText) ? filter : filter.Where(e => e.Question.ToLower().Contains(ques.searchText.ToLower()) || e.Answer.ToLower().Contains(ques.searchText.ToLower()));
            
            int totalCount = query.Count();
            PageResult<Questions> result = new PageResult<Questions>
            {
                Count = totalCount,
                PageIndex = ques.page ?? 1,
                PageSize = ques.pagesize,
                Items = query.Skip((ques.page - 1 ?? 0) * ques.pagesize).Take(serversize).ToList()
            };
            return Ok(result);
        }
        /// <summary>
        /// to fetch the all questions received
        /// </summary>
        /// <returns></returns>
        public static List<Questions> GetQuestions()
        {
            return new List<Questions>
            {
                new Questions(1,1,"How to concentrate while studying1??","Get Focussed"),
                 new Questions(2,1,"How to concentrate while studying2??","Get Focussed"),
                  new Questions(3,1,"How to concentrate while studying3??","Get Focussed"),
                   new Questions(4,1,"How to concentrate while studying4??","Get Focussed"),
                  new Questions(5,1,"How to concentrate while studying5??","Get Focussed"),
                   new Questions(21,1,"How to concentrate while studying6??","Get Focussed"),
                 new Questions(22,1,"How to concentrate while studying7??","Get Focussed"),
                  new Questions(23,1,"How to concentrate while studying8??","Get Focussed"),
                   new Questions(24,1,"How to concentrate while studying9??","Get Focussed"),
                  new Questions(25,1,"How to concentrate while studying10??","Get Focussed"),
                  new Questions(1,1,"How to concentrate while studying11??","Get Focussed"),
                 new Questions(2,1,"How to concentrate while studying12??","Get Focussed"),
                  new Questions(3,1,"How to concentrate while studying13??","Get Focussed"),
                   new Questions(4,1,"How to concentrate while studying14??","Get Focussed"),
                  new Questions(5,1,"How to concentrate while studying15??","Get Focussed"),
                   new Questions(21,1,"How to concentrate while studying16??","Get Focussed"),
                 new Questions(22,1,"How to concentrate while studying17??","Get Focussed"),
                  new Questions(23,1,"How to concentrate while studying18??","Get Focussed"),
                   new Questions(24,1,"How to concentrate while studying19??","Get Focussed"),
                  new Questions(25,1,"How to concentrate while studying20??","Get Focussed"),
                   new Questions(1,1,"How to concentrate while studying21??","Get Focussed"),
                 new Questions(2,1,"How to concentrate while studying22??","Get Focussed"),
                  new Questions(3,1,"How to concentrate while studying23??","Get Focussed"),
                   new Questions(4,1,"How to concentrate while studying24??","Get Focussed"),
                  new Questions(5,1,"How to concentrate while studying25??","Get Focussed"),
                   new Questions(21,1,"How to concentrate while studying26??","Get Focussed"),
                 new Questions(22,1,"How to concentrate while studying27??","Get Focussed"),
                  new Questions(23,1,"How to concentrate while studying28??","Get Focussed"),
                   new Questions(24,1,"How to concentrate while studying29??","Get Focussed"),
                  new Questions(25,1,"How to concentrate while studying30??","Get Focussed"),
                   new Questions(1,1,"How to concentrate while studying31??","Get Focussed"),
                 new Questions(2,1,"How to concentrate while studying32??","Get Focussed"),
                  new Questions(3,1,"How to concentrate while studying33??","Get Focussed"),
                   new Questions(4,1,"How to concentrate while studying34??","Get Focussed"),
                  new Questions(5,1,"How to concentrate while studying35??","Get Focussed"),
                   new Questions(21,1,"How to concentrate while studying36??","Get Focussed"),
                 new Questions(22,1,"How to concentrate while studying37??","Get Focussed"),
                  new Questions(23,1,"How to concentrate while studying38??","Get Focussed"),
                   new Questions(24,1,"How to concentrate while studying39??","Get Focussed"),
                  new Questions(25,1,"How to concentrate while studying40??","Get Focussed"),
                    new Questions(1,1,"How to concentrate while studying41??","Get Focussed"),
                 new Questions(2,1,"How to concentrate while studying42??","Get Focussed"),
                  new Questions(3,1,"How to concentrate while studying43??","Get Focussed"),
                   new Questions(4,1,"How to concentrate while studying44??","Get Focussed"),
                  new Questions(5,1,"How to concentrate while studying45??","Get Focussed"),
                   new Questions(21,1,"How to concentrate while studying46??","Get Focussed"),
                 new Questions(22,1,"How to concentrate while studying47??","Get Focussed"),
                  new Questions(23,1,"How to concentrate while studying48??","Get Focussed"),
                   new Questions(24,1,"How to concentrate while studying49??","Get Focussed"),
                  new Questions(25,1,"How to concentrate while studying50??","Get Focussed"),
                   new Questions(1,1,"How to concentrate while studying51??","Get Focussed"),
                 new Questions(2,1,"How to concentrate while studying52??","Get Focussed"),
                  new Questions(3,1,"How to concentrate while studying53??","Get Focussed"),
                   new Questions(4,1,"How to concentrate while studying54??","Get Focussed"),
                  new Questions(5,1,"How to concentrate while studying55??","Get Focussed"),
                   new Questions(21,1,"How to concentrate while studying56??","Get Focussed"),
                 new Questions(22,1,"How to concentrate while studying57??","Get Focussed"),
                  new Questions(23,1,"How to concentrate while studying58??","Get Focussed"),
                   new Questions(24,1,"How to concentrate while studying59??","Get Focussed"),
                  new Questions(25,1,"How to concentrate while studying60??","Get Focussed"),
                   new Questions(1,1,"How to concentrate while studying61??","Get Focussed"),
                 new Questions(2,1,"How to concentrate while studying62??","Get Focussed"),
                  new Questions(3,1,"How to concentrate while studying63??","Get Focussed"),
                   new Questions(4,1,"How to concentrate while studying64??","Get Focussed"),
                  new Questions(5,1,"How to concentrate while studying65??","Get Focussed"),
                   new Questions(21,1,"How to concentrate while studying66??","Get Focussed"),
                 new Questions(22,1,"How to concentrate while studying67??","Get Focussed"),
                  new Questions(23,1,"How to concentrate while studying68??","Get Focussed"),
                   new Questions(24,1,"How to concentrate while studying69??","Get Focussed"),
                  new Questions(25,1,"How to concentrate while studying70??","Get Focussed"),
                  new Questions(1,1,"How to concentrate while studying71??","Get Focussed"),
                 new Questions(2,1,"How to concentrate while studying72??","Get Focussed"),
                  new Questions(3,1,"How to concentrate while studying73??","Get Focussed"),
                   new Questions(4,1,"How to concentrate while studying74??","Get Focussed"),
                  new Questions(5,1,"How to concentrate while studying75??","Get Focussed"),
                   new Questions(21,1,"How to concentrate while studying76??","Get Focussed"),
                 new Questions(22,1,"How to concentrate while studying77??","Get Focussed"),
                  new Questions(23,1,"How to concentrate while studying78??","Get Focussed"),
                   new Questions(24,1,"How to concentrate while studying79??","Get Focussed"),
                  new Questions(25,1,"How to concentrate while studying80??","Get Focussed"),
                  new Questions(1,1,"How to concentrate while studying81??","Get Focussed"),
                 new Questions(2,1,"How to concentrate while studying82??","Get Focussed"),
                  new Questions(3,1,"How to concentrate while studying83??","Get Focussed"),
                   new Questions(4,1,"How to concentrate while studying84??","Get Focussed"),
                  new Questions(5,1,"How to concentrate while studying85??","Get Focussed"),
                   new Questions(21,1,"How to concentrate while studying86??","Get Focussed"),
                 new Questions(22,1,"How to concentrate while studying87??","Get Focussed"),
                  new Questions(23,1,"How to concentrate while studying88??","Get Focussed"),
                   new Questions(24,1,"How to concentrate while studying89??","Get Focussed"),
                  new Questions(25,1,"How to concentrate while studying90??","Get Focussed"),
                  new Questions(1,1,"How to concentrate while studying91??","Get Focussed"),
                 new Questions(2,1,"How to concentrate while studying92??","Get Focussed"),
                  new Questions(3,1,"How to concentrate while studying93??","Get Focussed"),
                   new Questions(4,1,"How to concentrate while studying94??","Get Focussed"),
                  new Questions(5,1,"How to concentrate while studying95??","Get Focussed"),
                   new Questions(21,1,"How to concentrate while studying96??","Get Focussed"),
                 new Questions(22,1,"How to concentrate while studying97??","Get Focussed"),
                  new Questions(23,1,"How to concentrate while studying98??","Get Focussed"),
                   new Questions(24,1,"How to concentrate while studying99??","Get Focussed"),
                  new Questions(25,1,"How to concentrate while studying100??","Get Focussed"),

                   new Questions(1,1,"How to concentrate while studying101??","Get Focussed"),
                 new Questions(2,1,"How to concentrate while studying102??","Get Focussed"),
                  new Questions(3,1,"How to concentrate while studying103??","Get Focussed"),
                   new Questions(4,1,"How to concentrate while studying104??","Get Focussed"),
                  new Questions(5,1,"How to concentrate while studying105??","Get Focussed"),
                   new Questions(21,1,"How to concentrate while studying106??","Get Focussed"),
                 new Questions(22,1,"How to concentrate while studying107??","Get Focussed"),
                  new Questions(23,1,"How to concentrate while studying108??","Get Focussed"),
                   new Questions(24,1,"How to concentrate while studying109??","Get Focussed"),
                  new Questions(25,1,"How to concentrate while studying110??","Get Focussed"),
                   new Questions(1,1,"How to concentrate while studying111??","Get Focussed"),
                 new Questions(2,1,"How to concentrate while studying112??","Get Focussed"),
                  new Questions(3,1,"How to concentrate while studying113??","Get Focussed"),
                   new Questions(4,1,"How to concentrate while studying114??","Get Focussed"),
                  new Questions(5,1,"How to concentrate while studying115??","Get Focussed"),
                   new Questions(21,1,"How to concentrate while studying116??","Get Focussed"),
                 new Questions(22,1,"How to concentrate while studying117??","Get Focussed"),
                  new Questions(23,1,"How to concentrate while studying118??","Get Focussed"),
                   new Questions(24,1,"How to concentrate while studying119??","Get Focussed"),
                  new Questions(25,1,"How to concentrate while studying120??","Get Focussed"),
                  new Questions(1,1,"How to concentrate while studying121??","Get Focussed"),
                 new Questions(2,1,"How to concentrate while studying122??","Get Focussed"),
                  new Questions(3,1,"How to concentrate while studying123??","Get Focussed"),
                   new Questions(4,1,"How to concentrate while studying124??","Get Focussed"),
                  new Questions(5,1,"How to concentrate while studying125??","Get Focussed"),
                   new Questions(21,1,"How to concentrate while studying126??","Get Focussed"),
                 new Questions(22,1,"How to concentrate while studying127??","Get Focussed"),
                  new Questions(23,1,"How to concentrate while studying128??","Get Focussed"),
                   new Questions(24,1,"How to concentrate while studying129??","Get Focussed"),
                  new Questions(25,1,"How to concentrate while studying130??","Get Focussed"),
                  new Questions(1,1,"How to concentrate while studying131??","Get Focussed"),
                 new Questions(2,1,"How to concentrate while studying132??","Get Focussed"),
                  new Questions(3,1,"How to concentrate while studying133??","Get Focussed"),
                   new Questions(4,1,"How to concentrate while studying134??","Get Focussed"),
                  new Questions(5,1,"How to concentrate while studying135??","Get Focussed"),
                   new Questions(21,1,"How to concentrate while studying136??","Get Focussed"),
                 new Questions(22,1,"How to concentrate while studying137??","Get Focussed"),
                  new Questions(23,1,"How to concentrate while studying138??","Get Focussed"),
                   new Questions(24,1,"How to concentrate while studying139??","Get Focussed"),
                  new Questions(25,1,"How to concentrate while studying140??","Get Focussed"),
                  new Questions(1,1,"How to concentrate while studying141??","Get Focussed"),
                 new Questions(2,1,"How to concentrate while studying142??","Get Focussed"),
                  new Questions(3,1,"How to concentrate while studying143??","Get Focussed"),
                   new Questions(4,1,"How to concentrate while studying144??","Get Focussed"),
                  new Questions(5,1,"How to concentrate while studying145??","Get Focussed"),
                   new Questions(21,1,"How to concentrate while studying146??","Get Focussed"),
                 new Questions(22,1,"How to concentrate while studying147??","Get Focussed"),
                  new Questions(23,1,"How to concentrate while studying148??","Get Focussed"),
                   new Questions(24,1,"How to concentrate while studying149??","Get Focussed"),
                  new Questions(25,1,"How to concentrate while studying150??","Get Focussed"),


                   new Questions(6,2,"How to keep timemanagement1???","Get Focussed"),
                 new Questions(7,2,"How to keep timemanagement2???","Get Focussed"),
                  new Questions(8,2,"How to keep timemanagement3???","Get Focussed"),
                   new Questions(9,2,"How to keep timemanagement4???","Get Focussed"),
                  new Questions(10,2,"How to keep timemanagement5???","Get Focussed"),
                   new Questions(26,2,"How to keep timemanagement6???","Get Focussed"),
                 new Questions(27,2,"How to keep timemanagement7???","Get Focussed"),
                  new Questions(28,2,"How to keep timemanagement8???","Get Focussed"),
                   new Questions(29,2,"How to keep timemanagement9???","Get Focussed"),
                  new Questions(30,2,"How to keep timemanagement10???","Get Focussed"),

                  new Questions(6,2,"How to keep timemanagement11???","Get Focussed"),
                 new Questions(7,2,"How to keep timemanagement12???","Get Focussed"),
                  new Questions(8,2,"How to keep timemanagement13???","Get Focussed"),
                   new Questions(9,2,"How to keep timemanagement14???","Get Focussed"),
                  new Questions(10,2,"How to keep timemanagement15???","Get Focussed"),
                   new Questions(26,2,"How to keep timemanagement16???","Get Focussed"),
                 new Questions(27,2,"How to keep timemanagement17???","Get Focussed"),
                  new Questions(28,2,"How to keep timemanagement18???","Get Focussed"),
                   new Questions(29,2,"How to keep timemanagement19???","Get Focussed"),
                  new Questions(30,2,"How to keep timemanagement20???","Get Focussed"),
                  new Questions(6,2,"How to keep timemanagement21???","Get Focussed"),
                 new Questions(7,2,"How to keep timemanagement22???","Get Focussed"),
                  new Questions(8,2,"How to keep timemanagement23???","Get Focussed"),
                   new Questions(9,2,"How to keep timemanagement24???","Get Focussed"),
                  new Questions(10,2,"How to keep timemanagement25???","Get Focussed"),
                   new Questions(26,2,"How to keep timemanagement26???","Get Focussed"),
                 new Questions(27,2,"How to keep timemanagement27???","Get Focussed"),
                  new Questions(28,2,"How to keep timemanagement28???","Get Focussed"),
                   new Questions(29,2,"How to keep timemanagement29???","Get Focussed"),
                  new Questions(30,2,"How to keep timemanagement30???","Get Focussed"),

                   new Questions(11,3,"How to gain Knowledge1???","Get Focussed"),
                 new Questions(12,3,"How to gain Knowledge2???","Get Focussed"),
                  new Questions(13,3,"How to gain Knowledge3???","Get Focussed"),
                   new Questions(14,3,"How to gain Knowledge4???","Get Focussed"),
                  new Questions(15,3,"How to gain Knowledge5???","Get Focussed"),
                  new Questions(31,3,"How to gain Knowledge6???","Get Focussed"),
                 new Questions(32,3,"How to gain Knowledge7???","Get Focussed"),
                  new Questions(33,3,"How to gain Knowledge8???","Get Focussed"),
                   new Questions(34,3,"How to gain Knowledge9???","Get Focussed"),
                  new Questions(35,3,"How to gain Knowledge10???","Get Focussed"),

                   new Questions(16,4,"How to get good marks1???","Get Focussed"),
                 new Questions(17,4,"How to get good marks2???","Get Focussed"),
                  new Questions(18,4,"How to get good marks3???","Get Focussed"),
                   new Questions(19,4,"How to get good marks4???","Get Focussed"),
                  new Questions(20,4,"How to get good marks5???","Get Focussed"),
                  new Questions(36,4,"How to get good marks6???","Get Focussed"),
                 new Questions(37,4,"How to get good marks7???","Get Focussed"),
                  new Questions(38,4,"How to get good marks8???","Get Focussed"),
                   new Questions(39,4,"How to get good marks9???","Get Focussed"),
                  new Questions(40,4,"How to get good marks10???","Get Focussed")
            };
        }
        /// <summary>
        /// to fetch the view count details
        /// </summary>
        /// <param name="creditTransfer"></param>
        /// <returns></returns>
        [HttpGet("GetViewCountStatistics")]
        public async Task<IActionResult> GetViewCountStatistics([FromQuery] CreditTransferParam creditTransfer)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetViewCountStatistics Method");
                var credits = await this.creditTransferServices.GetViewCountStatistics(creditTransfer);
                this.Logger.LogInformation("Exiting from GetViewCountStatistics  Method");
                return Success("GetViewCountStatistics Details", credits);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetViewCountStatistics Method" + Ex);
                return Error("Failed to GetViewCountStatistics Details ");
            }
        }
        /// <summary>
        /// to fetch the list of credit based on filter
        /// </summary>
        /// <param name="creditTransfer"></param>
        /// <returns></returns>
        // Report 2 DataTable
        [HttpGet("GetCreditListingStatistics")]
        public async Task<IActionResult> GetCreditListingStatistics([FromQuery] CreditTransferParam creditTransfer)
        {
            try
            {
                this.Logger.LogInformation("Entering into GetCreditListingStatistics Method");
                var credit = await this.creditTransferServices.GetCreditListingStatistics(creditTransfer);
                this.Logger.LogInformation("Exiting from GetCreditListingStatistics  Method");
                return Success("GetCreditListingStatistics Details", credit);
            }
            catch (Exception Ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Error Occured in GetCreditListingStatistics Method" + Ex);
                return Error("Failed to  GetCreditListingStatistics Details ");
            }
        }
        /// <summary>
        /// to fetch the credit count details for report based on filters
        /// </summary>
        /// <returns></returns>

        [HttpGet("GetCreditReportCountDetails")]
        public async Task<IActionResult> GetCreditReportCountDetails()
        {
            try
            {
                this.Logger.LogInformation("Entering into GetCreditReportCountDetails Method");
                var count = await this.creditTransferServices.GetCreditReportCountDetails();

                this.Logger.LogInformation("Exiting from GetCreditReportCountDetails Method");
                return Success("GetCreditReportCountDetails successfully", count);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "ERROR Occured in GetCreditReportCountDetails  method " + ex);
                return Error("Failed to GetCreditReportCountDetails");
            }
        }
        /// <summary>
        /// to update  the totall views 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="viewDetails"></param>
        /// <returns></returns>
        [HttpPut("update/{id}")]
        public async Task<IActionResult> Put(long id, [FromBody] CreditTransferDto viewDetails)
        {
            try
            {
                if (id == 0)
                {
                    return BadRequest("Invalid Data");
                }
                viewDetails.Id = id;
                await this.creditTransferServices.UpdateTotalViews(viewDetails);
                var status = new { Id = viewDetails.Id };
                return Success("TotalViews Updated Successfully", status);
            }
            catch (Exception ex)
            {
                this.Logger.LogError(new Exception("Error Occured"), "Failed to Update the Data" + ex);
                return Error("Failed to Update TotalViews");
            }
        }

    }
}